(()=>{var Ze=(s,t)=>{try{return s()}catch{return t}},Sd=s=>new Promise(t=>setTimeout(t,s)),Vc="voxelisles.save",be=null,tn=!1,Gc=!1,Wc=!1,Sr=!1,Xc=0,Is={async init(){be=window.ytgame||null,tn=!!(be&&be.IN_PLAYABLES_ENV)},get sdkReady(){return tn},loadingStart(){},firstFrame(){Gc||(Gc=!0,Ze(()=>be&&be.game.firstFrameReady()))},gameReady(){Wc||(Wc=!0,Ze(()=>be&&be.game.gameReady()))},gameplayStart(){},gameplayStop(){},happytime(){},async getLanguage(){let s=tn?await Ze(()=>be.system.getLanguage(),Promise.resolve("en")).catch(()=>"en"):navigator.language||"en";return String(s||"en").toLowerCase().slice(0,2)},isAudioEnabled(){return tn?Ze(()=>be.system.isAudioEnabled(),!0):!0},onAudioEnabledChange(s){tn&&Ze(()=>be.system.onAudioEnabledChange(s))},onPause(s){tn&&Ze(()=>be.system.onPause(s)),document.addEventListener("visibilitychange",()=>document.hidden&&s())},onResume(s){tn&&Ze(()=>be.system.onResume(s)),document.addEventListener("visibilitychange",()=>!document.hidden&&s())},async loadData(){return tn?Ze(()=>be.game.loadData(),Promise.resolve("")).catch(()=>(Is.logWarning(),"")):Ze(()=>localStorage.getItem(Vc)||"","")},async saveData(s){if(tn)return Ze(()=>be.game.saveData(s),Promise.resolve()).catch(()=>Is.logWarning());Ze(()=>localStorage.setItem(Vc,s))},sendScore(s){tn&&Ze(()=>be.engagement.sendScore({value:Math.floor(s)}).catch(()=>{}))},logError(){tn&&Ze(()=>be.health.logError())},logWarning(){tn&&Ze(()=>be.health.logWarning())},ads:{has(s){return tn&&!!be&&!!be.ads&&typeof be.ads[s]=="function"},canReward(){return this.has("requestRewardedAd")&&!Sr&&performance.now()>Xc},async request(s,t){if(!this.has(s)||Sr)return!1;Sr=!0;let e=!1;try{let n=await Promise.race([be.ads[s](t),Sd(12e4).then(()=>{throw new Error("ad timeout")})]);e=s==="requestRewardedAd"?n===!0||!!(n&&(n.rewarded||n.earned)):!0}catch{e=!1}return Sr=!1,!e&&s==="requestRewardedAd"&&(Xc=performance.now()+12e4),e},midgame(){return this.request("requestInterstitialAd").then(()=>{})},rewarded(){return this.request("requestRewardedAd","double_coins")}}};addEventListener("error",()=>Is.logError());addEventListener("unhandledrejection",()=>Is.logError());var Se=Is;var _e=[{id:"red",name:"Red",hex:"#e2453c",wool:30},{id:"blue",name:"Blue",hex:"#3c6ee2",wool:31},{id:"green",name:"Green",hex:"#4fbf3a",wool:32},{id:"yellow",name:"Yellow",hex:"#f2cc2e",wool:33},{id:"purple",name:"Purple",hex:"#9b4fd8",wool:34},{id:"orange",name:"Orange",hex:"#f08a2a",wool:35},{id:"cyan",name:"Cyan",hex:"#2fc3c9",wool:36},{id:"pink",name:"Pink",hex:"#ef7fb8",wool:37}],wr=[],Gt=(s,t,e,n={})=>{let i=typeof e=="string"?{top:e,side:e,bottom:e}:e;wr[s]={id:s,name:t,tex:i,solid:n.solid!==!1,transparent:!!n.transparent,cross:!!n.cross,hardness:n.hardness??1,tool:n.tool||"pick",unbreakable:!!n.unbreakable,light:n.light||0,sound:n.sound||"stone",color:n.color||"#888",invisible:!!n.invisible}};Gt(1,"Grass",{top:"grass_top",side:"grass_side",bottom:"dirt"},{hardness:.6,tool:"shovel",sound:"grass",color:"#5fa83a"});Gt(2,"Dirt","dirt",{hardness:.5,tool:"shovel",sound:"gravel",color:"#8a5a36"});Gt(3,"Stone","stone",{hardness:1.5,sound:"stone",color:"#8c8c8c"});Gt(4,"Cobblestone","cobble",{hardness:2,sound:"stone",color:"#7a7a7a"});Gt(5,"Planks","planks",{hardness:1.2,tool:"axe",sound:"wood",color:"#b4874c"});Gt(6,"Log",{top:"log_top",side:"log_side",bottom:"log_top"},{hardness:1.6,tool:"axe",sound:"wood",color:"#6b4a2b"});Gt(7,"Leaves","leaves",{hardness:.2,transparent:!0,tool:"none",sound:"grass",color:"#3f8f2a"});Gt(8,"Sand","sand",{hardness:.5,tool:"shovel",sound:"sand",color:"#e3d394"});Gt(9,"Sandstone",{top:"sandstone_top",side:"sandstone_side",bottom:"sandstone_top"},{hardness:.9,sound:"stone",color:"#d8c47e"});Gt(10,"Snow",{top:"snow",side:"snow_side",bottom:"dirt"},{hardness:.4,tool:"shovel",sound:"snow",color:"#f2f6fa"});Gt(11,"Ice","ice",{hardness:.5,transparent:!0,sound:"glass",color:"#a9d4f5"});Gt(12,"Glass","glass",{hardness:.3,transparent:!0,tool:"none",sound:"glass",color:"#cfe8f2"});Gt(13,"Obsidian","obsidian",{hardness:12,sound:"stone",color:"#231a33"});Gt(14,"Gold Block","gold_block",{hardness:3,sound:"metal",color:"#f5cf3d"});Gt(15,"Iron Block","iron_block",{hardness:3,sound:"metal",color:"#d8d8d8"});Gt(16,"Diamond Block","diamond_block",{hardness:3,sound:"metal",color:"#5fe0d8"});Gt(17,"Chest",{top:"chest_top",side:"chest_side",bottom:"chest_top"},{hardness:1.5,tool:"axe",sound:"wood",unbreakable:!0,color:"#9a6a32"});Gt(18,"Basalt",{top:"basalt_top",side:"basalt_side",bottom:"basalt_top"},{hardness:1.4,sound:"stone",color:"#3e3c42"});Gt(19,"Magma","magma",{hardness:1,sound:"stone",light:1,color:"#c8501e"});Gt(20,"Moonstone","moonstone",{hardness:2,sound:"stone",color:"#efe9b8"});Gt(21,"Bricks","bricks",{hardness:2,sound:"stone",color:"#a1503a"});Gt(22,"Terracotta","terracotta",{hardness:1.3,sound:"stone",color:"#b06a48"});Gt(23,"Core","core",{unbreakable:!0,sound:"stone",color:"#2a2a30"});Gt(24,"Iron Ore","iron_ore",{unbreakable:!0,sound:"stone",color:"#9a8a80"});Gt(25,"Gold Ore","gold_ore",{unbreakable:!0,sound:"stone",color:"#a69a60"});Gt(26,"Diamond Ore","diamond_ore",{unbreakable:!0,sound:"stone",color:"#7fa6a8"});Gt(27,"Lantern","lantern",{hardness:.5,sound:"metal",light:1,color:"#ffd27a"});Gt(28,"Mossy Stone","mossy",{hardness:1.5,sound:"stone",color:"#6f8a5a"});Gt(29,"Pumpkin",{top:"pumpkin_top",side:"pumpkin_side",bottom:"pumpkin_top"},{hardness:1,tool:"axe",sound:"wood",color:"#e08a1e"});for(let s of _e)Gt(s.wool,`${s.name} Wool`,`wool_${s.id}`,{hardness:.35,tool:"shears",sound:"cloth",color:s.hex});Gt(38,"White Wool","wool_white",{hardness:.35,tool:"shears",sound:"cloth",color:"#eeeeee"});Gt(40,"Tall Grass","tallgrass",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#6bbf3a"});Gt(41,"Red Flower","flower_red",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#e23c3c"});Gt(42,"Yellow Flower","flower_yellow",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#f2d22e"});Gt(43,"Dead Bush","deadbush",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#8a6a3a"});Gt(44,"Cactus",{top:"cactus_top",side:"cactus_side",bottom:"cactus_top"},{hardness:.4,tool:"none",sound:"cloth",color:"#4f8a2a"});Gt(45,"Egg","core",{invisible:!0,transparent:!0,hardness:1.2,tool:"none",sound:"egg",color:"#c86ae0"});Gt(46,"Barrier","glass",{invisible:!0,transparent:!0,unbreakable:!0,sound:"glass",color:"#ffffff"});var Zt=wr;var ce=s=>s!==0&&wr[s]&&wr[s].solid;var Dt=16,Ln=16;function wd(s){let t=s>>>0||1;return()=>(t^=t<<13,t^=t>>>17,t^=t<<5,(t>>>0)%1e5/1e5)}var Ed=s=>{let t=2166136261;for(let e=0;e<s.length;e++)t^=s.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0},Z=s=>[parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16)],He=(s,t)=>s.map(e=>Math.max(0,Math.min(255,Math.round(e*t)))),Td=(s,t,e)=>s.map((n,i)=>Math.round(n+(t[i]-n)*e)),Ka=class{constructor(t){this.px=new Uint8ClampedArray(Dt*Dt*4),this.r=wd(Ed(t))}set(t,e,n,i=255){if(t<0||e<0||t>=Dt||e>=Dt)return;let r=(e*Dt+t)*4;this.px[r]=n[0],this.px[r+1]=n[1],this.px[r+2]=n[2],this.px[r+3]=i}get(t,e){let n=(e*Dt+t)*4;return[this.px[n],this.px[n+1],this.px[n+2],this.px[n+3]]}noise(t,e=.12,n=255){for(let i=0;i<Dt;i++)for(let r=0;r<Dt;r++)this.set(r,i,He(t,1-e+this.r()*e*2),n);return this}palette(t,e=255){for(let n=0;n<Dt;n++)for(let i=0;i<Dt;i++)this.set(i,n,t[Math.floor(this.r()*t.length)],e);return this}specks(t,e){for(let n=0;n<e;n++)this.set(Math.floor(this.r()*Dt),Math.floor(this.r()*Dt),He(t,.85+this.r()*.3));return this}blobs(t,e,n=2){for(let i=0;i<e;i++){let r=Math.floor(this.r()*Dt),o=Math.floor(this.r()*Dt);for(let a=0;a<n;a++)for(let l=0;l<n;l++)this.r()>.25&&this.set((r+l)%Dt,(o+a)%Dt,He(t,.9+this.r()*.2))}return this}rect(t,e,n,i,r){for(let o=e;o<e+i;o++)for(let a=t;a<t+n;a++)this.set(a,o,r);return this}border(t){for(let e=0;e<Dt;e++)this.set(e,0,t),this.set(e,Dt-1,t),this.set(0,e,t),this.set(Dt-1,e,t);return this}clear(){return this.px.fill(0),this}},un={grass:["#5fa83a","#6bb842","#559c33","#78c04a","#4f9030"].map(Z),dirt:["#8a5a36","#7a4e2e","#94643c","#6e4428","#9c6c44"].map(Z),stone:["#8c8c8c","#7f7f7f","#999999","#858585","#a3a3a3"].map(Z),sand:["#e3d394","#dccb88","#ead9a0","#d6c47e"].map(Z),snow:["#f2f6fa","#e8eef5","#ffffff","#dfe8f0"].map(Z)},Et={};Et.dirt=s=>s.palette(un.dirt).specks(Z("#5c3a20"),10);Et.grass_top=s=>s.palette(un.grass).specks(Z("#8ad05a"),14).specks(Z("#447f28"),10);Et.grass_side=s=>{Et.dirt(s);for(let t=0;t<Dt;t++){let e=3+Math.floor(s.r()*3);for(let n=0;n<e;n++)s.set(t,n,un.grass[Math.floor(s.r()*un.grass.length)])}return s};Et.stone=s=>s.palette(un.stone).blobs(Z("#727272"),7,3).specks(Z("#b0b0b0"),8);Et.cobble=s=>{s.noise(Z("#7a7a7a"),.1);for(let t=0;t<9;t++){let e=Math.floor(s.r()*13),n=Math.floor(s.r()*13),i=3+Math.floor(s.r()*3);s.rect(e,n,i,i-1,He(Z("#9a9a9a"),.9+s.r()*.25))}for(let t=0;t<26;t++)s.set(Math.floor(s.r()*16),Math.floor(s.r()*16),Z("#555555"));return s};Et.planks=s=>{s.noise(Z("#b4874c"),.08);for(let t=0;t<Dt;t+=4){for(let n=0;n<Dt;n++)s.set(n,t,Z("#7d5a2e"));let e=t/4%2?4:12;s.set(e,t+1,Z("#7d5a2e")),s.set(e,t+2,Z("#7d5a2e")),s.set(e,t+3,Z("#7d5a2e"))}return s.specks(Z("#9c7340"),12)};Et.log_side=s=>{for(let t=0;t<Dt;t++){let e=He(Z("#6b4a2b"),t%4===0?.75:.95+s.r()*.15);for(let n=0;n<Dt;n++)s.set(t,n,He(e,.94+s.r()*.1))}return s};Et.log_top=s=>{s.noise(Z("#b08a54"),.06);for(let t=0;t<8;t++){let e=t%2?Z("#9a7444"):Z("#c09a62");for(let n=0;n<64;n++){let i=Math.round(7.5+Math.cos(n/10.2)*t),r=Math.round(7.5+Math.sin(n/10.2)*t);s.set(i,r,e)}}return s.border(Z("#6b4a2b"))};Et.leaves=s=>{for(let t=0;t<Dt;t++)for(let e=0;e<Dt;e++){let n=s.r();n<.16?s.set(e,t,[0,0,0],0):s.set(e,t,He(Z("#3f8f2a"),.7+n*.5))}return s};Et.sand=s=>s.palette(un.sand).specks(Z("#c2b070"),10);Et.sandstone_side=s=>{s.palette(un.sand);for(let t of[0,5,11])for(let e=0;e<Dt;e++)s.set(e,t,Z("#c7b46e"));return s.specks(Z("#cbb878"),8)};Et.sandstone_top=s=>s.palette(un.sand).border(Z("#cbb878"));Et.snow=s=>s.palette(un.snow).specks(Z("#d0dce8"),6);Et.snow_side=s=>{Et.dirt(s);for(let t=0;t<Dt;t++){let e=3+Math.floor(s.r()*3);for(let n=0;n<e;n++)s.set(t,n,un.snow[Math.floor(s.r()*un.snow.length)])}return s};Et.ice=s=>{s.noise(Z("#a9d4f5"),.06,200);for(let t=0;t<4;t++){let e=Math.floor(s.r()*12);for(let n=0;n<5;n++)s.set(e+n,3+t*3+n%2,Z("#e6f4ff"),220)}return s};Et.glass=s=>(s.clear(),s.border(Z("#cfe8f2")),s.set(3,3,Z("#ffffff")),s.set(4,4,Z("#ffffff")),s.set(4,3,Z("#ffffff")),s.set(10,9,Z("#e8f6ff")),s.set(11,10,Z("#e8f6ff")),s);Et.obsidian=s=>s.noise(Z("#231a33"),.15).blobs(Z("#3a2a55"),6,2).specks(Z("#5a3a8a"),6);var ja=(s,t,e)=>n=>(n.noise(Z(s),.05),n.rect(1,1,14,1,Z(t)),n.rect(1,1,1,14,Z(t)),n.rect(1,14,14,1,Z(e)),n.rect(14,1,1,14,Z(e)),n.border(Z(e)),n.specks(Z(t),6));Et.gold_block=ja("#f5cf3d","#fff3a0","#c89a1a");Et.iron_block=ja("#d8d8d8","#ffffff","#a8a8a8");Et.diamond_block=ja("#5fe0d8","#c8fffb","#2aa8a0");Et.chest_side=s=>{s.noise(Z("#9a6a32"),.08);for(let t=0;t<Dt;t+=5)for(let e=0;e<Dt;e++)s.set(e,t,Z("#5e3e18"));return s.border(Z("#4a3010")),s.rect(7,5,2,4,Z("#d8d8d8")),s.set(7,8,Z("#7a7a7a")),s};Et.chest_top=s=>{s.noise(Z("#a8743a"),.08),s.border(Z("#4a3010"));for(let t=1;t<15;t++)s.set(t,7,Z("#6e4a20"));return s};Et.basalt_side=s=>{for(let t=0;t<Dt;t++){let e=t%3===0?.7:.95+s.r()*.15;for(let n=0;n<Dt;n++)s.set(t,n,He(Z("#3e3c42"),e*(.92+s.r()*.12)))}return s};Et.basalt_top=s=>s.noise(Z("#4a474e"),.12).blobs(Z("#2e2c32"),5,3);Et.magma=s=>{s.noise(Z("#7a2a12"),.15);for(let t=0;t<6;t++){let e=Math.floor(s.r()*16),n=Math.floor(s.r()*16);for(let i=0;i<7;i++)s.set(e,n,i%2?Z("#ffb040"):Z("#ff7a1e")),e+=Math.round(s.r()*2-1),n+=1}return s};Et.moonstone=s=>s.palette(["#efe9b8","#e6dfa8","#f5f0c8","#ddd59a"].map(Z)).blobs(Z("#cfc68a"),6,2);Et.bricks=s=>{s.noise(Z("#a1503a"),.1);for(let t=0;t<Dt;t+=4){for(let n=0;n<Dt;n++)s.set(n,t,Z("#c8bba8"));let e=t/4%2?0:8;for(let n=1;n<4;n++)s.set(e,t+n,Z("#c8bba8")),s.set((e+8)%16,t+n,Z("#c8bba8"))}return s};Et.terracotta=s=>s.noise(Z("#b06a48"),.07).specks(Z("#9a5a3a"),10);Et.core=s=>s.noise(Z("#2a2a30"),.25).specks(Z("#4a4a55"),14).specks(Z("#111114"),10);var Qa=s=>t=>{Et.stone(t);for(let e=0;e<6;e++){let n=1+Math.floor(t.r()*13),i=1+Math.floor(t.r()*13);t.set(n,i,Z(s)),t.set(n+1,i,He(Z(s),.8)),t.set(n,i+1,He(Z(s),1.15))}return t};Et.iron_ore=Qa("#e0b090");Et.gold_ore=Qa("#f5d53d");Et.diamond_ore=Qa("#5fe8e0");Et.lantern=s=>(s.noise(Z("#3a3a3a"),.1),s.rect(3,3,10,10,Z("#ffd27a")),s.rect(5,5,6,6,Z("#fff2c0")),s.border(Z("#2a2a2a")));Et.mossy=s=>(Et.cobble(s),s.blobs(Z("#4f7a3a"),9,2));Et.pumpkin_side=s=>{for(let t=0;t<Dt;t++){let e=t%4===0?.8:1;for(let n=0;n<Dt;n++)s.set(t,n,He(Z("#e08a1e"),e*(.92+s.r()*.12)))}return s};Et.pumpkin_top=s=>(s.noise(Z("#d07a18"),.1),s.rect(7,7,2,2,Z("#5a7a2a")),s);var qc=s=>t=>{t.noise(Z(s),.07);for(let e=0;e<18;e++){let n=Math.floor(t.r()*15),i=Math.floor(t.r()*16);t.set(n,i,He(Z(s),.85)),t.set(n+1,i,He(Z(s),1.1))}return t};for(let s of _e)Et[`wool_${s.id}`]=qc(s.hex);Et.wool_white=qc("#eeeeee");var tl=s=>t=>(t.clear(),s(t),t);Et.tallgrass=tl(s=>{for(let t=0;t<9;t++){let e=1+Math.floor(s.r()*14),n=5+Math.floor(s.r()*9);for(let i=0;i<n;i++)s.set(e+(i>n-3?t%2?1:-1:0),15-i,He(Z("#6bbf3a"),.7+s.r()*.5))}});var $c=s=>tl(t=>{for(let e=6;e<16;e++)t.set(7,e,Z("#3f8f2a"));t.set(6,11,Z("#3f8f2a")),t.set(5,10,Z("#3f8f2a")),t.set(8,12,Z("#3f8f2a")),t.set(9,11,Z("#3f8f2a"));for(let[e,n]of[[0,-1],[-1,0],[1,0],[0,1],[-1,-1],[1,1],[1,-1],[-1,1]])t.set(7+e,4+n,He(Z(s),.85+t.r()*.3));t.set(7,4,Z("#f5e050"))});Et.flower_red=$c("#e23c3c");Et.flower_yellow=$c("#f2d22e");Et.deadbush=tl(s=>{let t=Z("#8a6a3a");for(let e=8;e<16;e++)s.set(7,e,t);for(let e=0;e<4;e++)s.set(7-e,8-e,t),s.set(8+e,9-e,t),s.set(6-e,12-e,t),s.set(9+e,12-e,t)});Et.cactus_side=s=>{s.noise(Z("#4f8a2a"),.08);for(let t=0;t<Dt;t++)s.set(1,t,Z("#3a6a1e")),s.set(14,t,Z("#3a6a1e"));for(let t=0;t<6;t++)s.set(2+Math.floor(s.r()*12),Math.floor(s.r()*16),Z("#e8e0a0"));return s};Et.cactus_top=s=>s.noise(Z("#5a9a32"),.08).border(Z("#3a6a1e"));Et.crack0=s=>Er(s,3);Et.crack1=s=>Er(s,6);Et.crack2=s=>Er(s,10);Et.crack3=s=>Er(s,15);function Er(s,t){s.clear();for(let e=0;e<t;e++){let n=8,i=8,r=s.r()*Math.PI*2;for(let o=0;o<8;o++)s.set(Math.round(n),Math.round(i),[20,20,20],170),n+=Math.cos(r),i+=Math.sin(r),r+=(s.r()-.5)*1.2}return s}function Yc(s={}){let t=[...Object.keys(Et),...Object.keys(s)],e=Math.ceil(t.length/Ln),n=Dt*Ln,i=Dt*Math.max(Ln,e),r=new Uint8ClampedArray(n*i*4),o={};return t.forEach((a,l)=>{let c=new Ka(a);(Et[a]||s[a])(c,{hex:Z,shade:He,mix:Td});let h=l%Ln*Dt,u=Math.floor(l/Ln)*Dt;for(let f=0;f<Dt;f++)for(let d=0;d<Dt;d++){let g=(f*Dt+d)*4,x=((u+f)*n+h+d)*4;r[x]=c.px[g],r[x+1]=c.px[g+1],r[x+2]=c.px[g+2],r[x+3]=c.px[g+3]}o[a]=l}),{data:r,width:n,height:i,index:o,uv:a=>{let l=o[a]??0;return[l%Ln/Ln,Math.floor(l/Ln)/(i/Dt),1/Ln,1/(i/Dt)]}}}var bh=0,Ul=1,Sh=2;var Nl=1,wh=2,Rn=3,Bn=0,Be=1,hn=2,Gn=0,vi=1,Fl=2,kl=3,Ol=4,Eh=5,ii=100,Th=101,Ah=102,Ch=103,Rh=104,Ih=200,Ph=201,Lh=202,Dh=203,eo=204,no=205,Uh=206,Nh=207,Fh=208,kh=209,Oh=210,Bh=211,zh=212,Hh=213,Vh=214,Io=0,Po=1,Lo=2,yi=3,Do=4,Uo=5,No=6,Fo=7,ko=0,Gh=1,Wh=2,Wn=0,Xh=1,qh=2,$h=3,Yh=4,Zh=5,Jh=6,Kh=7;var Bl=300,Ii=301,Pi=302,Oo=303,Bo=304,cr=306,io=1e3,ei=1001,so=1002,Te=1003,jh=1004;var hr=1005;var gn=1006,zo=1007;var oi=1008;var vn=1009,zl=1010,Hl=1011,ds=1012,Ho=1013,ai=1014,yn=1015,fs=1016,Vo=1017,Go=1018,ps=1020,Vl=35902,Gl=35899,Wl=1021,Xl=1022,Ke=1023,is=1026,ms=1027,Wo=1028,Xo=1029,ql=1030,qo=1031;var $o=1033,ur=33776,dr=33777,fr=33778,pr=33779,Yo=35840,Zo=35841,Jo=35842,Ko=35843,jo=36196,Qo=37492,ta=37496,ea=37808,na=37809,ia=37810,sa=37811,ra=37812,oa=37813,aa=37814,la=37815,ca=37816,ha=37817,ua=37818,da=37819,fa=37820,pa=37821,ma=36492,ga=36494,xa=36495,_a=36283,va=36284,ya=36285,Ma=36286;var Hs=2300,ro=2301,Qr=2302,Al=2400,Cl=2401,Rl=2402;var Qh=3200,tu=3201;var $l=0,eu=1,Xn="",Re="srgb",Mi="srgb-linear",Vs="linear",ne="srgb";var _i=7680;var Il=519,nu=512,iu=513,su=514,Yl=515,ru=516,ou=517,au=518,lu=519,oo=35044,Zl=35048;var Jl="300 es",mn=2e3,Gs=2001;var zn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){let n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){let n=this._listeners;if(n===void 0)return;let i=n[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){let e=this._listeners;if(e===void 0)return;let n=e[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,o=i.length;r<o;r++)i[r].call(this,t);t.target=null}}},Ve=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var to=Math.PI/180,ao=180/Math.PI;function ni(){let s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ve[s&255]+Ve[s>>8&255]+Ve[s>>16&255]+Ve[s>>24&255]+"-"+Ve[t&255]+Ve[t>>8&255]+"-"+Ve[t>>16&15|64]+Ve[t>>24&255]+"-"+Ve[e&63|128]+Ve[e>>8&255]+"-"+Ve[e>>16&255]+Ve[e>>24&255]+Ve[n&255]+Ve[n>>8&255]+Ve[n>>16&255]+Ve[n>>24&255]).toLowerCase()}function Xt(s,t,e){return Math.max(t,Math.min(e,s))}function Ad(s,t){return(s%t+t)%t}function el(s,t,e){return(1-e)*s+e*t}function wn(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function re(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}var Nt=class s{constructor(t=0,e=0){s.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Xt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*i+t.x,this.y=r*i+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},sn=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,o,a){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3],f=r[o+0],d=r[o+1],g=r[o+2],x=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(a===1){t[e+0]=f,t[e+1]=d,t[e+2]=g,t[e+3]=x;return}if(u!==x||l!==f||c!==d||h!==g){let m=1-a,p=l*f+c*d+h*g+u*x,S=p>=0?1:-1,y=1-p*p;if(y>Number.EPSILON){let T=Math.sqrt(y),E=Math.atan2(T,p*S);m=Math.sin(m*E)/T,a=Math.sin(a*E)/T}let v=a*S;if(l=l*m+f*v,c=c*m+d*v,h=h*m+g*v,u=u*m+x*v,m===1-a){let T=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=T,c*=T,h*=T,u*=T}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,o){let a=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=r[o],f=r[o+1],d=r[o+2],g=r[o+3];return t[e]=a*g+h*u+l*d-c*f,t[e+1]=l*g+h*f+c*u-a*d,t[e+2]=c*g+h*d+a*f-l*u,t[e+3]=h*g-a*u-l*f-c*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(i/2),u=a(r/2),f=l(n/2),d=l(i/2),g=l(r/2);switch(o){case"XYZ":this._x=f*h*u+c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u-f*d*g;break;case"YXZ":this._x=f*h*u+c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u+f*d*g;break;case"ZXY":this._x=f*h*u-c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u-f*d*g;break;case"ZYX":this._x=f*h*u-c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u+f*d*g;break;case"YZX":this._x=f*h*u+c*d*g,this._y=c*d*u+f*h*g,this._z=c*h*g-f*d*u,this._w=c*h*u-f*d*g;break;case"XZY":this._x=f*h*u-c*d*g,this._y=c*d*u-f*h*g,this._z=c*h*g+f*d*u,this._w=c*h*u+f*d*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],u=e[10],f=n+a+u;if(f>0){let d=.5/Math.sqrt(f+1);this._w=.25/d,this._x=(h-l)*d,this._y=(r-c)*d,this._z=(o-i)*d}else if(n>a&&n>u){let d=2*Math.sqrt(1+n-a-u);this._w=(h-l)/d,this._x=.25*d,this._y=(i+o)/d,this._z=(r+c)/d}else if(a>u){let d=2*Math.sqrt(1+a-n-u);this._w=(r-c)/d,this._x=(i+o)/d,this._y=.25*d,this._z=(l+h)/d}else{let d=2*Math.sqrt(1+u-n-a);this._w=(o-i)/d,this._x=(r+c)/d,this._y=(l+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Xt(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+o*a+i*c-r*l,this._y=i*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-i*a,this._w=o*h-n*a-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,i=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+i*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=i,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let d=1-e;return this._w=d*o+e*this._w,this._x=d*n+e*this._x,this._y=d*i+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-e)*h)/c,f=Math.sin(e*h)/c;return this._w=o*u+this._w*f,this._x=n*u+this._x*f,this._y=i*u+this._y*f,this._z=r*u+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},D=class s{constructor(t=0,e=0,n=0){s.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Zc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Zc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*i-a*n),h=2*(a*e-r*i),u=2*(r*n-o*e);return this.x=e+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=i+l*u+r*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=i*l-r*a,this.y=r*o-n*l,this.z=n*a-i*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return nl.copy(this).projectOnVector(t),this.sub(nl)}reflect(t){return this.sub(nl.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Xt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},nl=new D,Zc=new sn,Ot=class s{constructor(t,e,n,i,r,o,a,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,l,c)}set(t,e,n,i,r,o,a,l,c){let h=this.elements;return h[0]=t,h[1]=i,h[2]=a,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],f=n[2],d=n[5],g=n[8],x=i[0],m=i[3],p=i[6],S=i[1],y=i[4],v=i[7],T=i[2],E=i[5],C=i[8];return r[0]=o*x+a*S+l*T,r[3]=o*m+a*y+l*E,r[6]=o*p+a*v+l*C,r[1]=c*x+h*S+u*T,r[4]=c*m+h*y+u*E,r[7]=c*p+h*v+u*C,r[2]=f*x+d*S+g*T,r[5]=f*m+d*y+g*E,r[8]=f*p+d*v+g*C,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-n*r*h+n*a*l+i*r*c-i*o*l}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=h*o-a*c,f=a*l-h*r,d=c*r-o*l,g=e*u+n*f+i*d;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/g;return t[0]=u*x,t[1]=(i*c-h*n)*x,t[2]=(a*n-i*o)*x,t[3]=f*x,t[4]=(h*e-i*l)*x,t[5]=(i*r-a*e)*x,t[6]=d*x,t[7]=(n*l-c*e)*x,t[8]=(o*e-n*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-i*c,i*l,-i*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(il.makeScale(t,e)),this}rotate(t){return this.premultiply(il.makeRotation(-t)),this}translate(t,e){return this.premultiply(il.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},il=new Ot;function Kl(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Ws(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function cu(){let s=Ws("canvas");return s.style.display="block",s}var Jc={};function ss(s){s in Jc||(Jc[s]=!0,console.warn(s))}function hu(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}var Kc=new Ot().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),jc=new Ot().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Cd(){let s={enabled:!0,workingColorSpace:Mi,spaces:{},convert:function(i,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===ne&&(i.r=On(i.r),i.g=On(i.g),i.b=On(i.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===ne&&(i.r=ns(i.r),i.g=ns(i.g),i.b=ns(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Xn?Vs:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,o){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return ss("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return ss("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[Mi]:{primaries:t,whitePoint:n,transfer:Vs,toXYZ:Kc,fromXYZ:jc,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Re},outputColorSpaceConfig:{drawingBufferColorSpace:Re}},[Re]:{primaries:t,whitePoint:n,transfer:ne,toXYZ:Kc,fromXYZ:jc,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Re}}}),s}var $t=Cd();function On(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function ns(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}var Bi,lo=class{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{Bi===void 0&&(Bi=Ws("canvas")),Bi.width=t.width,Bi.height=t.height;let i=Bi.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=Bi}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Ws("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let o=0;o<r.length;o++)r[o]=On(r[o]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(On(e[n]/255)*255):e[n]=On(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Rd=0,rs=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Rd++}),this.uuid=ni(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){let e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?r.push(sl(i[o].image)):r.push(sl(i[o]))}else r=sl(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function sl(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?lo.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Id=0,rl=new D,$e=class s extends zn{constructor(t=s.DEFAULT_IMAGE,e=s.DEFAULT_MAPPING,n=ei,i=ei,r=gn,o=oi,a=Ke,l=vn,c=s.DEFAULT_ANISOTROPY,h=Xn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Id++}),this.uuid=ni(),this.name="",this.source=new rs(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Nt(0,0),this.repeat=new Nt(1,1),this.center=new Nt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ot,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(rl).x}get height(){return this.source.getSize(rl).y}get depth(){return this.source.getSize(rl).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Bl)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case io:t.x=t.x-Math.floor(t.x);break;case ei:t.x=t.x<0?0:1;break;case so:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case io:t.y=t.y-Math.floor(t.y);break;case ei:t.y=t.y<0?0:1;break;case so:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};$e.DEFAULT_IMAGE=null;$e.DEFAULT_MAPPING=Bl;$e.DEFAULT_ANISOTROPY=1;var ve=class s{constructor(t=0,e=0,n=0,i=1){s.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*i+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*i+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*i+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*i+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,l=t.elements,c=l[0],h=l[4],u=l[8],f=l[1],d=l[5],g=l[9],x=l[2],m=l[6],p=l[10];if(Math.abs(h-f)<.01&&Math.abs(u-x)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+f)<.1&&Math.abs(u+x)<.1&&Math.abs(g+m)<.1&&Math.abs(c+d+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(c+1)/2,v=(d+1)/2,T=(p+1)/2,E=(h+f)/4,C=(u+x)/4,I=(g+m)/4;return y>v&&y>T?y<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(y),i=E/n,r=C/n):v>T?v<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(v),n=E/i,r=I/i):T<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(T),n=C/r,i=I/r),this.set(n,i,r,e),this}let S=Math.sqrt((m-g)*(m-g)+(u-x)*(u-x)+(f-h)*(f-h));return Math.abs(S)<.001&&(S=1),this.x=(m-g)/S,this.y=(u-x)/S,this.z=(f-h)/S,this.w=Math.acos((c+d+p-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this.w=Xt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this.w=Xt(this.w,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},co=class extends zn{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:gn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new ve(0,0,t,e),this.scissorTest=!1,this.viewport=new ve(0,0,t,e);let i={width:t,height:e,depth:n.depth},r=new $e(i);this.textures=[];let o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){let e={minFilter:gn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isArrayTexture=this.textures[i].image.depth>1;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;let i=Object.assign({},t.textures[e].image);this.textures[e].source=new rs(i)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Tn=class extends co{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},Xs=class extends $e{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Te,this.minFilter=Te,this.wrapR=ei,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var ho=class extends $e{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Te,this.minFilter=Te,this.wrapR=ei,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var An=class{constructor(t=new D(1/0,1/0,1/0),e=new D(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(dn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(dn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=dn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,dn):dn.fromBufferAttribute(r,o),dn.applyMatrix4(t.matrixWorld),this.expandByPoint(dn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Tr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Tr.copy(n.boundingBox)),Tr.applyMatrix4(t.matrixWorld),this.union(Tr)}let i=t.children;for(let r=0,o=i.length;r<o;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,dn),dn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Ps),Ar.subVectors(this.max,Ps),zi.subVectors(t.a,Ps),Hi.subVectors(t.b,Ps),Vi.subVectors(t.c,Ps),Zn.subVectors(Hi,zi),Jn.subVectors(Vi,Hi),pi.subVectors(zi,Vi);let e=[0,-Zn.z,Zn.y,0,-Jn.z,Jn.y,0,-pi.z,pi.y,Zn.z,0,-Zn.x,Jn.z,0,-Jn.x,pi.z,0,-pi.x,-Zn.y,Zn.x,0,-Jn.y,Jn.x,0,-pi.y,pi.x,0];return!ol(e,zi,Hi,Vi,Ar)||(e=[1,0,0,0,1,0,0,0,1],!ol(e,zi,Hi,Vi,Ar))?!1:(Cr.crossVectors(Zn,Jn),e=[Cr.x,Cr.y,Cr.z],ol(e,zi,Hi,Vi,Ar))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,dn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(dn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Dn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Dn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Dn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Dn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Dn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Dn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Dn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Dn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Dn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}},Dn=[new D,new D,new D,new D,new D,new D,new D,new D],dn=new D,Tr=new An,zi=new D,Hi=new D,Vi=new D,Zn=new D,Jn=new D,pi=new D,Ps=new D,Ar=new D,Cr=new D,mi=new D;function ol(s,t,e,n,i){for(let r=0,o=s.length-3;r<=o;r+=3){mi.fromArray(s,r);let a=i.x*Math.abs(mi.x)+i.y*Math.abs(mi.y)+i.z*Math.abs(mi.z),l=t.dot(mi),c=e.dot(mi),h=n.dot(mi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var Pd=new An,Ls=new D,al=new D,Hn=class{constructor(t=new D,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):Pd.setFromPoints(t).getCenter(n);let i=0;for(let r=0,o=t.length;r<o;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ls.subVectors(t,this.center);let e=Ls.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Ls,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(al.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ls.copy(t.center).add(al)),this.expandByPoint(Ls.copy(t.center).sub(al))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}},Un=new D,ll=new D,Rr=new D,Kn=new D,cl=new D,Ir=new D,hl=new D,qs=class{constructor(t=new D,e=new D(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Un)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Un.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Un.copy(this.origin).addScaledVector(this.direction,e),Un.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){ll.copy(t).add(e).multiplyScalar(.5),Rr.copy(e).sub(t).normalize(),Kn.copy(this.origin).sub(ll);let r=t.distanceTo(e)*.5,o=-this.direction.dot(Rr),a=Kn.dot(this.direction),l=-Kn.dot(Rr),c=Kn.lengthSq(),h=Math.abs(1-o*o),u,f,d,g;if(h>0)if(u=o*l-a,f=o*a-l,g=r*h,u>=0)if(f>=-g)if(f<=g){let x=1/h;u*=x,f*=x,d=u*(u+o*f+2*a)+f*(o*u+f+2*l)+c}else f=r,u=Math.max(0,-(o*f+a)),d=-u*u+f*(f+2*l)+c;else f=-r,u=Math.max(0,-(o*f+a)),d=-u*u+f*(f+2*l)+c;else f<=-g?(u=Math.max(0,-(-o*r+a)),f=u>0?-r:Math.min(Math.max(-r,-l),r),d=-u*u+f*(f+2*l)+c):f<=g?(u=0,f=Math.min(Math.max(-r,-l),r),d=f*(f+2*l)+c):(u=Math.max(0,-(o*r+a)),f=u>0?r:Math.min(Math.max(-r,-l),r),d=-u*u+f*(f+2*l)+c);else f=o>0?-r:r,u=Math.max(0,-(o*f+a)),d=-u*u+f*(f+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(ll).addScaledVector(Rr,f),d}intersectSphere(t,e){Un.subVectors(t.center,this.origin);let n=Un.dot(this.direction),i=Un.dot(Un)-n*n,r=t.radius*t.radius;if(i>r)return null;let o=Math.sqrt(r-i),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,f=this.origin;return c>=0?(n=(t.min.x-f.x)*c,i=(t.max.x-f.x)*c):(n=(t.max.x-f.x)*c,i=(t.min.x-f.x)*c),h>=0?(r=(t.min.y-f.y)*h,o=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,o=(t.min.y-f.y)*h),n>o||r>i||((r>n||isNaN(n))&&(n=r),(o<i||isNaN(i))&&(i=o),u>=0?(a=(t.min.z-f.z)*u,l=(t.max.z-f.z)*u):(a=(t.max.z-f.z)*u,l=(t.min.z-f.z)*u),n>l||a>i)||((a>n||n!==n)&&(n=a),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Un)!==null}intersectTriangle(t,e,n,i,r){cl.subVectors(e,t),Ir.subVectors(n,t),hl.crossVectors(cl,Ir);let o=this.direction.dot(hl),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Kn.subVectors(this.origin,t);let l=a*this.direction.dot(Ir.crossVectors(Kn,Ir));if(l<0)return null;let c=a*this.direction.dot(cl.cross(Kn));if(c<0||l+c>o)return null;let h=-a*Kn.dot(hl);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Qt=class s{constructor(t,e,n,i,r,o,a,l,c,h,u,f,d,g,x,m){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,l,c,h,u,f,d,g,x,m)}set(t,e,n,i,r,o,a,l,c,h,u,f,d,g,x,m){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=f,p[3]=d,p[7]=g,p[11]=x,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,i=1/Gi.setFromMatrixColumn(t,0).length(),r=1/Gi.setFromMatrixColumn(t,1).length(),o=1/Gi.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let f=o*h,d=o*u,g=a*h,x=a*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=d+g*c,e[5]=f-x*c,e[9]=-a*l,e[2]=x-f*c,e[6]=g+d*c,e[10]=o*l}else if(t.order==="YXZ"){let f=l*h,d=l*u,g=c*h,x=c*u;e[0]=f+x*a,e[4]=g*a-d,e[8]=o*c,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=d*a-g,e[6]=x+f*a,e[10]=o*l}else if(t.order==="ZXY"){let f=l*h,d=l*u,g=c*h,x=c*u;e[0]=f-x*a,e[4]=-o*u,e[8]=g+d*a,e[1]=d+g*a,e[5]=o*h,e[9]=x-f*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let f=o*h,d=o*u,g=a*h,x=a*u;e[0]=l*h,e[4]=g*c-d,e[8]=f*c+x,e[1]=l*u,e[5]=x*c+f,e[9]=d*c-g,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let f=o*l,d=o*c,g=a*l,x=a*c;e[0]=l*h,e[4]=x-f*u,e[8]=g*u+d,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=d*u+g,e[10]=f-x*u}else if(t.order==="XZY"){let f=o*l,d=o*c,g=a*l,x=a*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=f*u+x,e[5]=o*h,e[9]=d*u-g,e[2]=g*u-d,e[6]=a*h,e[10]=x*u+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Ld,t,Dd)}lookAt(t,e,n){let i=this.elements;return en.subVectors(t,e),en.lengthSq()===0&&(en.z=1),en.normalize(),jn.crossVectors(n,en),jn.lengthSq()===0&&(Math.abs(n.z)===1?en.x+=1e-4:en.z+=1e-4,en.normalize(),jn.crossVectors(n,en)),jn.normalize(),Pr.crossVectors(en,jn),i[0]=jn.x,i[4]=Pr.x,i[8]=en.x,i[1]=jn.y,i[5]=Pr.y,i[9]=en.y,i[2]=jn.z,i[6]=Pr.z,i[10]=en.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],f=n[9],d=n[13],g=n[2],x=n[6],m=n[10],p=n[14],S=n[3],y=n[7],v=n[11],T=n[15],E=i[0],C=i[4],I=i[8],M=i[12],w=i[1],P=i[5],k=i[9],H=i[13],W=i[2],X=i[6],V=i[10],Q=i[14],O=i[3],rt=i[7],lt=i[11],pt=i[15];return r[0]=o*E+a*w+l*W+c*O,r[4]=o*C+a*P+l*X+c*rt,r[8]=o*I+a*k+l*V+c*lt,r[12]=o*M+a*H+l*Q+c*pt,r[1]=h*E+u*w+f*W+d*O,r[5]=h*C+u*P+f*X+d*rt,r[9]=h*I+u*k+f*V+d*lt,r[13]=h*M+u*H+f*Q+d*pt,r[2]=g*E+x*w+m*W+p*O,r[6]=g*C+x*P+m*X+p*rt,r[10]=g*I+x*k+m*V+p*lt,r[14]=g*M+x*H+m*Q+p*pt,r[3]=S*E+y*w+v*W+T*O,r[7]=S*C+y*P+v*X+T*rt,r[11]=S*I+y*k+v*V+T*lt,r[15]=S*M+y*H+v*Q+T*pt,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],u=t[6],f=t[10],d=t[14],g=t[3],x=t[7],m=t[11],p=t[15];return g*(+r*l*u-i*c*u-r*a*f+n*c*f+i*a*d-n*l*d)+x*(+e*l*d-e*c*f+r*o*f-i*o*d+i*c*h-r*l*h)+m*(+e*c*u-e*a*d-r*o*u+n*o*d+r*a*h-n*c*h)+p*(-i*a*h-e*l*u+e*a*f+i*o*u-n*o*f+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],u=t[9],f=t[10],d=t[11],g=t[12],x=t[13],m=t[14],p=t[15],S=u*m*c-x*f*c+x*l*d-a*m*d-u*l*p+a*f*p,y=g*f*c-h*m*c-g*l*d+o*m*d+h*l*p-o*f*p,v=h*x*c-g*u*c+g*a*d-o*x*d-h*a*p+o*u*p,T=g*u*l-h*x*l-g*a*f+o*x*f+h*a*m-o*u*m,E=e*S+n*y+i*v+r*T;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let C=1/E;return t[0]=S*C,t[1]=(x*f*r-u*m*r-x*i*d+n*m*d+u*i*p-n*f*p)*C,t[2]=(a*m*r-x*l*r+x*i*c-n*m*c-a*i*p+n*l*p)*C,t[3]=(u*l*r-a*f*r-u*i*c+n*f*c+a*i*d-n*l*d)*C,t[4]=y*C,t[5]=(h*m*r-g*f*r+g*i*d-e*m*d-h*i*p+e*f*p)*C,t[6]=(g*l*r-o*m*r-g*i*c+e*m*c+o*i*p-e*l*p)*C,t[7]=(o*f*r-h*l*r+h*i*c-e*f*c-o*i*d+e*l*d)*C,t[8]=v*C,t[9]=(g*u*r-h*x*r-g*n*d+e*x*d+h*n*p-e*u*p)*C,t[10]=(o*x*r-g*a*r+g*n*c-e*x*c-o*n*p+e*a*p)*C,t[11]=(h*a*r-o*u*r-h*n*c+e*u*c+o*n*d-e*a*d)*C,t[12]=T*C,t[13]=(h*x*i-g*u*i+g*n*f-e*x*f-h*n*m+e*u*m)*C,t[14]=(g*a*i-o*x*i-g*n*l+e*x*l+o*n*m-e*a*m)*C,t[15]=(o*u*i-h*a*i+h*n*l-e*u*l-o*n*f+e*a*f)*C,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-i*l,c*l+i*a,0,c*a+i*l,h*a+n,h*l-i*o,0,c*l-i*a,h*l+i*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,o){return this.set(1,n,r,0,t,1,o,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,h=o+o,u=a+a,f=r*c,d=r*h,g=r*u,x=o*h,m=o*u,p=a*u,S=l*c,y=l*h,v=l*u,T=n.x,E=n.y,C=n.z;return i[0]=(1-(x+p))*T,i[1]=(d+v)*T,i[2]=(g-y)*T,i[3]=0,i[4]=(d-v)*E,i[5]=(1-(f+p))*E,i[6]=(m+S)*E,i[7]=0,i[8]=(g+y)*C,i[9]=(m-S)*C,i[10]=(1-(f+x))*C,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements,r=Gi.set(i[0],i[1],i[2]).length(),o=Gi.set(i[4],i[5],i[6]).length(),a=Gi.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],fn.copy(this);let c=1/r,h=1/o,u=1/a;return fn.elements[0]*=c,fn.elements[1]*=c,fn.elements[2]*=c,fn.elements[4]*=h,fn.elements[5]*=h,fn.elements[6]*=h,fn.elements[8]*=u,fn.elements[9]*=u,fn.elements[10]*=u,e.setFromRotationMatrix(fn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,i,r,o,a=mn,l=!1){let c=this.elements,h=2*r/(e-t),u=2*r/(n-i),f=(e+t)/(e-t),d=(n+i)/(n-i),g,x;if(l)g=r/(o-r),x=o*r/(o-r);else if(a===mn)g=-(o+r)/(o-r),x=-2*o*r/(o-r);else if(a===Gs)g=-o/(o-r),x=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=f,c[12]=0,c[1]=0,c[5]=u,c[9]=d,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,r,o,a=mn,l=!1){let c=this.elements,h=2/(e-t),u=2/(n-i),f=-(e+t)/(e-t),d=-(n+i)/(n-i),g,x;if(l)g=1/(o-r),x=o/(o-r);else if(a===mn)g=-2/(o-r),x=-(o+r)/(o-r);else if(a===Gs)g=-1/(o-r),x=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=0,c[12]=f,c[1]=0,c[5]=u,c[9]=0,c[13]=d,c[2]=0,c[6]=0,c[10]=g,c[14]=x,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},Gi=new D,fn=new Qt,Ld=new D(0,0,0),Dd=new D(1,1,1),jn=new D,Pr=new D,en=new D,Qc=new Qt,th=new sn,xn=class s{constructor(t=0,e=0,n=0,i=s.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],o=i[4],a=i[8],l=i[1],c=i[5],h=i[9],u=i[2],f=i[6],d=i[10];switch(e){case"XYZ":this._y=Math.asin(Xt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(f,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Xt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,d),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Xt(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-u,d),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Xt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(f,d),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Xt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,d));break;case"XZY":this._z=Math.asin(-Xt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(f,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Qc.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Qc,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return th.setFromEuler(this),this.setFromQuaternion(th,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};xn.DEFAULT_ORDER="XYZ";var $s=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Ud=0,eh=new D,Wi=new sn,Nn=new Qt,Lr=new D,Ds=new D,Nd=new D,Fd=new sn,nh=new D(1,0,0),ih=new D(0,1,0),sh=new D(0,0,1),rh={type:"added"},kd={type:"removed"},Xi={type:"childadded",child:null},ul={type:"childremoved",child:null},Ne=class s extends zn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ud++}),this.uuid=ni(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let t=new D,e=new xn,n=new sn,i=new D(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Qt},normalMatrix:{value:new Ot}}),this.matrix=new Qt,this.matrixWorld=new Qt,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new $s,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Wi.setFromAxisAngle(t,e),this.quaternion.multiply(Wi),this}rotateOnWorldAxis(t,e){return Wi.setFromAxisAngle(t,e),this.quaternion.premultiply(Wi),this}rotateX(t){return this.rotateOnAxis(nh,t)}rotateY(t){return this.rotateOnAxis(ih,t)}rotateZ(t){return this.rotateOnAxis(sh,t)}translateOnAxis(t,e){return eh.copy(t).applyQuaternion(this.quaternion),this.position.add(eh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(nh,t)}translateY(t){return this.translateOnAxis(ih,t)}translateZ(t){return this.translateOnAxis(sh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Nn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Lr.copy(t):Lr.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),Ds.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Nn.lookAt(Ds,Lr,this.up):Nn.lookAt(Lr,Ds,this.up),this.quaternion.setFromRotationMatrix(Nn),i&&(Nn.extractRotation(i.matrixWorld),Wi.setFromRotationMatrix(Nn),this.quaternion.premultiply(Wi.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(rh),Xi.child=t,this.dispatchEvent(Xi),Xi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(kd),ul.child=t,this.dispatchEvent(ul),ul.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Nn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Nn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Nn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(rh),Xi.child=t,this.dispatchEvent(Xi),Xi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ds,t,Nd),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ds,Fd,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(a=>({...a})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));i.material=a}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];i.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),u=o(t.shapes),f=o(t.skeletons),d=o(t.animations),g=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),f.length>0&&(n.skeletons=f),d.length>0&&(n.animations=d),g.length>0&&(n.nodes=g)}return n.object=i,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}};Ne.DEFAULT_UP=new D(0,1,0);Ne.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ne.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var pn=new D,Fn=new D,dl=new D,kn=new D,qi=new D,$i=new D,oh=new D,fl=new D,pl=new D,ml=new D,gl=new ve,xl=new ve,_l=new ve,En=class s{constructor(t=new D,e=new D,n=new D){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),pn.subVectors(t,e),i.cross(pn);let r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){pn.subVectors(i,e),Fn.subVectors(n,e),dl.subVectors(t,e);let o=pn.dot(pn),a=pn.dot(Fn),l=pn.dot(dl),c=Fn.dot(Fn),h=Fn.dot(dl),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let f=1/u,d=(c*l-a*h)*f,g=(o*h-a*l)*f;return r.set(1-d-g,g,d)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,kn)===null?!1:kn.x>=0&&kn.y>=0&&kn.x+kn.y<=1}static getInterpolation(t,e,n,i,r,o,a,l){return this.getBarycoord(t,e,n,i,kn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,kn.x),l.addScaledVector(o,kn.y),l.addScaledVector(a,kn.z),l)}static getInterpolatedAttribute(t,e,n,i,r,o){return gl.setScalar(0),xl.setScalar(0),_l.setScalar(0),gl.fromBufferAttribute(t,e),xl.fromBufferAttribute(t,n),_l.fromBufferAttribute(t,i),o.setScalar(0),o.addScaledVector(gl,r.x),o.addScaledVector(xl,r.y),o.addScaledVector(_l,r.z),o}static isFrontFacing(t,e,n,i){return pn.subVectors(n,e),Fn.subVectors(t,e),pn.cross(Fn).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return pn.subVectors(this.c,this.b),Fn.subVectors(this.a,this.b),pn.cross(Fn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return s.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return s.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return s.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return s.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,i=this.b,r=this.c,o,a;qi.subVectors(i,n),$i.subVectors(r,n),fl.subVectors(t,n);let l=qi.dot(fl),c=$i.dot(fl);if(l<=0&&c<=0)return e.copy(n);pl.subVectors(t,i);let h=qi.dot(pl),u=$i.dot(pl);if(h>=0&&u<=h)return e.copy(i);let f=l*u-h*c;if(f<=0&&l>=0&&h<=0)return o=l/(l-h),e.copy(n).addScaledVector(qi,o);ml.subVectors(t,r);let d=qi.dot(ml),g=$i.dot(ml);if(g>=0&&d<=g)return e.copy(r);let x=d*c-l*g;if(x<=0&&c>=0&&g<=0)return a=c/(c-g),e.copy(n).addScaledVector($i,a);let m=h*g-d*u;if(m<=0&&u-h>=0&&d-g>=0)return oh.subVectors(r,i),a=(u-h)/(u-h+(d-g)),e.copy(i).addScaledVector(oh,a);let p=1/(m+x+f);return o=x*p,a=f*p,e.copy(n).addScaledVector(qi,o).addScaledVector($i,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},uu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Qn={h:0,s:0,l:0},Dr={h:0,s:0,l:0};function vl(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}var Lt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Re){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,$t.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=$t.workingColorSpace){return this.r=t,this.g=e,this.b=n,$t.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=$t.workingColorSpace){if(t=Ad(t,1),e=Xt(e,0,1),n=Xt(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=vl(o,r,t+1/3),this.g=vl(o,r,t),this.b=vl(o,r,t-1/3)}return $t.colorSpaceToWorking(this,i),this}setStyle(t,e=Re){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Re){let n=uu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=On(t.r),this.g=On(t.g),this.b=On(t.b),this}copyLinearToSRGB(t){return this.r=ns(t.r),this.g=ns(t.g),this.b=ns(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Re){return $t.workingToColorSpace(Ge.copy(this),t),Math.round(Xt(Ge.r*255,0,255))*65536+Math.round(Xt(Ge.g*255,0,255))*256+Math.round(Xt(Ge.b*255,0,255))}getHexString(t=Re){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=$t.workingColorSpace){$t.workingToColorSpace(Ge.copy(this),e);let n=Ge.r,i=Ge.g,r=Ge.b,o=Math.max(n,i,r),a=Math.min(n,i,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(i-r)/u+(i<r?6:0);break;case i:l=(r-n)/u+2;break;case r:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=$t.workingColorSpace){return $t.workingToColorSpace(Ge.copy(this),e),t.r=Ge.r,t.g=Ge.g,t.b=Ge.b,t}getStyle(t=Re){$t.workingToColorSpace(Ge.copy(this),t);let e=Ge.r,n=Ge.g,i=Ge.b;return t!==Re?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Qn),this.setHSL(Qn.h+t,Qn.s+e,Qn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Qn),t.getHSL(Dr);let n=el(Qn.h,Dr.h,e),i=el(Qn.s,Dr.s,e),r=el(Qn.l,Dr.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Ge=new Lt;Lt.NAMES=uu;var Od=0,Cn=class extends zn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Od++}),this.uuid=ni(),this.name="",this.type="Material",this.blending=vi,this.side=Bn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=eo,this.blendDst=no,this.blendEquation=ii,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Lt(0,0,0),this.blendAlpha=0,this.depthFunc=yi,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Il,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=_i,this.stencilZFail=_i,this.stencilZPass=_i,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==vi&&(n.blending=this.blending),this.side!==Bn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==eo&&(n.blendSrc=this.blendSrc),this.blendDst!==no&&(n.blendDst=this.blendDst),this.blendEquation!==ii&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==yi&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Il&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==_i&&(n.stencilFail=this.stencilFail),this.stencilZFail!==_i&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==_i&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=i(t.textures),o=i(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Ae=class extends Cn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Lt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=ko,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var we=new D,Ur=new Nt,Bd=0,Ee=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Bd++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=oo,this.updateRanges=[],this.gpuType=yn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Ur.fromBufferAttribute(this,e),Ur.applyMatrix3(t),this.setXY(e,Ur.x,Ur.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)we.fromBufferAttribute(this,e),we.applyMatrix3(t),this.setXYZ(e,we.x,we.y,we.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)we.fromBufferAttribute(this,e),we.applyMatrix4(t),this.setXYZ(e,we.x,we.y,we.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)we.fromBufferAttribute(this,e),we.applyNormalMatrix(t),this.setXYZ(e,we.x,we.y,we.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)we.fromBufferAttribute(this,e),we.transformDirection(t),this.setXYZ(e,we.x,we.y,we.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=wn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=re(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=wn(e,this.array)),e}setX(t,e){return this.normalized&&(e=re(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=wn(e,this.array)),e}setY(t,e){return this.normalized&&(e=re(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=wn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=re(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=wn(e,this.array)),e}setW(t,e){return this.normalized&&(e=re(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=re(e,this.array),n=re(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=re(e,this.array),n=re(n,this.array),i=re(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=re(e,this.array),n=re(n,this.array),i=re(i,this.array),r=re(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==oo&&(t.usage=this.usage),t}};var Ys=class extends Ee{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Zs=class extends Ee{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var he=class extends Ee{constructor(t,e,n){super(new Float32Array(t),e,n)}},zd=0,cn=new Qt,yl=new Ne,Yi=new D,nn=new An,Us=new An,De=new D,ke=class s extends zn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:zd++}),this.uuid=ni(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Kl(t)?Zs:Ys)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Ot().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return cn.makeRotationFromQuaternion(t),this.applyMatrix4(cn),this}rotateX(t){return cn.makeRotationX(t),this.applyMatrix4(cn),this}rotateY(t){return cn.makeRotationY(t),this.applyMatrix4(cn),this}rotateZ(t){return cn.makeRotationZ(t),this.applyMatrix4(cn),this}translate(t,e,n){return cn.makeTranslation(t,e,n),this.applyMatrix4(cn),this}scale(t,e,n){return cn.makeScale(t,e,n),this.applyMatrix4(cn),this}lookAt(t){return yl.lookAt(t),yl.updateMatrix(),this.applyMatrix4(yl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Yi).negate(),this.translate(Yi.x,Yi.y,Yi.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let i=0,r=t.length;i<r;i++){let o=t[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new he(n,3))}else{let n=Math.min(t.length,e.count);for(let i=0;i<n;i++){let r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new An);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new D(-1/0,-1/0,-1/0),new D(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];nn.setFromBufferAttribute(r),this.morphTargetsRelative?(De.addVectors(this.boundingBox.min,nn.min),this.boundingBox.expandByPoint(De),De.addVectors(this.boundingBox.max,nn.max),this.boundingBox.expandByPoint(De)):(this.boundingBox.expandByPoint(nn.min),this.boundingBox.expandByPoint(nn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Hn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new D,1/0);return}if(t){let n=this.boundingSphere.center;if(nn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];Us.setFromBufferAttribute(a),this.morphTargetsRelative?(De.addVectors(nn.min,Us.min),nn.expandByPoint(De),De.addVectors(nn.max,Us.max),nn.expandByPoint(De)):(nn.expandByPoint(Us.min),nn.expandByPoint(Us.max))}nn.getCenter(n);let i=0;for(let r=0,o=t.count;r<o;r++)De.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(De));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)De.fromBufferAttribute(a,c),l&&(Yi.fromBufferAttribute(t,c),De.add(Yi)),i=Math.max(i,n.distanceToSquared(De))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ee(new Float32Array(4*n.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let I=0;I<n.count;I++)a[I]=new D,l[I]=new D;let c=new D,h=new D,u=new D,f=new Nt,d=new Nt,g=new Nt,x=new D,m=new D;function p(I,M,w){c.fromBufferAttribute(n,I),h.fromBufferAttribute(n,M),u.fromBufferAttribute(n,w),f.fromBufferAttribute(r,I),d.fromBufferAttribute(r,M),g.fromBufferAttribute(r,w),h.sub(c),u.sub(c),d.sub(f),g.sub(f);let P=1/(d.x*g.y-g.x*d.y);isFinite(P)&&(x.copy(h).multiplyScalar(g.y).addScaledVector(u,-d.y).multiplyScalar(P),m.copy(u).multiplyScalar(d.x).addScaledVector(h,-g.x).multiplyScalar(P),a[I].add(x),a[M].add(x),a[w].add(x),l[I].add(m),l[M].add(m),l[w].add(m))}let S=this.groups;S.length===0&&(S=[{start:0,count:t.count}]);for(let I=0,M=S.length;I<M;++I){let w=S[I],P=w.start,k=w.count;for(let H=P,W=P+k;H<W;H+=3)p(t.getX(H+0),t.getX(H+1),t.getX(H+2))}let y=new D,v=new D,T=new D,E=new D;function C(I){T.fromBufferAttribute(i,I),E.copy(T);let M=a[I];y.copy(M),y.sub(T.multiplyScalar(T.dot(M))).normalize(),v.crossVectors(E,M);let P=v.dot(l[I])<0?-1:1;o.setXYZW(I,y.x,y.y,y.z,P)}for(let I=0,M=S.length;I<M;++I){let w=S[I],P=w.start,k=w.count;for(let H=P,W=P+k;H<W;H+=3)C(t.getX(H+0)),C(t.getX(H+1)),C(t.getX(H+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Ee(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let f=0,d=n.count;f<d;f++)n.setXYZ(f,0,0,0);let i=new D,r=new D,o=new D,a=new D,l=new D,c=new D,h=new D,u=new D;if(t)for(let f=0,d=t.count;f<d;f+=3){let g=t.getX(f+0),x=t.getX(f+1),m=t.getX(f+2);i.fromBufferAttribute(e,g),r.fromBufferAttribute(e,x),o.fromBufferAttribute(e,m),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let f=0,d=e.count;f<d;f+=3)i.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),o.fromBufferAttribute(e,f+2),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),n.setXYZ(f+0,h.x,h.y,h.z),n.setXYZ(f+1,h.x,h.y,h.z),n.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)De.fromBufferAttribute(t,e),De.normalize(),t.setXYZ(e,De.x,De.y,De.z)}toNonIndexed(){function t(a,l){let c=a.array,h=a.itemSize,u=a.normalized,f=new c.constructor(l.length*h),d=0,g=0;for(let x=0,m=l.length;x<m;x++){a.isInterleavedBufferAttribute?d=l[x]*a.data.stride+a.offset:d=l[x]*h;for(let p=0;p<h;p++)f[g++]=c[d++]}return new Ee(f,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new s,n=this.index.array,i=this.attributes;for(let a in i){let l=i[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let f=c[h],d=t(f,n);l.push(d)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let i={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,f=c.length;u<f;u++){let d=c[u];h.push(d.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone());let i=t.attributes;for(let c in i){let h=i[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let f=0,d=u.length;f<d;f++)h.push(u[f].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},ah=new Qt,gi=new qs,Nr=new Hn,lh=new D,Fr=new D,kr=new D,Or=new D,Ml=new D,Br=new D,ch=new D,zr=new D,ie=class extends Ne{constructor(t=new ke,e=new Ae){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){let a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(i,t);let a=this.morphTargetInfluences;if(r&&a){Br.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(Ml.fromBufferAttribute(u,t),o?Br.addScaledVector(Ml,h):Br.addScaledVector(Ml.sub(e),h))}e.add(Br)}return e}raycast(t,e){let n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Nr.copy(n.boundingSphere),Nr.applyMatrix4(r),gi.copy(t.ray).recast(t.near),!(Nr.containsPoint(gi.origin)===!1&&(gi.intersectSphere(Nr,lh)===null||gi.origin.distanceToSquared(lh)>(t.far-t.near)**2))&&(ah.copy(r).invert(),gi.copy(t.ray).applyMatrix4(ah),!(n.boundingBox!==null&&gi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,gi)))}_computeIntersections(t,e,n){let i,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,f=r.groups,d=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,x=f.length;g<x;g++){let m=f[g],p=o[m.materialIndex],S=Math.max(m.start,d.start),y=Math.min(a.count,Math.min(m.start+m.count,d.start+d.count));for(let v=S,T=y;v<T;v+=3){let E=a.getX(v),C=a.getX(v+1),I=a.getX(v+2);i=Hr(this,p,t,n,c,h,u,E,C,I),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,d.start),x=Math.min(a.count,d.start+d.count);for(let m=g,p=x;m<p;m+=3){let S=a.getX(m),y=a.getX(m+1),v=a.getX(m+2);i=Hr(this,o,t,n,c,h,u,S,y,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,x=f.length;g<x;g++){let m=f[g],p=o[m.materialIndex],S=Math.max(m.start,d.start),y=Math.min(l.count,Math.min(m.start+m.count,d.start+d.count));for(let v=S,T=y;v<T;v+=3){let E=v,C=v+1,I=v+2;i=Hr(this,p,t,n,c,h,u,E,C,I),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{let g=Math.max(0,d.start),x=Math.min(l.count,d.start+d.count);for(let m=g,p=x;m<p;m+=3){let S=m,y=m+1,v=m+2;i=Hr(this,o,t,n,c,h,u,S,y,v),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}};function Hd(s,t,e,n,i,r,o,a){let l;if(t.side===Be?l=n.intersectTriangle(o,r,i,!0,a):l=n.intersectTriangle(i,r,o,t.side===Bn,a),l===null)return null;zr.copy(a),zr.applyMatrix4(s.matrixWorld);let c=e.ray.origin.distanceTo(zr);return c<e.near||c>e.far?null:{distance:c,point:zr.clone(),object:s}}function Hr(s,t,e,n,i,r,o,a,l,c){s.getVertexPosition(a,Fr),s.getVertexPosition(l,kr),s.getVertexPosition(c,Or);let h=Hd(s,t,e,n,Fr,kr,Or,ch);if(h){let u=new D;En.getBarycoord(ch,Fr,kr,Or,u),i&&(h.uv=En.getInterpolatedAttribute(i,a,l,c,u,new Nt)),r&&(h.uv1=En.getInterpolatedAttribute(r,a,l,c,u,new Nt)),o&&(h.normal=En.getInterpolatedAttribute(o,a,l,c,u,new D),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let f={a,b:l,c,normal:new D,materialIndex:0};En.getNormal(Fr,kr,Or,f.normal),h.face=f,h.barycoord=u}return h}var Oe=class s extends ke{constructor(t=1,e=1,n=1,i=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:o};let a=this;i=Math.floor(i),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],f=0,d=0;g("z","y","x",-1,-1,n,e,t,o,r,0),g("z","y","x",1,-1,n,e,-t,o,r,1),g("x","z","y",1,1,t,n,e,i,o,2),g("x","z","y",1,-1,t,n,-e,i,o,3),g("x","y","z",1,-1,t,e,n,i,r,4),g("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new he(c,3)),this.setAttribute("normal",new he(h,3)),this.setAttribute("uv",new he(u,2));function g(x,m,p,S,y,v,T,E,C,I,M){let w=v/C,P=T/I,k=v/2,H=T/2,W=E/2,X=C+1,V=I+1,Q=0,O=0,rt=new D;for(let lt=0;lt<V;lt++){let pt=lt*P-H;for(let zt=0;zt<X;zt++){let ee=zt*w-k;rt[x]=ee*S,rt[m]=pt*y,rt[p]=W,c.push(rt.x,rt.y,rt.z),rt[x]=0,rt[m]=0,rt[p]=E>0?1:-1,h.push(rt.x,rt.y,rt.z),u.push(zt/C),u.push(1-lt/I),Q+=1}}for(let lt=0;lt<I;lt++)for(let pt=0;pt<C;pt++){let zt=f+pt+X*lt,ee=f+pt+X*(lt+1),ae=f+(pt+1)+X*(lt+1),Kt=f+(pt+1)+X*lt;l.push(zt,ee,Kt),l.push(ee,ae,Kt),O+=6}a.addGroup(d,O,M),d+=O,f+=Q}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Li(s){let t={};for(let e in s){t[e]={};for(let n in s[e]){let i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function We(s){let t={};for(let e=0;e<s.length;e++){let n=Li(s[e]);for(let i in n)t[i]=n[i]}return t}function Vd(s){let t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function jl(s){let t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:$t.workingColorSpace}var du={clone:Li,merge:We},Gd=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Wd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,_n=class extends Cn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Gd,this.fragmentShader=Wd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Li(t.uniforms),this.uniformsGroups=Vd(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let i in this.uniforms){let o=this.uniforms[i].value;o&&o.isTexture?e.uniforms[i]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[i]={type:"m4",value:o.toArray()}:e.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},Js=class extends Ne{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Qt,this.projectionMatrix=new Qt,this.projectionMatrixInverse=new Qt,this.coordinateSystem=mn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},ti=new D,hh=new Nt,uh=new Nt,Ue=class extends Js{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=ao*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(to*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return ao*2*Math.atan(Math.tan(to*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){ti.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(ti.x,ti.y).multiplyScalar(-t/ti.z),ti.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ti.x,ti.y).multiplyScalar(-t/ti.z)}getViewSize(t,e){return this.getViewBounds(t,hh,uh),e.subVectors(uh,hh)}setViewOffset(t,e,n,i,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(to*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*i/l,e-=o.offsetY*n/c,i*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Zi=-90,Ji=1,uo=class extends Ne{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Ue(Zi,Ji,t,e);i.layers=this.layers,this.add(i);let r=new Ue(Zi,Ji,t,e);r.layers=this.layers,this.add(r);let o=new Ue(Zi,Ji,t,e);o.layers=this.layers,this.add(o);let a=new Ue(Zi,Ji,t,e);a.layers=this.layers,this.add(a);let l=new Ue(Zi,Ji,t,e);l.layers=this.layers,this.add(l);let c=new Ue(Zi,Ji,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,i,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===mn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===Gs)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=t.getRenderTarget(),f=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;let x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,o),t.setRenderTarget(n,2,i),t.render(e,a),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=x,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,f,d),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},Ks=class extends $e{constructor(t=[],e=Ii,n,i,r,o,a,l,c,h){super(t,e,n,i,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},fo=class extends Tn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new Ks(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Oe(5,5,5),r=new _n({name:"CubemapFromEquirect",uniforms:Li(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Be,blending:Gn});r.uniforms.tEquirect.value=e;let o=new ie(i,r),a=e.minFilter;return e.minFilter===oi&&(e.minFilter=gn),new uo(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,i);t.setRenderTarget(r)}},Je=class extends Ne{constructor(){super(),this.isGroup=!0,this.type="Group"}},Xd={type:"move"},os=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Je,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Je,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new D,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new D),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Je,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new D,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new D),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let x of t.hand.values()){let m=e.getJointPose(x,n),p=this._getHandJoint(c,x);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],f=h.position.distanceTo(u.position),d=.02,g=.005;c.inputState.pinching&&f>d+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&f<=d-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Xd)))}return a!==null&&(a.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Je;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}};var js=class s{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new Lt(t),this.near=e,this.far=n}clone(){return new s(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},bi=class extends Ne{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new xn,this.environmentIntensity=1,this.environmentRotation=new xn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},po=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=oo,this.updateRanges=[],this.version=0,this.uuid=ni()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,r=this.stride;i<r;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ni()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ni()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},qe=new D,Qs=class s{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyMatrix4(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyNormalMatrix(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.transformDirection(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=wn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=re(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=re(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=re(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=re(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=re(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=wn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=wn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=wn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=wn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=re(e,this.array),n=re(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=re(e,this.array),n=re(n,this.array),i=re(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=re(e,this.array),n=re(n,this.array),i=re(i,this.array),r=re(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return new Ee(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new s(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},as=class extends Cn{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Lt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Ki,Ns=new D,ji=new D,Qi=new D,ts=new Nt,Fs=new Nt,fu=new Qt,Vr=new D,ks=new D,Gr=new D,dh=new Nt,bl=new Nt,fh=new Nt,tr=class extends Ne{constructor(t=new as){if(super(),this.isSprite=!0,this.type="Sprite",Ki===void 0){Ki=new ke;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new po(e,5);Ki.setIndex([0,1,2,0,2,3]),Ki.setAttribute("position",new Qs(n,3,0,!1)),Ki.setAttribute("uv",new Qs(n,2,3,!1))}this.geometry=Ki,this.material=t,this.center=new Nt(.5,.5),this.count=1}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),ji.setFromMatrixScale(this.matrixWorld),fu.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Qi.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&ji.multiplyScalar(-Qi.z);let n=this.material.rotation,i,r;n!==0&&(r=Math.cos(n),i=Math.sin(n));let o=this.center;Wr(Vr.set(-.5,-.5,0),Qi,o,ji,i,r),Wr(ks.set(.5,-.5,0),Qi,o,ji,i,r),Wr(Gr.set(.5,.5,0),Qi,o,ji,i,r),dh.set(0,0),bl.set(1,0),fh.set(1,1);let a=t.ray.intersectTriangle(Vr,ks,Gr,!1,Ns);if(a===null&&(Wr(ks.set(-.5,.5,0),Qi,o,ji,i,r),bl.set(0,1),a=t.ray.intersectTriangle(Vr,Gr,ks,!1,Ns),a===null))return;let l=t.ray.origin.distanceTo(Ns);l<t.near||l>t.far||e.push({distance:l,point:Ns.clone(),uv:En.getInterpolation(Ns,Vr,ks,Gr,dh,bl,fh,new Nt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Wr(s,t,e,n,i,r){ts.subVectors(s,e).addScalar(.5).multiply(n),i!==void 0?(Fs.x=r*ts.x-i*ts.y,Fs.y=i*ts.x+r*ts.y):Fs.copy(ts),s.copy(t),s.x+=Fs.x,s.y+=Fs.y,s.applyMatrix4(fu)}var ls=class extends $e{constructor(t=null,e=1,n=1,i,r,o,a,l,c=Te,h=Te,u,f){super(null,o,a,l,c,h,i,r,u,f),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Si=class extends Ee{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},es=new Qt,ph=new Qt,Xr=[],mh=new An,qd=new Qt,Os=new ie,Bs=new Hn,wi=class extends ie{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Si(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,qd)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new An),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,es),mh.copy(t.boundingBox).applyMatrix4(es),this.boundingBox.union(mh)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Hn),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,es),Bs.copy(t.boundingSphere).applyMatrix4(es),this.boundingSphere.union(Bs)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=i[o+a]}raycast(t,e){let n=this.matrixWorld,i=this.count;if(Os.geometry=this.geometry,Os.material=this.material,Os.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Bs.copy(this.boundingSphere),Bs.applyMatrix4(n),t.ray.intersectsSphere(Bs)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,es),ph.multiplyMatrices(n,es),Os.matrixWorld=ph,Os.raycast(t,Xr);for(let o=0,a=Xr.length;o<a;o++){let l=Xr[o];l.instanceId=r,l.object=this,e.push(l)}Xr.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Si(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new ls(new Float32Array(i*this.count),i,this.count,Wo,yn));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=i*t;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},Sl=new D,$d=new D,Yd=new Ot,Sn=class{constructor(t=new D(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let i=Sl.subVectors(n,e).cross($d.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(Sl),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||Yd.getNormalMatrix(t),i=this.coplanarPoint(Sl).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},xi=new Hn,Zd=new Nt(.5,.5),qr=new D,cs=class{constructor(t=new Sn,e=new Sn,n=new Sn,i=new Sn,r=new Sn,o=new Sn){this.planes=[t,e,n,i,r,o]}set(t,e,n,i,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(i),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=mn,n=!1){let i=this.planes,r=t.elements,o=r[0],a=r[1],l=r[2],c=r[3],h=r[4],u=r[5],f=r[6],d=r[7],g=r[8],x=r[9],m=r[10],p=r[11],S=r[12],y=r[13],v=r[14],T=r[15];if(i[0].setComponents(c-o,d-h,p-g,T-S).normalize(),i[1].setComponents(c+o,d+h,p+g,T+S).normalize(),i[2].setComponents(c+a,d+u,p+x,T+y).normalize(),i[3].setComponents(c-a,d-u,p-x,T-y).normalize(),n)i[4].setComponents(l,f,m,v).normalize(),i[5].setComponents(c-l,d-f,p-m,T-v).normalize();else if(i[4].setComponents(c-l,d-f,p-m,T-v).normalize(),e===mn)i[5].setComponents(c+l,d+f,p+m,T+v).normalize();else if(e===Gs)i[5].setComponents(l,f,m,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),xi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),xi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(xi)}intersectsSprite(t){xi.center.set(0,0,0);let e=Zd.distanceTo(t.center);return xi.radius=.7071067811865476+e,xi.applyMatrix4(t.matrixWorld),this.intersectsSphere(xi)}intersectsSphere(t){let e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let i=e[n];if(qr.x=i.normal.x>0?t.max.x:t.min.x,qr.y=i.normal.y>0?t.max.y:t.min.y,qr.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(qr)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};var hs=class extends Cn{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Lt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},mo=new D,go=new D,gh=new Qt,zs=new qs,$r=new Hn,wl=new D,xh=new D,xo=class extends Ne{constructor(t=new ke,e=new hs){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[0];for(let i=1,r=e.count;i<r;i++)mo.fromBufferAttribute(e,i-1),go.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=mo.distanceTo(go);t.setAttribute("lineDistance",new he(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),$r.copy(n.boundingSphere),$r.applyMatrix4(i),$r.radius+=r,t.ray.intersectsSphere($r)===!1)return;gh.copy(i).invert(),zs.copy(t.ray).applyMatrix4(gh);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,f=n.attributes.position;if(h!==null){let d=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let x=d,m=g-1;x<m;x+=c){let p=h.getX(x),S=h.getX(x+1),y=Yr(this,t,zs,l,p,S,x);y&&e.push(y)}if(this.isLineLoop){let x=h.getX(g-1),m=h.getX(d),p=Yr(this,t,zs,l,x,m,g-1);p&&e.push(p)}}else{let d=Math.max(0,o.start),g=Math.min(f.count,o.start+o.count);for(let x=d,m=g-1;x<m;x+=c){let p=Yr(this,t,zs,l,x,x+1,x);p&&e.push(p)}if(this.isLineLoop){let x=Yr(this,t,zs,l,g-1,d,g-1);x&&e.push(x)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){let a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Yr(s,t,e,n,i,r,o){let a=s.geometry.attributes.position;if(mo.fromBufferAttribute(a,i),go.fromBufferAttribute(a,r),e.distanceSqToSegment(mo,go,wl,xh)>n)return;wl.applyMatrix4(s.matrixWorld);let c=t.ray.origin.distanceTo(wl);if(!(c<t.near||c>t.far))return{distance:c,point:xh.clone().applyMatrix4(s.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:s}}var _h=new D,vh=new D,er=class extends xo{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[];for(let i=0,r=e.count;i<r;i+=2)_h.fromBufferAttribute(e,i),vh.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+_h.distanceTo(vh);t.setAttribute("lineDistance",new he(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var us=class extends $e{constructor(t,e,n,i,r,o,a,l,c){super(t,e,n,i,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},nr=class extends $e{constructor(t,e,n=ai,i,r,o,a=Te,l=Te,c,h=is,u=1){if(h!==is&&h!==ms)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let f={width:t,height:e,depth:u};super(f,i,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new rs(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},ir=class extends $e{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}};var Zr=new D,Jr=new D,El=new D,Kr=new En,sr=class extends ke{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){let i=Math.pow(10,4),r=Math.cos(to*e),o=t.getIndex(),a=t.getAttribute("position"),l=o?o.count:a.count,c=[0,0,0],h=["a","b","c"],u=new Array(3),f={},d=[];for(let g=0;g<l;g+=3){o?(c[0]=o.getX(g),c[1]=o.getX(g+1),c[2]=o.getX(g+2)):(c[0]=g,c[1]=g+1,c[2]=g+2);let{a:x,b:m,c:p}=Kr;if(x.fromBufferAttribute(a,c[0]),m.fromBufferAttribute(a,c[1]),p.fromBufferAttribute(a,c[2]),Kr.getNormal(El),u[0]=`${Math.round(x.x*i)},${Math.round(x.y*i)},${Math.round(x.z*i)}`,u[1]=`${Math.round(m.x*i)},${Math.round(m.y*i)},${Math.round(m.z*i)}`,u[2]=`${Math.round(p.x*i)},${Math.round(p.y*i)},${Math.round(p.z*i)}`,!(u[0]===u[1]||u[1]===u[2]||u[2]===u[0]))for(let S=0;S<3;S++){let y=(S+1)%3,v=u[S],T=u[y],E=Kr[h[S]],C=Kr[h[y]],I=`${v}_${T}`,M=`${T}_${v}`;M in f&&f[M]?(El.dot(f[M].normal)<=r&&(d.push(E.x,E.y,E.z),d.push(C.x,C.y,C.z)),f[M]=null):I in f||(f[I]={index0:c[S],index1:c[y],normal:El.clone()})}}for(let g in f)if(f[g]){let{index0:x,index1:m}=f[g];Zr.fromBufferAttribute(a,x),Jr.fromBufferAttribute(a,m),d.push(Zr.x,Zr.y,Zr.z),d.push(Jr.x,Jr.y,Jr.z)}this.setAttribute("position",new he(d,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}};var rr=class s extends ke{constructor(t=[new Nt(0,-.5),new Nt(.5,0),new Nt(0,.5)],e=12,n=0,i=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:i},e=Math.floor(e),i=Xt(i,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/e,u=new D,f=new Nt,d=new D,g=new D,x=new D,m=0,p=0;for(let S=0;S<=t.length-1;S++)switch(S){case 0:m=t[S+1].x-t[S].x,p=t[S+1].y-t[S].y,d.x=p*1,d.y=-m,d.z=p*0,x.copy(d),d.normalize(),l.push(d.x,d.y,d.z);break;case t.length-1:l.push(x.x,x.y,x.z);break;default:m=t[S+1].x-t[S].x,p=t[S+1].y-t[S].y,d.x=p*1,d.y=-m,d.z=p*0,g.copy(d),d.x+=x.x,d.y+=x.y,d.z+=x.z,d.normalize(),l.push(d.x,d.y,d.z),x.copy(g)}for(let S=0;S<=e;S++){let y=n+S*h*i,v=Math.sin(y),T=Math.cos(y);for(let E=0;E<=t.length-1;E++){u.x=t[E].x*v,u.y=t[E].y,u.z=t[E].x*T,o.push(u.x,u.y,u.z),f.x=S/e,f.y=E/(t.length-1),a.push(f.x,f.y);let C=l[3*E+0]*v,I=l[3*E+1],M=l[3*E+0]*T;c.push(C,I,M)}}for(let S=0;S<e;S++)for(let y=0;y<t.length-1;y++){let v=y+S*t.length,T=v,E=v+t.length,C=v+t.length+1,I=v+1;r.push(T,E,I),r.push(C,I,E)}this.setIndex(r),this.setAttribute("position",new he(o,3)),this.setAttribute("uv",new he(a,2)),this.setAttribute("normal",new he(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.points,t.segments,t.phiStart,t.phiLength)}};var Ei=class s extends ke{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(i),c=a+1,h=l+1,u=t/a,f=e/l,d=[],g=[],x=[],m=[];for(let p=0;p<h;p++){let S=p*f-o;for(let y=0;y<c;y++){let v=y*u-r;g.push(v,-S,0),x.push(0,0,1),m.push(y/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let S=0;S<a;S++){let y=S+c*p,v=S+c*(p+1),T=S+1+c*(p+1),E=S+1+c*p;d.push(y,v,E),d.push(v,T,E)}this.setIndex(d),this.setAttribute("position",new he(g,3)),this.setAttribute("normal",new he(x,3)),this.setAttribute("uv",new he(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.widthSegments,t.heightSegments)}};var Ti=class s extends ke{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new D,f=new D,d=[],g=[],x=[],m=[];for(let p=0;p<=n;p++){let S=[],y=p/n,v=0;p===0&&o===0?v=.5/e:p===n&&l===Math.PI&&(v=-.5/e);for(let T=0;T<=e;T++){let E=T/e;u.x=-t*Math.cos(i+E*r)*Math.sin(o+y*a),u.y=t*Math.cos(o+y*a),u.z=t*Math.sin(i+E*r)*Math.sin(o+y*a),g.push(u.x,u.y,u.z),f.copy(u).normalize(),x.push(f.x,f.y,f.z),m.push(E+v,1-y),S.push(c++)}h.push(S)}for(let p=0;p<n;p++)for(let S=0;S<e;S++){let y=h[p][S+1],v=h[p][S],T=h[p+1][S],E=h[p+1][S+1];(p!==0||o>0)&&d.push(y,v,E),(p!==n-1||l<Math.PI)&&d.push(v,T,E)}this.setIndex(d),this.setAttribute("position",new he(g,3)),this.setAttribute("normal",new he(x,3)),this.setAttribute("uv",new he(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Vn=class extends Cn{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Lt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Lt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=$l,this.normalScale=new Nt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=ko,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},_o=class extends Cn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Qh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},vo=class extends Cn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}};function jr(s,t){return!s||s.constructor===t?s:typeof t.BYTES_PER_ELEMENT=="number"?new t(s):Array.prototype.slice.call(s)}function Jd(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var Ai=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];t:{e:{let o;n:{i:if(!(t<i)){for(let a=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=i,i=e[++n],t<i)break e}o=e.length;break n}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=r,r=e[--n-1],t>=r)break e}o=n,n=0;break n}break t}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let o=0;o!==i;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},yo=class extends Ai{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Al,endingEnd:Al}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,o=t+1,a=i[r],l=i[o];if(a===void 0)switch(this.getSettings_().endingStart){case Cl:r=t,a=2*e-n;break;case Rl:r=i.length-2,a=e+i[r]-i[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Cl:o=t,l=2*n-e;break;case Rl:o=1,l=n+i[1]-i[0];break;default:o=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,f=this._weightPrev,d=this._weightNext,g=(n-e)/(i-e),x=g*g,m=x*g,p=-f*m+2*f*x-f*g,S=(1+f)*m+(-1.5-2*f)*x+(-.5+f)*g+1,y=(-1-d)*m+(1.5+d)*x+.5*g,v=d*m-d*x;for(let T=0;T!==a;++T)r[T]=p*o[h+T]+S*o[c+T]+y*o[l+T]+v*o[u+T];return r}},Mo=class extends Ai{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=(n-e)/(i-e),u=1-h;for(let f=0;f!==a;++f)r[f]=o[c+f]*u+o[l+f]*h;return r}},bo=class extends Ai{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},rn=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=jr(e,this.TimeBufferType),this.values=jr(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:jr(t.times,Array),values:jr(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new bo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Mo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new yo(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case Hs:e=this.InterpolantFactoryMethodDiscrete;break;case ro:e=this.InterpolantFactoryMethodLinear;break;case Qr:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Hs;case this.InterpolantFactoryMethodLinear:return ro;case this.InterpolantFactoryMethodSmooth:return Qr}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t}return this}trim(t,e){let n=this.times,i=n.length,r=0,o=i-1;for(;r!==i&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==i){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(i!==void 0&&Jd(i))for(let a=0,l=i.length;a!==l;++a){let c=i[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Qr,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],h=t[a+1];if(c!==h&&(a!==1||c!==t[0]))if(i)l=!0;else{let u=a*n,f=u-n,d=u+n;for(let g=0;g!==n;++g){let x=e[u+g];if(x!==e[f+g]||x!==e[d+g]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let u=a*n,f=o*n;for(let d=0;d!==n;++d)e[f+d]=e[u+d]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,i}};rn.prototype.ValueTypeName="";rn.prototype.TimeBufferType=Float32Array;rn.prototype.ValueBufferType=Float32Array;rn.prototype.DefaultInterpolation=ro;var si=class extends rn{constructor(t,e,n){super(t,e,n)}};si.prototype.ValueTypeName="bool";si.prototype.ValueBufferType=Array;si.prototype.DefaultInterpolation=Hs;si.prototype.InterpolantFactoryMethodLinear=void 0;si.prototype.InterpolantFactoryMethodSmooth=void 0;var So=class extends rn{constructor(t,e,n,i){super(t,e,n,i)}};So.prototype.ValueTypeName="color";var wo=class extends rn{constructor(t,e,n,i){super(t,e,n,i)}};wo.prototype.ValueTypeName="number";var Eo=class extends Ai{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(i-e),c=t*a;for(let h=c+a;c!==h;c+=4)sn.slerpFlat(r,0,o,c-a,o,c,l);return r}},or=class extends rn{constructor(t,e,n,i){super(t,e,n,i)}InterpolantFactoryMethodLinear(t){return new Eo(this.times,this.values,this.getValueSize(),t)}};or.prototype.ValueTypeName="quaternion";or.prototype.InterpolantFactoryMethodSmooth=void 0;var ri=class extends rn{constructor(t,e,n){super(t,e,n)}};ri.prototype.ValueTypeName="string";ri.prototype.ValueBufferType=Array;ri.prototype.DefaultInterpolation=Hs;ri.prototype.InterpolantFactoryMethodLinear=void 0;ri.prototype.InterpolantFactoryMethodSmooth=void 0;var To=class extends rn{constructor(t,e,n,i){super(t,e,n,i)}};To.prototype.ValueTypeName="vector";var Ao=class{constructor(t,e,n){let i=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.abortController=new AbortController,this.itemStart=function(h){a++,r===!1&&i.onStart!==void 0&&i.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,i.onProgress!==void 0&&i.onProgress(h,o,a),o===a&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,f=c.length;u<f;u+=2){let d=c[u],g=c[u+1];if(d.global&&(d.lastIndex=0),d.test(h))return g}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}},pu=new Ao,Co=class{constructor(t){this.manager=t!==void 0?t:pu,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}abort(){return this}};Co.DEFAULT_MATERIAL_NAME="__DEFAULT";var ar=class extends Ne{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Lt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},Ci=class extends ar{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ne.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Lt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Tl=new Qt,yh=new D,Mh=new D,Pl=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Nt(512,512),this.mapType=vn,this.map=null,this.mapPass=null,this.matrix=new Qt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new cs,this._frameExtents=new Nt(1,1),this._viewportCount=1,this._viewports=[new ve(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;yh.setFromMatrixPosition(t.matrixWorld),e.position.copy(yh),Mh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Mh),e.updateMatrixWorld(),Tl.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Tl,e.coordinateSystem,e.reversedDepth),e.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(Tl)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var lr=class extends Js{constructor(t=-1,e=1,n=1,i=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,r=n-t,o=n+t,a=i+e,l=i-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Ll=class extends Pl{constructor(){super(new lr(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ri=class extends ar{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ne.DEFAULT_UP),this.updateMatrix(),this.target=new Ne,this.shadow=new Ll}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Ro=class extends Ue{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}};var Ql="\\[\\]\\.:\\/",Kd=new RegExp("["+Ql+"]","g"),tc="[^"+Ql+"]",jd="[^"+Ql.replace("\\.","")+"]",Qd=/((?:WC+[\/:])*)/.source.replace("WC",tc),tf=/(WCOD+)?/.source.replace("WCOD",jd),ef=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",tc),nf=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",tc),sf=new RegExp("^"+Qd+tf+ef+nf+"$"),rf=["material","materials","bones","map"],Dl=class{constructor(t,e,n){let i=n||fe.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},fe=class s{constructor(t,e,n){this.path=e,this.parsedPath=n||s.parseTrackName(e),this.node=s.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new s.Composite(t,e,n):new s(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(Kd,"")}static parseTrackName(t){let e=sf.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);rf.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=s.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[i];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?a=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};fe.Composite=Dl;fe.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};fe.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};fe.prototype.GetterByBindingType=[fe.prototype._getValue_direct,fe.prototype._getValue_array,fe.prototype._getValue_arrayElement,fe.prototype._getValue_toArray];fe.prototype.SetterByBindingTypeAndVersioning=[[fe.prototype._setValue_direct,fe.prototype._setValue_direct_setNeedsUpdate,fe.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_array,fe.prototype._setValue_array_setNeedsUpdate,fe.prototype._setValue_array_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_arrayElement,fe.prototype._setValue_arrayElement_setNeedsUpdate,fe.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_fromArray,fe.prototype._setValue_fromArray_setNeedsUpdate,fe.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var px=new Float32Array(1);function ec(s,t,e,n){let i=of(n);switch(e){case Wl:return s*t;case Wo:return s*t/i.components*i.byteLength;case Xo:return s*t/i.components*i.byteLength;case ql:return s*t*2/i.components*i.byteLength;case qo:return s*t*2/i.components*i.byteLength;case Xl:return s*t*3/i.components*i.byteLength;case Ke:return s*t*4/i.components*i.byteLength;case $o:return s*t*4/i.components*i.byteLength;case ur:case dr:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case fr:case pr:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Zo:case Ko:return Math.max(s,16)*Math.max(t,8)/4;case Yo:case Jo:return Math.max(s,8)*Math.max(t,8)/2;case jo:case Qo:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case ta:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case ea:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case na:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case ia:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case sa:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case ra:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case oa:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case aa:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case la:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case ca:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case ha:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case ua:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case da:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case fa:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case pa:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case ma:case ga:case xa:return Math.ceil(s/4)*Math.ceil(t/4)*16;case _a:case va:return Math.ceil(s/4)*Math.ceil(t/4)*8;case ya:case Ma:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function of(s){switch(s){case vn:case zl:return{byteLength:1,components:1};case ds:case Hl:case fs:return{byteLength:2,components:1};case Vo:case Go:return{byteLength:2,components:4};case ai:case Ho:case yn:return{byteLength:4,components:1};case Vl:case Gl:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"180"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="180");function Ou(){let s=null,t=!1,e=null,n=null;function i(r,o){e(r,o),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function lf(s){let t=new WeakMap;function e(a,l){let c=a.array,h=a.usage,u=c.byteLength,f=s.createBuffer();s.bindBuffer(l,f),s.bufferData(l,c,h),a.onUploadCallback();let d;if(c instanceof Float32Array)d=s.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)d=s.HALF_FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?d=s.HALF_FLOAT:d=s.UNSIGNED_SHORT;else if(c instanceof Int16Array)d=s.SHORT;else if(c instanceof Uint32Array)d=s.UNSIGNED_INT;else if(c instanceof Int32Array)d=s.INT;else if(c instanceof Int8Array)d=s.BYTE;else if(c instanceof Uint8Array)d=s.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)d=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:f,type:d,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){let h=l.array,u=l.updateRanges;if(s.bindBuffer(c,a),u.length===0)s.bufferSubData(c,0,h);else{u.sort((d,g)=>d.start-g.start);let f=0;for(let d=1;d<u.length;d++){let g=u[f],x=u[d];x.start<=g.start+g.count+1?g.count=Math.max(g.count,x.start+x.count-g.start):(++f,u[f]=x)}u.length=f+1;for(let d=0,g=u.length;d<g;d++){let x=u[d];s.bufferSubData(c,x.start*h.BYTES_PER_ELEMENT,h,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=t.get(a);l&&(s.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:i,remove:r,update:o}}var cf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,hf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,uf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,df=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,ff=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,pf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,mf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,gf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,xf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,_f=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,vf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,yf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Mf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,bf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Sf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,wf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Ef=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Tf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Af=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Cf=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Rf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,If=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Pf=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Lf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Df=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Uf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Nf=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ff=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,kf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Of=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Bf="gl_FragColor = linearToOutputTexel( gl_FragColor );",zf=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Hf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Gf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Wf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Xf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$f=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Yf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Zf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Jf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Kf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,jf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Qf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,tp=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,ep=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,np=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ip=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,sp=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,rp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,op=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ap=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,cp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,hp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,up=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,dp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,pp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,mp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,xp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,_p=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,vp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,yp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Mp=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,bp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Sp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wp=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Ep=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ap=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Cp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Rp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ip=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Pp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Lp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Dp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Up=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Np=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Fp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,kp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Op=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Bp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,zp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Hp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Vp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Gp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Wp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Xp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,qp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,$p=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Yp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Zp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Jp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Kp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,jp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Qp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tm=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,em=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,nm=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,im=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,sm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,rm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,om=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,am=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,lm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cm=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,um=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fm=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,xm=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,_m=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ym=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Mm=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,bm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Sm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wm=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Em=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tm=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Am=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Rm=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Im=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Pm=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Dm=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Um=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nm=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fm=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,km=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Om=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bm=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,zm=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Hm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Vt={alphahash_fragment:cf,alphahash_pars_fragment:hf,alphamap_fragment:uf,alphamap_pars_fragment:df,alphatest_fragment:ff,alphatest_pars_fragment:pf,aomap_fragment:mf,aomap_pars_fragment:gf,batching_pars_vertex:xf,batching_vertex:_f,begin_vertex:vf,beginnormal_vertex:yf,bsdfs:Mf,iridescence_fragment:bf,bumpmap_pars_fragment:Sf,clipping_planes_fragment:wf,clipping_planes_pars_fragment:Ef,clipping_planes_pars_vertex:Tf,clipping_planes_vertex:Af,color_fragment:Cf,color_pars_fragment:Rf,color_pars_vertex:If,color_vertex:Pf,common:Lf,cube_uv_reflection_fragment:Df,defaultnormal_vertex:Uf,displacementmap_pars_vertex:Nf,displacementmap_vertex:Ff,emissivemap_fragment:kf,emissivemap_pars_fragment:Of,colorspace_fragment:Bf,colorspace_pars_fragment:zf,envmap_fragment:Hf,envmap_common_pars_fragment:Vf,envmap_pars_fragment:Gf,envmap_pars_vertex:Wf,envmap_physical_pars_fragment:ep,envmap_vertex:Xf,fog_vertex:qf,fog_pars_vertex:$f,fog_fragment:Yf,fog_pars_fragment:Zf,gradientmap_pars_fragment:Jf,lightmap_pars_fragment:Kf,lights_lambert_fragment:jf,lights_lambert_pars_fragment:Qf,lights_pars_begin:tp,lights_toon_fragment:np,lights_toon_pars_fragment:ip,lights_phong_fragment:sp,lights_phong_pars_fragment:rp,lights_physical_fragment:op,lights_physical_pars_fragment:ap,lights_fragment_begin:lp,lights_fragment_maps:cp,lights_fragment_end:hp,logdepthbuf_fragment:up,logdepthbuf_pars_fragment:dp,logdepthbuf_pars_vertex:fp,logdepthbuf_vertex:pp,map_fragment:mp,map_pars_fragment:gp,map_particle_fragment:xp,map_particle_pars_fragment:_p,metalnessmap_fragment:vp,metalnessmap_pars_fragment:yp,morphinstance_vertex:Mp,morphcolor_vertex:bp,morphnormal_vertex:Sp,morphtarget_pars_vertex:wp,morphtarget_vertex:Ep,normal_fragment_begin:Tp,normal_fragment_maps:Ap,normal_pars_fragment:Cp,normal_pars_vertex:Rp,normal_vertex:Ip,normalmap_pars_fragment:Pp,clearcoat_normal_fragment_begin:Lp,clearcoat_normal_fragment_maps:Dp,clearcoat_pars_fragment:Up,iridescence_pars_fragment:Np,opaque_fragment:Fp,packing:kp,premultiplied_alpha_fragment:Op,project_vertex:Bp,dithering_fragment:zp,dithering_pars_fragment:Hp,roughnessmap_fragment:Vp,roughnessmap_pars_fragment:Gp,shadowmap_pars_fragment:Wp,shadowmap_pars_vertex:Xp,shadowmap_vertex:qp,shadowmask_pars_fragment:$p,skinbase_vertex:Yp,skinning_pars_vertex:Zp,skinning_vertex:Jp,skinnormal_vertex:Kp,specularmap_fragment:jp,specularmap_pars_fragment:Qp,tonemapping_fragment:tm,tonemapping_pars_fragment:em,transmission_fragment:nm,transmission_pars_fragment:im,uv_pars_fragment:sm,uv_pars_vertex:rm,uv_vertex:om,worldpos_vertex:am,background_vert:lm,background_frag:cm,backgroundCube_vert:hm,backgroundCube_frag:um,cube_vert:dm,cube_frag:fm,depth_vert:pm,depth_frag:mm,distanceRGBA_vert:gm,distanceRGBA_frag:xm,equirect_vert:_m,equirect_frag:vm,linedashed_vert:ym,linedashed_frag:Mm,meshbasic_vert:bm,meshbasic_frag:Sm,meshlambert_vert:wm,meshlambert_frag:Em,meshmatcap_vert:Tm,meshmatcap_frag:Am,meshnormal_vert:Cm,meshnormal_frag:Rm,meshphong_vert:Im,meshphong_frag:Pm,meshphysical_vert:Lm,meshphysical_frag:Dm,meshtoon_vert:Um,meshtoon_frag:Nm,points_vert:Fm,points_frag:km,shadow_vert:Om,shadow_frag:Bm,sprite_vert:zm,sprite_frag:Hm},at={common:{diffuse:{value:new Lt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ot},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ot}},envmap:{envMap:{value:null},envMapRotation:{value:new Ot},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ot}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ot}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ot},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ot},normalScale:{value:new Nt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ot},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ot}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ot}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ot}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Lt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Lt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0},uvTransform:{value:new Ot}},sprite:{diffuse:{value:new Lt(16777215)},opacity:{value:1},center:{value:new Nt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ot},alphaMap:{value:null},alphaMapTransform:{value:new Ot},alphaTest:{value:0}}},In={basic:{uniforms:We([at.common,at.specularmap,at.envmap,at.aomap,at.lightmap,at.fog]),vertexShader:Vt.meshbasic_vert,fragmentShader:Vt.meshbasic_frag},lambert:{uniforms:We([at.common,at.specularmap,at.envmap,at.aomap,at.lightmap,at.emissivemap,at.bumpmap,at.normalmap,at.displacementmap,at.fog,at.lights,{emissive:{value:new Lt(0)}}]),vertexShader:Vt.meshlambert_vert,fragmentShader:Vt.meshlambert_frag},phong:{uniforms:We([at.common,at.specularmap,at.envmap,at.aomap,at.lightmap,at.emissivemap,at.bumpmap,at.normalmap,at.displacementmap,at.fog,at.lights,{emissive:{value:new Lt(0)},specular:{value:new Lt(1118481)},shininess:{value:30}}]),vertexShader:Vt.meshphong_vert,fragmentShader:Vt.meshphong_frag},standard:{uniforms:We([at.common,at.envmap,at.aomap,at.lightmap,at.emissivemap,at.bumpmap,at.normalmap,at.displacementmap,at.roughnessmap,at.metalnessmap,at.fog,at.lights,{emissive:{value:new Lt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Vt.meshphysical_vert,fragmentShader:Vt.meshphysical_frag},toon:{uniforms:We([at.common,at.aomap,at.lightmap,at.emissivemap,at.bumpmap,at.normalmap,at.displacementmap,at.gradientmap,at.fog,at.lights,{emissive:{value:new Lt(0)}}]),vertexShader:Vt.meshtoon_vert,fragmentShader:Vt.meshtoon_frag},matcap:{uniforms:We([at.common,at.bumpmap,at.normalmap,at.displacementmap,at.fog,{matcap:{value:null}}]),vertexShader:Vt.meshmatcap_vert,fragmentShader:Vt.meshmatcap_frag},points:{uniforms:We([at.points,at.fog]),vertexShader:Vt.points_vert,fragmentShader:Vt.points_frag},dashed:{uniforms:We([at.common,at.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Vt.linedashed_vert,fragmentShader:Vt.linedashed_frag},depth:{uniforms:We([at.common,at.displacementmap]),vertexShader:Vt.depth_vert,fragmentShader:Vt.depth_frag},normal:{uniforms:We([at.common,at.bumpmap,at.normalmap,at.displacementmap,{opacity:{value:1}}]),vertexShader:Vt.meshnormal_vert,fragmentShader:Vt.meshnormal_frag},sprite:{uniforms:We([at.sprite,at.fog]),vertexShader:Vt.sprite_vert,fragmentShader:Vt.sprite_frag},background:{uniforms:{uvTransform:{value:new Ot},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Vt.background_vert,fragmentShader:Vt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ot}},vertexShader:Vt.backgroundCube_vert,fragmentShader:Vt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Vt.cube_vert,fragmentShader:Vt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Vt.equirect_vert,fragmentShader:Vt.equirect_frag},distanceRGBA:{uniforms:We([at.common,at.displacementmap,{referencePosition:{value:new D},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Vt.distanceRGBA_vert,fragmentShader:Vt.distanceRGBA_frag},shadow:{uniforms:We([at.lights,at.fog,{color:{value:new Lt(0)},opacity:{value:1}}]),vertexShader:Vt.shadow_vert,fragmentShader:Vt.shadow_frag}};In.physical={uniforms:We([In.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ot},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ot},clearcoatNormalScale:{value:new Nt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ot},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ot},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ot},sheen:{value:0},sheenColor:{value:new Lt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ot},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ot},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ot},transmissionSamplerSize:{value:new Nt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ot},attenuationDistance:{value:0},attenuationColor:{value:new Lt(0)},specularColor:{value:new Lt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ot},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ot},anisotropyVector:{value:new Nt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ot}}]),vertexShader:Vt.meshphysical_vert,fragmentShader:Vt.meshphysical_frag};var ba={r:0,b:0,g:0},Di=new xn,Vm=new Qt;function Gm(s,t,e,n,i,r,o){let a=new Lt(0),l=r===!0?0:1,c,h,u=null,f=0,d=null;function g(y){let v=y.isScene===!0?y.background:null;return v&&v.isTexture&&(v=(y.backgroundBlurriness>0?e:t).get(v)),v}function x(y){let v=!1,T=g(y);T===null?p(a,l):T&&T.isColor&&(p(T,1),v=!0);let E=s.xr.getEnvironmentBlendMode();E==="additive"?n.buffers.color.setClear(0,0,0,1,o):E==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(s.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function m(y,v){let T=g(v);T&&(T.isCubeTexture||T.mapping===cr)?(h===void 0&&(h=new ie(new Oe(1,1,1),new _n({name:"BackgroundCubeMaterial",uniforms:Li(In.backgroundCube.uniforms),vertexShader:In.backgroundCube.vertexShader,fragmentShader:In.backgroundCube.fragmentShader,side:Be,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(E,C,I){this.matrixWorld.copyPosition(I.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),Di.copy(v.backgroundRotation),Di.x*=-1,Di.y*=-1,Di.z*=-1,T.isCubeTexture&&T.isRenderTargetTexture===!1&&(Di.y*=-1,Di.z*=-1),h.material.uniforms.envMap.value=T,h.material.uniforms.flipEnvMap.value=T.isCubeTexture&&T.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Vm.makeRotationFromEuler(Di)),h.material.toneMapped=$t.getTransfer(T.colorSpace)!==ne,(u!==T||f!==T.version||d!==s.toneMapping)&&(h.material.needsUpdate=!0,u=T,f=T.version,d=s.toneMapping),h.layers.enableAll(),y.unshift(h,h.geometry,h.material,0,0,null)):T&&T.isTexture&&(c===void 0&&(c=new ie(new Ei(2,2),new _n({name:"BackgroundMaterial",uniforms:Li(In.background.uniforms),vertexShader:In.background.vertexShader,fragmentShader:In.background.fragmentShader,side:Bn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=T,c.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,c.material.toneMapped=$t.getTransfer(T.colorSpace)!==ne,T.matrixAutoUpdate===!0&&T.updateMatrix(),c.material.uniforms.uvTransform.value.copy(T.matrix),(u!==T||f!==T.version||d!==s.toneMapping)&&(c.material.needsUpdate=!0,u=T,f=T.version,d=s.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null))}function p(y,v){y.getRGB(ba,jl(s)),n.buffers.color.setClear(ba.r,ba.g,ba.b,v,o)}function S(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(y,v=1){a.set(y),l=v,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(y){l=y,p(a,l)},render:x,addToRenderList:m,dispose:S}}function Wm(s,t){let e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=f(null),r=i,o=!1;function a(w,P,k,H,W){let X=!1,V=u(H,k,P);r!==V&&(r=V,c(r.object)),X=d(w,H,k,W),X&&g(w,H,k,W),W!==null&&t.update(W,s.ELEMENT_ARRAY_BUFFER),(X||o)&&(o=!1,v(w,P,k,H),W!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(W).buffer))}function l(){return s.createVertexArray()}function c(w){return s.bindVertexArray(w)}function h(w){return s.deleteVertexArray(w)}function u(w,P,k){let H=k.wireframe===!0,W=n[w.id];W===void 0&&(W={},n[w.id]=W);let X=W[P.id];X===void 0&&(X={},W[P.id]=X);let V=X[H];return V===void 0&&(V=f(l()),X[H]=V),V}function f(w){let P=[],k=[],H=[];for(let W=0;W<e;W++)P[W]=0,k[W]=0,H[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:k,attributeDivisors:H,object:w,attributes:{},index:null}}function d(w,P,k,H){let W=r.attributes,X=P.attributes,V=0,Q=k.getAttributes();for(let O in Q)if(Q[O].location>=0){let lt=W[O],pt=X[O];if(pt===void 0&&(O==="instanceMatrix"&&w.instanceMatrix&&(pt=w.instanceMatrix),O==="instanceColor"&&w.instanceColor&&(pt=w.instanceColor)),lt===void 0||lt.attribute!==pt||pt&&lt.data!==pt.data)return!0;V++}return r.attributesNum!==V||r.index!==H}function g(w,P,k,H){let W={},X=P.attributes,V=0,Q=k.getAttributes();for(let O in Q)if(Q[O].location>=0){let lt=X[O];lt===void 0&&(O==="instanceMatrix"&&w.instanceMatrix&&(lt=w.instanceMatrix),O==="instanceColor"&&w.instanceColor&&(lt=w.instanceColor));let pt={};pt.attribute=lt,lt&&lt.data&&(pt.data=lt.data),W[O]=pt,V++}r.attributes=W,r.attributesNum=V,r.index=H}function x(){let w=r.newAttributes;for(let P=0,k=w.length;P<k;P++)w[P]=0}function m(w){p(w,0)}function p(w,P){let k=r.newAttributes,H=r.enabledAttributes,W=r.attributeDivisors;k[w]=1,H[w]===0&&(s.enableVertexAttribArray(w),H[w]=1),W[w]!==P&&(s.vertexAttribDivisor(w,P),W[w]=P)}function S(){let w=r.newAttributes,P=r.enabledAttributes;for(let k=0,H=P.length;k<H;k++)P[k]!==w[k]&&(s.disableVertexAttribArray(k),P[k]=0)}function y(w,P,k,H,W,X,V){V===!0?s.vertexAttribIPointer(w,P,k,W,X):s.vertexAttribPointer(w,P,k,H,W,X)}function v(w,P,k,H){x();let W=H.attributes,X=k.getAttributes(),V=P.defaultAttributeValues;for(let Q in X){let O=X[Q];if(O.location>=0){let rt=W[Q];if(rt===void 0&&(Q==="instanceMatrix"&&w.instanceMatrix&&(rt=w.instanceMatrix),Q==="instanceColor"&&w.instanceColor&&(rt=w.instanceColor)),rt!==void 0){let lt=rt.normalized,pt=rt.itemSize,zt=t.get(rt);if(zt===void 0)continue;let ee=zt.buffer,ae=zt.type,Kt=zt.bytesPerElement,$=ae===s.INT||ae===s.UNSIGNED_INT||rt.gpuType===Ho;if(rt.isInterleavedBufferAttribute){let j=rt.data,mt=j.stride,Ut=rt.offset;if(j.isInstancedInterleavedBuffer){for(let wt=0;wt<O.locationSize;wt++)p(O.location+wt,j.meshPerAttribute);w.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=j.meshPerAttribute*j.count)}else for(let wt=0;wt<O.locationSize;wt++)m(O.location+wt);s.bindBuffer(s.ARRAY_BUFFER,ee);for(let wt=0;wt<O.locationSize;wt++)y(O.location+wt,pt/O.locationSize,ae,lt,mt*Kt,(Ut+pt/O.locationSize*wt)*Kt,$)}else{if(rt.isInstancedBufferAttribute){for(let j=0;j<O.locationSize;j++)p(O.location+j,rt.meshPerAttribute);w.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=rt.meshPerAttribute*rt.count)}else for(let j=0;j<O.locationSize;j++)m(O.location+j);s.bindBuffer(s.ARRAY_BUFFER,ee);for(let j=0;j<O.locationSize;j++)y(O.location+j,pt/O.locationSize,ae,lt,pt*Kt,pt/O.locationSize*j*Kt,$)}}else if(V!==void 0){let lt=V[Q];if(lt!==void 0)switch(lt.length){case 2:s.vertexAttrib2fv(O.location,lt);break;case 3:s.vertexAttrib3fv(O.location,lt);break;case 4:s.vertexAttrib4fv(O.location,lt);break;default:s.vertexAttrib1fv(O.location,lt)}}}}S()}function T(){I();for(let w in n){let P=n[w];for(let k in P){let H=P[k];for(let W in H)h(H[W].object),delete H[W];delete P[k]}delete n[w]}}function E(w){if(n[w.id]===void 0)return;let P=n[w.id];for(let k in P){let H=P[k];for(let W in H)h(H[W].object),delete H[W];delete P[k]}delete n[w.id]}function C(w){for(let P in n){let k=n[P];if(k[w.id]===void 0)continue;let H=k[w.id];for(let W in H)h(H[W].object),delete H[W];delete k[w.id]}}function I(){M(),o=!0,r!==i&&(r=i,c(r.object))}function M(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:I,resetDefaultState:M,dispose:T,releaseStatesOfGeometry:E,releaseStatesOfProgram:C,initAttributes:x,enableAttribute:m,disableUnusedAttributes:S}}function Xm(s,t,e){let n;function i(c){n=c}function r(c,h){s.drawArrays(n,c,h),e.update(h,n,1)}function o(c,h,u){u!==0&&(s.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function a(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let d=0;for(let g=0;g<u;g++)d+=h[g];e.update(d,n,1)}function l(c,h,u,f){if(u===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let g=0;g<c.length;g++)o(c[g],h[g],f[g]);else{d.multiDrawArraysInstancedWEBGL(n,c,0,h,0,f,0,u);let g=0;for(let x=0;x<u;x++)g+=h[x]*f[x];e.update(g,n,1)}}this.setMode=i,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function qm(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let C=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(C){return!(C!==Ke&&n.convert(C)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(C){let I=C===fs&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(C!==vn&&n.convert(C)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&C!==yn&&!I)}function l(C){if(C==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=e.logarithmicDepthBuffer===!0,f=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),d=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),g=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=s.getParameter(s.MAX_TEXTURE_SIZE),m=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),p=s.getParameter(s.MAX_VERTEX_ATTRIBS),S=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),y=s.getParameter(s.MAX_VARYING_VECTORS),v=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),T=g>0,E=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:f,maxTextures:d,maxVertexTextures:g,maxTextureSize:x,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:S,maxVaryings:y,maxFragmentUniforms:v,vertexTextures:T,maxSamples:E}}function $m(s){let t=this,e=null,n=0,i=!1,r=!1,o=new Sn,a=new Ot,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,f){let d=u.length!==0||f||n!==0||i;return i=f,n=u.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,f){e=h(u,f,0)},this.setState=function(u,f,d){let g=u.clippingPlanes,x=u.clipIntersection,m=u.clipShadows,p=s.get(u);if(!i||g===null||g.length===0||r&&!m)r?h(null):c();else{let S=r?0:n,y=S*4,v=p.clippingState||null;l.value=v,v=h(g,f,y,d);for(let T=0;T!==y;++T)v[T]=e[T];p.clippingState=v,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=S}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,f,d,g){let x=u!==null?u.length:0,m=null;if(x!==0){if(m=l.value,g!==!0||m===null){let p=d+x*4,S=f.matrixWorldInverse;a.getNormalMatrix(S),(m===null||m.length<p)&&(m=new Float32Array(p));for(let y=0,v=d;y!==x;++y,v+=4)o.copy(u[y]).applyMatrix4(S,a),o.normal.toArray(m,v),m[v+3]=o.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,m}}function Ym(s){let t=new WeakMap;function e(o,a){return a===Oo?o.mapping=Ii:a===Bo&&(o.mapping=Pi),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Oo||a===Bo)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new fo(l.height);return c.fromEquirectangularTexture(s,o),t.set(o,c),o.addEventListener("dispose",i),e(c.texture,o.mapping)}else return null}}return o}function i(o){let a=o.target;a.removeEventListener("dispose",i);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var xs=4,mu=[.125,.215,.35,.446,.526,.582],Fi=20,nc=new lr,gu=new Lt,ic=null,sc=0,rc=0,oc=!1,Ni=(1+Math.sqrt(5))/2,gs=1/Ni,xu=[new D(-Ni,gs,0),new D(Ni,gs,0),new D(-gs,0,Ni),new D(gs,0,Ni),new D(0,Ni,-gs),new D(0,Ni,gs),new D(-1,1,-1),new D(1,1,-1),new D(-1,1,1),new D(1,1,1)],Zm=new D,Ea=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100,r={}){let{size:o=256,position:a=Zm}=r;ic=this._renderer.getRenderTarget(),sc=this._renderer.getActiveCubeFace(),rc=this._renderer.getActiveMipmapLevel(),oc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);let l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(t,n,i,l,a),e>0&&this._blur(l,0,0,e),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=yu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=vu(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(ic,sc,rc),this._renderer.xr.enabled=oc,t.scissorTest=!1,Sa(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===Ii||t.mapping===Pi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),ic=this._renderer.getRenderTarget(),sc=this._renderer.getActiveCubeFace(),rc=this._renderer.getActiveMipmapLevel(),oc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:gn,minFilter:gn,generateMipmaps:!1,type:fs,format:Ke,colorSpace:Mi,depthBuffer:!1},i=_u(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=_u(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Jm(r)),this._blurMaterial=Km(r,t,e)}return i}_compileMaterial(t){let e=new ie(this._lodPlanes[0],t);this._renderer.compile(e,nc)}_sceneToCubeUV(t,e,n,i,r){let l=new Ue(90,1,e,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,f=u.autoClear,d=u.toneMapping;u.getClearColor(gu),u.toneMapping=Wn,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(i),u.clearDepth(),u.setRenderTarget(null));let x=new Ae({name:"PMREM.Background",side:Be,depthWrite:!1,depthTest:!1}),m=new ie(new Oe,x),p=!1,S=t.background;S?S.isColor&&(x.color.copy(S),t.background=null,p=!0):(x.color.copy(gu),p=!0);for(let y=0;y<6;y++){let v=y%3;v===0?(l.up.set(0,c[y],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+h[y],r.y,r.z)):v===1?(l.up.set(0,0,c[y]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+h[y],r.z)):(l.up.set(0,c[y],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+h[y]));let T=this._cubeSize;Sa(i,v*T,y>2?T:0,T,T),u.setRenderTarget(i),p&&u.render(m,l),u.render(t,l)}m.geometry.dispose(),m.material.dispose(),u.toneMapping=d,u.autoClear=f,t.background=S}_textureToCubeUV(t,e){let n=this._renderer,i=t.mapping===Ii||t.mapping===Pi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=yu()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=vu());let r=i?this._cubemapMaterial:this._equirectMaterial,o=new ie(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;Sa(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,nc)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let i=this._lodPlanes.length;for(let r=1;r<i;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=xu[(i-r-1)%xu.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,i,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,i,"latitudinal",r),this._halfBlur(o,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new ie(this._lodPlanes[i],c),f=c.uniforms,d=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*Fi-1),x=r/g,m=isFinite(r)?1+Math.floor(h*x):Fi;m>Fi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Fi}`);let p=[],S=0;for(let C=0;C<Fi;++C){let I=C/x,M=Math.exp(-I*I/2);p.push(M),C===0?S+=M:C<m&&(S+=2*M)}for(let C=0;C<p.length;C++)p[C]=p[C]/S;f.envMap.value=t.texture,f.samples.value=m,f.weights.value=p,f.latitudinal.value=o==="latitudinal",a&&(f.poleAxis.value=a);let{_lodMax:y}=this;f.dTheta.value=g,f.mipInt.value=y-n;let v=this._sizeLods[i],T=3*v*(i>y-xs?i-y+xs:0),E=4*(this._cubeSize-v);Sa(e,T,E,3*v,2*v),l.setRenderTarget(e),l.render(u,nc)}};function Jm(s){let t=[],e=[],n=[],i=s,r=s-xs+1+mu.length;for(let o=0;o<r;o++){let a=Math.pow(2,i);e.push(a);let l=1/a;o>s-xs?l=mu[o-s+xs-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,f=[h,h,u,h,u,u,h,h,u,u,h,u],d=6,g=6,x=3,m=2,p=1,S=new Float32Array(x*g*d),y=new Float32Array(m*g*d),v=new Float32Array(p*g*d);for(let E=0;E<d;E++){let C=E%3*2/3-1,I=E>2?0:-1,M=[C,I,0,C+2/3,I,0,C+2/3,I+1,0,C,I,0,C+2/3,I+1,0,C,I+1,0];S.set(M,x*g*E),y.set(f,m*g*E);let w=[E,E,E,E,E,E];v.set(w,p*g*E)}let T=new ke;T.setAttribute("position",new Ee(S,x)),T.setAttribute("uv",new Ee(y,m)),T.setAttribute("faceIndex",new Ee(v,p)),t.push(T),i>xs&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function _u(s,t,e){let n=new Tn(s,t,e);return n.texture.mapping=cr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Sa(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function Km(s,t,e){let n=new Float32Array(Fi),i=new D(0,1,0);return new _n({name:"SphericalGaussianBlur",defines:{n:Fi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Gn,depthTest:!1,depthWrite:!1})}function vu(){return new _n({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Gn,depthTest:!1,depthWrite:!1})}function yu(){return new _n({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:gc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Gn,depthTest:!1,depthWrite:!1})}function gc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function jm(s){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Oo||l===Bo,h=l===Ii||l===Pi;if(c||h){let u=t.get(a),f=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==f)return e===null&&(e=new Ea(s)),u=c?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{let d=a.image;return c&&d&&d.height>0||h&&d&&i(d)?(e===null&&(e=new Ea(s)),u=c?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function i(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function Qm(s){let t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let i=e(n);return i===null&&ss("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function tg(s,t,e,n){let i={},r=new WeakMap;function o(u){let f=u.target;f.index!==null&&t.remove(f.index);for(let g in f.attributes)t.remove(f.attributes[g]);f.removeEventListener("dispose",o),delete i[f.id];let d=r.get(f);d&&(t.remove(d),r.delete(f)),n.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function a(u,f){return i[f.id]===!0||(f.addEventListener("dispose",o),i[f.id]=!0,e.memory.geometries++),f}function l(u){let f=u.attributes;for(let d in f)t.update(f[d],s.ARRAY_BUFFER)}function c(u){let f=[],d=u.index,g=u.attributes.position,x=0;if(d!==null){let S=d.array;x=d.version;for(let y=0,v=S.length;y<v;y+=3){let T=S[y+0],E=S[y+1],C=S[y+2];f.push(T,E,E,C,C,T)}}else if(g!==void 0){let S=g.array;x=g.version;for(let y=0,v=S.length/3-1;y<v;y+=3){let T=y+0,E=y+1,C=y+2;f.push(T,E,E,C,C,T)}}else return;let m=new(Kl(f)?Zs:Ys)(f,1);m.version=x;let p=r.get(u);p&&t.remove(p),r.set(u,m)}function h(u){let f=r.get(u);if(f){let d=u.index;d!==null&&f.version<d.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function eg(s,t,e){let n;function i(f){n=f}let r,o;function a(f){r=f.type,o=f.bytesPerElement}function l(f,d){s.drawElements(n,d,r,f*o),e.update(d,n,1)}function c(f,d,g){g!==0&&(s.drawElementsInstanced(n,d,r,f*o,g),e.update(d,n,g))}function h(f,d,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,r,f,0,g);let m=0;for(let p=0;p<g;p++)m+=d[p];e.update(m,n,1)}function u(f,d,g,x){if(g===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<f.length;p++)c(f[p]/o,d[p],x[p]);else{m.multiDrawElementsInstancedWEBGL(n,d,0,r,f,0,x,0,g);let p=0;for(let S=0;S<g;S++)p+=d[S]*x[S];e.update(p,n,1)}}this.setMode=i,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function ng(s){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case s.TRIANGLES:e.triangles+=a*(r/3);break;case s.LINES:e.lines+=a*(r/2);break;case s.LINE_STRIP:e.lines+=a*(r-1);break;case s.LINE_LOOP:e.lines+=a*r;break;case s.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function ig(s,t,e){let n=new WeakMap,i=new ve;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0,f=n.get(a);if(f===void 0||f.count!==u){let M=function(){C.dispose(),n.delete(a),a.removeEventListener("dispose",M)};f!==void 0&&f.texture.dispose();let d=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,x=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],S=a.morphAttributes.color||[],y=0;d===!0&&(y=1),g===!0&&(y=2),x===!0&&(y=3);let v=a.attributes.position.count*y,T=1;v>t.maxTextureSize&&(T=Math.ceil(v/t.maxTextureSize),v=t.maxTextureSize);let E=new Float32Array(v*T*4*u),C=new Xs(E,v,T,u);C.type=yn,C.needsUpdate=!0;let I=y*4;for(let w=0;w<u;w++){let P=m[w],k=p[w],H=S[w],W=v*T*4*w;for(let X=0;X<P.count;X++){let V=X*I;d===!0&&(i.fromBufferAttribute(P,X),E[W+V+0]=i.x,E[W+V+1]=i.y,E[W+V+2]=i.z,E[W+V+3]=0),g===!0&&(i.fromBufferAttribute(k,X),E[W+V+4]=i.x,E[W+V+5]=i.y,E[W+V+6]=i.z,E[W+V+7]=0),x===!0&&(i.fromBufferAttribute(H,X),E[W+V+8]=i.x,E[W+V+9]=i.y,E[W+V+10]=i.z,E[W+V+11]=H.itemSize===4?i.w:1)}}f={count:u,texture:C,size:new Nt(v,T)},n.set(a,f),a.addEventListener("dispose",M)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(s,"morphTexture",o.morphTexture,e);else{let d=0;for(let x=0;x<c.length;x++)d+=c[x];let g=a.morphTargetsRelative?1:1-d;l.getUniforms().setValue(s,"morphTargetBaseInfluence",g),l.getUniforms().setValue(s,"morphTargetInfluences",c)}l.getUniforms().setValue(s,"morphTargetsTexture",f.texture,e),l.getUniforms().setValue(s,"morphTargetsTextureSize",f.size)}return{update:r}}function sg(s,t,e,n){let i=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(i.get(u)!==c&&(t.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),i.get(l)!==c&&(e.update(l.instanceMatrix,s.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,s.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){let f=l.skeleton;i.get(f)!==c&&(f.update(),i.set(f,c))}return u}function o(){i=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var Bu=new $e,Mu=new nr(1,1),zu=new Xs,Hu=new ho,Vu=new Ks,bu=[],Su=[],wu=new Float32Array(16),Eu=new Float32Array(9),Tu=new Float32Array(4);function vs(s,t,e){let n=s[0];if(n<=0||n>0)return s;let i=t*e,r=bu[i];if(r===void 0&&(r=new Float32Array(i),bu[i]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,s[o].toArray(r,a)}return r}function Ie(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Pe(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function Aa(s,t){let e=Su[t];e===void 0&&(e=new Int32Array(t),Su[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function rg(s,t){let e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function og(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ie(e,t))return;s.uniform2fv(this.addr,t),Pe(e,t)}}function ag(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ie(e,t))return;s.uniform3fv(this.addr,t),Pe(e,t)}}function lg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ie(e,t))return;s.uniform4fv(this.addr,t),Pe(e,t)}}function cg(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ie(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Pe(e,t)}else{if(Ie(e,n))return;Tu.set(n),s.uniformMatrix2fv(this.addr,!1,Tu),Pe(e,n)}}function hg(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ie(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Pe(e,t)}else{if(Ie(e,n))return;Eu.set(n),s.uniformMatrix3fv(this.addr,!1,Eu),Pe(e,n)}}function ug(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ie(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Pe(e,t)}else{if(Ie(e,n))return;wu.set(n),s.uniformMatrix4fv(this.addr,!1,wu),Pe(e,n)}}function dg(s,t){let e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function fg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ie(e,t))return;s.uniform2iv(this.addr,t),Pe(e,t)}}function pg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ie(e,t))return;s.uniform3iv(this.addr,t),Pe(e,t)}}function mg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ie(e,t))return;s.uniform4iv(this.addr,t),Pe(e,t)}}function gg(s,t){let e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function xg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ie(e,t))return;s.uniform2uiv(this.addr,t),Pe(e,t)}}function _g(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ie(e,t))return;s.uniform3uiv(this.addr,t),Pe(e,t)}}function vg(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ie(e,t))return;s.uniform4uiv(this.addr,t),Pe(e,t)}}function yg(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(Mu.compareFunction=Yl,r=Mu):r=Bu,e.setTexture2D(t||r,i)}function Mg(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Hu,i)}function bg(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Vu,i)}function Sg(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||zu,i)}function wg(s){switch(s){case 5126:return rg;case 35664:return og;case 35665:return ag;case 35666:return lg;case 35674:return cg;case 35675:return hg;case 35676:return ug;case 5124:case 35670:return dg;case 35667:case 35671:return fg;case 35668:case 35672:return pg;case 35669:case 35673:return mg;case 5125:return gg;case 36294:return xg;case 36295:return _g;case 36296:return vg;case 35678:case 36198:case 36298:case 36306:case 35682:return yg;case 35679:case 36299:case 36307:return Mg;case 35680:case 36300:case 36308:case 36293:return bg;case 36289:case 36303:case 36311:case 36292:return Sg}}function Eg(s,t){s.uniform1fv(this.addr,t)}function Tg(s,t){let e=vs(t,this.size,2);s.uniform2fv(this.addr,e)}function Ag(s,t){let e=vs(t,this.size,3);s.uniform3fv(this.addr,e)}function Cg(s,t){let e=vs(t,this.size,4);s.uniform4fv(this.addr,e)}function Rg(s,t){let e=vs(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function Ig(s,t){let e=vs(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function Pg(s,t){let e=vs(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function Lg(s,t){s.uniform1iv(this.addr,t)}function Dg(s,t){s.uniform2iv(this.addr,t)}function Ug(s,t){s.uniform3iv(this.addr,t)}function Ng(s,t){s.uniform4iv(this.addr,t)}function Fg(s,t){s.uniform1uiv(this.addr,t)}function kg(s,t){s.uniform2uiv(this.addr,t)}function Og(s,t){s.uniform3uiv(this.addr,t)}function Bg(s,t){s.uniform4uiv(this.addr,t)}function zg(s,t,e){let n=this.cache,i=t.length,r=Aa(e,i);Ie(n,r)||(s.uniform1iv(this.addr,r),Pe(n,r));for(let o=0;o!==i;++o)e.setTexture2D(t[o]||Bu,r[o])}function Hg(s,t,e){let n=this.cache,i=t.length,r=Aa(e,i);Ie(n,r)||(s.uniform1iv(this.addr,r),Pe(n,r));for(let o=0;o!==i;++o)e.setTexture3D(t[o]||Hu,r[o])}function Vg(s,t,e){let n=this.cache,i=t.length,r=Aa(e,i);Ie(n,r)||(s.uniform1iv(this.addr,r),Pe(n,r));for(let o=0;o!==i;++o)e.setTextureCube(t[o]||Vu,r[o])}function Gg(s,t,e){let n=this.cache,i=t.length,r=Aa(e,i);Ie(n,r)||(s.uniform1iv(this.addr,r),Pe(n,r));for(let o=0;o!==i;++o)e.setTexture2DArray(t[o]||zu,r[o])}function Wg(s){switch(s){case 5126:return Eg;case 35664:return Tg;case 35665:return Ag;case 35666:return Cg;case 35674:return Rg;case 35675:return Ig;case 35676:return Pg;case 5124:case 35670:return Lg;case 35667:case 35671:return Dg;case 35668:case 35672:return Ug;case 35669:case 35673:return Ng;case 5125:return Fg;case 36294:return kg;case 36295:return Og;case 36296:return Bg;case 35678:case 36198:case 36298:case 36306:case 35682:return zg;case 35679:case 36299:case 36307:return Hg;case 35680:case 36300:case 36308:case 36293:return Vg;case 36289:case 36303:case 36311:case 36292:return Gg}}var lc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=wg(e.type)}},cc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Wg(e.type)}},hc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let i=this.seq;for(let r=0,o=i.length;r!==o;++r){let a=i[r];a.setValue(t,e[a.id],n)}}},ac=/(\w+)(\])?(\[|\.)?/g;function Au(s,t){s.seq.push(t),s.map[t.id]=t}function Xg(s,t,e){let n=s.name,i=n.length;for(ac.lastIndex=0;;){let r=ac.exec(n),o=ac.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===i){Au(e,c===void 0?new lc(a,s,t):new cc(a,s,t));break}else{let u=e.map[a];u===void 0&&(u=new hc(a),Au(e,u)),e=u}}}var _s=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let r=t.getActiveUniform(e,i),o=t.getUniformLocation(e,r.name);Xg(r,o,this)}}setValue(t,e,n,i){let r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){let i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,i)}}static seqWithValue(t,e){let n=[];for(let i=0,r=t.length;i!==r;++i){let o=t[i];o.id in e&&n.push(o)}return n}};function Cu(s,t,e){let n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}var qg=37297,$g=0;function Yg(s,t){let e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=i;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}var Ru=new Ot;function Zg(s){$t._getMatrix(Ru,$t.workingColorSpace,s);let t=`mat3( ${Ru.elements.map(e=>e.toFixed(4))} )`;switch($t.getTransfer(s)){case Vs:return[t,"LinearTransferOETF"];case ne:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function Iu(s,t,e){let n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";let o=/ERROR: 0:(\d+)/.exec(r);if(o){let a=parseInt(o[1]);return e.toUpperCase()+`

`+r+`

`+Yg(s.getShaderSource(t),a)}else return r}function Jg(s,t){let e=Zg(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Kg(s,t){let e;switch(t){case Xh:e="Linear";break;case qh:e="Reinhard";break;case $h:e="Cineon";break;case Yh:e="ACESFilmic";break;case Jh:e="AgX";break;case Kh:e="Neutral";break;case Zh:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var wa=new D;function jg(){$t.getLuminanceCoefficients(wa);let s=wa.x.toFixed(4),t=wa.y.toFixed(4),e=wa.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Qg(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(mr).join(`
`)}function t0(s){let t=[];for(let e in s){let n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function e0(s,t){let e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let r=s.getActiveAttrib(t,i),o=r.name,a=1;r.type===s.FLOAT_MAT2&&(a=2),r.type===s.FLOAT_MAT3&&(a=3),r.type===s.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:s.getAttribLocation(t,o),locationSize:a}}return e}function mr(s){return s!==""}function Pu(s,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Lu(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var n0=/^[ \t]*#include +<([\w\d./]+)>/gm;function uc(s){return s.replace(n0,s0)}var i0=new Map;function s0(s,t){let e=Vt[t];if(e===void 0){let n=i0.get(t);if(n!==void 0)e=Vt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return uc(e)}var r0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Du(s){return s.replace(r0,o0)}function o0(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Uu(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function a0(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===Nl?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===wh?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Rn&&(t="SHADOWMAP_TYPE_VSM"),t}function l0(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case Ii:case Pi:t="ENVMAP_TYPE_CUBE";break;case cr:t="ENVMAP_TYPE_CUBE_UV";break}return t}function c0(s){let t="ENVMAP_MODE_REFLECTION";return s.envMap&&s.envMapMode===Pi&&(t="ENVMAP_MODE_REFRACTION"),t}function h0(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case ko:t="ENVMAP_BLENDING_MULTIPLY";break;case Gh:t="ENVMAP_BLENDING_MIX";break;case Wh:t="ENVMAP_BLENDING_ADD";break}return t}function u0(s){let t=s.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function d0(s,t,e,n){let i=s.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=a0(e),c=l0(e),h=c0(e),u=h0(e),f=u0(e),d=Qg(e),g=t0(r),x=i.createProgram(),m,p,S=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(mr).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g].filter(mr).join(`
`),p.length>0&&(p+=`
`)):(m=[Uu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(mr).join(`
`),p=[Uu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,g,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Wn?"#define TONE_MAPPING":"",e.toneMapping!==Wn?Vt.tonemapping_pars_fragment:"",e.toneMapping!==Wn?Kg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Vt.colorspace_pars_fragment,Jg("linearToOutputTexel",e.outputColorSpace),jg(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(mr).join(`
`)),o=uc(o),o=Pu(o,e),o=Lu(o,e),a=uc(a),a=Pu(a,e),a=Lu(a,e),o=Du(o),a=Du(a),e.isRawShaderMaterial!==!0&&(S=`#version 300 es
`,m=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",e.glslVersion===Jl?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Jl?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let y=S+m+o,v=S+p+a,T=Cu(i,i.VERTEX_SHADER,y),E=Cu(i,i.FRAGMENT_SHADER,v);i.attachShader(x,T),i.attachShader(x,E),e.index0AttributeName!==void 0?i.bindAttribLocation(x,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(x,0,"position"),i.linkProgram(x);function C(P){if(s.debug.checkShaderErrors){let k=i.getProgramInfoLog(x)||"",H=i.getShaderInfoLog(T)||"",W=i.getShaderInfoLog(E)||"",X=k.trim(),V=H.trim(),Q=W.trim(),O=!0,rt=!0;if(i.getProgramParameter(x,i.LINK_STATUS)===!1)if(O=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,x,T,E);else{let lt=Iu(i,T,"vertex"),pt=Iu(i,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(x,i.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+X+`
`+lt+`
`+pt)}else X!==""?console.warn("THREE.WebGLProgram: Program Info Log:",X):(V===""||Q==="")&&(rt=!1);rt&&(P.diagnostics={runnable:O,programLog:X,vertexShader:{log:V,prefix:m},fragmentShader:{log:Q,prefix:p}})}i.deleteShader(T),i.deleteShader(E),I=new _s(i,x),M=e0(i,x)}let I;this.getUniforms=function(){return I===void 0&&C(this),I};let M;this.getAttributes=function(){return M===void 0&&C(this),M};let w=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return w===!1&&(w=i.getProgramParameter(x,qg)),w},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(x),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=$g++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=T,this.fragmentShader=E,this}var f0=0,dc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new fc(t),e.set(t,n)),n}},fc=class{constructor(t){this.id=f0++,this.code=t,this.usedTimes=0}};function p0(s,t,e,n,i,r,o){let a=new $s,l=new dc,c=new Set,h=[],u=i.logarithmicDepthBuffer,f=i.vertexTextures,d=i.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(M){return c.add(M),M===0?"uv":`uv${M}`}function m(M,w,P,k,H){let W=k.fog,X=H.geometry,V=M.isMeshStandardMaterial?k.environment:null,Q=(M.isMeshStandardMaterial?e:t).get(M.envMap||V),O=Q&&Q.mapping===cr?Q.image.height:null,rt=g[M.type];M.precision!==null&&(d=i.getMaxPrecision(M.precision),d!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",d,"instead."));let lt=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,pt=lt!==void 0?lt.length:0,zt=0;X.morphAttributes.position!==void 0&&(zt=1),X.morphAttributes.normal!==void 0&&(zt=2),X.morphAttributes.color!==void 0&&(zt=3);let ee,ae,Kt,$;if(rt){let jt=In[rt];ee=jt.vertexShader,ae=jt.fragmentShader}else ee=M.vertexShader,ae=M.fragmentShader,l.update(M),Kt=l.getVertexShaderID(M),$=l.getFragmentShaderID(M);let j=s.getRenderTarget(),mt=s.state.buffers.depth.getReversed(),Ut=H.isInstancedMesh===!0,wt=H.isBatchedMesh===!0,qt=!!M.map,ze=!!M.matcap,R=!!Q,pe=!!M.aoMap,kt=!!M.lightMap,It=!!M.bumpMap,_t=!!M.normalMap,me=!!M.displacementMap,vt=!!M.emissiveMap,Ht=!!M.metalnessMap,Le=!!M.roughnessMap,Me=M.anisotropy>0,A=M.clearcoat>0,_=M.dispersion>0,F=M.iridescence>0,q=M.sheen>0,K=M.transmission>0,G=Me&&!!M.anisotropyMap,St=A&&!!M.clearcoatMap,st=A&&!!M.clearcoatNormalMap,yt=A&&!!M.clearcoatRoughnessMap,Mt=F&&!!M.iridescenceMap,nt=F&&!!M.iridescenceThicknessMap,ut=q&&!!M.sheenColorMap,Rt=q&&!!M.sheenRoughnessMap,bt=!!M.specularMap,ct=!!M.specularColorMap,Bt=!!M.specularIntensityMap,L=K&&!!M.transmissionMap,it=K&&!!M.thicknessMap,ot=!!M.gradientMap,ft=!!M.alphaMap,tt=M.alphaTest>0,Y=!!M.alphaHash,xt=!!M.extensions,Ft=Wn;M.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Ft=s.toneMapping);let le={shaderID:rt,shaderType:M.type,shaderName:M.name,vertexShader:ee,fragmentShader:ae,defines:M.defines,customVertexShaderID:Kt,customFragmentShaderID:$,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:d,batching:wt,batchingColor:wt&&H._colorsTexture!==null,instancing:Ut,instancingColor:Ut&&H.instanceColor!==null,instancingMorph:Ut&&H.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:j===null?s.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:Mi,alphaToCoverage:!!M.alphaToCoverage,map:qt,matcap:ze,envMap:R,envMapMode:R&&Q.mapping,envMapCubeUVHeight:O,aoMap:pe,lightMap:kt,bumpMap:It,normalMap:_t,displacementMap:f&&me,emissiveMap:vt,normalMapObjectSpace:_t&&M.normalMapType===eu,normalMapTangentSpace:_t&&M.normalMapType===$l,metalnessMap:Ht,roughnessMap:Le,anisotropy:Me,anisotropyMap:G,clearcoat:A,clearcoatMap:St,clearcoatNormalMap:st,clearcoatRoughnessMap:yt,dispersion:_,iridescence:F,iridescenceMap:Mt,iridescenceThicknessMap:nt,sheen:q,sheenColorMap:ut,sheenRoughnessMap:Rt,specularMap:bt,specularColorMap:ct,specularIntensityMap:Bt,transmission:K,transmissionMap:L,thicknessMap:it,gradientMap:ot,opaque:M.transparent===!1&&M.blending===vi&&M.alphaToCoverage===!1,alphaMap:ft,alphaTest:tt,alphaHash:Y,combine:M.combine,mapUv:qt&&x(M.map.channel),aoMapUv:pe&&x(M.aoMap.channel),lightMapUv:kt&&x(M.lightMap.channel),bumpMapUv:It&&x(M.bumpMap.channel),normalMapUv:_t&&x(M.normalMap.channel),displacementMapUv:me&&x(M.displacementMap.channel),emissiveMapUv:vt&&x(M.emissiveMap.channel),metalnessMapUv:Ht&&x(M.metalnessMap.channel),roughnessMapUv:Le&&x(M.roughnessMap.channel),anisotropyMapUv:G&&x(M.anisotropyMap.channel),clearcoatMapUv:St&&x(M.clearcoatMap.channel),clearcoatNormalMapUv:st&&x(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:yt&&x(M.clearcoatRoughnessMap.channel),iridescenceMapUv:Mt&&x(M.iridescenceMap.channel),iridescenceThicknessMapUv:nt&&x(M.iridescenceThicknessMap.channel),sheenColorMapUv:ut&&x(M.sheenColorMap.channel),sheenRoughnessMapUv:Rt&&x(M.sheenRoughnessMap.channel),specularMapUv:bt&&x(M.specularMap.channel),specularColorMapUv:ct&&x(M.specularColorMap.channel),specularIntensityMapUv:Bt&&x(M.specularIntensityMap.channel),transmissionMapUv:L&&x(M.transmissionMap.channel),thicknessMapUv:it&&x(M.thicknessMap.channel),alphaMapUv:ft&&x(M.alphaMap.channel),vertexTangents:!!X.attributes.tangent&&(_t||Me),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,pointsUvs:H.isPoints===!0&&!!X.attributes.uv&&(qt||ft),fog:!!W,useFog:M.fog===!0,fogExp2:!!W&&W.isFogExp2,flatShading:M.flatShading===!0&&M.wireframe===!1,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:mt,skinning:H.isSkinnedMesh===!0,morphTargets:X.morphAttributes.position!==void 0,morphNormals:X.morphAttributes.normal!==void 0,morphColors:X.morphAttributes.color!==void 0,morphTargetsCount:pt,morphTextureStride:zt,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:M.dithering,shadowMapEnabled:s.shadowMap.enabled&&P.length>0,shadowMapType:s.shadowMap.type,toneMapping:Ft,decodeVideoTexture:qt&&M.map.isVideoTexture===!0&&$t.getTransfer(M.map.colorSpace)===ne,decodeVideoTextureEmissive:vt&&M.emissiveMap.isVideoTexture===!0&&$t.getTransfer(M.emissiveMap.colorSpace)===ne,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===hn,flipSided:M.side===Be,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionClipCullDistance:xt&&M.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(xt&&M.extensions.multiDraw===!0||wt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()};return le.vertexUv1s=c.has(1),le.vertexUv2s=c.has(2),le.vertexUv3s=c.has(3),c.clear(),le}function p(M){let w=[];if(M.shaderID?w.push(M.shaderID):(w.push(M.customVertexShaderID),w.push(M.customFragmentShaderID)),M.defines!==void 0)for(let P in M.defines)w.push(P),w.push(M.defines[P]);return M.isRawShaderMaterial===!1&&(S(w,M),y(w,M),w.push(s.outputColorSpace)),w.push(M.customProgramCacheKey),w.join()}function S(M,w){M.push(w.precision),M.push(w.outputColorSpace),M.push(w.envMapMode),M.push(w.envMapCubeUVHeight),M.push(w.mapUv),M.push(w.alphaMapUv),M.push(w.lightMapUv),M.push(w.aoMapUv),M.push(w.bumpMapUv),M.push(w.normalMapUv),M.push(w.displacementMapUv),M.push(w.emissiveMapUv),M.push(w.metalnessMapUv),M.push(w.roughnessMapUv),M.push(w.anisotropyMapUv),M.push(w.clearcoatMapUv),M.push(w.clearcoatNormalMapUv),M.push(w.clearcoatRoughnessMapUv),M.push(w.iridescenceMapUv),M.push(w.iridescenceThicknessMapUv),M.push(w.sheenColorMapUv),M.push(w.sheenRoughnessMapUv),M.push(w.specularMapUv),M.push(w.specularColorMapUv),M.push(w.specularIntensityMapUv),M.push(w.transmissionMapUv),M.push(w.thicknessMapUv),M.push(w.combine),M.push(w.fogExp2),M.push(w.sizeAttenuation),M.push(w.morphTargetsCount),M.push(w.morphAttributeCount),M.push(w.numDirLights),M.push(w.numPointLights),M.push(w.numSpotLights),M.push(w.numSpotLightMaps),M.push(w.numHemiLights),M.push(w.numRectAreaLights),M.push(w.numDirLightShadows),M.push(w.numPointLightShadows),M.push(w.numSpotLightShadows),M.push(w.numSpotLightShadowsWithMaps),M.push(w.numLightProbes),M.push(w.shadowMapType),M.push(w.toneMapping),M.push(w.numClippingPlanes),M.push(w.numClipIntersection),M.push(w.depthPacking)}function y(M,w){a.disableAll(),w.supportsVertexTextures&&a.enable(0),w.instancing&&a.enable(1),w.instancingColor&&a.enable(2),w.instancingMorph&&a.enable(3),w.matcap&&a.enable(4),w.envMap&&a.enable(5),w.normalMapObjectSpace&&a.enable(6),w.normalMapTangentSpace&&a.enable(7),w.clearcoat&&a.enable(8),w.iridescence&&a.enable(9),w.alphaTest&&a.enable(10),w.vertexColors&&a.enable(11),w.vertexAlphas&&a.enable(12),w.vertexUv1s&&a.enable(13),w.vertexUv2s&&a.enable(14),w.vertexUv3s&&a.enable(15),w.vertexTangents&&a.enable(16),w.anisotropy&&a.enable(17),w.alphaHash&&a.enable(18),w.batching&&a.enable(19),w.dispersion&&a.enable(20),w.batchingColor&&a.enable(21),w.gradientMap&&a.enable(22),M.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reversedDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),M.push(a.mask)}function v(M){let w=g[M.type],P;if(w){let k=In[w];P=du.clone(k.uniforms)}else P=M.uniforms;return P}function T(M,w){let P;for(let k=0,H=h.length;k<H;k++){let W=h[k];if(W.cacheKey===w){P=W,++P.usedTimes;break}}return P===void 0&&(P=new d0(s,w,M,r),h.push(P)),P}function E(M){if(--M.usedTimes===0){let w=h.indexOf(M);h[w]=h[h.length-1],h.pop(),M.destroy()}}function C(M){l.remove(M)}function I(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:T,releaseProgram:E,releaseShaderCache:C,programs:h,dispose:I}}function m0(){let s=new WeakMap;function t(o){return s.has(o)}function e(o){let a=s.get(o);return a===void 0&&(a={},s.set(o,a)),a}function n(o){s.delete(o)}function i(o,a,l){s.get(o)[a]=l}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function g0(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function Nu(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Fu(){let s=[],t=0,e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function o(u,f,d,g,x,m){let p=s[t];return p===void 0?(p={id:u.id,object:u,geometry:f,material:d,groupOrder:g,renderOrder:u.renderOrder,z:x,group:m},s[t]=p):(p.id=u.id,p.object=u,p.geometry=f,p.material=d,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=x,p.group=m),t++,p}function a(u,f,d,g,x,m){let p=o(u,f,d,g,x,m);d.transmission>0?n.push(p):d.transparent===!0?i.push(p):e.push(p)}function l(u,f,d,g,x,m){let p=o(u,f,d,g,x,m);d.transmission>0?n.unshift(p):d.transparent===!0?i.unshift(p):e.unshift(p)}function c(u,f){e.length>1&&e.sort(u||g0),n.length>1&&n.sort(f||Nu),i.length>1&&i.sort(f||Nu)}function h(){for(let u=t,f=s.length;u<f;u++){let d=s[u];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:a,unshift:l,finish:h,sort:c}}function x0(){let s=new WeakMap;function t(n,i){let r=s.get(n),o;return r===void 0?(o=new Fu,s.set(n,[o])):i>=r.length?(o=new Fu,r.push(o)):o=r[i],o}function e(){s=new WeakMap}return{get:t,dispose:e}}function _0(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new D,color:new Lt};break;case"SpotLight":e={position:new D,direction:new D,color:new Lt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new D,color:new Lt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new D,skyColor:new Lt,groundColor:new Lt};break;case"RectAreaLight":e={color:new Lt,position:new D,halfWidth:new D,halfHeight:new D};break}return s[t.id]=e,e}}}function v0(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}var y0=0;function M0(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function b0(s){let t=new _0,e=v0(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new D);let i=new D,r=new Qt,o=new Qt;function a(c){let h=0,u=0,f=0;for(let M=0;M<9;M++)n.probe[M].set(0,0,0);let d=0,g=0,x=0,m=0,p=0,S=0,y=0,v=0,T=0,E=0,C=0;c.sort(M0);for(let M=0,w=c.length;M<w;M++){let P=c[M],k=P.color,H=P.intensity,W=P.distance,X=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)h+=k.r*H,u+=k.g*H,f+=k.b*H;else if(P.isLightProbe){for(let V=0;V<9;V++)n.probe[V].addScaledVector(P.sh.coefficients[V],H);C++}else if(P.isDirectionalLight){let V=t.get(P);if(V.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){let Q=P.shadow,O=e.get(P);O.shadowIntensity=Q.intensity,O.shadowBias=Q.bias,O.shadowNormalBias=Q.normalBias,O.shadowRadius=Q.radius,O.shadowMapSize=Q.mapSize,n.directionalShadow[d]=O,n.directionalShadowMap[d]=X,n.directionalShadowMatrix[d]=P.shadow.matrix,S++}n.directional[d]=V,d++}else if(P.isSpotLight){let V=t.get(P);V.position.setFromMatrixPosition(P.matrixWorld),V.color.copy(k).multiplyScalar(H),V.distance=W,V.coneCos=Math.cos(P.angle),V.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),V.decay=P.decay,n.spot[x]=V;let Q=P.shadow;if(P.map&&(n.spotLightMap[T]=P.map,T++,Q.updateMatrices(P),P.castShadow&&E++),n.spotLightMatrix[x]=Q.matrix,P.castShadow){let O=e.get(P);O.shadowIntensity=Q.intensity,O.shadowBias=Q.bias,O.shadowNormalBias=Q.normalBias,O.shadowRadius=Q.radius,O.shadowMapSize=Q.mapSize,n.spotShadow[x]=O,n.spotShadowMap[x]=X,v++}x++}else if(P.isRectAreaLight){let V=t.get(P);V.color.copy(k).multiplyScalar(H),V.halfWidth.set(P.width*.5,0,0),V.halfHeight.set(0,P.height*.5,0),n.rectArea[m]=V,m++}else if(P.isPointLight){let V=t.get(P);if(V.color.copy(P.color).multiplyScalar(P.intensity),V.distance=P.distance,V.decay=P.decay,P.castShadow){let Q=P.shadow,O=e.get(P);O.shadowIntensity=Q.intensity,O.shadowBias=Q.bias,O.shadowNormalBias=Q.normalBias,O.shadowRadius=Q.radius,O.shadowMapSize=Q.mapSize,O.shadowCameraNear=Q.camera.near,O.shadowCameraFar=Q.camera.far,n.pointShadow[g]=O,n.pointShadowMap[g]=X,n.pointShadowMatrix[g]=P.shadow.matrix,y++}n.point[g]=V,g++}else if(P.isHemisphereLight){let V=t.get(P);V.skyColor.copy(P.color).multiplyScalar(H),V.groundColor.copy(P.groundColor).multiplyScalar(H),n.hemi[p]=V,p++}}m>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=at.LTC_FLOAT_1,n.rectAreaLTC2=at.LTC_FLOAT_2):(n.rectAreaLTC1=at.LTC_HALF_1,n.rectAreaLTC2=at.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=f;let I=n.hash;(I.directionalLength!==d||I.pointLength!==g||I.spotLength!==x||I.rectAreaLength!==m||I.hemiLength!==p||I.numDirectionalShadows!==S||I.numPointShadows!==y||I.numSpotShadows!==v||I.numSpotMaps!==T||I.numLightProbes!==C)&&(n.directional.length=d,n.spot.length=x,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=S,n.directionalShadowMap.length=S,n.pointShadow.length=y,n.pointShadowMap.length=y,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=S,n.pointShadowMatrix.length=y,n.spotLightMatrix.length=v+T-E,n.spotLightMap.length=T,n.numSpotLightShadowsWithMaps=E,n.numLightProbes=C,I.directionalLength=d,I.pointLength=g,I.spotLength=x,I.rectAreaLength=m,I.hemiLength=p,I.numDirectionalShadows=S,I.numPointShadows=y,I.numSpotShadows=v,I.numSpotMaps=T,I.numLightProbes=C,n.version=y0++)}function l(c,h){let u=0,f=0,d=0,g=0,x=0,m=h.matrixWorldInverse;for(let p=0,S=c.length;p<S;p++){let y=c[p];if(y.isDirectionalLight){let v=n.directional[u];v.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(m),u++}else if(y.isSpotLight){let v=n.spot[d];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),v.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(m),d++}else if(y.isRectAreaLight){let v=n.rectArea[g];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),o.identity(),r.copy(y.matrixWorld),r.premultiply(m),o.extractRotation(r),v.halfWidth.set(y.width*.5,0,0),v.halfHeight.set(0,y.height*.5,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),g++}else if(y.isPointLight){let v=n.point[f];v.position.setFromMatrixPosition(y.matrixWorld),v.position.applyMatrix4(m),f++}else if(y.isHemisphereLight){let v=n.hemi[x];v.direction.setFromMatrixPosition(y.matrixWorld),v.direction.transformDirection(m),x++}}}return{setup:a,setupView:l,state:n}}function ku(s){let t=new b0(s),e=[],n=[];function i(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function S0(s){let t=new WeakMap;function e(i,r=0){let o=t.get(i),a;return o===void 0?(a=new ku(s),t.set(i,[a])):r>=o.length?(a=new ku(s),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}var w0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,E0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function T0(s,t,e){let n=new cs,i=new Nt,r=new Nt,o=new ve,a=new _o({depthPacking:tu}),l=new vo,c={},h=e.maxTextureSize,u={[Bn]:Be,[Be]:Bn,[hn]:hn},f=new _n({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Nt},radius:{value:4}},vertexShader:w0,fragmentShader:E0}),d=f.clone();d.defines.HORIZONTAL_PASS=1;let g=new ke;g.setAttribute("position",new Ee(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new ie(g,f),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Nl;let p=this.type;this.render=function(E,C,I){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;let M=s.getRenderTarget(),w=s.getActiveCubeFace(),P=s.getActiveMipmapLevel(),k=s.state;k.setBlending(Gn),k.buffers.depth.getReversed()===!0?k.buffers.color.setClear(0,0,0,0):k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);let H=p!==Rn&&this.type===Rn,W=p===Rn&&this.type!==Rn;for(let X=0,V=E.length;X<V;X++){let Q=E[X],O=Q.shadow;if(O===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(O.autoUpdate===!1&&O.needsUpdate===!1)continue;i.copy(O.mapSize);let rt=O.getFrameExtents();if(i.multiply(rt),r.copy(O.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/rt.x),i.x=r.x*rt.x,O.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/rt.y),i.y=r.y*rt.y,O.mapSize.y=r.y)),O.map===null||H===!0||W===!0){let pt=this.type!==Rn?{minFilter:Te,magFilter:Te}:{};O.map!==null&&O.map.dispose(),O.map=new Tn(i.x,i.y,pt),O.map.texture.name=Q.name+".shadowMap",O.camera.updateProjectionMatrix()}s.setRenderTarget(O.map),s.clear();let lt=O.getViewportCount();for(let pt=0;pt<lt;pt++){let zt=O.getViewport(pt);o.set(r.x*zt.x,r.y*zt.y,r.x*zt.z,r.y*zt.w),k.viewport(o),O.updateMatrices(Q,pt),n=O.getFrustum(),v(C,I,O.camera,Q,this.type)}O.isPointLightShadow!==!0&&this.type===Rn&&S(O,I),O.needsUpdate=!1}p=this.type,m.needsUpdate=!1,s.setRenderTarget(M,w,P)};function S(E,C){let I=t.update(x);f.defines.VSM_SAMPLES!==E.blurSamples&&(f.defines.VSM_SAMPLES=E.blurSamples,d.defines.VSM_SAMPLES=E.blurSamples,f.needsUpdate=!0,d.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new Tn(i.x,i.y)),f.uniforms.shadow_pass.value=E.map.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,s.setRenderTarget(E.mapPass),s.clear(),s.renderBufferDirect(C,null,I,f,x,null),d.uniforms.shadow_pass.value=E.mapPass.texture,d.uniforms.resolution.value=E.mapSize,d.uniforms.radius.value=E.radius,s.setRenderTarget(E.map),s.clear(),s.renderBufferDirect(C,null,I,d,x,null)}function y(E,C,I,M){let w=null,P=I.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(P!==void 0)w=P;else if(w=I.isPointLight===!0?l:a,s.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0||C.alphaToCoverage===!0){let k=w.uuid,H=C.uuid,W=c[k];W===void 0&&(W={},c[k]=W);let X=W[H];X===void 0&&(X=w.clone(),W[H]=X,C.addEventListener("dispose",T)),w=X}if(w.visible=C.visible,w.wireframe=C.wireframe,M===Rn?w.side=C.shadowSide!==null?C.shadowSide:C.side:w.side=C.shadowSide!==null?C.shadowSide:u[C.side],w.alphaMap=C.alphaMap,w.alphaTest=C.alphaToCoverage===!0?.5:C.alphaTest,w.map=C.map,w.clipShadows=C.clipShadows,w.clippingPlanes=C.clippingPlanes,w.clipIntersection=C.clipIntersection,w.displacementMap=C.displacementMap,w.displacementScale=C.displacementScale,w.displacementBias=C.displacementBias,w.wireframeLinewidth=C.wireframeLinewidth,w.linewidth=C.linewidth,I.isPointLight===!0&&w.isMeshDistanceMaterial===!0){let k=s.properties.get(w);k.light=I}return w}function v(E,C,I,M,w){if(E.visible===!1)return;if(E.layers.test(C.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&w===Rn)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(I.matrixWorldInverse,E.matrixWorld);let H=t.update(E),W=E.material;if(Array.isArray(W)){let X=H.groups;for(let V=0,Q=X.length;V<Q;V++){let O=X[V],rt=W[O.materialIndex];if(rt&&rt.visible){let lt=y(E,rt,M,w);E.onBeforeShadow(s,E,C,I,H,lt,O),s.renderBufferDirect(I,null,H,lt,E,O),E.onAfterShadow(s,E,C,I,H,lt,O)}}}else if(W.visible){let X=y(E,W,M,w);E.onBeforeShadow(s,E,C,I,H,X,null),s.renderBufferDirect(I,null,H,X,E,null),E.onAfterShadow(s,E,C,I,H,X,null)}}let k=E.children;for(let H=0,W=k.length;H<W;H++)v(k[H],C,I,M,w)}function T(E){E.target.removeEventListener("dispose",T);for(let I in c){let M=c[I],w=E.target.uuid;w in M&&(M[w].dispose(),delete M[w])}}}var A0={[Io]:Po,[Lo]:No,[Do]:Fo,[yi]:Uo,[Po]:Io,[No]:Lo,[Fo]:Do,[Uo]:yi};function C0(s,t){function e(){let L=!1,it=new ve,ot=null,ft=new ve(0,0,0,0);return{setMask:function(tt){ot!==tt&&!L&&(s.colorMask(tt,tt,tt,tt),ot=tt)},setLocked:function(tt){L=tt},setClear:function(tt,Y,xt,Ft,le){le===!0&&(tt*=Ft,Y*=Ft,xt*=Ft),it.set(tt,Y,xt,Ft),ft.equals(it)===!1&&(s.clearColor(tt,Y,xt,Ft),ft.copy(it))},reset:function(){L=!1,ot=null,ft.set(-1,0,0,0)}}}function n(){let L=!1,it=!1,ot=null,ft=null,tt=null;return{setReversed:function(Y){if(it!==Y){let xt=t.get("EXT_clip_control");Y?xt.clipControlEXT(xt.LOWER_LEFT_EXT,xt.ZERO_TO_ONE_EXT):xt.clipControlEXT(xt.LOWER_LEFT_EXT,xt.NEGATIVE_ONE_TO_ONE_EXT),it=Y;let Ft=tt;tt=null,this.setClear(Ft)}},getReversed:function(){return it},setTest:function(Y){Y?j(s.DEPTH_TEST):mt(s.DEPTH_TEST)},setMask:function(Y){ot!==Y&&!L&&(s.depthMask(Y),ot=Y)},setFunc:function(Y){if(it&&(Y=A0[Y]),ft!==Y){switch(Y){case Io:s.depthFunc(s.NEVER);break;case Po:s.depthFunc(s.ALWAYS);break;case Lo:s.depthFunc(s.LESS);break;case yi:s.depthFunc(s.LEQUAL);break;case Do:s.depthFunc(s.EQUAL);break;case Uo:s.depthFunc(s.GEQUAL);break;case No:s.depthFunc(s.GREATER);break;case Fo:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}ft=Y}},setLocked:function(Y){L=Y},setClear:function(Y){tt!==Y&&(it&&(Y=1-Y),s.clearDepth(Y),tt=Y)},reset:function(){L=!1,ot=null,ft=null,tt=null,it=!1}}}function i(){let L=!1,it=null,ot=null,ft=null,tt=null,Y=null,xt=null,Ft=null,le=null;return{setTest:function(jt){L||(jt?j(s.STENCIL_TEST):mt(s.STENCIL_TEST))},setMask:function(jt){it!==jt&&!L&&(s.stencilMask(jt),it=jt)},setFunc:function(jt,Pn,bn){(ot!==jt||ft!==Pn||tt!==bn)&&(s.stencilFunc(jt,Pn,bn),ot=jt,ft=Pn,tt=bn)},setOp:function(jt,Pn,bn){(Y!==jt||xt!==Pn||Ft!==bn)&&(s.stencilOp(jt,Pn,bn),Y=jt,xt=Pn,Ft=bn)},setLocked:function(jt){L=jt},setClear:function(jt){le!==jt&&(s.clearStencil(jt),le=jt)},reset:function(){L=!1,it=null,ot=null,ft=null,tt=null,Y=null,xt=null,Ft=null,le=null}}}let r=new e,o=new n,a=new i,l=new WeakMap,c=new WeakMap,h={},u={},f=new WeakMap,d=[],g=null,x=!1,m=null,p=null,S=null,y=null,v=null,T=null,E=null,C=new Lt(0,0,0),I=0,M=!1,w=null,P=null,k=null,H=null,W=null,X=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),V=!1,Q=0,O=s.getParameter(s.VERSION);O.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(O)[1]),V=Q>=1):O.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(O)[1]),V=Q>=2);let rt=null,lt={},pt=s.getParameter(s.SCISSOR_BOX),zt=s.getParameter(s.VIEWPORT),ee=new ve().fromArray(pt),ae=new ve().fromArray(zt);function Kt(L,it,ot,ft){let tt=new Uint8Array(4),Y=s.createTexture();s.bindTexture(L,Y),s.texParameteri(L,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(L,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let xt=0;xt<ot;xt++)L===s.TEXTURE_3D||L===s.TEXTURE_2D_ARRAY?s.texImage3D(it,0,s.RGBA,1,1,ft,0,s.RGBA,s.UNSIGNED_BYTE,tt):s.texImage2D(it+xt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,tt);return Y}let $={};$[s.TEXTURE_2D]=Kt(s.TEXTURE_2D,s.TEXTURE_2D,1),$[s.TEXTURE_CUBE_MAP]=Kt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),$[s.TEXTURE_2D_ARRAY]=Kt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),$[s.TEXTURE_3D]=Kt(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),j(s.DEPTH_TEST),o.setFunc(yi),It(!1),_t(Ul),j(s.CULL_FACE),pe(Gn);function j(L){h[L]!==!0&&(s.enable(L),h[L]=!0)}function mt(L){h[L]!==!1&&(s.disable(L),h[L]=!1)}function Ut(L,it){return u[L]!==it?(s.bindFramebuffer(L,it),u[L]=it,L===s.DRAW_FRAMEBUFFER&&(u[s.FRAMEBUFFER]=it),L===s.FRAMEBUFFER&&(u[s.DRAW_FRAMEBUFFER]=it),!0):!1}function wt(L,it){let ot=d,ft=!1;if(L){ot=f.get(it),ot===void 0&&(ot=[],f.set(it,ot));let tt=L.textures;if(ot.length!==tt.length||ot[0]!==s.COLOR_ATTACHMENT0){for(let Y=0,xt=tt.length;Y<xt;Y++)ot[Y]=s.COLOR_ATTACHMENT0+Y;ot.length=tt.length,ft=!0}}else ot[0]!==s.BACK&&(ot[0]=s.BACK,ft=!0);ft&&s.drawBuffers(ot)}function qt(L){return g!==L?(s.useProgram(L),g=L,!0):!1}let ze={[ii]:s.FUNC_ADD,[Th]:s.FUNC_SUBTRACT,[Ah]:s.FUNC_REVERSE_SUBTRACT};ze[Ch]=s.MIN,ze[Rh]=s.MAX;let R={[Ih]:s.ZERO,[Ph]:s.ONE,[Lh]:s.SRC_COLOR,[eo]:s.SRC_ALPHA,[Oh]:s.SRC_ALPHA_SATURATE,[Fh]:s.DST_COLOR,[Uh]:s.DST_ALPHA,[Dh]:s.ONE_MINUS_SRC_COLOR,[no]:s.ONE_MINUS_SRC_ALPHA,[kh]:s.ONE_MINUS_DST_COLOR,[Nh]:s.ONE_MINUS_DST_ALPHA,[Bh]:s.CONSTANT_COLOR,[zh]:s.ONE_MINUS_CONSTANT_COLOR,[Hh]:s.CONSTANT_ALPHA,[Vh]:s.ONE_MINUS_CONSTANT_ALPHA};function pe(L,it,ot,ft,tt,Y,xt,Ft,le,jt){if(L===Gn){x===!0&&(mt(s.BLEND),x=!1);return}if(x===!1&&(j(s.BLEND),x=!0),L!==Eh){if(L!==m||jt!==M){if((p!==ii||v!==ii)&&(s.blendEquation(s.FUNC_ADD),p=ii,v=ii),jt)switch(L){case vi:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Fl:s.blendFunc(s.ONE,s.ONE);break;case kl:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Ol:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}else switch(L){case vi:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Fl:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case kl:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Ol:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",L);break}S=null,y=null,T=null,E=null,C.set(0,0,0),I=0,m=L,M=jt}return}tt=tt||it,Y=Y||ot,xt=xt||ft,(it!==p||tt!==v)&&(s.blendEquationSeparate(ze[it],ze[tt]),p=it,v=tt),(ot!==S||ft!==y||Y!==T||xt!==E)&&(s.blendFuncSeparate(R[ot],R[ft],R[Y],R[xt]),S=ot,y=ft,T=Y,E=xt),(Ft.equals(C)===!1||le!==I)&&(s.blendColor(Ft.r,Ft.g,Ft.b,le),C.copy(Ft),I=le),m=L,M=!1}function kt(L,it){L.side===hn?mt(s.CULL_FACE):j(s.CULL_FACE);let ot=L.side===Be;it&&(ot=!ot),It(ot),L.blending===vi&&L.transparent===!1?pe(Gn):pe(L.blending,L.blendEquation,L.blendSrc,L.blendDst,L.blendEquationAlpha,L.blendSrcAlpha,L.blendDstAlpha,L.blendColor,L.blendAlpha,L.premultipliedAlpha),o.setFunc(L.depthFunc),o.setTest(L.depthTest),o.setMask(L.depthWrite),r.setMask(L.colorWrite);let ft=L.stencilWrite;a.setTest(ft),ft&&(a.setMask(L.stencilWriteMask),a.setFunc(L.stencilFunc,L.stencilRef,L.stencilFuncMask),a.setOp(L.stencilFail,L.stencilZFail,L.stencilZPass)),vt(L.polygonOffset,L.polygonOffsetFactor,L.polygonOffsetUnits),L.alphaToCoverage===!0?j(s.SAMPLE_ALPHA_TO_COVERAGE):mt(s.SAMPLE_ALPHA_TO_COVERAGE)}function It(L){w!==L&&(L?s.frontFace(s.CW):s.frontFace(s.CCW),w=L)}function _t(L){L!==bh?(j(s.CULL_FACE),L!==P&&(L===Ul?s.cullFace(s.BACK):L===Sh?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):mt(s.CULL_FACE),P=L}function me(L){L!==k&&(V&&s.lineWidth(L),k=L)}function vt(L,it,ot){L?(j(s.POLYGON_OFFSET_FILL),(H!==it||W!==ot)&&(s.polygonOffset(it,ot),H=it,W=ot)):mt(s.POLYGON_OFFSET_FILL)}function Ht(L){L?j(s.SCISSOR_TEST):mt(s.SCISSOR_TEST)}function Le(L){L===void 0&&(L=s.TEXTURE0+X-1),rt!==L&&(s.activeTexture(L),rt=L)}function Me(L,it,ot){ot===void 0&&(rt===null?ot=s.TEXTURE0+X-1:ot=rt);let ft=lt[ot];ft===void 0&&(ft={type:void 0,texture:void 0},lt[ot]=ft),(ft.type!==L||ft.texture!==it)&&(rt!==ot&&(s.activeTexture(ot),rt=ot),s.bindTexture(L,it||$[L]),ft.type=L,ft.texture=it)}function A(){let L=lt[rt];L!==void 0&&L.type!==void 0&&(s.bindTexture(L.type,null),L.type=void 0,L.texture=void 0)}function _(){try{s.compressedTexImage2D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function F(){try{s.compressedTexImage3D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function q(){try{s.texSubImage2D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function K(){try{s.texSubImage3D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function G(){try{s.compressedTexSubImage2D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function St(){try{s.compressedTexSubImage3D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function st(){try{s.texStorage2D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function yt(){try{s.texStorage3D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function Mt(){try{s.texImage2D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function nt(){try{s.texImage3D(...arguments)}catch(L){console.error("THREE.WebGLState:",L)}}function ut(L){ee.equals(L)===!1&&(s.scissor(L.x,L.y,L.z,L.w),ee.copy(L))}function Rt(L){ae.equals(L)===!1&&(s.viewport(L.x,L.y,L.z,L.w),ae.copy(L))}function bt(L,it){let ot=c.get(it);ot===void 0&&(ot=new WeakMap,c.set(it,ot));let ft=ot.get(L);ft===void 0&&(ft=s.getUniformBlockIndex(it,L.name),ot.set(L,ft))}function ct(L,it){let ft=c.get(it).get(L);l.get(it)!==ft&&(s.uniformBlockBinding(it,ft,L.__bindingPointIndex),l.set(it,ft))}function Bt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),o.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},rt=null,lt={},u={},f=new WeakMap,d=[],g=null,x=!1,m=null,p=null,S=null,y=null,v=null,T=null,E=null,C=new Lt(0,0,0),I=0,M=!1,w=null,P=null,k=null,H=null,W=null,ee.set(0,0,s.canvas.width,s.canvas.height),ae.set(0,0,s.canvas.width,s.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:j,disable:mt,bindFramebuffer:Ut,drawBuffers:wt,useProgram:qt,setBlending:pe,setMaterial:kt,setFlipSided:It,setCullFace:_t,setLineWidth:me,setPolygonOffset:vt,setScissorTest:Ht,activeTexture:Le,bindTexture:Me,unbindTexture:A,compressedTexImage2D:_,compressedTexImage3D:F,texImage2D:Mt,texImage3D:nt,updateUBOMapping:bt,uniformBlockBinding:ct,texStorage2D:st,texStorage3D:yt,texSubImage2D:q,texSubImage3D:K,compressedTexSubImage2D:G,compressedTexSubImage3D:St,scissor:ut,viewport:Rt,reset:Bt}}function R0(s,t,e,n,i,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Nt,h=new WeakMap,u,f=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,_){return d?new OffscreenCanvas(A,_):Ws("canvas")}function x(A,_,F){let q=1,K=Me(A);if((K.width>F||K.height>F)&&(q=F/Math.max(K.width,K.height)),q<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){let G=Math.floor(q*K.width),St=Math.floor(q*K.height);u===void 0&&(u=g(G,St));let st=_?g(G,St):u;return st.width=G,st.height=St,st.getContext("2d").drawImage(A,0,0,G,St),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+K.width+"x"+K.height+") to ("+G+"x"+St+")."),st}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+K.width+"x"+K.height+")."),A;return A}function m(A){return A.generateMipmaps}function p(A){s.generateMipmap(A)}function S(A){return A.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?s.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function y(A,_,F,q,K=!1){if(A!==null){if(s[A]!==void 0)return s[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let G=_;if(_===s.RED&&(F===s.FLOAT&&(G=s.R32F),F===s.HALF_FLOAT&&(G=s.R16F),F===s.UNSIGNED_BYTE&&(G=s.R8)),_===s.RED_INTEGER&&(F===s.UNSIGNED_BYTE&&(G=s.R8UI),F===s.UNSIGNED_SHORT&&(G=s.R16UI),F===s.UNSIGNED_INT&&(G=s.R32UI),F===s.BYTE&&(G=s.R8I),F===s.SHORT&&(G=s.R16I),F===s.INT&&(G=s.R32I)),_===s.RG&&(F===s.FLOAT&&(G=s.RG32F),F===s.HALF_FLOAT&&(G=s.RG16F),F===s.UNSIGNED_BYTE&&(G=s.RG8)),_===s.RG_INTEGER&&(F===s.UNSIGNED_BYTE&&(G=s.RG8UI),F===s.UNSIGNED_SHORT&&(G=s.RG16UI),F===s.UNSIGNED_INT&&(G=s.RG32UI),F===s.BYTE&&(G=s.RG8I),F===s.SHORT&&(G=s.RG16I),F===s.INT&&(G=s.RG32I)),_===s.RGB_INTEGER&&(F===s.UNSIGNED_BYTE&&(G=s.RGB8UI),F===s.UNSIGNED_SHORT&&(G=s.RGB16UI),F===s.UNSIGNED_INT&&(G=s.RGB32UI),F===s.BYTE&&(G=s.RGB8I),F===s.SHORT&&(G=s.RGB16I),F===s.INT&&(G=s.RGB32I)),_===s.RGBA_INTEGER&&(F===s.UNSIGNED_BYTE&&(G=s.RGBA8UI),F===s.UNSIGNED_SHORT&&(G=s.RGBA16UI),F===s.UNSIGNED_INT&&(G=s.RGBA32UI),F===s.BYTE&&(G=s.RGBA8I),F===s.SHORT&&(G=s.RGBA16I),F===s.INT&&(G=s.RGBA32I)),_===s.RGB&&(F===s.UNSIGNED_INT_5_9_9_9_REV&&(G=s.RGB9_E5),F===s.UNSIGNED_INT_10F_11F_11F_REV&&(G=s.R11F_G11F_B10F)),_===s.RGBA){let St=K?Vs:$t.getTransfer(q);F===s.FLOAT&&(G=s.RGBA32F),F===s.HALF_FLOAT&&(G=s.RGBA16F),F===s.UNSIGNED_BYTE&&(G=St===ne?s.SRGB8_ALPHA8:s.RGBA8),F===s.UNSIGNED_SHORT_4_4_4_4&&(G=s.RGBA4),F===s.UNSIGNED_SHORT_5_5_5_1&&(G=s.RGB5_A1)}return(G===s.R16F||G===s.R32F||G===s.RG16F||G===s.RG32F||G===s.RGBA16F||G===s.RGBA32F)&&t.get("EXT_color_buffer_float"),G}function v(A,_){let F;return A?_===null||_===ai||_===ps?F=s.DEPTH24_STENCIL8:_===yn?F=s.DEPTH32F_STENCIL8:_===ds&&(F=s.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===ai||_===ps?F=s.DEPTH_COMPONENT24:_===yn?F=s.DEPTH_COMPONENT32F:_===ds&&(F=s.DEPTH_COMPONENT16),F}function T(A,_){return m(A)===!0||A.isFramebufferTexture&&A.minFilter!==Te&&A.minFilter!==gn?Math.log2(Math.max(_.width,_.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?_.mipmaps.length:1}function E(A){let _=A.target;_.removeEventListener("dispose",E),I(_),_.isVideoTexture&&h.delete(_)}function C(A){let _=A.target;_.removeEventListener("dispose",C),w(_)}function I(A){let _=n.get(A);if(_.__webglInit===void 0)return;let F=A.source,q=f.get(F);if(q){let K=q[_.__cacheKey];K.usedTimes--,K.usedTimes===0&&M(A),Object.keys(q).length===0&&f.delete(F)}n.remove(A)}function M(A){let _=n.get(A);s.deleteTexture(_.__webglTexture);let F=A.source,q=f.get(F);delete q[_.__cacheKey],o.memory.textures--}function w(A){let _=n.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),n.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(_.__webglFramebuffer[q]))for(let K=0;K<_.__webglFramebuffer[q].length;K++)s.deleteFramebuffer(_.__webglFramebuffer[q][K]);else s.deleteFramebuffer(_.__webglFramebuffer[q]);_.__webglDepthbuffer&&s.deleteRenderbuffer(_.__webglDepthbuffer[q])}else{if(Array.isArray(_.__webglFramebuffer))for(let q=0;q<_.__webglFramebuffer.length;q++)s.deleteFramebuffer(_.__webglFramebuffer[q]);else s.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&s.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&s.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let q=0;q<_.__webglColorRenderbuffer.length;q++)_.__webglColorRenderbuffer[q]&&s.deleteRenderbuffer(_.__webglColorRenderbuffer[q]);_.__webglDepthRenderbuffer&&s.deleteRenderbuffer(_.__webglDepthRenderbuffer)}let F=A.textures;for(let q=0,K=F.length;q<K;q++){let G=n.get(F[q]);G.__webglTexture&&(s.deleteTexture(G.__webglTexture),o.memory.textures--),n.remove(F[q])}n.remove(A)}let P=0;function k(){P=0}function H(){let A=P;return A>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+i.maxTextures),P+=1,A}function W(A){let _=[];return _.push(A.wrapS),_.push(A.wrapT),_.push(A.wrapR||0),_.push(A.magFilter),_.push(A.minFilter),_.push(A.anisotropy),_.push(A.internalFormat),_.push(A.format),_.push(A.type),_.push(A.generateMipmaps),_.push(A.premultiplyAlpha),_.push(A.flipY),_.push(A.unpackAlignment),_.push(A.colorSpace),_.join()}function X(A,_){let F=n.get(A);if(A.isVideoTexture&&Ht(A),A.isRenderTargetTexture===!1&&A.isExternalTexture!==!0&&A.version>0&&F.__version!==A.version){let q=A.image;if(q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{$(F,A,_);return}}else A.isExternalTexture&&(F.__webglTexture=A.sourceTexture?A.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,F.__webglTexture,s.TEXTURE0+_)}function V(A,_){let F=n.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&F.__version!==A.version){$(F,A,_);return}e.bindTexture(s.TEXTURE_2D_ARRAY,F.__webglTexture,s.TEXTURE0+_)}function Q(A,_){let F=n.get(A);if(A.isRenderTargetTexture===!1&&A.version>0&&F.__version!==A.version){$(F,A,_);return}e.bindTexture(s.TEXTURE_3D,F.__webglTexture,s.TEXTURE0+_)}function O(A,_){let F=n.get(A);if(A.version>0&&F.__version!==A.version){j(F,A,_);return}e.bindTexture(s.TEXTURE_CUBE_MAP,F.__webglTexture,s.TEXTURE0+_)}let rt={[io]:s.REPEAT,[ei]:s.CLAMP_TO_EDGE,[so]:s.MIRRORED_REPEAT},lt={[Te]:s.NEAREST,[jh]:s.NEAREST_MIPMAP_NEAREST,[hr]:s.NEAREST_MIPMAP_LINEAR,[gn]:s.LINEAR,[zo]:s.LINEAR_MIPMAP_NEAREST,[oi]:s.LINEAR_MIPMAP_LINEAR},pt={[nu]:s.NEVER,[lu]:s.ALWAYS,[iu]:s.LESS,[Yl]:s.LEQUAL,[su]:s.EQUAL,[au]:s.GEQUAL,[ru]:s.GREATER,[ou]:s.NOTEQUAL};function zt(A,_){if(_.type===yn&&t.has("OES_texture_float_linear")===!1&&(_.magFilter===gn||_.magFilter===zo||_.magFilter===hr||_.magFilter===oi||_.minFilter===gn||_.minFilter===zo||_.minFilter===hr||_.minFilter===oi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(A,s.TEXTURE_WRAP_S,rt[_.wrapS]),s.texParameteri(A,s.TEXTURE_WRAP_T,rt[_.wrapT]),(A===s.TEXTURE_3D||A===s.TEXTURE_2D_ARRAY)&&s.texParameteri(A,s.TEXTURE_WRAP_R,rt[_.wrapR]),s.texParameteri(A,s.TEXTURE_MAG_FILTER,lt[_.magFilter]),s.texParameteri(A,s.TEXTURE_MIN_FILTER,lt[_.minFilter]),_.compareFunction&&(s.texParameteri(A,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(A,s.TEXTURE_COMPARE_FUNC,pt[_.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===Te||_.minFilter!==hr&&_.minFilter!==oi||_.type===yn&&t.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||n.get(_).__currentAnisotropy){let F=t.get("EXT_texture_filter_anisotropic");s.texParameterf(A,F.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,i.getMaxAnisotropy())),n.get(_).__currentAnisotropy=_.anisotropy}}}function ee(A,_){let F=!1;A.__webglInit===void 0&&(A.__webglInit=!0,_.addEventListener("dispose",E));let q=_.source,K=f.get(q);K===void 0&&(K={},f.set(q,K));let G=W(_);if(G!==A.__cacheKey){K[G]===void 0&&(K[G]={texture:s.createTexture(),usedTimes:0},o.memory.textures++,F=!0),K[G].usedTimes++;let St=K[A.__cacheKey];St!==void 0&&(K[A.__cacheKey].usedTimes--,St.usedTimes===0&&M(_)),A.__cacheKey=G,A.__webglTexture=K[G].texture}return F}function ae(A,_,F){return Math.floor(Math.floor(A/F)/_)}function Kt(A,_,F,q){let G=A.updateRanges;if(G.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,_.width,_.height,F,q,_.data);else{G.sort((nt,ut)=>nt.start-ut.start);let St=0;for(let nt=1;nt<G.length;nt++){let ut=G[St],Rt=G[nt],bt=ut.start+ut.count,ct=ae(Rt.start,_.width,4),Bt=ae(ut.start,_.width,4);Rt.start<=bt+1&&ct===Bt&&ae(Rt.start+Rt.count-1,_.width,4)===ct?ut.count=Math.max(ut.count,Rt.start+Rt.count-ut.start):(++St,G[St]=Rt)}G.length=St+1;let st=s.getParameter(s.UNPACK_ROW_LENGTH),yt=s.getParameter(s.UNPACK_SKIP_PIXELS),Mt=s.getParameter(s.UNPACK_SKIP_ROWS);s.pixelStorei(s.UNPACK_ROW_LENGTH,_.width);for(let nt=0,ut=G.length;nt<ut;nt++){let Rt=G[nt],bt=Math.floor(Rt.start/4),ct=Math.ceil(Rt.count/4),Bt=bt%_.width,L=Math.floor(bt/_.width),it=ct,ot=1;s.pixelStorei(s.UNPACK_SKIP_PIXELS,Bt),s.pixelStorei(s.UNPACK_SKIP_ROWS,L),e.texSubImage2D(s.TEXTURE_2D,0,Bt,L,it,ot,F,q,_.data)}A.clearUpdateRanges(),s.pixelStorei(s.UNPACK_ROW_LENGTH,st),s.pixelStorei(s.UNPACK_SKIP_PIXELS,yt),s.pixelStorei(s.UNPACK_SKIP_ROWS,Mt)}}function $(A,_,F){let q=s.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(q=s.TEXTURE_2D_ARRAY),_.isData3DTexture&&(q=s.TEXTURE_3D);let K=ee(A,_),G=_.source;e.bindTexture(q,A.__webglTexture,s.TEXTURE0+F);let St=n.get(G);if(G.version!==St.__version||K===!0){e.activeTexture(s.TEXTURE0+F);let st=$t.getPrimaries($t.workingColorSpace),yt=_.colorSpace===Xn?null:$t.getPrimaries(_.colorSpace),Mt=_.colorSpace===Xn||st===yt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,_.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,_.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt);let nt=x(_.image,!1,i.maxTextureSize);nt=Le(_,nt);let ut=r.convert(_.format,_.colorSpace),Rt=r.convert(_.type),bt=y(_.internalFormat,ut,Rt,_.colorSpace,_.isVideoTexture);zt(q,_);let ct,Bt=_.mipmaps,L=_.isVideoTexture!==!0,it=St.__version===void 0||K===!0,ot=G.dataReady,ft=T(_,nt);if(_.isDepthTexture)bt=v(_.format===ms,_.type),it&&(L?e.texStorage2D(s.TEXTURE_2D,1,bt,nt.width,nt.height):e.texImage2D(s.TEXTURE_2D,0,bt,nt.width,nt.height,0,ut,Rt,null));else if(_.isDataTexture)if(Bt.length>0){L&&it&&e.texStorage2D(s.TEXTURE_2D,ft,bt,Bt[0].width,Bt[0].height);for(let tt=0,Y=Bt.length;tt<Y;tt++)ct=Bt[tt],L?ot&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,ct.width,ct.height,ut,Rt,ct.data):e.texImage2D(s.TEXTURE_2D,tt,bt,ct.width,ct.height,0,ut,Rt,ct.data);_.generateMipmaps=!1}else L?(it&&e.texStorage2D(s.TEXTURE_2D,ft,bt,nt.width,nt.height),ot&&Kt(_,nt,ut,Rt)):e.texImage2D(s.TEXTURE_2D,0,bt,nt.width,nt.height,0,ut,Rt,nt.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){L&&it&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ft,bt,Bt[0].width,Bt[0].height,nt.depth);for(let tt=0,Y=Bt.length;tt<Y;tt++)if(ct=Bt[tt],_.format!==Ke)if(ut!==null)if(L){if(ot)if(_.layerUpdates.size>0){let xt=ec(ct.width,ct.height,_.format,_.type);for(let Ft of _.layerUpdates){let le=ct.data.subarray(Ft*xt/ct.data.BYTES_PER_ELEMENT,(Ft+1)*xt/ct.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,Ft,ct.width,ct.height,1,ut,le)}_.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,0,ct.width,ct.height,nt.depth,ut,ct.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,tt,bt,ct.width,ct.height,nt.depth,0,ct.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else L?ot&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,0,ct.width,ct.height,nt.depth,ut,Rt,ct.data):e.texImage3D(s.TEXTURE_2D_ARRAY,tt,bt,ct.width,ct.height,nt.depth,0,ut,Rt,ct.data)}else{L&&it&&e.texStorage2D(s.TEXTURE_2D,ft,bt,Bt[0].width,Bt[0].height);for(let tt=0,Y=Bt.length;tt<Y;tt++)ct=Bt[tt],_.format!==Ke?ut!==null?L?ot&&e.compressedTexSubImage2D(s.TEXTURE_2D,tt,0,0,ct.width,ct.height,ut,ct.data):e.compressedTexImage2D(s.TEXTURE_2D,tt,bt,ct.width,ct.height,0,ct.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):L?ot&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,ct.width,ct.height,ut,Rt,ct.data):e.texImage2D(s.TEXTURE_2D,tt,bt,ct.width,ct.height,0,ut,Rt,ct.data)}else if(_.isDataArrayTexture)if(L){if(it&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ft,bt,nt.width,nt.height,nt.depth),ot)if(_.layerUpdates.size>0){let tt=ec(nt.width,nt.height,_.format,_.type);for(let Y of _.layerUpdates){let xt=nt.data.subarray(Y*tt/nt.data.BYTES_PER_ELEMENT,(Y+1)*tt/nt.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,Y,nt.width,nt.height,1,ut,Rt,xt)}_.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,nt.width,nt.height,nt.depth,ut,Rt,nt.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,bt,nt.width,nt.height,nt.depth,0,ut,Rt,nt.data);else if(_.isData3DTexture)L?(it&&e.texStorage3D(s.TEXTURE_3D,ft,bt,nt.width,nt.height,nt.depth),ot&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,nt.width,nt.height,nt.depth,ut,Rt,nt.data)):e.texImage3D(s.TEXTURE_3D,0,bt,nt.width,nt.height,nt.depth,0,ut,Rt,nt.data);else if(_.isFramebufferTexture){if(it)if(L)e.texStorage2D(s.TEXTURE_2D,ft,bt,nt.width,nt.height);else{let tt=nt.width,Y=nt.height;for(let xt=0;xt<ft;xt++)e.texImage2D(s.TEXTURE_2D,xt,bt,tt,Y,0,ut,Rt,null),tt>>=1,Y>>=1}}else if(Bt.length>0){if(L&&it){let tt=Me(Bt[0]);e.texStorage2D(s.TEXTURE_2D,ft,bt,tt.width,tt.height)}for(let tt=0,Y=Bt.length;tt<Y;tt++)ct=Bt[tt],L?ot&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,ut,Rt,ct):e.texImage2D(s.TEXTURE_2D,tt,bt,ut,Rt,ct);_.generateMipmaps=!1}else if(L){if(it){let tt=Me(nt);e.texStorage2D(s.TEXTURE_2D,ft,bt,tt.width,tt.height)}ot&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,ut,Rt,nt)}else e.texImage2D(s.TEXTURE_2D,0,bt,ut,Rt,nt);m(_)&&p(q),St.__version=G.version,_.onUpdate&&_.onUpdate(_)}A.__version=_.version}function j(A,_,F){if(_.image.length!==6)return;let q=ee(A,_),K=_.source;e.bindTexture(s.TEXTURE_CUBE_MAP,A.__webglTexture,s.TEXTURE0+F);let G=n.get(K);if(K.version!==G.__version||q===!0){e.activeTexture(s.TEXTURE0+F);let St=$t.getPrimaries($t.workingColorSpace),st=_.colorSpace===Xn?null:$t.getPrimaries(_.colorSpace),yt=_.colorSpace===Xn||St===st?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,_.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,_.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,yt);let Mt=_.isCompressedTexture||_.image[0].isCompressedTexture,nt=_.image[0]&&_.image[0].isDataTexture,ut=[];for(let Y=0;Y<6;Y++)!Mt&&!nt?ut[Y]=x(_.image[Y],!0,i.maxCubemapSize):ut[Y]=nt?_.image[Y].image:_.image[Y],ut[Y]=Le(_,ut[Y]);let Rt=ut[0],bt=r.convert(_.format,_.colorSpace),ct=r.convert(_.type),Bt=y(_.internalFormat,bt,ct,_.colorSpace),L=_.isVideoTexture!==!0,it=G.__version===void 0||q===!0,ot=K.dataReady,ft=T(_,Rt);zt(s.TEXTURE_CUBE_MAP,_);let tt;if(Mt){L&&it&&e.texStorage2D(s.TEXTURE_CUBE_MAP,ft,Bt,Rt.width,Rt.height);for(let Y=0;Y<6;Y++){tt=ut[Y].mipmaps;for(let xt=0;xt<tt.length;xt++){let Ft=tt[xt];_.format!==Ke?bt!==null?L?ot&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt,0,0,Ft.width,Ft.height,bt,Ft.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt,Bt,Ft.width,Ft.height,0,Ft.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):L?ot&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt,0,0,Ft.width,Ft.height,bt,ct,Ft.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt,Bt,Ft.width,Ft.height,0,bt,ct,Ft.data)}}}else{if(tt=_.mipmaps,L&&it){tt.length>0&&ft++;let Y=Me(ut[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,ft,Bt,Y.width,Y.height)}for(let Y=0;Y<6;Y++)if(nt){L?ot&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,0,0,0,ut[Y].width,ut[Y].height,bt,ct,ut[Y].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,0,Bt,ut[Y].width,ut[Y].height,0,bt,ct,ut[Y].data);for(let xt=0;xt<tt.length;xt++){let le=tt[xt].image[Y].image;L?ot&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt+1,0,0,le.width,le.height,bt,ct,le.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt+1,Bt,le.width,le.height,0,bt,ct,le.data)}}else{L?ot&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,0,0,0,bt,ct,ut[Y]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,0,Bt,bt,ct,ut[Y]);for(let xt=0;xt<tt.length;xt++){let Ft=tt[xt];L?ot&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt+1,0,0,bt,ct,Ft.image[Y]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Y,xt+1,Bt,bt,ct,Ft.image[Y])}}}m(_)&&p(s.TEXTURE_CUBE_MAP),G.__version=K.version,_.onUpdate&&_.onUpdate(_)}A.__version=_.version}function mt(A,_,F,q,K,G){let St=r.convert(F.format,F.colorSpace),st=r.convert(F.type),yt=y(F.internalFormat,St,st,F.colorSpace),Mt=n.get(_),nt=n.get(F);if(nt.__renderTarget=_,!Mt.__hasExternalTextures){let ut=Math.max(1,_.width>>G),Rt=Math.max(1,_.height>>G);K===s.TEXTURE_3D||K===s.TEXTURE_2D_ARRAY?e.texImage3D(K,G,yt,ut,Rt,_.depth,0,St,st,null):e.texImage2D(K,G,yt,ut,Rt,0,St,st,null)}e.bindFramebuffer(s.FRAMEBUFFER,A),vt(_)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,q,K,nt.__webglTexture,0,me(_)):(K===s.TEXTURE_2D||K>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&K<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,q,K,nt.__webglTexture,G),e.bindFramebuffer(s.FRAMEBUFFER,null)}function Ut(A,_,F){if(s.bindRenderbuffer(s.RENDERBUFFER,A),_.depthBuffer){let q=_.depthTexture,K=q&&q.isDepthTexture?q.type:null,G=v(_.stencilBuffer,K),St=_.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,st=me(_);vt(_)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,st,G,_.width,_.height):F?s.renderbufferStorageMultisample(s.RENDERBUFFER,st,G,_.width,_.height):s.renderbufferStorage(s.RENDERBUFFER,G,_.width,_.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,St,s.RENDERBUFFER,A)}else{let q=_.textures;for(let K=0;K<q.length;K++){let G=q[K],St=r.convert(G.format,G.colorSpace),st=r.convert(G.type),yt=y(G.internalFormat,St,st,G.colorSpace),Mt=me(_);F&&vt(_)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,Mt,yt,_.width,_.height):vt(_)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,Mt,yt,_.width,_.height):s.renderbufferStorage(s.RENDERBUFFER,yt,_.width,_.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function wt(A,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,A),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let q=n.get(_.depthTexture);q.__renderTarget=_,(!q.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),X(_.depthTexture,0);let K=q.__webglTexture,G=me(_);if(_.depthTexture.format===is)vt(_)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,K,0,G):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,K,0);else if(_.depthTexture.format===ms)vt(_)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,K,0,G):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,K,0);else throw new Error("Unknown depthTexture format")}function qt(A){let _=n.get(A),F=A.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==A.depthTexture){let q=A.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),q){let K=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,q.removeEventListener("dispose",K)};q.addEventListener("dispose",K),_.__depthDisposeCallback=K}_.__boundDepthTexture=q}if(A.depthTexture&&!_.__autoAllocateDepthBuffer){if(F)throw new Error("target.depthTexture not supported in Cube render targets");let q=A.texture.mipmaps;q&&q.length>0?wt(_.__webglFramebuffer[0],A):wt(_.__webglFramebuffer,A)}else if(F){_.__webglDepthbuffer=[];for(let q=0;q<6;q++)if(e.bindFramebuffer(s.FRAMEBUFFER,_.__webglFramebuffer[q]),_.__webglDepthbuffer[q]===void 0)_.__webglDepthbuffer[q]=s.createRenderbuffer(),Ut(_.__webglDepthbuffer[q],A,!1);else{let K=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,G=_.__webglDepthbuffer[q];s.bindRenderbuffer(s.RENDERBUFFER,G),s.framebufferRenderbuffer(s.FRAMEBUFFER,K,s.RENDERBUFFER,G)}}else{let q=A.texture.mipmaps;if(q&&q.length>0?e.bindFramebuffer(s.FRAMEBUFFER,_.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=s.createRenderbuffer(),Ut(_.__webglDepthbuffer,A,!1);else{let K=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,G=_.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,G),s.framebufferRenderbuffer(s.FRAMEBUFFER,K,s.RENDERBUFFER,G)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function ze(A,_,F){let q=n.get(A);_!==void 0&&mt(q.__webglFramebuffer,A,A.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),F!==void 0&&qt(A)}function R(A){let _=A.texture,F=n.get(A),q=n.get(_);A.addEventListener("dispose",C);let K=A.textures,G=A.isWebGLCubeRenderTarget===!0,St=K.length>1;if(St||(q.__webglTexture===void 0&&(q.__webglTexture=s.createTexture()),q.__version=_.version,o.memory.textures++),G){F.__webglFramebuffer=[];for(let st=0;st<6;st++)if(_.mipmaps&&_.mipmaps.length>0){F.__webglFramebuffer[st]=[];for(let yt=0;yt<_.mipmaps.length;yt++)F.__webglFramebuffer[st][yt]=s.createFramebuffer()}else F.__webglFramebuffer[st]=s.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){F.__webglFramebuffer=[];for(let st=0;st<_.mipmaps.length;st++)F.__webglFramebuffer[st]=s.createFramebuffer()}else F.__webglFramebuffer=s.createFramebuffer();if(St)for(let st=0,yt=K.length;st<yt;st++){let Mt=n.get(K[st]);Mt.__webglTexture===void 0&&(Mt.__webglTexture=s.createTexture(),o.memory.textures++)}if(A.samples>0&&vt(A)===!1){F.__webglMultisampledFramebuffer=s.createFramebuffer(),F.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,F.__webglMultisampledFramebuffer);for(let st=0;st<K.length;st++){let yt=K[st];F.__webglColorRenderbuffer[st]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,F.__webglColorRenderbuffer[st]);let Mt=r.convert(yt.format,yt.colorSpace),nt=r.convert(yt.type),ut=y(yt.internalFormat,Mt,nt,yt.colorSpace,A.isXRRenderTarget===!0),Rt=me(A);s.renderbufferStorageMultisample(s.RENDERBUFFER,Rt,ut,A.width,A.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+st,s.RENDERBUFFER,F.__webglColorRenderbuffer[st])}s.bindRenderbuffer(s.RENDERBUFFER,null),A.depthBuffer&&(F.__webglDepthRenderbuffer=s.createRenderbuffer(),Ut(F.__webglDepthRenderbuffer,A,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(G){e.bindTexture(s.TEXTURE_CUBE_MAP,q.__webglTexture),zt(s.TEXTURE_CUBE_MAP,_);for(let st=0;st<6;st++)if(_.mipmaps&&_.mipmaps.length>0)for(let yt=0;yt<_.mipmaps.length;yt++)mt(F.__webglFramebuffer[st][yt],A,_,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+st,yt);else mt(F.__webglFramebuffer[st],A,_,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0);m(_)&&p(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(St){for(let st=0,yt=K.length;st<yt;st++){let Mt=K[st],nt=n.get(Mt),ut=s.TEXTURE_2D;(A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(ut=A.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ut,nt.__webglTexture),zt(ut,Mt),mt(F.__webglFramebuffer,A,Mt,s.COLOR_ATTACHMENT0+st,ut,0),m(Mt)&&p(ut)}e.unbindTexture()}else{let st=s.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(st=A.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(st,q.__webglTexture),zt(st,_),_.mipmaps&&_.mipmaps.length>0)for(let yt=0;yt<_.mipmaps.length;yt++)mt(F.__webglFramebuffer[yt],A,_,s.COLOR_ATTACHMENT0,st,yt);else mt(F.__webglFramebuffer,A,_,s.COLOR_ATTACHMENT0,st,0);m(_)&&p(st),e.unbindTexture()}A.depthBuffer&&qt(A)}function pe(A){let _=A.textures;for(let F=0,q=_.length;F<q;F++){let K=_[F];if(m(K)){let G=S(A),St=n.get(K).__webglTexture;e.bindTexture(G,St),p(G),e.unbindTexture()}}}let kt=[],It=[];function _t(A){if(A.samples>0){if(vt(A)===!1){let _=A.textures,F=A.width,q=A.height,K=s.COLOR_BUFFER_BIT,G=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,St=n.get(A),st=_.length>1;if(st)for(let Mt=0;Mt<_.length;Mt++)e.bindFramebuffer(s.FRAMEBUFFER,St.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Mt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,St.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Mt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,St.__webglMultisampledFramebuffer);let yt=A.texture.mipmaps;yt&&yt.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,St.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,St.__webglFramebuffer);for(let Mt=0;Mt<_.length;Mt++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(K|=s.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(K|=s.STENCIL_BUFFER_BIT)),st){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,St.__webglColorRenderbuffer[Mt]);let nt=n.get(_[Mt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,nt,0)}s.blitFramebuffer(0,0,F,q,0,0,F,q,K,s.NEAREST),l===!0&&(kt.length=0,It.length=0,kt.push(s.COLOR_ATTACHMENT0+Mt),A.depthBuffer&&A.resolveDepthBuffer===!1&&(kt.push(G),It.push(G),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,It)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,kt))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),st)for(let Mt=0;Mt<_.length;Mt++){e.bindFramebuffer(s.FRAMEBUFFER,St.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Mt,s.RENDERBUFFER,St.__webglColorRenderbuffer[Mt]);let nt=n.get(_[Mt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,St.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Mt,s.TEXTURE_2D,nt,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,St.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){let _=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[_])}}}function me(A){return Math.min(i.maxSamples,A.samples)}function vt(A){let _=n.get(A);return A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function Ht(A){let _=o.render.frame;h.get(A)!==_&&(h.set(A,_),A.update())}function Le(A,_){let F=A.colorSpace,q=A.format,K=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||F!==Mi&&F!==Xn&&($t.getTransfer(F)===ne?(q!==Ke||K!==vn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",F)),_}function Me(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=H,this.resetTextureUnits=k,this.setTexture2D=X,this.setTexture2DArray=V,this.setTexture3D=Q,this.setTextureCube=O,this.rebindTextures=ze,this.setupRenderTarget=R,this.updateRenderTargetMipmap=pe,this.updateMultisampleRenderTarget=_t,this.setupDepthRenderbuffer=qt,this.setupFrameBufferTexture=mt,this.useMultisampledRTT=vt}function I0(s,t){function e(n,i=Xn){let r,o=$t.getTransfer(i);if(n===vn)return s.UNSIGNED_BYTE;if(n===Vo)return s.UNSIGNED_SHORT_4_4_4_4;if(n===Go)return s.UNSIGNED_SHORT_5_5_5_1;if(n===Vl)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===Gl)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===zl)return s.BYTE;if(n===Hl)return s.SHORT;if(n===ds)return s.UNSIGNED_SHORT;if(n===Ho)return s.INT;if(n===ai)return s.UNSIGNED_INT;if(n===yn)return s.FLOAT;if(n===fs)return s.HALF_FLOAT;if(n===Wl)return s.ALPHA;if(n===Xl)return s.RGB;if(n===Ke)return s.RGBA;if(n===is)return s.DEPTH_COMPONENT;if(n===ms)return s.DEPTH_STENCIL;if(n===Wo)return s.RED;if(n===Xo)return s.RED_INTEGER;if(n===ql)return s.RG;if(n===qo)return s.RG_INTEGER;if(n===$o)return s.RGBA_INTEGER;if(n===ur||n===dr||n===fr||n===pr)if(o===ne)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===ur)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===dr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===fr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===pr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===ur)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===dr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===fr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===pr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Yo||n===Zo||n===Jo||n===Ko)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Yo)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Zo)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Jo)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ko)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===jo||n===Qo||n===ta)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===jo||n===Qo)return o===ne?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===ta)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===ea||n===na||n===ia||n===sa||n===ra||n===oa||n===aa||n===la||n===ca||n===ha||n===ua||n===da||n===fa||n===pa)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===ea)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===na)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===ia)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===sa)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ra)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===oa)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===aa)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===la)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===ca)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===ha)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ua)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===da)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===fa)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===pa)return o===ne?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===ma||n===ga||n===xa)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===ma)return o===ne?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===ga)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===xa)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===_a||n===va||n===ya||n===Ma)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===_a)return r.COMPRESSED_RED_RGTC1_EXT;if(n===va)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ya)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ma)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ps?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}var P0=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,L0=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,pc=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){let n=new ir(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new _n({vertexShader:P0,fragmentShader:L0,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new ie(new Ei(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},mc=class extends zn{constructor(t,e){super();let n=this,i=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,f=null,d=null,g=null,x=typeof XRWebGLBinding<"u",m=new pc,p={},S=e.getContextAttributes(),y=null,v=null,T=[],E=[],C=new Nt,I=null,M=new Ue;M.viewport=new ve;let w=new Ue;w.viewport=new ve;let P=[M,w],k=new Ro,H=null,W=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let j=T[$];return j===void 0&&(j=new os,T[$]=j),j.getTargetRaySpace()},this.getControllerGrip=function($){let j=T[$];return j===void 0&&(j=new os,T[$]=j),j.getGripSpace()},this.getHand=function($){let j=T[$];return j===void 0&&(j=new os,T[$]=j),j.getHandSpace()};function X($){let j=E.indexOf($.inputSource);if(j===-1)return;let mt=T[j];mt!==void 0&&(mt.update($.inputSource,$.frame,c||o),mt.dispatchEvent({type:$.type,data:$.inputSource}))}function V(){i.removeEventListener("select",X),i.removeEventListener("selectstart",X),i.removeEventListener("selectend",X),i.removeEventListener("squeeze",X),i.removeEventListener("squeezestart",X),i.removeEventListener("squeezeend",X),i.removeEventListener("end",V),i.removeEventListener("inputsourceschange",Q);for(let $=0;$<T.length;$++){let j=E[$];j!==null&&(E[$]=null,T[$].disconnect(j))}H=null,W=null,m.reset();for(let $ in p)delete p[$];t.setRenderTarget(y),d=null,f=null,u=null,i=null,v=null,Kt.stop(),n.isPresenting=!1,t.setPixelRatio(I),t.setSize(C.width,C.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){r=$,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){a=$,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function($){c=$},this.getBaseLayer=function(){return f!==null?f:d},this.getBinding=function(){return u===null&&x&&(u=new XRWebGLBinding(i,e)),u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function($){if(i=$,i!==null){if(y=t.getRenderTarget(),i.addEventListener("select",X),i.addEventListener("selectstart",X),i.addEventListener("selectend",X),i.addEventListener("squeeze",X),i.addEventListener("squeezestart",X),i.addEventListener("squeezeend",X),i.addEventListener("end",V),i.addEventListener("inputsourceschange",Q),S.xrCompatible!==!0&&await e.makeXRCompatible(),I=t.getPixelRatio(),t.getSize(C),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let mt=null,Ut=null,wt=null;S.depth&&(wt=S.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,mt=S.stencil?ms:is,Ut=S.stencil?ps:ai);let qt={colorFormat:e.RGBA8,depthFormat:wt,scaleFactor:r};u=this.getBinding(),f=u.createProjectionLayer(qt),i.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),v=new Tn(f.textureWidth,f.textureHeight,{format:Ke,type:vn,depthTexture:new nr(f.textureWidth,f.textureHeight,Ut,void 0,void 0,void 0,void 0,void 0,void 0,mt),stencilBuffer:S.stencil,colorSpace:t.outputColorSpace,samples:S.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}else{let mt={antialias:S.antialias,alpha:!0,depth:S.depth,stencil:S.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(i,e,mt),i.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),v=new Tn(d.framebufferWidth,d.framebufferHeight,{format:Ke,type:vn,colorSpace:t.outputColorSpace,stencilBuffer:S.stencil,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await i.requestReferenceSpace(a),Kt.setContext(i),Kt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function Q($){for(let j=0;j<$.removed.length;j++){let mt=$.removed[j],Ut=E.indexOf(mt);Ut>=0&&(E[Ut]=null,T[Ut].disconnect(mt))}for(let j=0;j<$.added.length;j++){let mt=$.added[j],Ut=E.indexOf(mt);if(Ut===-1){for(let qt=0;qt<T.length;qt++)if(qt>=E.length){E.push(mt),Ut=qt;break}else if(E[qt]===null){E[qt]=mt,Ut=qt;break}if(Ut===-1)break}let wt=T[Ut];wt&&wt.connect(mt)}}let O=new D,rt=new D;function lt($,j,mt){O.setFromMatrixPosition(j.matrixWorld),rt.setFromMatrixPosition(mt.matrixWorld);let Ut=O.distanceTo(rt),wt=j.projectionMatrix.elements,qt=mt.projectionMatrix.elements,ze=wt[14]/(wt[10]-1),R=wt[14]/(wt[10]+1),pe=(wt[9]+1)/wt[5],kt=(wt[9]-1)/wt[5],It=(wt[8]-1)/wt[0],_t=(qt[8]+1)/qt[0],me=ze*It,vt=ze*_t,Ht=Ut/(-It+_t),Le=Ht*-It;if(j.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(Le),$.translateZ(Ht),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert(),wt[10]===-1)$.projectionMatrix.copy(j.projectionMatrix),$.projectionMatrixInverse.copy(j.projectionMatrixInverse);else{let Me=ze+Ht,A=R+Ht,_=me-Le,F=vt+(Ut-Le),q=pe*R/A*Me,K=kt*R/A*Me;$.projectionMatrix.makePerspective(_,F,q,K,Me,A),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}}function pt($,j){j===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(j.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(i===null)return;let j=$.near,mt=$.far;m.texture!==null&&(m.depthNear>0&&(j=m.depthNear),m.depthFar>0&&(mt=m.depthFar)),k.near=w.near=M.near=j,k.far=w.far=M.far=mt,(H!==k.near||W!==k.far)&&(i.updateRenderState({depthNear:k.near,depthFar:k.far}),H=k.near,W=k.far),k.layers.mask=$.layers.mask|6,M.layers.mask=k.layers.mask&3,w.layers.mask=k.layers.mask&5;let Ut=$.parent,wt=k.cameras;pt(k,Ut);for(let qt=0;qt<wt.length;qt++)pt(wt[qt],Ut);wt.length===2?lt(k,M,w):k.projectionMatrix.copy(M.projectionMatrix),zt($,k,Ut)};function zt($,j,mt){mt===null?$.matrix.copy(j.matrixWorld):($.matrix.copy(mt.matrixWorld),$.matrix.invert(),$.matrix.multiply(j.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(j.projectionMatrix),$.projectionMatrixInverse.copy(j.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=ao*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return k},this.getFoveation=function(){if(!(f===null&&d===null))return l},this.setFoveation=function($){l=$,f!==null&&(f.fixedFoveation=$),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=$)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(k)},this.getCameraTexture=function($){return p[$]};let ee=null;function ae($,j){if(h=j.getViewerPose(c||o),g=j,h!==null){let mt=h.views;d!==null&&(t.setRenderTargetFramebuffer(v,d.framebuffer),t.setRenderTarget(v));let Ut=!1;mt.length!==k.cameras.length&&(k.cameras.length=0,Ut=!0);for(let R=0;R<mt.length;R++){let pe=mt[R],kt=null;if(d!==null)kt=d.getViewport(pe);else{let _t=u.getViewSubImage(f,pe);kt=_t.viewport,R===0&&(t.setRenderTargetTextures(v,_t.colorTexture,_t.depthStencilTexture),t.setRenderTarget(v))}let It=P[R];It===void 0&&(It=new Ue,It.layers.enable(R),It.viewport=new ve,P[R]=It),It.matrix.fromArray(pe.transform.matrix),It.matrix.decompose(It.position,It.quaternion,It.scale),It.projectionMatrix.fromArray(pe.projectionMatrix),It.projectionMatrixInverse.copy(It.projectionMatrix).invert(),It.viewport.set(kt.x,kt.y,kt.width,kt.height),R===0&&(k.matrix.copy(It.matrix),k.matrix.decompose(k.position,k.quaternion,k.scale)),Ut===!0&&k.cameras.push(It)}let wt=i.enabledFeatures;if(wt&&wt.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&x){u=n.getBinding();let R=u.getDepthInformation(mt[0]);R&&R.isValid&&R.texture&&m.init(R,i.renderState)}if(wt&&wt.includes("camera-access")&&x){t.state.unbindTexture(),u=n.getBinding();for(let R=0;R<mt.length;R++){let pe=mt[R].camera;if(pe){let kt=p[pe];kt||(kt=new ir,p[pe]=kt);let It=u.getCameraImage(pe);kt.sourceTexture=It}}}}for(let mt=0;mt<T.length;mt++){let Ut=E[mt],wt=T[mt];Ut!==null&&wt!==void 0&&wt.update(Ut,j,c||o)}ee&&ee($,j),j.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:j}),g=null}let Kt=new Ou;Kt.setAnimationLoop(ae),this.setAnimationLoop=function($){ee=$},this.dispose=function(){}}},Ui=new xn,D0=new Qt;function U0(s,t){function e(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,jl(s)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,S,y,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),f(m,p),p.isMeshPhysicalMaterial&&d(m,p,v)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),x(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,S,y):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,e(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Be&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,e(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Be&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,e(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,e(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let S=t.get(p),y=S.envMap,v=S.envMapRotation;y&&(m.envMap.value=y,Ui.copy(v),Ui.x*=-1,Ui.y*=-1,Ui.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(Ui.y*=-1,Ui.z*=-1),m.envMapRotation.value.setFromMatrix4(D0.makeRotationFromEuler(Ui)),m.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,S,y){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*S,m.scale.value=y*.5,p.map&&(m.map.value=p.map,e(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,e(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,e(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function f(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function d(m,p,S){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Be&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=S.texture,m.transmissionSamplerSize.value.set(S.width,S.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function x(m,p){let S=t.get(p).light;m.referencePosition.value.setFromMatrixPosition(S.matrixWorld),m.nearDistance.value=S.shadow.camera.near,m.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function N0(s,t,e,n){let i={},r={},o=[],a=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function l(S,y){let v=y.program;n.uniformBlockBinding(S,v)}function c(S,y){let v=i[S.id];v===void 0&&(g(S),v=h(S),i[S.id]=v,S.addEventListener("dispose",m));let T=y.program;n.updateUBOMapping(S,T);let E=t.render.frame;r[S.id]!==E&&(f(S),r[S.id]=E)}function h(S){let y=u();S.__bindingPointIndex=y;let v=s.createBuffer(),T=S.__size,E=S.usage;return s.bindBuffer(s.UNIFORM_BUFFER,v),s.bufferData(s.UNIFORM_BUFFER,T,E),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,y,v),v}function u(){for(let S=0;S<a;S++)if(o.indexOf(S)===-1)return o.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(S){let y=i[S.id],v=S.uniforms,T=S.__cache;s.bindBuffer(s.UNIFORM_BUFFER,y);for(let E=0,C=v.length;E<C;E++){let I=Array.isArray(v[E])?v[E]:[v[E]];for(let M=0,w=I.length;M<w;M++){let P=I[M];if(d(P,E,M,T)===!0){let k=P.__offset,H=Array.isArray(P.value)?P.value:[P.value],W=0;for(let X=0;X<H.length;X++){let V=H[X],Q=x(V);typeof V=="number"||typeof V=="boolean"?(P.__data[0]=V,s.bufferSubData(s.UNIFORM_BUFFER,k+W,P.__data)):V.isMatrix3?(P.__data[0]=V.elements[0],P.__data[1]=V.elements[1],P.__data[2]=V.elements[2],P.__data[3]=0,P.__data[4]=V.elements[3],P.__data[5]=V.elements[4],P.__data[6]=V.elements[5],P.__data[7]=0,P.__data[8]=V.elements[6],P.__data[9]=V.elements[7],P.__data[10]=V.elements[8],P.__data[11]=0):(V.toArray(P.__data,W),W+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,k,P.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function d(S,y,v,T){let E=S.value,C=y+"_"+v;if(T[C]===void 0)return typeof E=="number"||typeof E=="boolean"?T[C]=E:T[C]=E.clone(),!0;{let I=T[C];if(typeof E=="number"||typeof E=="boolean"){if(I!==E)return T[C]=E,!0}else if(I.equals(E)===!1)return I.copy(E),!0}return!1}function g(S){let y=S.uniforms,v=0,T=16;for(let C=0,I=y.length;C<I;C++){let M=Array.isArray(y[C])?y[C]:[y[C]];for(let w=0,P=M.length;w<P;w++){let k=M[w],H=Array.isArray(k.value)?k.value:[k.value];for(let W=0,X=H.length;W<X;W++){let V=H[W],Q=x(V),O=v%T,rt=O%Q.boundary,lt=O+rt;v+=rt,lt!==0&&T-lt<Q.storage&&(v+=T-lt),k.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=v,v+=Q.storage}}}let E=v%T;return E>0&&(v+=T-E),S.__size=v,S.__cache={},this}function x(S){let y={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(y.boundary=4,y.storage=4):S.isVector2?(y.boundary=8,y.storage=8):S.isVector3||S.isColor?(y.boundary=16,y.storage=12):S.isVector4?(y.boundary=16,y.storage=16):S.isMatrix3?(y.boundary=48,y.storage=48):S.isMatrix4?(y.boundary=64,y.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),y}function m(S){let y=S.target;y.removeEventListener("dispose",m);let v=o.indexOf(y.__bindingPointIndex);o.splice(v,1),s.deleteBuffer(i[y.id]),delete i[y.id],delete r[y.id]}function p(){for(let S in i)s.deleteBuffer(i[S]);o=[],i={},r={}}return{bind:l,update:c,dispose:p}}var Ta=class{constructor(t={}){let{canvas:e=cu(),context:n=null,depth:i=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:f=!1}=t;this.isWebGLRenderer=!0;let d;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");d=n.getContextAttributes().alpha}else d=o;let g=new Uint32Array(4),x=new Int32Array(4),m=null,p=null,S=[],y=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Wn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let v=this,T=!1;this._outputColorSpace=Re;let E=0,C=0,I=null,M=-1,w=null,P=new ve,k=new ve,H=null,W=new Lt(0),X=0,V=e.width,Q=e.height,O=1,rt=null,lt=null,pt=new ve(0,0,V,Q),zt=new ve(0,0,V,Q),ee=!1,ae=new cs,Kt=!1,$=!1,j=new Qt,mt=new D,Ut=new ve,wt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},qt=!1;function ze(){return I===null?O:1}let R=n;function pe(b,U){return e.getContext(b,U)}try{let b={alpha:!0,depth:i,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${"180"}`),e.addEventListener("webglcontextlost",ot,!1),e.addEventListener("webglcontextrestored",ft,!1),e.addEventListener("webglcontextcreationerror",tt,!1),R===null){let U="webgl2";if(R=pe(U,b),R===null)throw pe(U)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(b){throw console.error("THREE.WebGLRenderer: "+b.message),b}let kt,It,_t,me,vt,Ht,Le,Me,A,_,F,q,K,G,St,st,yt,Mt,nt,ut,Rt,bt,ct,Bt;function L(){kt=new Qm(R),kt.init(),bt=new I0(R,kt),It=new qm(R,kt,t,bt),_t=new C0(R,kt),It.reversedDepthBuffer&&f&&_t.buffers.depth.setReversed(!0),me=new ng(R),vt=new m0,Ht=new R0(R,kt,_t,vt,It,bt,me),Le=new Ym(v),Me=new jm(v),A=new lf(R),ct=new Wm(R,A),_=new tg(R,A,me,ct),F=new sg(R,_,A,me),nt=new ig(R,It,Ht),st=new $m(vt),q=new p0(v,Le,Me,kt,It,ct,st),K=new U0(v,vt),G=new x0,St=new S0(kt),Mt=new Gm(v,Le,Me,_t,F,d,l),yt=new T0(v,F,It),Bt=new N0(R,me,It,_t),ut=new Xm(R,kt,me),Rt=new eg(R,kt,me),me.programs=q.programs,v.capabilities=It,v.extensions=kt,v.properties=vt,v.renderLists=G,v.shadowMap=yt,v.state=_t,v.info=me}L();let it=new mc(v,R);this.xr=it,this.getContext=function(){return R},this.getContextAttributes=function(){return R.getContextAttributes()},this.forceContextLoss=function(){let b=kt.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){let b=kt.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return O},this.setPixelRatio=function(b){b!==void 0&&(O=b,this.setSize(V,Q,!1))},this.getSize=function(b){return b.set(V,Q)},this.setSize=function(b,U,B=!0){if(it.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}V=b,Q=U,e.width=Math.floor(b*O),e.height=Math.floor(U*O),B===!0&&(e.style.width=b+"px",e.style.height=U+"px"),this.setViewport(0,0,b,U)},this.getDrawingBufferSize=function(b){return b.set(V*O,Q*O).floor()},this.setDrawingBufferSize=function(b,U,B){V=b,Q=U,O=B,e.width=Math.floor(b*B),e.height=Math.floor(U*B),this.setViewport(0,0,b,U)},this.getCurrentViewport=function(b){return b.copy(P)},this.getViewport=function(b){return b.copy(pt)},this.setViewport=function(b,U,B,z){b.isVector4?pt.set(b.x,b.y,b.z,b.w):pt.set(b,U,B,z),_t.viewport(P.copy(pt).multiplyScalar(O).round())},this.getScissor=function(b){return b.copy(zt)},this.setScissor=function(b,U,B,z){b.isVector4?zt.set(b.x,b.y,b.z,b.w):zt.set(b,U,B,z),_t.scissor(k.copy(zt).multiplyScalar(O).round())},this.getScissorTest=function(){return ee},this.setScissorTest=function(b){_t.setScissorTest(ee=b)},this.setOpaqueSort=function(b){rt=b},this.setTransparentSort=function(b){lt=b},this.getClearColor=function(b){return b.copy(Mt.getClearColor())},this.setClearColor=function(){Mt.setClearColor(...arguments)},this.getClearAlpha=function(){return Mt.getClearAlpha()},this.setClearAlpha=function(){Mt.setClearAlpha(...arguments)},this.clear=function(b=!0,U=!0,B=!0){let z=0;if(b){let N=!1;if(I!==null){let et=I.texture.format;N=et===$o||et===qo||et===Xo}if(N){let et=I.texture.type,ht=et===vn||et===ai||et===ds||et===ps||et===Vo||et===Go,gt=Mt.getClearColor(),dt=Mt.getClearAlpha(),Ct=gt.r,Pt=gt.g,Tt=gt.b;ht?(g[0]=Ct,g[1]=Pt,g[2]=Tt,g[3]=dt,R.clearBufferuiv(R.COLOR,0,g)):(x[0]=Ct,x[1]=Pt,x[2]=Tt,x[3]=dt,R.clearBufferiv(R.COLOR,0,x))}else z|=R.COLOR_BUFFER_BIT}U&&(z|=R.DEPTH_BUFFER_BIT),B&&(z|=R.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),R.clear(z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",ot,!1),e.removeEventListener("webglcontextrestored",ft,!1),e.removeEventListener("webglcontextcreationerror",tt,!1),Mt.dispose(),G.dispose(),St.dispose(),vt.dispose(),Le.dispose(),Me.dispose(),F.dispose(),ct.dispose(),Bt.dispose(),q.dispose(),it.dispose(),it.removeEventListener("sessionstart",bn),it.removeEventListener("sessionend",Fc),di.stop()};function ot(b){b.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),T=!0}function ft(){console.log("THREE.WebGLRenderer: Context Restored."),T=!1;let b=me.autoReset,U=yt.enabled,B=yt.autoUpdate,z=yt.needsUpdate,N=yt.type;L(),me.autoReset=b,yt.enabled=U,yt.autoUpdate=B,yt.needsUpdate=z,yt.type=N}function tt(b){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function Y(b){let U=b.target;U.removeEventListener("dispose",Y),xt(U)}function xt(b){Ft(b),vt.remove(b)}function Ft(b){let U=vt.get(b).programs;U!==void 0&&(U.forEach(function(B){q.releaseProgram(B)}),b.isShaderMaterial&&q.releaseShaderCache(b))}this.renderBufferDirect=function(b,U,B,z,N,et){U===null&&(U=wt);let ht=N.isMesh&&N.matrixWorld.determinant()<0,gt=xd(b,U,B,z,N);_t.setMaterial(z,ht);let dt=B.index,Ct=1;if(z.wireframe===!0){if(dt=_.getWireframeAttribute(B),dt===void 0)return;Ct=2}let Pt=B.drawRange,Tt=B.attributes.position,Wt=Pt.start*Ct,se=(Pt.start+Pt.count)*Ct;et!==null&&(Wt=Math.max(Wt,et.start*Ct),se=Math.min(se,(et.start+et.count)*Ct)),dt!==null?(Wt=Math.max(Wt,0),se=Math.min(se,dt.count)):Tt!=null&&(Wt=Math.max(Wt,0),se=Math.min(se,Tt.count));let ye=se-Wt;if(ye<0||ye===1/0)return;ct.setup(N,z,gt,B,dt);let de,oe=ut;if(dt!==null&&(de=A.get(dt),oe=Rt,oe.setIndex(de)),N.isMesh)z.wireframe===!0?(_t.setLineWidth(z.wireframeLinewidth*ze()),oe.setMode(R.LINES)):oe.setMode(R.TRIANGLES);else if(N.isLine){let At=z.linewidth;At===void 0&&(At=1),_t.setLineWidth(At*ze()),N.isLineSegments?oe.setMode(R.LINES):N.isLineLoop?oe.setMode(R.LINE_LOOP):oe.setMode(R.LINE_STRIP)}else N.isPoints?oe.setMode(R.POINTS):N.isSprite&&oe.setMode(R.TRIANGLES);if(N.isBatchedMesh)if(N._multiDrawInstances!==null)ss("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),oe.renderMultiDrawInstances(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount,N._multiDrawInstances);else if(kt.get("WEBGL_multi_draw"))oe.renderMultiDraw(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount);else{let At=N._multiDrawStarts,ge=N._multiDrawCounts,Yt=N._multiDrawCount,je=dt?A.get(dt).bytesPerElement:1,Oi=vt.get(z).currentProgram.getUniforms();for(let Qe=0;Qe<Yt;Qe++)Oi.setValue(R,"_gl_DrawID",Qe),oe.render(At[Qe]/je,ge[Qe])}else if(N.isInstancedMesh)oe.renderInstances(Wt,ye,N.count);else if(B.isInstancedBufferGeometry){let At=B._maxInstanceCount!==void 0?B._maxInstanceCount:1/0,ge=Math.min(B.instanceCount,At);oe.renderInstances(Wt,ye,ge)}else oe.render(Wt,ye)};function le(b,U,B){b.transparent===!0&&b.side===hn&&b.forceSinglePass===!1?(b.side=Be,b.needsUpdate=!0,br(b,U,B),b.side=Bn,b.needsUpdate=!0,br(b,U,B),b.side=hn):br(b,U,B)}this.compile=function(b,U,B=null){B===null&&(B=b),p=St.get(B),p.init(U),y.push(p),B.traverseVisible(function(N){N.isLight&&N.layers.test(U.layers)&&(p.pushLight(N),N.castShadow&&p.pushShadow(N))}),b!==B&&b.traverseVisible(function(N){N.isLight&&N.layers.test(U.layers)&&(p.pushLight(N),N.castShadow&&p.pushShadow(N))}),p.setupLights();let z=new Set;return b.traverse(function(N){if(!(N.isMesh||N.isPoints||N.isLine||N.isSprite))return;let et=N.material;if(et)if(Array.isArray(et))for(let ht=0;ht<et.length;ht++){let gt=et[ht];le(gt,B,N),z.add(gt)}else le(et,B,N),z.add(et)}),p=y.pop(),z},this.compileAsync=function(b,U,B=null){let z=this.compile(b,U,B);return new Promise(N=>{function et(){if(z.forEach(function(ht){vt.get(ht).currentProgram.isReady()&&z.delete(ht)}),z.size===0){N(b);return}setTimeout(et,10)}kt.get("KHR_parallel_shader_compile")!==null?et():setTimeout(et,10)})};let jt=null;function Pn(b){jt&&jt(b)}function bn(){di.stop()}function Fc(){di.start()}let di=new Ou;di.setAnimationLoop(Pn),typeof self<"u"&&di.setContext(self),this.setAnimationLoop=function(b){jt=b,it.setAnimationLoop(b),b===null?di.stop():di.start()},it.addEventListener("sessionstart",bn),it.addEventListener("sessionend",Fc),this.render=function(b,U){if(U!==void 0&&U.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(T===!0)return;if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),U.parent===null&&U.matrixWorldAutoUpdate===!0&&U.updateMatrixWorld(),it.enabled===!0&&it.isPresenting===!0&&(it.cameraAutoUpdate===!0&&it.updateCamera(U),U=it.getCamera()),b.isScene===!0&&b.onBeforeRender(v,b,U,I),p=St.get(b,y.length),p.init(U),y.push(p),j.multiplyMatrices(U.projectionMatrix,U.matrixWorldInverse),ae.setFromProjectionMatrix(j,mn,U.reversedDepth),$=this.localClippingEnabled,Kt=st.init(this.clippingPlanes,$),m=G.get(b,S.length),m.init(),S.push(m),it.enabled===!0&&it.isPresenting===!0){let et=v.xr.getDepthSensingMesh();et!==null&&Za(et,U,-1/0,v.sortObjects)}Za(b,U,0,v.sortObjects),m.finish(),v.sortObjects===!0&&m.sort(rt,lt),qt=it.enabled===!1||it.isPresenting===!1||it.hasDepthSensing()===!1,qt&&Mt.addToRenderList(m,b),this.info.render.frame++,Kt===!0&&st.beginShadows();let B=p.state.shadowsArray;yt.render(B,b,U),Kt===!0&&st.endShadows(),this.info.autoReset===!0&&this.info.reset();let z=m.opaque,N=m.transmissive;if(p.setupLights(),U.isArrayCamera){let et=U.cameras;if(N.length>0)for(let ht=0,gt=et.length;ht<gt;ht++){let dt=et[ht];Oc(z,N,b,dt)}qt&&Mt.render(b);for(let ht=0,gt=et.length;ht<gt;ht++){let dt=et[ht];kc(m,b,dt,dt.viewport)}}else N.length>0&&Oc(z,N,b,U),qt&&Mt.render(b),kc(m,b,U);I!==null&&C===0&&(Ht.updateMultisampleRenderTarget(I),Ht.updateRenderTargetMipmap(I)),b.isScene===!0&&b.onAfterRender(v,b,U),ct.resetDefaultState(),M=-1,w=null,y.pop(),y.length>0?(p=y[y.length-1],Kt===!0&&st.setGlobalState(v.clippingPlanes,p.state.camera)):p=null,S.pop(),S.length>0?m=S[S.length-1]:m=null};function Za(b,U,B,z){if(b.visible===!1)return;if(b.layers.test(U.layers)){if(b.isGroup)B=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(U);else if(b.isLight)p.pushLight(b),b.castShadow&&p.pushShadow(b);else if(b.isSprite){if(!b.frustumCulled||ae.intersectsSprite(b)){z&&Ut.setFromMatrixPosition(b.matrixWorld).applyMatrix4(j);let ht=F.update(b),gt=b.material;gt.visible&&m.push(b,ht,gt,B,Ut.z,null)}}else if((b.isMesh||b.isLine||b.isPoints)&&(!b.frustumCulled||ae.intersectsObject(b))){let ht=F.update(b),gt=b.material;if(z&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),Ut.copy(b.boundingSphere.center)):(ht.boundingSphere===null&&ht.computeBoundingSphere(),Ut.copy(ht.boundingSphere.center)),Ut.applyMatrix4(b.matrixWorld).applyMatrix4(j)),Array.isArray(gt)){let dt=ht.groups;for(let Ct=0,Pt=dt.length;Ct<Pt;Ct++){let Tt=dt[Ct],Wt=gt[Tt.materialIndex];Wt&&Wt.visible&&m.push(b,ht,Wt,B,Ut.z,Tt)}}else gt.visible&&m.push(b,ht,gt,B,Ut.z,null)}}let et=b.children;for(let ht=0,gt=et.length;ht<gt;ht++)Za(et[ht],U,B,z)}function kc(b,U,B,z){let N=b.opaque,et=b.transmissive,ht=b.transparent;p.setupLightsView(B),Kt===!0&&st.setGlobalState(v.clippingPlanes,B),z&&_t.viewport(P.copy(z)),N.length>0&&Mr(N,U,B),et.length>0&&Mr(et,U,B),ht.length>0&&Mr(ht,U,B),_t.buffers.depth.setTest(!0),_t.buffers.depth.setMask(!0),_t.buffers.color.setMask(!0),_t.setPolygonOffset(!1)}function Oc(b,U,B,z){if((B.isScene===!0?B.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[z.id]===void 0&&(p.state.transmissionRenderTarget[z.id]=new Tn(1,1,{generateMipmaps:!0,type:kt.has("EXT_color_buffer_half_float")||kt.has("EXT_color_buffer_float")?fs:vn,minFilter:oi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:$t.workingColorSpace}));let et=p.state.transmissionRenderTarget[z.id],ht=z.viewport||P;et.setSize(ht.z*v.transmissionResolutionScale,ht.w*v.transmissionResolutionScale);let gt=v.getRenderTarget(),dt=v.getActiveCubeFace(),Ct=v.getActiveMipmapLevel();v.setRenderTarget(et),v.getClearColor(W),X=v.getClearAlpha(),X<1&&v.setClearColor(16777215,.5),v.clear(),qt&&Mt.render(B);let Pt=v.toneMapping;v.toneMapping=Wn;let Tt=z.viewport;if(z.viewport!==void 0&&(z.viewport=void 0),p.setupLightsView(z),Kt===!0&&st.setGlobalState(v.clippingPlanes,z),Mr(b,B,z),Ht.updateMultisampleRenderTarget(et),Ht.updateRenderTargetMipmap(et),kt.has("WEBGL_multisampled_render_to_texture")===!1){let Wt=!1;for(let se=0,ye=U.length;se<ye;se++){let de=U[se],oe=de.object,At=de.geometry,ge=de.material,Yt=de.group;if(ge.side===hn&&oe.layers.test(z.layers)){let je=ge.side;ge.side=Be,ge.needsUpdate=!0,Bc(oe,B,z,At,ge,Yt),ge.side=je,ge.needsUpdate=!0,Wt=!0}}Wt===!0&&(Ht.updateMultisampleRenderTarget(et),Ht.updateRenderTargetMipmap(et))}v.setRenderTarget(gt,dt,Ct),v.setClearColor(W,X),Tt!==void 0&&(z.viewport=Tt),v.toneMapping=Pt}function Mr(b,U,B){let z=U.isScene===!0?U.overrideMaterial:null;for(let N=0,et=b.length;N<et;N++){let ht=b[N],gt=ht.object,dt=ht.geometry,Ct=ht.group,Pt=ht.material;Pt.allowOverride===!0&&z!==null&&(Pt=z),gt.layers.test(B.layers)&&Bc(gt,U,B,dt,Pt,Ct)}}function Bc(b,U,B,z,N,et){b.onBeforeRender(v,U,B,z,N,et),b.modelViewMatrix.multiplyMatrices(B.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),N.onBeforeRender(v,U,B,z,b,et),N.transparent===!0&&N.side===hn&&N.forceSinglePass===!1?(N.side=Be,N.needsUpdate=!0,v.renderBufferDirect(B,U,z,N,b,et),N.side=Bn,N.needsUpdate=!0,v.renderBufferDirect(B,U,z,N,b,et),N.side=hn):v.renderBufferDirect(B,U,z,N,b,et),b.onAfterRender(v,U,B,z,N,et)}function br(b,U,B){U.isScene!==!0&&(U=wt);let z=vt.get(b),N=p.state.lights,et=p.state.shadowsArray,ht=N.state.version,gt=q.getParameters(b,N.state,et,U,B),dt=q.getProgramCacheKey(gt),Ct=z.programs;z.environment=b.isMeshStandardMaterial?U.environment:null,z.fog=U.fog,z.envMap=(b.isMeshStandardMaterial?Me:Le).get(b.envMap||z.environment),z.envMapRotation=z.environment!==null&&b.envMap===null?U.environmentRotation:b.envMapRotation,Ct===void 0&&(b.addEventListener("dispose",Y),Ct=new Map,z.programs=Ct);let Pt=Ct.get(dt);if(Pt!==void 0){if(z.currentProgram===Pt&&z.lightsStateVersion===ht)return Hc(b,gt),Pt}else gt.uniforms=q.getUniforms(b),b.onBeforeCompile(gt,v),Pt=q.acquireProgram(gt,dt),Ct.set(dt,Pt),z.uniforms=gt.uniforms;let Tt=z.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Tt.clippingPlanes=st.uniform),Hc(b,gt),z.needsLights=vd(b),z.lightsStateVersion=ht,z.needsLights&&(Tt.ambientLightColor.value=N.state.ambient,Tt.lightProbe.value=N.state.probe,Tt.directionalLights.value=N.state.directional,Tt.directionalLightShadows.value=N.state.directionalShadow,Tt.spotLights.value=N.state.spot,Tt.spotLightShadows.value=N.state.spotShadow,Tt.rectAreaLights.value=N.state.rectArea,Tt.ltc_1.value=N.state.rectAreaLTC1,Tt.ltc_2.value=N.state.rectAreaLTC2,Tt.pointLights.value=N.state.point,Tt.pointLightShadows.value=N.state.pointShadow,Tt.hemisphereLights.value=N.state.hemi,Tt.directionalShadowMap.value=N.state.directionalShadowMap,Tt.directionalShadowMatrix.value=N.state.directionalShadowMatrix,Tt.spotShadowMap.value=N.state.spotShadowMap,Tt.spotLightMatrix.value=N.state.spotLightMatrix,Tt.spotLightMap.value=N.state.spotLightMap,Tt.pointShadowMap.value=N.state.pointShadowMap,Tt.pointShadowMatrix.value=N.state.pointShadowMatrix),z.currentProgram=Pt,z.uniformsList=null,Pt}function zc(b){if(b.uniformsList===null){let U=b.currentProgram.getUniforms();b.uniformsList=_s.seqWithValue(U.seq,b.uniforms)}return b.uniformsList}function Hc(b,U){let B=vt.get(b);B.outputColorSpace=U.outputColorSpace,B.batching=U.batching,B.batchingColor=U.batchingColor,B.instancing=U.instancing,B.instancingColor=U.instancingColor,B.instancingMorph=U.instancingMorph,B.skinning=U.skinning,B.morphTargets=U.morphTargets,B.morphNormals=U.morphNormals,B.morphColors=U.morphColors,B.morphTargetsCount=U.morphTargetsCount,B.numClippingPlanes=U.numClippingPlanes,B.numIntersection=U.numClipIntersection,B.vertexAlphas=U.vertexAlphas,B.vertexTangents=U.vertexTangents,B.toneMapping=U.toneMapping}function xd(b,U,B,z,N){U.isScene!==!0&&(U=wt),Ht.resetTextureUnits();let et=U.fog,ht=z.isMeshStandardMaterial?U.environment:null,gt=I===null?v.outputColorSpace:I.isXRRenderTarget===!0?I.texture.colorSpace:Mi,dt=(z.isMeshStandardMaterial?Me:Le).get(z.envMap||ht),Ct=z.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,Pt=!!B.attributes.tangent&&(!!z.normalMap||z.anisotropy>0),Tt=!!B.morphAttributes.position,Wt=!!B.morphAttributes.normal,se=!!B.morphAttributes.color,ye=Wn;z.toneMapped&&(I===null||I.isXRRenderTarget===!0)&&(ye=v.toneMapping);let de=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,oe=de!==void 0?de.length:0,At=vt.get(z),ge=p.state.lights;if(Kt===!0&&($===!0||b!==w)){let Xe=b===w&&z.id===M;st.setState(z,b,Xe)}let Yt=!1;z.version===At.__version?(At.needsLights&&At.lightsStateVersion!==ge.state.version||At.outputColorSpace!==gt||N.isBatchedMesh&&At.batching===!1||!N.isBatchedMesh&&At.batching===!0||N.isBatchedMesh&&At.batchingColor===!0&&N.colorTexture===null||N.isBatchedMesh&&At.batchingColor===!1&&N.colorTexture!==null||N.isInstancedMesh&&At.instancing===!1||!N.isInstancedMesh&&At.instancing===!0||N.isSkinnedMesh&&At.skinning===!1||!N.isSkinnedMesh&&At.skinning===!0||N.isInstancedMesh&&At.instancingColor===!0&&N.instanceColor===null||N.isInstancedMesh&&At.instancingColor===!1&&N.instanceColor!==null||N.isInstancedMesh&&At.instancingMorph===!0&&N.morphTexture===null||N.isInstancedMesh&&At.instancingMorph===!1&&N.morphTexture!==null||At.envMap!==dt||z.fog===!0&&At.fog!==et||At.numClippingPlanes!==void 0&&(At.numClippingPlanes!==st.numPlanes||At.numIntersection!==st.numIntersection)||At.vertexAlphas!==Ct||At.vertexTangents!==Pt||At.morphTargets!==Tt||At.morphNormals!==Wt||At.morphColors!==se||At.toneMapping!==ye||At.morphTargetsCount!==oe)&&(Yt=!0):(Yt=!0,At.__version=z.version);let je=At.currentProgram;Yt===!0&&(je=br(z,U,N));let Oi=!1,Qe=!1,Rs=!1,xe=je.getUniforms(),an=At.uniforms;if(_t.useProgram(je.program)&&(Oi=!0,Qe=!0,Rs=!0),z.id!==M&&(M=z.id,Qe=!0),Oi||w!==b){_t.buffers.depth.getReversed()&&b.reversedDepth!==!0&&(b._reversedDepth=!0,b.updateProjectionMatrix()),xe.setValue(R,"projectionMatrix",b.projectionMatrix),xe.setValue(R,"viewMatrix",b.matrixWorldInverse);let Ye=xe.map.cameraPosition;Ye!==void 0&&Ye.setValue(R,mt.setFromMatrixPosition(b.matrixWorld)),It.logarithmicDepthBuffer&&xe.setValue(R,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(z.isMeshPhongMaterial||z.isMeshToonMaterial||z.isMeshLambertMaterial||z.isMeshBasicMaterial||z.isMeshStandardMaterial||z.isShaderMaterial)&&xe.setValue(R,"isOrthographic",b.isOrthographicCamera===!0),w!==b&&(w=b,Qe=!0,Rs=!0)}if(N.isSkinnedMesh){xe.setOptional(R,N,"bindMatrix"),xe.setOptional(R,N,"bindMatrixInverse");let Xe=N.skeleton;Xe&&(Xe.boneTexture===null&&Xe.computeBoneTexture(),xe.setValue(R,"boneTexture",Xe.boneTexture,Ht))}N.isBatchedMesh&&(xe.setOptional(R,N,"batchingTexture"),xe.setValue(R,"batchingTexture",N._matricesTexture,Ht),xe.setOptional(R,N,"batchingIdTexture"),xe.setValue(R,"batchingIdTexture",N._indirectTexture,Ht),xe.setOptional(R,N,"batchingColorTexture"),N._colorsTexture!==null&&xe.setValue(R,"batchingColorTexture",N._colorsTexture,Ht));let ln=B.morphAttributes;if((ln.position!==void 0||ln.normal!==void 0||ln.color!==void 0)&&nt.update(N,B,je),(Qe||At.receiveShadow!==N.receiveShadow)&&(At.receiveShadow=N.receiveShadow,xe.setValue(R,"receiveShadow",N.receiveShadow)),z.isMeshGouraudMaterial&&z.envMap!==null&&(an.envMap.value=dt,an.flipEnvMap.value=dt.isCubeTexture&&dt.isRenderTargetTexture===!1?-1:1),z.isMeshStandardMaterial&&z.envMap===null&&U.environment!==null&&(an.envMapIntensity.value=U.environmentIntensity),Qe&&(xe.setValue(R,"toneMappingExposure",v.toneMappingExposure),At.needsLights&&_d(an,Rs),et&&z.fog===!0&&K.refreshFogUniforms(an,et),K.refreshMaterialUniforms(an,z,O,Q,p.state.transmissionRenderTarget[b.id]),_s.upload(R,zc(At),an,Ht)),z.isShaderMaterial&&z.uniformsNeedUpdate===!0&&(_s.upload(R,zc(At),an,Ht),z.uniformsNeedUpdate=!1),z.isSpriteMaterial&&xe.setValue(R,"center",N.center),xe.setValue(R,"modelViewMatrix",N.modelViewMatrix),xe.setValue(R,"normalMatrix",N.normalMatrix),xe.setValue(R,"modelMatrix",N.matrixWorld),z.isShaderMaterial||z.isRawShaderMaterial){let Xe=z.uniformsGroups;for(let Ye=0,Ja=Xe.length;Ye<Ja;Ye++){let fi=Xe[Ye];Bt.update(fi,je),Bt.bind(fi,je)}}return je}function _d(b,U){b.ambientLightColor.needsUpdate=U,b.lightProbe.needsUpdate=U,b.directionalLights.needsUpdate=U,b.directionalLightShadows.needsUpdate=U,b.pointLights.needsUpdate=U,b.pointLightShadows.needsUpdate=U,b.spotLights.needsUpdate=U,b.spotLightShadows.needsUpdate=U,b.rectAreaLights.needsUpdate=U,b.hemisphereLights.needsUpdate=U}function vd(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return C},this.getRenderTarget=function(){return I},this.setRenderTargetTextures=function(b,U,B){let z=vt.get(b);z.__autoAllocateDepthBuffer=b.resolveDepthBuffer===!1,z.__autoAllocateDepthBuffer===!1&&(z.__useRenderToTexture=!1),vt.get(b.texture).__webglTexture=U,vt.get(b.depthTexture).__webglTexture=z.__autoAllocateDepthBuffer?void 0:B,z.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(b,U){let B=vt.get(b);B.__webglFramebuffer=U,B.__useDefaultFramebuffer=U===void 0};let yd=R.createFramebuffer();this.setRenderTarget=function(b,U=0,B=0){I=b,E=U,C=B;let z=!0,N=null,et=!1,ht=!1;if(b){let dt=vt.get(b);if(dt.__useDefaultFramebuffer!==void 0)_t.bindFramebuffer(R.FRAMEBUFFER,null),z=!1;else if(dt.__webglFramebuffer===void 0)Ht.setupRenderTarget(b);else if(dt.__hasExternalTextures)Ht.rebindTextures(b,vt.get(b.texture).__webglTexture,vt.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){let Tt=b.depthTexture;if(dt.__boundDepthTexture!==Tt){if(Tt!==null&&vt.has(Tt)&&(b.width!==Tt.image.width||b.height!==Tt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Ht.setupDepthRenderbuffer(b)}}let Ct=b.texture;(Ct.isData3DTexture||Ct.isDataArrayTexture||Ct.isCompressedArrayTexture)&&(ht=!0);let Pt=vt.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(Pt[U])?N=Pt[U][B]:N=Pt[U],et=!0):b.samples>0&&Ht.useMultisampledRTT(b)===!1?N=vt.get(b).__webglMultisampledFramebuffer:Array.isArray(Pt)?N=Pt[B]:N=Pt,P.copy(b.viewport),k.copy(b.scissor),H=b.scissorTest}else P.copy(pt).multiplyScalar(O).floor(),k.copy(zt).multiplyScalar(O).floor(),H=ee;if(B!==0&&(N=yd),_t.bindFramebuffer(R.FRAMEBUFFER,N)&&z&&_t.drawBuffers(b,N),_t.viewport(P),_t.scissor(k),_t.setScissorTest(H),et){let dt=vt.get(b.texture);R.framebufferTexture2D(R.FRAMEBUFFER,R.COLOR_ATTACHMENT0,R.TEXTURE_CUBE_MAP_POSITIVE_X+U,dt.__webglTexture,B)}else if(ht){let dt=U;for(let Ct=0;Ct<b.textures.length;Ct++){let Pt=vt.get(b.textures[Ct]);R.framebufferTextureLayer(R.FRAMEBUFFER,R.COLOR_ATTACHMENT0+Ct,Pt.__webglTexture,B,dt)}}else if(b!==null&&B!==0){let dt=vt.get(b.texture);R.framebufferTexture2D(R.FRAMEBUFFER,R.COLOR_ATTACHMENT0,R.TEXTURE_2D,dt.__webglTexture,B)}M=-1},this.readRenderTargetPixels=function(b,U,B,z,N,et,ht,gt=0){if(!(b&&b.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let dt=vt.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&ht!==void 0&&(dt=dt[ht]),dt){_t.bindFramebuffer(R.FRAMEBUFFER,dt);try{let Ct=b.textures[gt],Pt=Ct.format,Tt=Ct.type;if(!It.textureFormatReadable(Pt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!It.textureTypeReadable(Tt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}U>=0&&U<=b.width-z&&B>=0&&B<=b.height-N&&(b.textures.length>1&&R.readBuffer(R.COLOR_ATTACHMENT0+gt),R.readPixels(U,B,z,N,bt.convert(Pt),bt.convert(Tt),et))}finally{let Ct=I!==null?vt.get(I).__webglFramebuffer:null;_t.bindFramebuffer(R.FRAMEBUFFER,Ct)}}},this.readRenderTargetPixelsAsync=async function(b,U,B,z,N,et,ht,gt=0){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let dt=vt.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&ht!==void 0&&(dt=dt[ht]),dt)if(U>=0&&U<=b.width-z&&B>=0&&B<=b.height-N){_t.bindFramebuffer(R.FRAMEBUFFER,dt);let Ct=b.textures[gt],Pt=Ct.format,Tt=Ct.type;if(!It.textureFormatReadable(Pt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!It.textureTypeReadable(Tt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let Wt=R.createBuffer();R.bindBuffer(R.PIXEL_PACK_BUFFER,Wt),R.bufferData(R.PIXEL_PACK_BUFFER,et.byteLength,R.STREAM_READ),b.textures.length>1&&R.readBuffer(R.COLOR_ATTACHMENT0+gt),R.readPixels(U,B,z,N,bt.convert(Pt),bt.convert(Tt),0);let se=I!==null?vt.get(I).__webglFramebuffer:null;_t.bindFramebuffer(R.FRAMEBUFFER,se);let ye=R.fenceSync(R.SYNC_GPU_COMMANDS_COMPLETE,0);return R.flush(),await hu(R,ye,4),R.bindBuffer(R.PIXEL_PACK_BUFFER,Wt),R.getBufferSubData(R.PIXEL_PACK_BUFFER,0,et),R.deleteBuffer(Wt),R.deleteSync(ye),et}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(b,U=null,B=0){let z=Math.pow(2,-B),N=Math.floor(b.image.width*z),et=Math.floor(b.image.height*z),ht=U!==null?U.x:0,gt=U!==null?U.y:0;Ht.setTexture2D(b,0),R.copyTexSubImage2D(R.TEXTURE_2D,B,0,0,ht,gt,N,et),_t.unbindTexture()};let Md=R.createFramebuffer(),bd=R.createFramebuffer();this.copyTextureToTexture=function(b,U,B=null,z=null,N=0,et=null){et===null&&(N!==0?(ss("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),et=N,N=0):et=0);let ht,gt,dt,Ct,Pt,Tt,Wt,se,ye,de=b.isCompressedTexture?b.mipmaps[et]:b.image;if(B!==null)ht=B.max.x-B.min.x,gt=B.max.y-B.min.y,dt=B.isBox3?B.max.z-B.min.z:1,Ct=B.min.x,Pt=B.min.y,Tt=B.isBox3?B.min.z:0;else{let ln=Math.pow(2,-N);ht=Math.floor(de.width*ln),gt=Math.floor(de.height*ln),b.isDataArrayTexture?dt=de.depth:b.isData3DTexture?dt=Math.floor(de.depth*ln):dt=1,Ct=0,Pt=0,Tt=0}z!==null?(Wt=z.x,se=z.y,ye=z.z):(Wt=0,se=0,ye=0);let oe=bt.convert(U.format),At=bt.convert(U.type),ge;U.isData3DTexture?(Ht.setTexture3D(U,0),ge=R.TEXTURE_3D):U.isDataArrayTexture||U.isCompressedArrayTexture?(Ht.setTexture2DArray(U,0),ge=R.TEXTURE_2D_ARRAY):(Ht.setTexture2D(U,0),ge=R.TEXTURE_2D),R.pixelStorei(R.UNPACK_FLIP_Y_WEBGL,U.flipY),R.pixelStorei(R.UNPACK_PREMULTIPLY_ALPHA_WEBGL,U.premultiplyAlpha),R.pixelStorei(R.UNPACK_ALIGNMENT,U.unpackAlignment);let Yt=R.getParameter(R.UNPACK_ROW_LENGTH),je=R.getParameter(R.UNPACK_IMAGE_HEIGHT),Oi=R.getParameter(R.UNPACK_SKIP_PIXELS),Qe=R.getParameter(R.UNPACK_SKIP_ROWS),Rs=R.getParameter(R.UNPACK_SKIP_IMAGES);R.pixelStorei(R.UNPACK_ROW_LENGTH,de.width),R.pixelStorei(R.UNPACK_IMAGE_HEIGHT,de.height),R.pixelStorei(R.UNPACK_SKIP_PIXELS,Ct),R.pixelStorei(R.UNPACK_SKIP_ROWS,Pt),R.pixelStorei(R.UNPACK_SKIP_IMAGES,Tt);let xe=b.isDataArrayTexture||b.isData3DTexture,an=U.isDataArrayTexture||U.isData3DTexture;if(b.isDepthTexture){let ln=vt.get(b),Xe=vt.get(U),Ye=vt.get(ln.__renderTarget),Ja=vt.get(Xe.__renderTarget);_t.bindFramebuffer(R.READ_FRAMEBUFFER,Ye.__webglFramebuffer),_t.bindFramebuffer(R.DRAW_FRAMEBUFFER,Ja.__webglFramebuffer);for(let fi=0;fi<dt;fi++)xe&&(R.framebufferTextureLayer(R.READ_FRAMEBUFFER,R.COLOR_ATTACHMENT0,vt.get(b).__webglTexture,N,Tt+fi),R.framebufferTextureLayer(R.DRAW_FRAMEBUFFER,R.COLOR_ATTACHMENT0,vt.get(U).__webglTexture,et,ye+fi)),R.blitFramebuffer(Ct,Pt,ht,gt,Wt,se,ht,gt,R.DEPTH_BUFFER_BIT,R.NEAREST);_t.bindFramebuffer(R.READ_FRAMEBUFFER,null),_t.bindFramebuffer(R.DRAW_FRAMEBUFFER,null)}else if(N!==0||b.isRenderTargetTexture||vt.has(b)){let ln=vt.get(b),Xe=vt.get(U);_t.bindFramebuffer(R.READ_FRAMEBUFFER,Md),_t.bindFramebuffer(R.DRAW_FRAMEBUFFER,bd);for(let Ye=0;Ye<dt;Ye++)xe?R.framebufferTextureLayer(R.READ_FRAMEBUFFER,R.COLOR_ATTACHMENT0,ln.__webglTexture,N,Tt+Ye):R.framebufferTexture2D(R.READ_FRAMEBUFFER,R.COLOR_ATTACHMENT0,R.TEXTURE_2D,ln.__webglTexture,N),an?R.framebufferTextureLayer(R.DRAW_FRAMEBUFFER,R.COLOR_ATTACHMENT0,Xe.__webglTexture,et,ye+Ye):R.framebufferTexture2D(R.DRAW_FRAMEBUFFER,R.COLOR_ATTACHMENT0,R.TEXTURE_2D,Xe.__webglTexture,et),N!==0?R.blitFramebuffer(Ct,Pt,ht,gt,Wt,se,ht,gt,R.COLOR_BUFFER_BIT,R.NEAREST):an?R.copyTexSubImage3D(ge,et,Wt,se,ye+Ye,Ct,Pt,ht,gt):R.copyTexSubImage2D(ge,et,Wt,se,Ct,Pt,ht,gt);_t.bindFramebuffer(R.READ_FRAMEBUFFER,null),_t.bindFramebuffer(R.DRAW_FRAMEBUFFER,null)}else an?b.isDataTexture||b.isData3DTexture?R.texSubImage3D(ge,et,Wt,se,ye,ht,gt,dt,oe,At,de.data):U.isCompressedArrayTexture?R.compressedTexSubImage3D(ge,et,Wt,se,ye,ht,gt,dt,oe,de.data):R.texSubImage3D(ge,et,Wt,se,ye,ht,gt,dt,oe,At,de):b.isDataTexture?R.texSubImage2D(R.TEXTURE_2D,et,Wt,se,ht,gt,oe,At,de.data):b.isCompressedTexture?R.compressedTexSubImage2D(R.TEXTURE_2D,et,Wt,se,de.width,de.height,oe,de.data):R.texSubImage2D(R.TEXTURE_2D,et,Wt,se,ht,gt,oe,At,de);R.pixelStorei(R.UNPACK_ROW_LENGTH,Yt),R.pixelStorei(R.UNPACK_IMAGE_HEIGHT,je),R.pixelStorei(R.UNPACK_SKIP_PIXELS,Oi),R.pixelStorei(R.UNPACK_SKIP_ROWS,Qe),R.pixelStorei(R.UNPACK_SKIP_IMAGES,Rs),et===0&&U.generateMipmaps&&R.generateMipmap(ge),_t.unbindTexture()},this.initRenderTarget=function(b){vt.get(b).__webglFramebuffer===void 0&&Ht.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?Ht.setTextureCube(b,0):b.isData3DTexture?Ht.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?Ht.setTexture2DArray(b,0):Ht.setTexture2D(b,0),_t.unbindTexture()},this.resetState=function(){E=0,C=0,I=null,_t.reset(),ct.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return mn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=$t._getDrawingBufferColorSpace(t),e.unpackColorSpace=$t._getUnpackColorSpace()}};var Ce=16,gr=class{constructor(t,e,n){this.sx=t,this.sy=e,this.sz=n,this.cx=Math.ceil(t/Ce),this.cy=Math.ceil(e/Ce),this.cz=Math.ceil(n/Ce),this.ox=Math.floor(t/2),this.oz=Math.floor(n/2),this.data=new Uint8Array(t*e*n),this.flags=new Uint8Array(t*e*n),this.dirty=new Set,this.listeners=[]}idx(t,e,n){return(e*this.sz+(n+this.oz))*this.sx+(t+this.ox)}inside(t,e,n){return e>=0&&e<this.sy&&t+this.ox>=0&&t+this.ox<this.sx&&n+this.oz>=0&&n+this.oz<this.sz}get(t,e,n){return t=Math.floor(t),e=Math.floor(e),n=Math.floor(n),this.inside(t,e,n)?this.data[this.idx(t,e,n)]:0}flag(t,e,n){return this.inside(t,e,n)?this.flags[this.idx(t,e,n)]:0}set(t,e,n,i,r=0,o=!1){if(!this.inside(t,e,n))return!1;let a=this.idx(t,e,n),l=this.data[a];if(this.data[a]=i,this.flags[a]=i?r:0,this.markDirty(t,e,n),!o)for(let c of this.listeners)c(t,e,n,i,l);return!0}markDirty(t,e,n){let i=t+this.ox,r=n+this.oz,o=Math.floor(i/Ce),a=Math.floor(e/Ce),l=Math.floor(r/Ce);this.dirty.add(this.key(o,a,l));let c=i%Ce,h=e%Ce,u=r%Ce;c===0&&o>0&&this.dirty.add(this.key(o-1,a,l)),c===Ce-1&&o<this.cx-1&&this.dirty.add(this.key(o+1,a,l)),h===0&&a>0&&this.dirty.add(this.key(o,a-1,l)),h===Ce-1&&a<this.cy-1&&this.dirty.add(this.key(o,a+1,l)),u===0&&l>0&&this.dirty.add(this.key(o,a,l-1)),u===Ce-1&&l<this.cz-1&&this.dirty.add(this.key(o,a,l+1))}key(t,e,n){return(t*this.cy+e)*this.cz+n}unkey(t){let e=t%this.cz,n=(t-e)/this.cz,i=n%this.cy;return[(n-i)/this.cy,i,e]}solidAt(t,e,n){return ce(this.get(t,e,n))}topY(t,e){for(let n=this.sy-1;n>=0;n--)if(ce(this.get(t,n,e)))return n;return-1}fill(t,e,n,i,r,o,a,l=0){for(let c=e;c<=r;c++)for(let h=n;h<=o;h++)for(let u=t;u<=i;u++)this.set(u,c,h,a,l,!0)}raycast(t,e,n,i,r,o,a,l=c=>c!==0){let c=Math.floor(t),h=Math.floor(e),u=Math.floor(n),f=Math.sign(i),d=Math.sign(r),g=Math.sign(o),x=i?Math.abs(1/i):1/0,m=r?Math.abs(1/r):1/0,p=o?Math.abs(1/o):1/0,S=i?(f>0?c+1-t:t-c)*x:1/0,y=r?(d>0?h+1-e:e-h)*m:1/0,v=o?(g>0?u+1-n:n-u)*p:1/0,T=0,E=0,C=0,I=0;for(let M=0;M<256&&T<=a;M++){let w=this.get(c,h,u);if(l(w,c,h,u))return{x:c,y:h,z:u,id:w,nx:E,ny:C,nz:I,t:T};S<y&&S<v?(c+=f,T=S,S+=x,E=-f,C=0,I=0):y<v?(h+=d,T=y,y+=m,E=0,C=-d,I=0):(u+=g,T=v,v+=p,E=0,C=0,I=-g)}return null}boxHits(t,e,n,i,r,o){for(let a=Math.floor(e);a<=Math.floor(r-1e-6);a++)for(let l=Math.floor(n);l<=Math.floor(o-1e-6);l++)for(let c=Math.floor(t);c<=Math.floor(i-1e-6);c++)if(ce(this.get(c,a,l)))return!0;return!1}};var F0=[{n:[1,0,0],a:0,c:[[1,0,1],[1,0,0],[1,1,0],[1,1,1]],s:.8,t:"side"},{n:[-1,0,0],a:0,c:[[0,0,0],[0,0,1],[0,1,1],[0,1,0]],s:.8,t:"side"},{n:[0,1,0],a:1,c:[[0,1,1],[1,1,1],[1,1,0],[0,1,0]],s:1,t:"top"},{n:[0,-1,0],a:1,c:[[0,0,0],[1,0,0],[1,0,1],[0,0,1]],s:.55,t:"bottom"},{n:[0,0,1],a:2,c:[[0,0,1],[1,0,1],[1,1,1],[0,1,1]],s:.68,t:"side"},{n:[0,0,-1],a:2,c:[[1,0,0],[0,0,0],[0,1,0],[1,1,0]],s:.68,t:"side"}],_c=[[0,1],[1,1],[1,0],[0,0]],k0=[.45,.66,.83,1],ys=class{constructor(){this.pos=[],this.uv=[],this.col=[],this.idx=[],this.n=0}quad(t,e,n,i){let r=this.n;for(let o=0;o<4;o++)this.pos.push(t[o][0],t[o][1],t[o][2]),this.uv.push(e[o][0],e[o][1]),this.col.push(n[o],n[o],n[o]);i?this.idx.push(r+1,r+2,r+3,r+1,r+3,r):this.idx.push(r,r+1,r+2,r,r+2,r+3),this.n+=4}out(){if(!this.n)return null;let t=new Uint8Array(this.col.length);for(let e=0;e<t.length;e++)t[e]=Math.max(0,Math.min(255,Math.round(this.col[e]*255)));return{pos:new Float32Array(this.pos),uv:new Float32Array(this.uv),col:t,idx:this.n>65535?new Uint32Array(this.idx):new Uint16Array(this.idx)}}};function Gu(s,t,e,n,i){let r={solid:new ys,cutout:new ys,plant:new ys,trans:new ys},o=e*Ce-s.ox,a=n*Ce,l=i*Ce-s.oz,c=.4/t.width,h={},u=d=>h[d]||(h[d]=t.uv(d)),f=(d,g,x)=>{let m=s.get(d,g,x);if(!m)return!1;let p=Zt[m];return p.solid&&!p.transparent};for(let d=a;d<a+Ce&&d<s.sy;d++)for(let g=l;g<l+Ce;g++)for(let x=o;x<o+Ce;x++){let m=s.get(x,d,g);if(!m)continue;let p=Zt[m];if(!p||p.invisible)continue;if(p.cross){let[y,v,T,E]=u(p.tex.side),C=.42,I=x+.5,M=g+.5,w=_c.map(([k,H])=>[y+c+k*(T-2*c),v+c+H*(E-2*c)]),P=[.95,.95,1,1];r.plant.quad([[I-C,d,M-C],[I+C,d,M+C],[I+C,d+.9,M+C],[I-C,d+.9,M-C]],w,P,!1),r.plant.quad([[I-C,d,M+C],[I+C,d,M-C],[I+C,d+.9,M-C],[I-C,d+.9,M+C]],w,P,!1);continue}let S=m===11?r.trans:p.transparent?r.cutout:r.solid;for(let y of F0){let v=x+y.n[0],T=d+y.n[1],E=g+y.n[2],C=s.get(v,T,E);if(C){let O=Zt[C];if(O&&O.solid&&!O.transparent||C===m&&p.transparent)continue}if(T<0)continue;let[I,M,w,P]=u(p.tex[y.t]),k=(y.a+1)%3,H=(y.a+2)%3,W=[0,0,0,0],X=new Array(4),V=new Array(4);for(let O=0;O<4;O++){let rt=y.c[O];if(X[O]=[x+rt[0],d+rt[1],g+rt[2]],V[O]=[I+c+_c[O][0]*(w-2*c),M+c+_c[O][1]*(P-2*c)],p.light){W[O]=3;continue}let lt=[0,0,0],pt=[0,0,0];lt[k]=rt[k]?1:-1,pt[H]=rt[H]?1:-1;let zt=f(v+lt[0],T+lt[1],E+lt[2])?1:0,ee=f(v+pt[0],T+pt[1],E+pt[2])?1:0,ae=f(v+lt[0]+pt[0],T+lt[1]+pt[1],E+lt[2]+pt[2])?1:0;W[O]=zt&&ee?0:3-(zt+ee+ae)}let Q=p.light?[1.15,1.15,1.15,1.15]:W.map(O=>k0[O]*y.s);S.quad(X,V,Q,W[0]+W[2]<W[1]+W[3])}}return{solid:r.solid.out(),cutout:r.cutout.out(),plant:r.plant.out(),trans:r.trans.out()}}var Wu={meadow:{skyTop:6266856,skyHorizon:13625087,fog:12573951,sun:16773848,hemiSky:14676223,hemiGround:6978138,void:2768227,clouds:16777215},desert:{skyTop:5214176,skyHorizon:16770744,fog:16178350,sun:16770736,hemiSky:16773328,hemiGround:9072720,void:5913130,clouds:16774888},snow:{skyTop:6983616,skyHorizon:15134970,fog:14412020,sun:15791871,hemiSky:15791871,hemiGround:8030874,void:3820138,clouds:16777215},volcano:{skyTop:3807786,skyHorizon:14180410,fog:9058858,sun:16756864,hemiSky:16760992,hemiGround:4860458,void:1706510,clouds:6965834},dusk:{skyTop:2767482,skyHorizon:15769712,fog:13146762,sun:16765088,hemiSky:16767168,hemiGround:5917290,void:1710650,clouds:16769232}},Ca=class{constructor(t){this.renderer=new Ta({canvas:t,antialias:!1,powerPreference:"high-performance",alpha:!1,stencil:!1}),this.renderer.outputColorSpace=Re,this.scene=new bi,this.camera=new Ue(75,1,.08,260),this.scene.add(this.camera),this.hemi=new Ci(16777215,6710886,1.6),this.sun=new Ri(16777215,1.4),this.sun.position.set(.5,1,.35),this.scene.add(this.hemi,this.sun),this.chunks=new Map,this.world=null,this.pixel=1}setAtlas(t){this.atlas=t;let e=new ls(t.data,t.width,t.height,Ke);e.magFilter=Te,e.minFilter=Te,e.generateMipmaps=!1,e.colorSpace=Re,e.needsUpdate=!0,this.atlasTex=e;let n={map:e,vertexColors:!0,fog:!0};this.mats={solid:new Ae({...n}),cutout:new Ae({...n,alphaTest:.5}),plant:new Ae({...n,alphaTest:.5,side:hn}),trans:new Ae({...n,transparent:!0,opacity:.85,depthWrite:!1})},this.buildOverlays()}buildOverlays(){let t=new Oe(1.004,1.004,1.004);this.outline=new er(new sr(t),new hs({color:1118481,transparent:!0,opacity:.55})),this.outline.visible=!1,this.scene.add(this.outline);let e=new Oe(1.01,1.01,1.01),n=e.attributes.uv;this.crackGeo=e,this.crackUV0=n.array.slice(),this.crack=new ie(e,new Ae({map:this.atlasTex,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1})),this.crack.visible=!1,this.scene.add(this.crack)}setCrack(t,e,n,i){if(i<0){this.crack.visible=!1;return}let[r,o,a,l]=this.atlas.uv(`crack${Math.min(3,i)}`),c=this.crackGeo.attributes.uv;for(let h=0;h<c.count;h++)c.array[h*2]=r+this.crackUV0[h*2]*a,c.array[h*2+1]=o+(1-this.crackUV0[h*2+1])*l;c.needsUpdate=!0,this.crack.position.set(t+.5,e+.5,n+.5),this.crack.visible=!0}setTheme(t){let e=Wu[t]||Wu.meadow;this.theme=e,this.scene.fog=new js(e.fog,60,190),this.hemi.color.set(e.hemiSky),this.hemi.groundColor.set(e.hemiGround),this.sun.color.set(e.sun),this.sky&&(this.scene.remove(this.sky),this.sky.geometry.dispose());let n=new Ti(200,24,16),i=new Lt(e.skyTop),r=new Lt(e.skyHorizon),o=new Lt(e.void),a=[],l=n.attributes.position;for(let c=0;c<l.count;c++){let h=l.getY(c)/200,u=h>0?r.clone().lerp(i,Math.pow(h,.6)):r.clone().lerp(o,Math.min(1,-h*2.2));a.push(u.r,u.g,u.b)}n.setAttribute("color",new he(a,3)),this.sky=new ie(n,new Ae({vertexColors:!0,side:Be,fog:!1,depthWrite:!1})),this.sky.renderOrder=-1,this.scene.add(this.sky),this.buildClouds(e.clouds)}buildClouds(t){this.clouds&&(this.scene.remove(this.clouds),this.clouds.geometry.dispose());let e=new Oe(1,1,1),n=46,i=new wi(e,new Ae({color:t,transparent:!0,opacity:.85,fog:!1}),n),r=new Qt,o=new sn,a=new D,l=new D,c=7,h=()=>(c=c*16807%2147483647,c/2147483647);for(let u=0;u<n;u++)l.set((h()-.5)*320,70+h()*10,(h()-.5)*320),a.set(8+h()*22,2.5,6+h()*16),r.compose(l,o,a),i.setMatrixAt(u,r);this.clouds=i,this.scene.add(i)}setWorld(t){for(let e of this.chunks.values())this.disposeChunk(e);this.chunks.clear(),this.world=t;for(let e=0;e<t.cx;e++)for(let n=0;n<t.cy;n++)for(let i=0;i<t.cz;i++)t.dirty.add(t.key(e,n,i));this.flush(1/0)}disposeChunk(t){for(let e of t)this.scene.remove(e),e.geometry.dispose()}flush(t=6){let e=this.world;if(!e||!e.dirty.size)return 0;let n=0;for(let i of[...e.dirty]){if(n>=t)break;e.dirty.delete(i);let[r,o,a]=e.unkey(i),l=this.chunks.get(i);l&&this.disposeChunk(l);let c=Gu(e,this.atlas,r,o,a),h=[];for(let[u,f]of Object.entries(c)){if(!f)continue;let d=new ke;d.setAttribute("position",new Ee(f.pos,3)),d.setAttribute("uv",new Ee(f.uv,2)),d.setAttribute("color",new Ee(f.col,3,!0)),d.setIndex(new Ee(f.idx,1)),d.computeBoundingSphere();let g=new ie(d,this.mats[u]);g.matrixAutoUpdate=!1,u==="trans"&&(g.renderOrder=2),this.scene.add(g),h.push(g)}this.chunks.set(i,h),n++}return n}resize(t,e,n){this.pixel=n,this.renderer.setPixelRatio(n),this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix()}render(t){this.clouds&&(this.clouds.position.x=(this.clouds.position.x+t*.6)%160),this.sky&&this.sky.position.copy(this.camera.position),this.renderer.render(this.scene,this.camera)}};var Ra=class{constructor(t,e){this.canvas=t,this.ui=e,this.keys=new Set,this.pressed=new Set,this.mouse={l:!1,r:!1,lp:!1,rp:!1},this.look={x:0,y:0},this.wheel=0,this.locked=!1,this.enabled=!1,this.touch=matchMedia("(pointer: coarse)").matches||"ontouchstart"in window&&navigator.maxTouchPoints>0,this.t={moveId:null,mx:0,my:0,ox:0,oy:0,lookId:null,lx:0,ly:0,attack:!1,attackP:!1,place:!1,jump:!1,crouch:!1,sprint:!1},this.pad=null,this.bind()}bind(){addEventListener("keydown",t=>{if(!this.enabled&&!["Escape"].includes(t.code)){this.pressed.add(t.code);return}["Space","ArrowUp","ArrowDown","Tab"].includes(t.code)&&t.preventDefault(),this.keys.has(t.code)||this.pressed.add(t.code),this.keys.add(t.code)}),addEventListener("keyup",t=>this.keys.delete(t.code)),addEventListener("blur",()=>{this.keys.clear(),this.mouse.l=this.mouse.r=!1}),this.canvas.addEventListener("mousedown",t=>{if(!this.touch){if(!this.locked&&this.enabled){this.requestLock();return}t.button===0&&(this.mouse.l=!0,this.mouse.lp=!0),t.button===2&&(this.mouse.r=!0,this.mouse.rp=!0)}}),addEventListener("mouseup",t=>{t.button===0&&(this.mouse.l=!1),t.button===2&&(this.mouse.r=!1)}),addEventListener("contextmenu",t=>t.preventDefault()),addEventListener("mousemove",t=>{this.locked&&(this.look.x+=t.movementX,this.look.y+=t.movementY)}),addEventListener("wheel",t=>{this.locked&&(this.wheel+=Math.sign(t.deltaY))},{passive:!0}),document.addEventListener("pointerlockchange",()=>{let t=this.locked;this.locked=document.pointerLockElement===this.canvas,t&&!this.locked&&this.onUnlock&&this.onUnlock()}),addEventListener("touchstart",()=>{this.touch||(this.touch=!0,this.onTouch&&this.onTouch())},{passive:!0,capture:!0})}requestLock(){if(!this.touch)try{let t=this.canvas.requestPointerLock({unadjustedMovement:!0});t&&t.catch&&t.catch(e=>{if(e&&e.name==="NotSupportedError")try{let n=this.canvas.requestPointerLock();n&&n.catch&&n.catch(()=>{})}catch{}})}catch{try{this.canvas.requestPointerLock()}catch{}}}exitLock(){document.pointerLockElement&&document.exitPointerLock()}enable(t){this.enabled=t,t||(this.keys.clear(),this.mouse.l=this.mouse.r=!1,this.t.attack=this.t.place=this.t.jump=!1)}wireTouch(t){let e=this.t,n=t.querySelector(".joy"),i=t.querySelector(".joy .knob"),r=t.querySelector(".look-zone"),o=h=>{e.moveId=h.identifier;let u=n.getBoundingClientRect();e.ox=u.left+u.width/2,e.oy=u.top+u.height/2,a(h)},a=h=>{let u=n.getBoundingClientRect(),f=u.width/2,d=h.clientX-e.ox,g=h.clientY-e.oy,x=Math.hypot(d,g);x>f&&(d*=f/x,g*=f/x),e.mx=d/f,e.my=-g/f,i.style.transform=`translate(${d}px, ${g}px)`,e.sprint=x>f*.95};t.querySelector(".joy-zone").addEventListener("touchstart",h=>{h.preventDefault(),e.moveId==null&&o(h.changedTouches[0])},{passive:!1}),r.addEventListener("touchstart",h=>{if(h.preventDefault(),e.lookId==null){let u=h.changedTouches[0];e.lookId=u.identifier,e.lx=u.clientX,e.ly=u.clientY,e.tapT=performance.now(),e.tapX=u.clientX,e.tapY=u.clientY}},{passive:!1}),addEventListener("touchmove",h=>{for(let u of h.changedTouches)u.identifier===e.moveId&&a(u),u.identifier===e.lookId&&(this.look.x+=(u.clientX-e.lx)*2.2,this.look.y+=(u.clientY-e.ly)*2.2,e.lx=u.clientX,e.ly=u.clientY)},{passive:!0});let l=h=>{for(let u of h.changedTouches)u.identifier===e.moveId&&(e.moveId=null,e.mx=e.my=0,e.sprint=!1,i.style.transform=""),u.identifier===e.lookId&&(e.lookId=null,performance.now()-e.tapT<220&&Math.hypot(u.clientX-e.tapX,u.clientY-e.tapY)<12&&(e.tapPlace=!0))};addEventListener("touchend",l),addEventListener("touchcancel",l);let c=(h,u,f)=>{let d=t.querySelector(h);if(!d)return;d.addEventListener("touchstart",x=>{x.preventDefault(),x.stopPropagation(),d.classList.add("on"),u()},{passive:!1});let g=x=>{d.classList.remove("on"),f&&f()};d.addEventListener("touchend",g),d.addEventListener("touchcancel",g)};c(".tb-attack",()=>{e.attack=!0,e.attackP=!0},()=>{e.attack=!1}),c(".tb-place",()=>{e.place=!0,e.placeP=!0},()=>{e.place=!1}),c(".tb-jump",()=>{e.jump=!0,e.jumpP=!0},()=>{e.jump=!1}),c(".tb-crouch",()=>{e.crouch=!e.crouch,t.querySelector(".tb-crouch").classList.toggle("lit",e.crouch)})}sample(){let t=this.keys,e=this.t,n=0,i=0;(t.has("KeyW")||t.has("ArrowUp"))&&(i+=1),(t.has("KeyS")||t.has("ArrowDown"))&&(i-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(n+=1),(t.has("KeyA")||t.has("ArrowLeft"))&&(n-=1);let r=this.mouse.l,o=this.mouse.lp,a=this.mouse.rp,l=this.mouse.r,c=t.has("Space"),h=t.has("ShiftLeft")||t.has("ShiftRight"),u=t.has("ControlLeft")||t.has("KeyR")||!1,f=null;for(let p=1;p<=9;p++)this.pressed.has("Digit"+p)&&(f=p-1);let d=this.wheel;this.wheel=0,this.touch&&((e.mx||e.my)&&(n=e.mx,i=e.my),r=r||e.attack,o=o||e.attackP,a=a||e.placeP||e.tapPlace,l=l||e.place,c=c||e.jump,h=h||e.crouch,u=u||e.sprint&&i>.7,e.attackP=!1,e.placeP=!1,e.tapPlace=!1);let x=(navigator.getGamepads?[...navigator.getGamepads()].filter(Boolean):[])[0];if(x){let p=M=>Math.abs(M)<.16?0:M,S=p(x.axes[0]),y=p(x.axes[1]),v=p(x.axes[2]),T=p(x.axes[3]);(S||y)&&(n=S,i=-y),this.look.x+=Math.sign(v)*v*v*14,this.look.y+=Math.sign(T)*T*T*10;let E=M=>x.buttons[M]&&x.buttons[M].pressed,C=this.padPrev||[],I=M=>E(M)&&!C[M];r=r||E(7),o=o||I(7),l=l||E(6),a=a||I(6),c=c||E(0),h=h||E(1),u=u||E(10),I(5)&&(d+=1),I(4)&&(d-=1),I(9)&&this.pressed.add("Escape"),this.padPrev=x.buttons.map(M=>M.pressed),this.gamepad=!0}let m={mx:n,my:i,lookX:this.look.x,lookY:this.look.y,attack:r,attackPressed:o,use:a,useHeld:l,jump:c,crouch:h,sprint:u,sel:f,wheel:d,pressed:new Set(this.pressed)};return this.look.x=0,this.look.y=0,this.mouse.lp=!1,this.mouse.rp=!1,this.pressed.clear(),m}};var Xu={grass:{f:900,q:.8,d:.12,g:.5},gravel:{f:700,q:1.2,d:.12,g:.55},stone:{f:1500,q:2.5,d:.09,g:.5},wood:{f:500,q:4,d:.11,g:.6},sand:{f:2200,q:.6,d:.13,g:.35},snow:{f:1800,q:.7,d:.12,g:.35},glass:{f:3200,q:8,d:.14,g:.4},metal:{f:2400,q:10,d:.1,g:.35},cloth:{f:650,q:.7,d:.1,g:.45},egg:{f:1100,q:6,d:.18,g:.6}},Ia=class{constructor(){this.ctx=null,this.master=null,this.volume=.8,this.musicVol=.4,this.muted=!1,this.listener={x:0,y:0,z:0},this.musicOn=!1}unlock(){if(this.ctx){this.ctx.state==="suspended"&&!this.suspended&&this.ctx.resume().catch(()=>{});return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;this.ctx=new t,this.master=this.ctx.createGain(),this.master.connect(this.ctx.destination),this.sfx=this.ctx.createGain(),this.sfx.connect(this.master),this.mus=this.ctx.createGain(),this.mus.connect(this.master);let e=this.ctx.sampleRate;this.noiseBuf=this.ctx.createBuffer(1,e,this.ctx.sampleRate);let n=this.noiseBuf.getChannelData(0);for(let i=0;i<e;i++)n[i]=Math.random()*2-1;this.apply()}apply(){if(!this.master)return;let t=this.ctx.currentTime;this.master.gain.setTargetAtTime(this.muted||this.suspended?0:this.volume,t,.03),this.mus.gain.setTargetAtTime(this.musicVol*.5,t,.3)}setVolume(t,e){this.volume=t,e!=null&&(this.musicVol=e),this.apply()}setMuted(t){this.muted=t,this.apply()}suspend(t){this.suspended=t,this.ctx&&(this.apply(),t?this.ctx.suspend().catch(()=>{}):this.ctx.resume().catch(()=>{}))}att(t){if(!t)return 1;let e=Math.hypot(t.x-this.listener.x,t.y-this.listener.y,t.z-this.listener.z);return Math.max(0,1-e/28)**1.4}noise(t,e,n,i,r,o="bandpass",a=0){if(!this.ctx||i<.01)return;let l=this.ctx,c=l.currentTime+a,h=l.createBufferSource();h.buffer=this.noiseBuf,h.playbackRate.value=.8+Math.random()*.4;let u=l.createBiquadFilter();u.type=o,u.frequency.value=e,u.Q.value=n;let f=l.createGain();f.gain.setValueAtTime(i,c),f.gain.exponentialRampToValueAtTime(.001,c+t),h.connect(u).connect(f).connect(r||this.sfx),h.start(c,Math.random()*.5),h.stop(c+t+.05)}tone(t,e,n="square",i=.15,r=0,o=0,a){if(!this.ctx||!(i>.002))return;let l=this.ctx,c=l.currentTime+o,h=l.createOscillator();h.type=n,h.frequency.setValueAtTime(t,c),r&&h.frequency.exponentialRampToValueAtTime(Math.max(30,t*r),c+e);let u=l.createGain();u.gain.setValueAtTime(1e-4,c),u.gain.exponentialRampToValueAtTime(i,c+.008),u.gain.exponentialRampToValueAtTime(1e-4,c+e),h.connect(u).connect(a||this.sfx),h.start(c),h.stop(c+e+.05)}block(t,e,n){let i=Xu[t]||Xu.stone,r=this.att(n);if(e==="dig")this.noise(i.d,i.f*(.9+Math.random()*.2),i.q,i.g*.55*r);else if(e==="break"){if(this.noise(i.d*2.2,i.f*.8,i.q*.6,i.g*.9*r),t==="glass")for(let o=0;o<3;o++)this.tone(2400+Math.random()*1800,.12,"triangle",.05*r,.6,o*.03)}else e==="place"?(this.noise(i.d*1.4,i.f*.7,i.q,i.g*.8*r),this.tone(i.f*.12,.06,"sine",.12*r)):e==="step"&&this.noise(i.d*.8,i.f*.75,i.q,i.g*.22*r)}hit(t,e){let n=this.att(t);if(this.noise(.08,800,1.5,.6*n,null,"lowpass"),this.tone(180,.09,"square",.12*n,.5),e)for(let i=0;i<4;i++)this.tone(1600+i*300,.06,"triangle",.05*n,1.3,i*.02)}hurt(t){this.tone(t?300:260,.14,"sawtooth",t?.12:.06,.55),this.noise(.1,600,1,t?.3:.15,null,"lowpass")}swing(t){this.noise(.12,1800,.7,.18*this.att(t),null,"highpass")}eat(){for(let t=0;t<3;t++)this.noise(.07,1200+t*200,2,.3,null,"bandpass",t*.12)}pickup(){this.tone(880+Math.random()*200,.07,"sine",.12,1.6)}click(){this.tone(660,.05,"square",.06,1.2)}hover(){this.tone(980,.03,"sine",.03)}beep(t){this.tone(t?1320:880,t?.35:.15,"square",.1)}kill(){[660,880,1320].forEach((t,e)=>this.tone(t,.12,"square",.08,1,e*.07))}death(){[440,330,220,165].forEach((t,e)=>this.tone(t,.22,"sawtooth",.08,.9,e*.12))}win(){[523,659,784,1046,784,1046].forEach((t,e)=>this.tone(t,.22,"square",.09,1,e*.13))}egg(t){this.noise(.5,900,3,.7*Math.max(.35,this.att(t))),[300,200,120].forEach((e,n)=>this.tone(e,.3,"sawtooth",.12,.6,n*.1))}throwS(){this.noise(.15,1400,1,.25,null,"highpass")}warp(){this.tone(300,.4,"sine",.14,4),this.tone(450,.4,"triangle",.08,3)}levelUp(){[523,784,1046,1568].forEach((t,e)=>this.tone(t,.18,"triangle",.1,1,e*.09))}startMusic(t="calm"){if(!this.ctx||this.musicOn)return;this.musicOn=!0,this.musicStyle=t;let e=this.ctx,n={calm:[0,2,4,7,9,12,14,16],tense:[0,3,5,7,10,12,15,17]},i=0,r=e.currentTime+.1,o=[[0,4,7],[-3,0,4],[-7,-3,0],[-5,-1,2]],a=()=>{if(this.musicOn){for(;r<e.currentTime+.6;){let l=n[this.musicStyle]||n.calm,c=Math.floor(i/16)%4,h=i%16,u=57,f=d=>440*Math.pow(2,(d-69)/12);if(h===0)for(let d of o[c])this.tone(f(u+d-12),3.2,"triangle",.035,1,r-e.currentTime,this.mus);if(h%2===0&&Math.random()<.72){let d=l[Math.floor(Math.random()*l.length)]+o[c][0];this.tone(f(u+d+12),.45,"sine",.045,1,r-e.currentTime,this.mus)}h%4===2&&Math.random()<.5&&this.tone(f(u+o[c][1]),.25,"square",.012,1,r-e.currentTime,this.mus),r+=.21,i++}this.musicTimer=setTimeout(a,200)}};a()}stopMusic(){this.musicOn=!1,clearTimeout(this.musicTimer)}setMusicStyle(t){this.musicStyle=t}};var Pa=["wood","stone","iron","diamond"],qu={wood:["#a9824a","#7a5a2e"],stone:["#9a9a9a","#6a6a6a"],iron:["#e8e8e8","#a8a8a8"],diamond:["#6ff0e8","#2aa8a0"],leather:["#9a5a30","#6a3a1a"],chain:["#b8b8c0","#70707a"],gold:["#ffd84a","#c89a1a"]},$u=["leather","chain","iron","diamond"],Yu=["helmet","chest","legs","boots"],O0={leather:[1,3,2,1],chain:[2,5,4,1],iron:[2,6,5,2],diamond:[3,8,6,3]},te={},on=(s,t)=>{te[s]={id:s,stack:64,...t}};for(let s of Zt)s&&on(s.id,{name:s.name,kind:"block",block:s.id,icon:null});Pa.forEach((s,t)=>on(100+t,{name:`${s[0].toUpperCase()+s.slice(1)} Sword`,kind:"sword",tier:t,damage:[4,5,6,7][t],stack:1,icon:`sword_${s}`}));Pa.forEach((s,t)=>on(110+t,{name:`${s[0].toUpperCase()+s.slice(1)} Pickaxe`,kind:"pick",tier:t,damage:2+t*.5,speed:[2,3.5,5,7][t],stack:1,icon:`pick_${s}`}));Pa.forEach((s,t)=>on(120+t,{name:`${s[0].toUpperCase()+s.slice(1)} Axe`,kind:"axe",tier:t,damage:[3,4,5,6][t],speed:[2,3.5,5,7][t],stack:1,icon:`axe_${s}`}));on(130,{name:"Golden Apple",kind:"food",heal:8,stack:16,icon:"gapple"});on(131,{name:"Snowball",kind:"throw",stack:16,icon:"snowball"});on(132,{name:"Warp Orb",kind:"warp",stack:8,icon:"orb"});on(133,{name:"Apple",kind:"food",heal:4,stack:16,icon:"apple"});$u.forEach((s,t)=>Yu.forEach((e,n)=>on(150+t*4+n,{name:`${s[0].toUpperCase()+s.slice(1)} ${e[0].toUpperCase()+e.slice(1)}`,kind:"armor",tier:t,slot:n,points:O0[s][n],stack:1,icon:`armor_${s}_${e}`})));on(170,{name:"Iron",kind:"currency",stack:64,icon:"ingot_iron"});on(171,{name:"Gold",kind:"currency",stack:64,icon:"ingot_gold"});on(172,{name:"Diamond",kind:"currency",stack:64,icon:"gem"});on(180,{name:"Shears",kind:"shears",speed:6,stack:1,damage:1,icon:"shears"});function li(s,t,e,n){let i=[],r=Math.max(Math.abs(e-s),Math.abs(n-t));for(let o=0;o<=r;o++)i.push([Math.round(s+(e-s)*o/r),Math.round(t+(n-t)*o/r)]);return i}function Zu(){let s={},t=(i,r)=>{for(let[o,a]of li(2,13,6,9))i.set(o,a,r.hex("#6a4a2a")),i.set(o+1,a,r.hex("#8a6a3a"))};for(let i of Pa){let[r,o]=qu[i];s[`sword_${i}`]=(a,l)=>{a.clear();for(let[c,h]of li(5,10,13,2))a.set(c,h,l.hex(r)),a.set(c+1,h+1,l.hex(o)),a.set(c,h+1,l.hex(o));for(let[c,h]of li(3,8,7,12))a.set(c,h,l.hex("#4a3a2a"));for(let[c,h]of li(1,14,4,11))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));a.set(14,1,l.hex(r))},s[`pick_${i}`]=(a,l)=>{a.clear(),t(a,l);for(let[c,h]of li(6,9,11,4))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));for(let[c,h]of[[4,4],[5,3],[6,2],[7,2],[8,2],[9,2],[10,3],[11,4],[12,5],[13,6],[13,7],[12,8],[5,4],[9,3],[12,6]])a.set(c,h,l.hex(c>8&&h>4?o:r))},s[`axe_${i}`]=(a,l)=>{a.clear(),t(a,l);for(let[c,h]of li(6,9,11,4))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));for(let c=2;c<8;c++)for(let h=8;h<14;h++)h-8+(7-c)<7&&!(h===13&&c>5)&&a.set(h,c,l.hex(h>11?o:r))}}s.gapple=(i,r)=>e(i,r,"#ffd84a","#c89a1a"),s.apple=(i,r)=>e(i,r,"#e23c3c","#a01e1e");function e(i,r,o,a){i.clear();for(let l=4;l<14;l++)for(let c=3;c<13;c++){let h=Math.hypot(c-7.5,(l-8.8)*1.05);h<5&&i.set(c,l,r.hex(h>3.6||c>8&&l>9?a:o))}i.set(6,6,r.hex("#ffffff")),i.set(7,2,r.hex("#5a3a1a")),i.set(7,3,r.hex("#5a3a1a")),i.set(8,2,r.hex("#3f8f2a")),i.set(9,1,r.hex("#3f8f2a"))}s.snowball=(i,r)=>{i.clear();for(let o=3;o<13;o++)for(let a=3;a<13;a++){let l=Math.hypot(a-7.5,o-7.5);l<4.8&&i.set(a,o,r.hex(l>3.8||a>8&&o>8?"#b8c8d8":"#f4faff"))}},s.orb=(i,r)=>{i.clear();for(let o=3;o<13;o++)for(let a=3;a<13;a++){let l=Math.hypot(a-7.5,o-7.5);l<4.8&&i.set(a,o,r.hex(l>3.8?"#1a5a5a":l>2?"#2aa8a0":"#9ff0e8"))}i.set(6,6,r.hex("#ffffff"))};for(let i of $u){let[r,o]=qu[i],a={helmet:[[3,4,10,2],[3,6,2,4],[11,6,2,4]],chest:[[2,3,4,3],[10,3,4,3],[4,5,8,8]],legs:[[4,3,8,3],[4,6,3,8],[9,6,3,8]],boots:[[3,8,3,5],[10,8,3,5],[2,12,4,2],[10,12,4,2]]};for(let l of Yu)s[`armor_${i}_${l}`]=(c,h)=>{c.clear();for(let[u,f,d,g]of a[l])for(let x=f;x<f+g;x++)for(let m=u;m<u+d;m++)c.set(m,x,h.hex((m+x)%5===0?o:r));for(let[u,f,d,g]of a[l])for(let x=u;x<u+d;x++)c.set(x,f+g-1,h.hex(o))}}let n=(i,r)=>(o,a)=>{o.clear();for(let l=6;l<12;l++)for(let c=2+(11-l);c<14-(l-6)*.3;c++)o.set(c,l,a.hex(l===6||c<4+(11-l)?"#ffffff":l>9?r:i))};s.ingot_iron=n("#d8d8d8","#9a9a9a"),s.ingot_gold=n("#ffd84a","#c89a1a"),s.gem=(i,r)=>{i.clear();let o=[[7,2],[8,2],[5,4],[6,4],[7,4],[8,4],[9,4],[10,4],[4,6],[5,6],[6,6],[7,6],[8,6],[9,6],[10,6],[11,6],[5,8],[6,8],[7,8],[8,8],[9,8],[10,8],[6,10],[7,10],[8,10],[9,10],[7,12],[8,12]];for(let[a,l]of o)i.set(a,l,r.hex(a<7?"#c8fffb":"#5fe0d8")),i.set(a,l+1,r.hex(a<7?"#5fe0d8":"#2aa8a0"))},s.shears=(i,r)=>{i.clear();for(let[o,a]of li(3,12,11,4))i.set(o,a,r.hex("#d8d8d8"));for(let[o,a]of li(5,12,13,4))i.set(o,a,r.hex("#a8a8a8"));for(let[o,a]of[[2,12],[3,13],[2,13],[5,13],[6,13]])i.set(o,a,r.hex("#c8302a"))};for(let i of Object.keys(s)){let r=s[i];s[i]=(o,a)=>(r(o,a),o)}return s}var Ms=(s,t)=>150+s*4+t;var xr=1,ue=2;function Mc(s){let t=s>>>0||1;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}function Ju(s){let t=Mc(s),e=new Uint8Array(512),n=new Float32Array(256);for(let a=0;a<256;a++)e[a]=a,n[a]=t();for(let a=255;a>0;a--){let l=Math.floor(t()*(a+1));[e[a],e[l]]=[e[l],e[a]]}for(let a=0;a<256;a++)e[a+256]=e[a];let i=(a,l)=>n[e[(a&255)+e[l&255]]],r=a=>a*a*(3-2*a),o=(a,l)=>{let c=Math.floor(a),h=Math.floor(l),u=r(a-c),f=r(l-h),d=i(c,h),g=i(c+1,h),x=i(c,h+1),m=i(c+1,h+1);return d+(g-d)*u+(x-d)*f+(d-g-x+m)*u*f};return(a,l,c=3)=>{let h=0,u=1,f=1,d=0;for(let g=0;g<c;g++)h+=o(a*f,l*f)*u,d+=u,u*=.5,f*=2;return h/d}}var yc={meadow:{top:1,under:2,core:3,accent:28,trunk:6,leaves:7,plants:[40,40,40,41,42],tree:"oak",rock:4},desert:{top:8,under:9,core:9,accent:22,trunk:44,leaves:0,plants:[43,43,40],tree:"cactus",rock:9},snow:{top:10,under:2,core:3,accent:11,trunk:6,leaves:7,plants:[40],tree:"spruce",rock:3},volcano:{top:18,under:18,core:13,accent:19,trunk:18,leaves:0,plants:[],tree:"spire",rock:18}};function bs(s,t,e,n,i,r,o,a={}){let l=Math.ceil(r*1.35),c=a.depth??r*1.1,h=[];for(let u=-l;u<=l;u++)for(let f=-l;f<=l;f++){let d=Math.hypot(f,u)/r+(t((e+f)*.13,(n+u)*.13)-.5)*(a.rough??.55);if(d>=1)continue;let g=e+f,x=n+u,m=a.flat?0:Math.floor(t(g*.21+50,x*.21)*2.2*(1-d)),p=i+m,S=Math.round(i-1-Math.pow(1-d,.75)*c*(.55+t(g*.3,x*.3+9)*.7));for(let y=S;y<=p;y++){let v=o.core;y===p?v=o.top:y>=p-2?v=o.under:t(g*.4,y*.4+x*.4)>.72&&(v=o.accent),s.set(g,y,x,v,ue,!0)}h.push([g,p,x,d])}return h}function B0(s,t,e,n,i,r,o){if(r==="oak"){let a=4+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,o.trunk,ue,!0);for(let l=a-2;l<=a+1;l++){let c=l>=a?1:2;for(let h=-c;h<=c;h++)for(let u=-c;u<=c;u++)Math.abs(u)===c&&Math.abs(h)===c&&(l===a+1||t()<.5)||s.get(e+u,n+l,i+h)||s.set(e+u,n+l,i+h,o.leaves,ue,!0)}}else if(r==="spruce"){let a=6+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,o.trunk,ue,!0);for(let l=2;l<=a+1;l++){let c=l===a+1?0:Math.max(1,Math.round((a-l)/2.2));for(let h=-c;h<=c;h++)for(let u=-c;u<=c;u++)Math.abs(u)+Math.abs(h)>c+1||s.get(e+u,n+l,i+h)||s.set(e+u,n+l,i+h,o.leaves,ue,!0);if(l%2)for(let[h,u]of[[1,0],[-1,0],[0,1],[0,-1]])s.get(e+h*2,n+l,i+u*2)===o.leaves&&s.set(e+h*2,n+l,i+u*2,10,ue,!0)}}else if(r==="cactus"){let a=2+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,44,ue,!0)}else if(r==="spire"){let a=3+Math.floor(t()*4);for(let l=1;l<=a;l++)s.set(e,n+l,i,l===a?19:18,ue,!0)}}function Ss(s,t,e,n,i=.18,r=1,o=()=>!0){let a=e.filter(([,,,c])=>c<.8),l=0;for(let c=0;c<r*6&&l<r;c++){let h=a[Math.floor(t()*a.length)];!h||h[3]<.25||s.get(h[0],h[1]+1,h[2])||!o(h[0],h[2])||(B0(s,t,h[0],h[1],h[2],n.tree,n),l++)}if(n.plants.length)for(let[c,h,u,f]of e)f<.9&&t()<i&&!s.get(c,h+1,u)&&s.get(c,h,u)===n.top&&s.set(c,h+1,u,n.plants[Math.floor(t()*n.plants.length)],ue,!0)}function vc(s,t,e,n,i,r){s.set(e,n,i,17,ue,!0);for(let o=n+1;o<=n+2;o++)s.get(e,o,i)>=40&&s.set(e,o,i,0,0,!0);t.push({x:e,y:n,z:i,tier:r,items:[]})}function bc(s,t="meadow",e=8){let n=new gr(120,64,120),i=Mc(s),r=Ju(s),o=yc[t],a=[],l=[],c=30,h=36;for(let f=0;f<e;f++){let d=f/e*Math.PI*2+.2,g=Math.round(Math.cos(d)*h),x=Math.round(Math.sin(d)*h),m=bs(n,r,g,x,c,5.2,o,{depth:6,rough:.35}),p=Math.round(Math.cos(d)*-1),S=Math.round(Math.sin(d)*-1),y=Math.max(...m.filter(([E,,C])=>Math.abs(E-g)<=1&&Math.abs(C-x)<=1).map(E=>E[1]));for(let E=-1;E<=1;E++)for(let C=-1;C<=1;C++){for(let I=y+1;I<y+5;I++)n.set(g+C,I,x+E,0,0,!0);n.set(g+C,y,x+E,o.top,ue,!0)}let v=[-Math.sin(d),Math.cos(d)],T=[[g+Math.round(v[0]*3),x+Math.round(v[1]*3)],[g-Math.round(v[0]*3),x-Math.round(v[1]*3)],[g-Math.round(Math.cos(d)*3),x-Math.round(Math.sin(d)*3)]];for(let[E,C]of T){let I=n.topY(E,C);I>0&&vc(n,l,E,n.get(E,I,C)>=40?I:I+1,C,"spawn")}Ss(n,i,m,o,.12,1,(E,C)=>(E-g)*Math.cos(d)+(C-x)*Math.sin(d)>1.5&&Math.hypot(E-g,C-x)>2.5&&(E-g)*Math.cos(d)+(C-x)*Math.sin(d)>2.4),a.push({x:g+.5,y:y+1,z:x+.5,yaw:Math.atan2(g,x),look:[p,S]})}let u=bs(n,r,0,0,c+2,10.5,o,{depth:13,rough:.5});Ss(n,i,u,o,.1,3);for(let f=-2;f<=2;f++)for(let d=-2;d<=2;d++)for(let g=c+1;g<=c+4;g++)n.set(d,g,f,0,0,!0);for(let f=-2;f<=2;f++)for(let d=-2;d<=2;d++)n.set(d,c+2,f,o.rock===9?9:4,ue,!0);for(let[f,d]of[[-2,-2],[2,-2],[-2,2],[2,2]])for(let g=c+3;g<=c+6;g++)n.set(f,g,d,o.rock===9?9:4,ue,!0);for(let f=-2;f<=2;f++)for(let d=-2;d<=2;d++)(Math.abs(d)===2||Math.abs(f)===2)&&n.set(d,c+7,f,t==="desert"?9:5,ue,!0);n.set(0,c+3,0,27,ue,!0);for(let[f,d]of[[0,-1],[0,1],[-1,0],[1,0]])vc(n,l,f,c+3,d,"mid");for(let f=0;f<e/2;f++){let d=(f+.5)/(e/2)*Math.PI*2+.2,g=Math.round(Math.cos(d)*20),x=Math.round(Math.sin(d)*20),m=bs(n,r,g,x,c+1,3.6,o,{depth:5,rough:.4});Ss(n,i,m,o,.15,0);let p=n.topY(g,x);vc(n,l,g,p+1,x,"satellite")}return{world:n,spawns:a,chests:l,theme:t,top:c,voidY:4,center:{x:0,y:c+3,z:0},radius:52}}function Ku(s,t="snow",e=4){let n=new gr(128,64,128),i=Mc(s),r=Ju(s),o=yc[t],a=30,l=38,c={world:n,theme:t,top:a,voidY:4,center:{x:0,y:a+2,z:0},radius:62,chests:[],spawns:[],teams:[],gens:[],npcs:[]},h=o.rock===9?9:o===yc.volcano?18:4;for(let f=0;f<e;f++){let d=f/e*Math.PI*2,g=Math.cos(d),x=Math.sin(d),m=Math.round(g*l),p=Math.round(x*l),S=bs(n,r,m,p,a,7.5,o,{depth:8,rough:.3,flat:!0});Ss(n,i,S.filter(([X,,V])=>Math.hypot(X-m,V-p)>5&&(X-m)*m+(V-p)*p>0),o,.08,1);let y=_e[f];for(let X=-2;X<=2;X++)for(let V=-2;V<=2;V++){n.set(m+V,a,p+X,y.wool,ue,!0);for(let Q=a+1;Q<a+5;Q++)n.set(m+V,Q,p+X,0,0,!0)}let v=Math.round(m+g*5),T=Math.round(p+x*5);for(let X=-1;X<=1;X++)for(let V=-1;V<=1;V++){n.set(v+V,a,T+X,13,ue,!0);for(let Q=a+1;Q<a+4;Q++)n.set(v+V,Q,T+X,0,0,!0)}n.set(v,a+1,T,13,ue,!0),n.set(v,a+2,T,45,ue,!0);let E=-Math.round(x*3),C=Math.round(g*3),I=m-E,M=p-C;n.set(I,a,M,24,ue,!0);let w=Math.round(m-E-g*2),P=Math.round(p-C-x*2);n.set(w,a,P,25,ue,!0),c.gens.push({x:I,y:a,z:M,item:170,every:1.25,cap:40,team:f},{x:w,y:a,z:P,item:171,every:5,cap:16,team:f});let k=m+E+.5,H=p+C+.5;c.npcs.push({npc:!0,kind:"shop",team:f,x:k,y:a+1,z:H,yaw:Math.atan2(-(m-k),-(p-H)),name:"Shop"});let W=Math.atan2(g,x);c.spawns.push({x:m+.5,y:a+1,z:p+.5,yaw:W,team:f}),c.teams.push({i:f,color:y,egg:{x:v,y:a+2,z:T},spawn:{x:m+.5,y:a+1,z:p+.5},center:{x:m,z:p}})}for(let f=0;f<e;f++){let d=(f+.5)/e*Math.PI*2,g=Math.round(Math.cos(d)*26),x=Math.round(Math.sin(d)*26),m=bs(n,r,g,x,a+1,4.2,o,{depth:5,rough:.35});Ss(n,i,m,o,.12,0);let p=n.topY(g,x);n.set(g,p,x,25,ue,!0),c.gens.push({x:g,y:p,z:x,item:171,every:7,cap:10})}let u=bs(n,r,0,0,a+2,7,o,{depth:10,rough:.4});Ss(n,i,u.filter(([f,,d])=>Math.hypot(f,d)>3),o,.1,2);for(let f=-2;f<=2;f++)for(let d=-2;d<=2;d++){n.set(d,a+2,f,h,ue,!0);for(let g=a+3;g<a+6;g++)n.set(d,g,f,0,0,!0)}for(let[f,d]of[[-1,0],[1,0]])n.set(f,a+2,d,26,ue,!0),c.gens.push({x:f,y:a+2,z:d,item:172,every:14,cap:6});return n.set(0,a+3,2,27,ue,!0),n.set(0,a+3,-2,27,ue,!0),c}function _r(s){return s.crouch?1.5:1.8}function qn(s){return s.crouch?1.28:1.62}function wc(s,t,e,n,i){return s.boxHits(t-.3,e,n-.3,t+.3,e+i,n+.3)}function z0(s,t,e,n){let i=Math.floor(e-.05);for(let r of[-.3+.02,.3-.02])for(let o of[-.3+.02,.3-.02])if(s.solidAt(Math.floor(t+r),i,Math.floor(n+o)))return!0;return!1}function Sc(s,t,e,n){if(!n)return!1;let i=_r(t),r=t.pos,o=Math.ceil(Math.abs(n)/.45),a=n/o;for(let l=0;l<o;l++){let c=e===0?r.x+a:r.x,h=e===1?r.y+a:r.y,u=e===2?r.z+a:r.z;if(!wc(s,c,h,u,i)){if(t.crouch&&t.onGround&&e!==1&&!z0(s,c,r.y,u))return!0;r.x=c,r.y=h,r.z=u;continue}return e===0?r.x=a>0?Math.floor(r.x+.3+a)-.3-1e-4:Math.floor(r.x-.3+a)+1+.3+1e-4:e===2?r.z=a>0?Math.floor(r.z+.3+a)-.3-1e-4:Math.floor(r.z-.3+a)+1+.3+1e-4:r.y=a>0?Math.floor(r.y+i+a)-i-1e-4:Math.floor(r.y+a)+1,wc(s,r.x,r.y,r.z,i)&&(e===0?r.x-=a:e===2?r.z-=a:r.y-=a),!0}return!1}function ju(s,t,e,n){let i=n.crouch?1.4:n.sprint?5.7:4.3,r=Math.hypot(n.mx,n.mz),o=r>0?n.mx/Math.max(1,r)*i:0,a=r>0?n.mz/Math.max(1,r)*i:0,l=t.onGround?40:10,c=Math.min(1,l*e);t.vel.x+=(o-t.vel.x)*c,t.vel.z+=(a-t.vel.z)*c,t.kb.x*=Math.pow(t.onGround?.02:.25,e),t.kb.z*=Math.pow(t.onGround?.02:.25,e),Math.abs(t.kb.x)<.05&&(t.kb.x=0),Math.abs(t.kb.z)<.05&&(t.kb.z=0);let h=t.crouch;t.crouch=!!n.crouch,h&&!t.crouch&&wc(s,t.pos.x,t.pos.y,t.pos.z,1.8)&&(t.crouch=!0),n.jump&&t.onGround&&!t.crouch&&(t.vel.y=8.6,t.onGround=!1,t.jumped=!0),t.vel.y=Math.max(-55,t.vel.y-30*e);let u=t.pos.y,f=Sc(s,t,0,(t.vel.x+t.kb.x)*e),d=Sc(s,t,2,(t.vel.z+t.kb.z)*e);f&&(t.vel.x=0,t.kb.x=0),d&&(t.vel.z=0,t.kb.z=0),t.blocked=f||d;let g=t.vel.y,x=Sc(s,t,1,g*e),m=t.onGround;x&&(t.vel.y=0),t.onGround=x&&g<=0;let p=0;return t.onGround?(m||(p=(t.airTop??t.pos.y)-t.pos.y),t.airTop=null):t.airTop=Math.max(t.airTop??u,t.pos.y),{landed:p}}function Qu(s,t,e,n,i){if(!s.inside(e,n,i))return!1;let r=s.get(e,n,i);if(r&&!(r>=40&&r<=43))return!1;for(let o of t){if(!o.alive)continue;let a=_r(o);if(e+1>o.pos.x-.3&&e<o.pos.x+.3&&i+1>o.pos.z-.3&&i<o.pos.z+.3&&n+1>o.pos.y&&n<o.pos.y+a)return!1}return!0}var H0=3.2,V0=4.8;function td(s,t,e,n,i,r,o,a){let l=0,c=1/0;for(let[h,u,f,d]of[[s.x,t.x,e,r],[s.y,t.y,n,o],[s.z,t.z,i,a]]){if(Math.abs(u)<1e-9){if(h<f||h>d)return-1;continue}let g=(f-h)/u,x=(d-h)/u;if(g>x&&([g,x]=[x,g]),l=Math.max(l,g),c=Math.min(c,x),l>c)return-1}return l}var La=class{constructor(t,e,n={}){this.map=t,this.world=t.world,this.mode=e,this.actors=[],this.drops=[],this.projectiles=[],this.events=[],this.time=0,this.state="countdown",this.countdown=n.countdown??5,this.seed=n.seed||1,this.rand=G0(this.seed),this.winner=null,this.over=!1,this.npcs=[],e.attach(this)}emit(t){this.events.push(t),this.events.length>400&&this.events.splice(0,100)}add(t){return this.actors.push(t),t.match=this,t}teamOf(t){return t.team}enemies(t,e){return t!==e&&(t.team<0||t.team!==e.team)}alive(){return this.actors.filter(t=>t.alive)}update(t){if(t=Math.min(t,.05),this.state==="countdown"){this.countdown-=t;for(let e of this.actors)this.stepPhysics(e,t,e.ctl?e.ctl(t,this):null,!0);this.countdown<=0&&(this.state="play",this.mode.start(),this.emit({t:"start"}));return}if(this.state==="over"){this.time+=t;for(let e of this.actors)e.alive&&this.stepPhysics(e,t,null,!0);return}this.time+=t;for(let e of this.actors){if(!e.alive){e.respawnT>0&&(e.respawnT-=t,e.respawnT<=0&&this.mode.respawn(e));continue}let n=e.ctl?e.ctl(t,this):null;this.tickActor(e,t,n)}this.updateDrops(t),this.updateProjectiles(t),this.mode.update(t)}stepPhysics(t,e,n,i){if(!t.alive)return;let r=n||{};r.yaw!=null&&(t.yaw=r.yaw),r.pitch!=null&&(t.pitch=Math.max(-1.55,Math.min(1.55,r.pitch)));let o=ju(this.world,t,e,i?{mx:0,mz:0}:r);return t.moveAmt=Math.hypot(t.vel.x,t.vel.z),t.walkPhase+=t.moveAmt*e*2.2,o}tickActor(t,e,n){let i=n||{};i.sel!=null&&i.sel>=0&&i.sel<9&&i.sel!==t.sel&&(t.sel=i.sel,t.mine=null,t.eatT=0),t.sprint=!!i.sprint&&!i.crouch;let r=this.stepPhysics(t,e,i,!1);if(t.hurtT=Math.max(0,t.hurtT-e),t.attackCd=Math.max(0,t.attackCd-e),t.swingT=Math.max(0,t.swingT-e),t.spawnProtect=Math.max(0,t.spawnProtect-e),r&&r.landed>3.5&&this.damage(t,Math.floor(r.landed-3),this.recentAttacker(t,5),"fall"),!t.alive)return;if(t.pos.y<this.map.voidY){this.kill(t,this.recentAttacker(t,10),"void");return}t.hp<t.maxHp&&this.time-t.lastHurt>5&&(t.regenT+=e,t.regenT>2.5&&(t.regenT=0,t.hp=Math.min(t.maxHp,t.hp+1)));let o=t.held();i.attack?this.attackOrMine(t,e,i.attackPressed):t.mine=null,o&&o.kind==="food"&&i.useHeld&&t.hp<t.maxHp?(t.eatT+=e,t.eatT>.9&&(t.eatT=0,t.hp=Math.min(t.maxHp,t.hp+o.heal),o.id===130&&(t.absorb=4),t.inv.useSlot(t.sel),this.emit({t:"eat",a:t}))):t.eatT=0,i.use&&this.use(t,i)}recentAttacker(t,e){return t.lastAttacker&&this.time-t.lastAttackT<e?t.lastAttacker:null}lookHit(t,e=V0){let n=t.eye(qn(t)),i=t.look();return this.world.raycast(n.x,n.y,n.z,i.x,i.y,i.z,e,r=>r!==0&&(Zt[r].solid||Zt[r].cross))}lookActor(t,e=H0){let n=t.eye(qn(t)),i=t.look(),r=null,o=e;for(let a of this.actors){if(a===t||!a.alive)continue;let l=_r(a),c=td(n,i,a.pos.x-.3-.1,a.pos.y-.1,a.pos.z-.3-.1,a.pos.x+.3+.1,a.pos.y+l+.1,a.pos.z+.3+.1);c>=0&&c<o&&(o=c,r=a)}for(let a of this.npcs){let l=td(n,i,a.x-.4,a.y,a.z-.4,a.x+.4,a.y+1.9,a.z+.4);l>=0&&l<o&&(o=l,r=a)}if(r){let a=this.lookHit(t,o);if(a&&a.t<o)return null}return r?{target:r,t:o}:null}attackOrMine(t,e,n){let i=this.lookActor(t);if(i&&!i.target.npc){t.mine=null,t.attackCd<=0&&(n||t.bot||t.autoSwing)&&this.melee(t,i.target);return}n&&(t.swingT=.25,this.emit({t:"swing",a:t}));let r=this.lookHit(t);if(!r||!ce(r.id)&&!Zt[r.id].cross){t.mine=null;return}if(!this.mode.canBreak(t,r.x,r.y,r.z,r.id)){t.mine=null;return}(!t.mine||t.mine.x!==r.x||t.mine.y!==r.y||t.mine.z!==r.z)&&(t.mine={x:r.x,y:r.y,z:r.z,p:0,need:this.breakTime(t,r.id),snd:0}),t.mine.p+=e,t.mine.snd+=e,t.swingT=.25,t.mine.snd>.24&&(t.mine.snd=0,this.emit({t:"dig",a:t,id:r.id,x:r.x,y:r.y,z:r.z})),t.mine.p>=t.mine.need&&this.breakBlock(t,r.x,r.y,r.z)}breakTime(t,e){let n=Zt[e];if(n.hardness<=0)return .05;let i=t.held(),r=1;i&&(i.kind==="pick"&&n.tool==="pick"||i.kind==="axe"&&n.tool==="axe"||i.kind==="shears"&&(n.tool==="shears"||e===7)?r=i.speed:i.kind==="sword"&&e===7&&(r=1.5)),n.tool==="shovel"&&(r=Math.max(r,1.6));let o=n.tool==="pick"&&(!i||i.kind!=="pick")?n.hardness*2.2:n.hardness*1.1;return Math.max(.05,o/r)}breakBlock(t,e,n,i){let r=this.world.get(e,n,i);if(!r)return;this.world.set(e,n,i,0),t.mine=null,t.broken++,this.emit({t:"break",a:t,id:r,x:e,y:n,z:i}),this.mode.onBreak(t,e,n,i,r);let o=this.mode.dropFor(r);if(o){let a=t.inv.add(o,1);a&&this.spawnDrop(o,a,e+.5,n+.5,i+.5)}for(let a=n+1;a<n+3;a++){let l=this.world.get(e,a,i);if(l&&Zt[l].cross)this.world.set(e,a,i,0);else break}}melee(t,e){if(t.attackCd=t.bot?.42:.3,t.swingT=.25,this.emit({t:"swing",a:t}),!this.enemies(t,e)||e.spawnProtect>0)return;let n=t.held(),i=n&&n.damage?n.damage:1,r=!t.onGround&&t.vel.y<-.5;if(r&&(i*=1.5),this.damage(e,i,t,"melee",r)){let a=Math.hypot(e.pos.x-t.pos.x,e.pos.z-t.pos.z)||1,l=(t.sprint?7.2:5.2)*(e.crouch?.6:1);e.kb.x=(e.pos.x-t.pos.x)/a*l,e.kb.z=(e.pos.z-t.pos.z)/a*l,e.onGround&&(e.vel.y=5.2,e.onGround=!1),t.sprint&&(t.sprint=!1)}}damage(t,e,n,i,r=!1){if(!t.alive||t.spawnProtect>0||i==="melee"&&t.hurtT>0)return!1;let o=e*(1-Math.min(.8,t.inv.armorPoints()*.04));if(t.absorb>0&&i!=="border"){let a=Math.min(t.absorb,o);t.absorb-=a,o-=a}return t.hp-=o,t.hurtT=.45,t.lastHurt=this.time,t.regenT=0,t.eatT=0,n&&n!==t&&(t.lastAttacker=n,t.lastAttackT=this.time),this.emit({t:"hurt",a:t,by:n,cause:i,crit:r,dmg:o}),t.hp<=0&&this.kill(t,n&&n!==t?n:this.recentAttacker(t,10),i),!0}kill(t,e,n){if(t.alive){if(t.alive=!1,t.hp=0,t.deaths++,t.mine=null,e&&e!==t&&e.kills++,this.emit({t:"kill",a:t,by:e,cause:n}),n!=="void"&&this.mode.dropsOnDeath)for(let i of t.inv.all())this.spawnDrop(i.id,i.count,t.pos.x,t.pos.y+.8,t.pos.z,!0);this.mode.onDeath(t,e,n)}}use(t,e){let n=t.held(),i=this.lookActor(t,4);if(i&&i.target.npc){this.emit({t:"npc",a:t,npc:i.target});return}let r=this.lookHit(t);if(r&&r.id===17){let o=this.chestAt(r.x,r.y,r.z);if(o){this.emit({t:"chest",a:t,chest:o});return}}if(n&&n.kind==="block"&&r){let o=r.x+r.nx,a=r.y+r.ny,l=r.z+r.nz;if(Zt[r.id].cross){this.place(t,r.x,r.y,r.z,n.block);return}this.place(t,o,a,l,n.block);return}n&&(n.kind==="throw"||n.kind==="warp")&&this.throwItem(t,n.id)}place(t,e,n,i,r){if(n>=this.world.sy-1||n<1||!this.mode.canPlace(t,e,n,i)||!Qu(this.world,this.actors.filter(a=>a.alive),e,n,i))return!1;let o=t.inv.slots[t.sel];return!o||o.id!==r?!1:(this.world.set(e,n,i,r,xr),t.inv.useSlot(t.sel),t.placed++,t.swingT=.2,this.emit({t:"place",a:t,id:r,x:e,y:n,z:i}),!0)}throwItem(t,e){if(t.attackCd>0)return;t.attackCd=.3,t.swingT=.25;let n=t.eye(qn(t)),i=t.look();this.projectiles.push({id:e,owner:t,x:n.x+i.x*.5,y:n.y+i.y*.5,z:n.z+i.z*.5,vx:i.x*22,vy:i.y*22+2,vz:i.z*22,age:0}),t.inv.useSlot(t.sel),this.emit({t:"throw",a:t,id:e})}updateProjectiles(t){for(let e=this.projectiles.length-1;e>=0;e--){let n=this.projectiles[e];n.age+=t,n.vy-=18*t;let i=n.x+n.vx*t,r=n.y+n.vy*t,o=n.z+n.vz*t,a=null;for(let c of this.actors)if(!(!c.alive||c===n.owner&&n.age<.3)&&Math.abs(c.pos.x-i)<.45&&Math.abs(c.pos.z-o)<.45&&r>c.pos.y&&r<c.pos.y+_r(c)){a=c;break}let l=ce(this.world.get(i,r,o));if(a||l||n.age>6||r<this.map.voidY-10){if(n.id===131&&a&&this.enemies(n.owner,a)){let c=Math.hypot(n.vx,n.vz)||1;a.kb.x=n.vx/c*4.5,a.kb.z=n.vz/c*4.5,a.onGround&&(a.vel.y=3.5,a.onGround=!1),this.damage(a,.5,n.owner,"snowball")}if(n.id===132&&n.owner.alive&&(l||a)&&r>this.map.voidY){let c=n.owner,h=n.x,u=n.y,f=n.z;if(l){u=Math.floor(r)+1;for(let d=0;d<3&&this.world.boxHits(h-.3,u,f-.3,h+.3,u+1.8,f+.3);d++)u++}c.pos.x=h,c.pos.y=u,c.pos.z=f,c.vel.x=c.vel.y=c.vel.z=0,c.kb.x=c.kb.z=0,this.damage(c,2,null,"warp"),this.emit({t:"warp",a:c})}this.emit({t:"impact",id:n.id,x:n.x,y:n.y,z:n.z}),this.projectiles.splice(e,1);continue}n.x=i,n.y=r,n.z=o}}spawnDrop(t,e,n,i,r,o=!1){this.drops.length>160&&this.drops.shift();let a=this.rand()*Math.PI*2,l=o?1.6+this.rand()*1.4:0;this.drops.push({id:t,count:e,x:n,y:i,z:r,vx:Math.cos(a)*l,vy:o?4:0,vz:Math.sin(a)*l,age:0,key:Math.random()})}updateDrops(t){for(let e=this.drops.length-1;e>=0;e--){let n=this.drops[e];n.age+=t,n.vy-=20*t;let i=n.y+n.vy*t;ce(this.world.get(n.x,i-.15,n.z))?(n.y=Math.floor(i-.15)+1.15,n.vy=0,n.vx*=.5,n.vz*=.5):n.y=i;let r=n.x+n.vx*t,o=n.z+n.vz*t;if(ce(this.world.get(r,n.y,n.z))?n.vx=0:n.x=r,ce(this.world.get(n.x,n.y,o))?n.vz=0:n.z=o,n.vx*=Math.pow(.3,t),n.vz*=Math.pow(.3,t),n.y<this.map.voidY-8||n.age>240){this.drops.splice(e,1);continue}if(!(n.age<.4))for(let a of this.actors){if(!a.alive)continue;let l=a.pos.x-n.x,c=a.pos.y+.6-n.y,h=a.pos.z-n.z;if(l*l+c*c+h*h<2){let u=a.inv.add(n.id,n.count);if(u<n.count&&this.emit({t:"pickup",a,id:n.id,n:n.count-u}),u)n.count=u;else{this.drops.splice(e,1);break}}}}}chestAt(t,e,n){return this.map.chests.find(i=>i.x===t&&i.y===e&&i.z===n)}takeFromChest(t,e,n){let i=e.items[n];if(!i)return!1;let r=t.inv.add(i.id,i.count);return r===i.count&&te[i.id].kind!=="armor"?!1:(r?i.count=r:e.items.splice(n,1),this.emit({t:"pickup",a:t,id:i.id,n:i.count-r}),!0)}takeAll(t,e){let n=!1;for(let i=e.items.length-1;i>=0;i--)n=this.takeFromChest(t,e,i)||n;return e.looted=!0,n}finish(t){this.over||(this.over=!0,this.state="over",this.winner=t,this.emit({t:"over",winner:t}))}};function G0(s){return()=>{s|=0,s=s+1831565813|0;let t=Math.imul(s^s>>>15,1|s);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}var Da=(s,t)=>t[Math.floor(s()*t.length)],$n=(s,t,e)=>t+Math.floor(s()*(e-t+1));function ws(s,t){return Ms(Da(s,t),Math.floor(s()*4))}function W0(s,t,e=!1){let n=[],i=(r,o=1)=>n.push({id:r,count:o});t==="spawn"?(i(Da(s,[5,5,4,3]),$n(s,14,24)),(e||s()<.45)&&i(s()<.6?101:100),(e||s()<.55)&&i(ws(s,[0,0,1])),s()<.45&&i(ws(s,[0,1,1,2])),s()<.4&&i(131,$n(s,4,8)),s()<.35&&i(133,$n(s,1,3)),s()<.25&&i(111),s()<.12&&i(130),s()<.12&&i(102)):t==="satellite"?(i(Da(s,[5,4,3]),$n(s,12,20)),i(ws(s,[1,2,2])),s()<.5&&i(ws(s,[2,2,3])),s()<.45&&i(102),s()<.5&&i(130),s()<.3&&i(132),s()<.4&&i(131,$n(s,6,12))):(i(Da(s,[5,4,3]),$n(s,20,32)),i(ws(s,[2,3,3])),s()<.65&&i(ws(s,[2,3])),s()<.55&&i(s()<.5?103:102),s()<.75&&i(130,$n(s,1,2)),s()<.5&&i(132,$n(s,1,2)),s()<.35&&i(112),s()<.4&&i(131,$n(s,8,16)));for(let r=n.length-1;r>0;r--){let o=Math.floor(s()*(r+1));[n[r],n[o]]=[n[o],n[r]]}return n}var Ua=class{constructor(){this.id="sky",this.dropsOnDeath=!0,this.refillAt=180,this.borderAt=300,this.borderDur=90,this.refilled=!1,this.cages=[],this.ranks=[]}attach(t){this.m=t,this.radius=t.map.radius,this.border=this.radius,this.fillChests(!1)}fillChests(t){let e=this.m.rand,n=new Set;for(let i of this.m.map.chests){let r=`${Math.round(i.x/12)},${Math.round(i.z/12)}`,o=!n.has(r);n.add(r);let a=W0(e,i.tier,o&&i.tier==="spawn"&&!t);i.items=t?[...i.items,...a].slice(0,12):a,i.looted=!1}}setup(t){let e=this.m.map.spawns;t.forEach((n,i)=>{let r=e[i%e.length];n.pos.x=r.x,n.pos.y=r.y,n.pos.z=r.z,n.yaw=r.yaw,n.pitch=-.15,n.spawn=r,n.home=r,this.cage(Math.floor(r.x),Math.floor(r.y),Math.floor(r.z),!0)})}cage(t,e,n,i){let r=this.m.world;for(let o=e;o<=e+2;o++)for(let[a,l]of[[1,0],[-1,0],[0,1],[0,-1]])(i?!r.get(t+a,o,n+l):r.get(t+a,o,n+l)===12)&&r.set(t+a,o,n+l,i?12:0,2);(i?!r.get(t,e+2,n):r.get(t,e+2,n)===12)&&r.set(t,e+2,n,i?12:0,2),i&&this.cages.push([t,e,n])}start(){for(let[t,e,n]of this.cages)this.cage(t,e,n,!1);this.cages=[];for(let t of this.m.actors)t.spawnProtect=3}update(t){let e=this.m;if(!this.refilled&&e.time>=this.refillAt&&(this.refilled=!0,this.fillChests(!0),e.emit({t:"refill"})),e.time>=this.borderAt){let i=Math.min(1,(e.time-this.borderAt)/this.borderDur);if(this.border=this.radius+(6-this.radius)*i,this.borderWarned||(this.borderWarned=!0,e.emit({t:"border"})),this.borderTick=(this.borderTick||0)+t,this.borderTick>1){this.borderTick=0;for(let r of e.actors)r.alive&&Math.hypot(r.pos.x,r.pos.z)>this.border&&e.damage(r,1.5,e.recentAttacker(r,10),"border")}}e.time>=this.borderAt+this.borderDur-20&&(this.rising||(this.rising=!0,this.voidBase=e.map.voidY,e.emit({t:"voidrise"})),e.map.voidY=Math.min(e.map.top+6,e.map.voidY+t*.3));let n=e.actors.filter(i=>i.alive);n.length<=1&&!e.over&&(n[0]&&(n[0].rank=1),e.finish(n[0]||null))}canBreak(t,e,n,i,r){return!Zt[r].unbreakable&&r!==17&&Math.hypot(e,i)<this.radius+6}canPlace(t,e,n,i){return Math.hypot(e+.5,i+.5)<this.radius+4&&n>2}dropFor(t){return t===1?2:t===7||t>=40&&t<=43||t===12||t===11?0:t===10?10:t}onBreak(){}onDeath(t){t.eliminated=!0,t.rank=this.m.actors.filter(e=>e.alive).length+1}respawn(){}info(){let t=this.m;return{rising:!!this.rising,alive:t.actors.filter(e=>e.alive).length,total:t.actors.length,refillIn:this.refilled?0:Math.max(0,this.refillAt-t.time),borderIn:Math.max(0,this.borderAt-t.time),border:this.border}}};var Mn=(s,t,e,n)=>ce(s.get(t,e-1,n))&&!ce(s.get(t,e,n))&&!ce(s.get(t,e+1,n))&&s.get(t,e-1,n)!==45;function hi(s,t,e,n,i=6){for(let r=e;r>e-i;r--)if(Mn(s,t,r,n))return r;return null}var Ec=class{constructor(){this.a=[]}push(t){let e=this.a;e.push(t);let n=e.length-1;for(;n>0;){let i=n-1>>1;if(e[i].f<=e[n].f)break;[e[i],e[n]]=[e[n],e[i]],n=i}}pop(){let t=this.a,e=t[0],n=t.pop();if(t.length){t[0]=n;let i=0;for(;;){let r=i*2+1,o=r+1,a=i;if(r<t.length&&t[r].f<t[a].f&&(a=r),o<t.length&&t[o].f<t[a].f&&(a=o),a===i)break;[t[a],t[i]]=[t[i],t[a]],i=a}}return e}get size(){return this.a.length}},X0=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];function Tc(s,t,e,n,i,r,o,a={}){let l=a.limit||2400,c=a.near??0,h=(y,v,T)=>`${y},${v},${T}`,u=(y,v,T)=>Math.hypot(y-i,T-o)+Math.abs(v-r)*.6,f=new Ec,d=new Map,g={x:t,y:e,z:n,g:0,f:u(t,e,n),p:null};f.push(g),d.set(h(t,e,n),0);let x=g,m=0;for(;f.size&&m++<l;){let y=f.pop();if(Math.abs(y.x-i)<=c&&Math.abs(y.z-o)<=c&&Math.abs(y.y-r)<=Math.max(1,c)){x=y;break}u(y.x,y.y,y.z)<u(x.x,x.y,x.z)&&(x=y);for(let[v,T]of X0){let E=y.x+v,C=y.z+T;if(v&&T&&!(Mn(s,y.x+v,y.y,y.z)&&Mn(s,y.x,y.y,y.z+T)))continue;let I=null,M=v&&T?1.414:1;if(Mn(s,E,y.y,C))I=y.y;else if(!v||!T){if(Mn(s,E,y.y+1,C)&&!ce(s.get(y.x,y.y+2,y.z)))I=y.y+1,M+=.8;else if(!ce(s.get(E,y.y,C))&&!ce(s.get(E,y.y+1,C))){for(let k=1;k<=3;k++)if(Mn(s,E,y.y-k,C)){I=y.y-k,M+=k*.3;break}}}if(I==null)continue;let w=h(E,I,C),P=y.g+M;d.has(w)&&d.get(w)<=P||(d.set(w,P),f.push({x:E,y:I,z:C,g:P,f:P+u(E,I,C),p:y}))}}let p=Math.abs(x.x-i)<=Math.max(c,0)&&Math.abs(x.z-o)<=Math.max(c,0)&&Math.abs(x.y-r)<=Math.max(1,c),S=[];for(let y=x;y;y=y.p)S.push({x:y.x,y:y.y,z:y.z});return S.reverse(),{path:S,reached:p,end:x}}function ed(s,t,e,n){let i=[],r=s,o=t,a=Math.abs(e-s)||1,l=Math.abs(n-t)||1;for(;i.length<200&&(r!==e||o!==n);){let c=Math.abs(e-r)/a,h=Math.abs(n-o)/l;r!==e&&(c>=h||o===n)?r+=Math.sign(e-r):o+=Math.sign(n-o),i.push([r,o])}return i}var Na=[{id:"wool",cat:"blocks",give:[["wool",16]],cost:[170,4]},{id:"planks",cat:"blocks",give:[[5,16]],cost:[170,10]},{id:"stone",cat:"blocks",give:[[3,12]],cost:[171,3]},{id:"obsidian",cat:"blocks",give:[[13,2]],cost:[172,2]},{id:"stone_sword",cat:"combat",give:[[101,1]],cost:[170,12]},{id:"iron_sword",cat:"combat",give:[[102,1]],cost:[171,6]},{id:"diamond_sword",cat:"combat",give:[[103,1]],cost:[172,4]},{id:"chain_set",cat:"armor",give:[0,1,2,3].map(s=>[Ms(1,s),1]),cost:[170,28]},{id:"iron_set",cat:"armor",give:[0,1,2,3].map(s=>[Ms(2,s),1]),cost:[171,14]},{id:"diamond_set",cat:"armor",give:[0,1,2,3].map(s=>[Ms(3,s),1]),cost:[172,8]},{id:"stone_pick",cat:"tools",give:[[111,1]],cost:[170,10]},{id:"iron_pick",cat:"tools",give:[[112,1]],cost:[171,4]},{id:"shears",cat:"tools",give:[[180,1]],cost:[170,16]},{id:"gapple",cat:"utility",give:[[130,1]],cost:[171,3]},{id:"snowball",cat:"utility",give:[[131,4]],cost:[170,6]},{id:"orb",cat:"utility",give:[[132,1]],cost:[172,3]}],Fa=class{constructor(){this.id="egg",this.dropsOnDeath=!1,this.suddenAt=360,this.timeLimit=540}attach(t){this.m=t,this.radius=t.map.radius,this.border=this.radius,this.teams=t.map.teams.map(e=>({...e,eggAlive:!0,out:!1}));for(let e of t.map.gens)e.t=Math.random()*e.every;t.npcs=t.map.npcs}setup(t){t.forEach(e=>{this.respawnAt(e),e.home=this.teams[e.team].spawn})}teamWool(t){return _e[t.team].wool}kit(t){t.inv.clear(),t.inv.add(100,1),t.inv.add(110,1),t.sel=0}respawnAt(t){let e=this.teams[t.team],n=e.spawn;t.reset(),t.alive=!0,t.pos.x=n.x+(Math.random()-.5)*1.5,t.pos.y=n.y,t.pos.z=n.z+(Math.random()-.5)*1.5,t.yaw=Math.atan2(n.x,n.z),t.pitch=-.1,t.spawnProtect=3,this.kit(t)}start(){this.m.emit({t:"eggstart"})}update(t){let e=this.m;for(let i of e.map.gens){if(i.t+=t,i.t<i.every)continue;i.t=0;let r=0;for(let o of e.drops)o.id===i.item&&Math.abs(o.x-i.x-.5)<1.5&&Math.abs(o.z-i.z-.5)<1.5&&(r+=o.count);r<i.cap&&e.spawnDrop(i.item,1,i.x+.5,i.y+1.3,i.z+.5)}if(!this.sudden&&e.time>=this.suddenAt){this.sudden=!0;for(let i of this.teams)i.eggAlive&&this.breakEgg(i,null);e.emit({t:"sudden"})}for(let i of this.teams){if(i.out)continue;let r=e.actors.filter(o=>o.team===i.i);if(!i.eggAlive&&r.every(o=>!o.alive)){i.out=!0,e.emit({t:"teamout",team:i.i});for(let o of r)o.rank=this.teams.filter(a=>!a.out).length+1}}let n=this.teams.filter(i=>!i.out);if(n.length<=1&&!e.over){for(let i of e.actors)n[0]&&i.team===n[0].i&&(i.rank=1);e.finish(n[0]?n[0].i:null)}if(e.time>=this.timeLimit&&!e.over){let i=o=>e.actors.filter(a=>a.team===o.i&&a.alive).length*100+e.actors.filter(a=>a.team===o.i).reduce((a,l)=>a+l.kills,0),r=n.sort((o,a)=>i(a)-i(o))[0];e.finish(r?r.i:null)}}breakEgg(t,e){t.eggAlive&&(t.eggAlive=!1,this.m.world.get(t.egg.x,t.egg.y,t.egg.z)===45&&this.m.world.set(t.egg.x,t.egg.y,t.egg.z,0),this.m.emit({t:"egg",team:t.i,by:e}))}canBreak(t,e,n,i,r){if(r===45){let o=this.teams.find(a=>a.egg.x===e&&a.egg.y===n&&a.egg.z===i);return!!o&&o.i!==t.team&&o.eggAlive}return this.m.world.flag(e,n,i)===xr}canPlace(t,e,n,i){if(Math.hypot(e,i)>this.radius)return!1;for(let r of this.teams)if(Math.abs(e-r.egg.x)<=0&&Math.abs(i-r.egg.z)<=0&&n>=r.egg.y&&n<=r.egg.y)return!1;for(let r of this.m.map.gens)if(e===r.x&&i===r.z&&n===r.y+1)return!1;return n>2}dropFor(t){return t===45?0:t}onBreak(t,e,n,i,r){if(r===45){let o=this.teams.find(a=>a.egg.x===e&&a.egg.y===n&&a.egg.z===i);o&&this.breakEgg(o,t)}}onDeath(t,e,n){let i=this.m;if(n!=="void")for(let o of t.inv.all())te[o.id].kind==="currency"&&i.spawnDrop(o.id,o.count,t.pos.x,t.pos.y+.8,t.pos.z,!0);if(e&&e.alive)for(let o of t.inv.all())te[o.id].kind==="currency"&&n==="void"&&e.inv.add(o.id,o.count);this.teams[t.team].eggAlive?(t.respawnT=5,i.emit({t:"respawning",a:t})):t.eliminated=!0}respawn(t){this.teams[t.team].eggAlive&&(this.respawnAt(t),this.m.emit({t:"respawn",a:t}))}canBuy(t,e){return t.inv.count(e.cost[0])>=e.cost[1]}buy(t,e){let n=Na.find(i=>i.id===e);if(!n||!this.canBuy(t,n))return!1;t.inv.take(n.cost[0],n.cost[1]);for(let[i,r]of n.give)t.inv.add(i==="wool"?this.teamWool(t):i,r);return this.m.emit({t:"buy",a:t,id:e}),!0}nearShop(t){return this.m.npcs.find(e=>e.team===t.team&&Math.hypot(e.x-t.pos.x,e.z-t.pos.z)<3.6&&Math.abs(e.y-t.pos.y)<2)}info(){return{teams:this.teams.map(t=>({i:t.i,egg:t.eggAlive,out:t.out,alive:this.m.actors.filter(e=>e.team===t.i&&e.alive).length})),suddenIn:Math.max(0,this.suddenAt-this.m.time)}}botPlan(t,e){let n=t.a,i=this.m,r=t.ctlObj,o=this.teams[n.team];t.role||(t.role=i.actors.filter(p=>p.team===n.team).indexOf(n)===0&&Math.random()<.6?"defend":"rush");let a=this.nearShop(n);a&&this.botShop(t);let l=n.inv.count(170),c=n.inv.count(171),h=i.npcs.find(p=>p.team===n.team),u=Math.hypot(o.spawn.x-n.pos.x,o.spawn.z-n.pos.z)<11&&Math.abs(o.spawn.y-n.pos.y)<3,f=n.inv.blocks()>=16&&n.inv.slots.some(p=>p&&p.id>=101&&p.id<=103),d=Na.some(p=>this.wanted(n,p.id)&&this.canBuy(n,p));if(u&&d&&!a)return t.goTo(Math.floor(h.x),h.y,Math.floor(h.z),e,1,!1),r;if(u&&(!f||t.role==="defend"&&!this.botGeared(n))&&i.time<600){let p=i.map.gens.find(S=>S.team===n.team&&S.item===(l<16||c>=6?170:171));return p&&Math.hypot(p.x+.5-n.pos.x,p.z+.5-n.pos.z)>.6?(t.steerOrPath(p.x,p.y+1,p.z,e),r):(r.mx=r.mz=0,t.aimAt(o.center.x,n.pos.y+1,o.center.z,e*.3),r)}if(n.inv.blocks()<4&&!u&&t.giveUp(e))return r;if(t.role==="defend"&&o.eggAlive&&i.time<420){let p=o.egg;return t.dist({x:p.x,y:p.y,z:p.z})>4?t.goTo(p.x,p.y-1,p.z-1,e,2,!1):t.wander(e),r}let g=this.teams.filter(p=>p.i!==n.team&&!p.out);if(!g.length)return r;(!t.eggTarget||t.eggTarget.out||!t.eggTarget.eggAlive&&Math.random()<.01)&&(t.eggTarget=g.sort((p,S)=>S.eggAlive-p.eggAlive||Math.hypot(p.egg.x-n.pos.x,p.egg.z-n.pos.z)-Math.hypot(S.egg.x-n.pos.x,S.egg.z-n.pos.z))[0]);let x=t.eggTarget;if(x.eggAlive){let p=x.egg;if(Math.hypot(p.x+.5-n.pos.x,p.z+.5-n.pos.z)<2.6&&Math.abs(p.y-n.pos.y)<3){r.mx=r.mz=0,t.aimAt(p.x+.5,p.y+.5,p.z+.5,e)<.3&&(r.attack=!0,t.selectKind("pick")||t.selectKind("sword"));let T=this.coverOf(p);return T&&t.aimAt(T.x+.5,T.y+.5,T.z+.5,e)<.3&&(r.attack=!0),r}let y=hi(i.world,p.x+1,p.y,p.z,4)??p.y-1;return t.goTo(p.x+1,y,p.z,e,1),r}let m=i.actors.filter(p=>p.alive&&p.team===x.i).sort((p,S)=>t.dist(p.pos)-t.dist(S.pos))[0];if(m){let p={x:Math.floor(m.pos.x),y:Math.floor(m.pos.y),z:Math.floor(m.pos.z)};t.goTo(p.x,hi(i.world,p.x,p.y,p.z,6)??p.y,p.z,e,1)}return r}coverOf(t){let e=this.m.world;for(let[n,i,r]of[[0,1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]])if(e.flag(t.x+n,t.y+i,t.z+r)===xr)return{x:t.x+n,y:t.y+i,z:t.z+r};return null}wanted(t,e){return e==="wool"?t.inv.blocks()<24:e==="stone_sword"?!t.inv.slots.some(n=>n&&n.id>=101&&n.id<=103):e==="iron_sword"?!t.inv.slots.some(n=>n&&n.id>=102&&n.id<=103):e==="diamond_sword"?!t.inv.slots.some(n=>n&&n.id===103):e==="chain_set"?t.inv.armorPoints()<12:e==="iron_set"?t.inv.armorPoints()<15:e==="diamond_set"?t.inv.armorPoints()<20:e==="gapple"?t.inv.count(130)<1:!1}botGeared(t){return t.inv.armorPoints()>=12&&t.inv.best("sword")>=0&&t.inv.slots.some(e=>e&&e.id>=101&&e.id<=103)}botShop(t){let e=t.a;for(let n of["wool","stone_sword","iron_sword","diamond_sword","diamond_set","iron_set","chain_set","gapple"])this.wanted(e,n)&&this.buy(e,n);t.equip()}};var Ac=class{constructor(t=9){this.slots=Array.from({length:t},()=>null),this.armor=[0,0,0,0]}count(t){let e=0;for(let n of this.slots)n&&n.id===t&&(e+=n.count);return e}add(t,e=1){let n=te[t];if(!n)return e;if(n.kind==="armor"){if(!this.armor[n.slot]||te[this.armor[n.slot]].points<n.points)return this.armor[n.slot]=t,0;if(this.armor[n.slot]===t||te[this.armor[n.slot]].points>=n.points)return 0}for(let i of this.slots)if(i&&i.id===t&&i.count<n.stack){let r=Math.min(e,n.stack-i.count);if(i.count+=r,e-=r,!e)return 0}for(let i=0;i<this.slots.length&&e>0;i++)if(!this.slots[i]){let r=Math.min(e,n.stack);this.slots[i]={id:t,count:r},e-=r}return e}take(t,e=1){if(this.count(t)<e)return!1;for(let n=this.slots.length-1;n>=0&&e>0;n--){let i=this.slots[n];if(i&&i.id===t){let r=Math.min(e,i.count);i.count-=r,e-=r,i.count||(this.slots[n]=null)}}return!0}useSlot(t,e=1){let n=this.slots[t];n&&(n.count-=e,n.count<=0&&(this.slots[t]=null))}armorPoints(){let t=0;for(let e of this.armor)e&&(t+=te[e].points);return t}best(t){let e=-1,n=-1;return this.slots.forEach((i,r)=>{let o=i&&te[i.id];o&&o.kind===t&&(o.damage??o.tier??0)>e&&(e=o.damage??o.tier??0,n=r)}),n}blockSlot(){let t=-1,e=0;return this.slots.forEach((n,i)=>{n&&n.id<100&&te[n.id].kind==="block"&&n.count>e&&(e=n.count,t=i)}),t}blocks(){let t=0;for(let e of this.slots)e&&e.id<100&&(t+=e.count);return t}clear(){this.slots.fill(null),this.armor=[0,0,0,0]}all(){let t=[];for(let e of this.slots)e&&t.push({...e});for(let e of this.armor)e&&t.push({id:e,count:1});return t}},q0=1,ka=class{constructor({name:t,team:e=-1,bot:n=!1,skin:i=0,local:r=!1}){this.id=q0++,this.name=t,this.team=e,this.bot=n,this.local=r,this.skin=i,this.pos={x:0,y:0,z:0},this.vel={x:0,y:0,z:0},this.kb={x:0,z:0},this.yaw=0,this.pitch=0,this.onGround=!1,this.crouch=!1,this.sprint=!1,this.inv=new Ac(9),this.sel=0,this.hp=20,this.maxHp=20,this.alive=!0,this.eliminated=!1,this.hurtT=0,this.attackCd=0,this.swingT=0,this.lastAttacker=null,this.lastAttackT=-99,this.kills=0,this.deaths=0,this.placed=0,this.broken=0,this.mine=null,this.eatT=0,this.regenT=0,this.respawnT=0,this.spawnProtect=0,this.walkPhase=0,this.moveAmt=0,this.lastHurt=-99,this.absorb=0,this.rank=0}held(){let t=this.inv.slots[this.sel];return t?te[t.id]:null}eye(t){return{x:this.pos.x,y:this.pos.y+t,z:this.pos.z}}look(){let t=Math.cos(this.pitch);return{x:-Math.sin(this.yaw)*t,y:Math.sin(this.pitch),z:-Math.cos(this.yaw)*t}}reset(){this.vel.x=this.vel.y=this.vel.z=0,this.kb.x=this.kb.z=0,this.hp=this.maxHp,this.hurtT=0,this.mine=null,this.eatT=0,this.airTop=null,this.onGround=!1,this.crouch=!1}};var nd=Math.PI*2,id=s=>{for(;s>Math.PI;)s-=nd;for(;s<-Math.PI;)s+=nd;return s},ki=s=>({x:Math.floor(s.x),y:Math.floor(s.y+.01),z:Math.floor(s.z)}),Oa=class{constructor(t,e,n=.5){this.a=t,this.m=e,this.skill=n,this.turn=5+n*9,this.cps=3.2+n*5,this.react=.55-n*.35,this.aimErr=.16-n*.12,this.greed=Math.random(),this.brave=.35+Math.random()*.5,this.path=null,this.pi=0,this.repath=0,this.goal=null,this.goalT=0,this.bridge=null,this.clickT=0,this.strafe=Math.random()<.5?1:-1,this.strafeT=0,this.pause=0,this.stuckT=0,this.lastPos={...t.pos},this.noticeT=0,this.target=null,this.jumpT=0,this.throwT=2+Math.random()*3,this.mineT=0,this.wanderT=0,this.patience=50+Math.random()*70,this.ctlObj={mx:0,mz:0,yaw:t.yaw,pitch:t.pitch,jump:!1,crouch:!1,sprint:!1,attack:!1,attackPressed:!1,use:!1,useHeld:!1,sel:null},t.ctl=i=>this.tick(i)}enemies(){return this.m.actors.filter(t=>t.alive&&this.m.enemies(this.a,t))}nearestEnemy(t=999){let e=null,n=t;for(let i of this.enemies()){let r=this.dist(i.pos);r<n&&(n=r,e=i)}return e?{o:e,d:n}:null}dist(t){return Math.hypot(t.x-this.a.pos.x,t.z-this.a.pos.z)+Math.abs(t.y-this.a.pos.y)*.5}visible(t){let e=this.a,n=e.eye(qn(e)),i={x:t.pos.x,y:t.pos.y+1.4,z:t.pos.z},r=i.x-n.x,o=i.y-n.y,a=i.z-n.z,l=Math.hypot(r,o,a)||1;return!this.m.world.raycast(n.x,n.y,n.z,r/l,o/l,a/l,l,h=>ce(h)&&h!==7&&h!==12)}aimAt(t,e,n,i,r=0){let o=this.a,a=o.eye(qn(o)),l=t-a.x,c=e-a.y,h=n-a.z,u=Math.atan2(-l,-h)+r*Math.sin(this.m.time*3.1+o.id),f=Math.atan2(c,Math.hypot(l,h))+r*.5*Math.cos(this.m.time*2.3+o.id),d=this.ctlObj,g=this.turn*i,x=id(u-d.yaw);return d.yaw=id(d.yaw+Math.max(-g,Math.min(g,x))),d.pitch+=Math.max(-g,Math.min(g,f-d.pitch)),Math.abs(x)+Math.abs(f-d.pitch)*.5}selectKind(t){let e=this.a.inv.best(t);return e>=0&&(this.ctlObj.sel=e),e>=0}selectBlocks(){let t=this.a.inv.blockSlot();return t>=0&&(this.ctlObj.sel=t),t>=0}steer(t,e,n,i=!0,r=!1){let o=this.a,a=this.ctlObj,l=t-o.pos.x,c=e-o.pos.z,h=Math.hypot(l,c);return h<.05?(a.mx=0,a.mz=0,h):(a.mx=l/h,a.mz=c/h,a.sprint=i&&h>2,!r&&this.unsafeAhead(a.mx,a.mz)&&(a.mx=0,a.mz=0,a.sprint=!1),h)}unsafeAhead(t,e){let n=this.a,i=this.m.world;if(!n.onGround)return!1;let r=Math.floor(n.pos.x+t*.55),o=Math.floor(n.pos.z+e*.55),a=Math.floor(n.pos.y+.01);if(r===Math.floor(n.pos.x)&&o===Math.floor(n.pos.z))return!1;for(let l=a-1;l>=a-4;l--)if(ce(i.get(r,l,o)))return!1;return!ce(i.get(r,a,o))}goTo(t,e,n,i,r=0,o=!0){let a=this.a,l=ki(a.pos);this.repath-=i;let c=`${t},${e},${n}`;if(this.bridge)return this.doBridge(i);if(!this.path||this.pathKey!==c||this.repath<=0||this.pi>=this.path.length){let f=Tc(this.m.world,l.x,l.y,l.z,t,e,n,{near:r,limit:2200});if(this.path=f.path,this.pi=1,this.pathKey=c,this.repath=1.2+Math.random()*.6,this.pathReached=f.reached,!f.reached&&o){let d=f.end;if(Math.hypot(d.x-t,d.z-n)>2&&this.a.inv.blocks()>0&&!(this.noBridge>0)&&Math.hypot(d.x-l.x,d.z-l.z)<1.5)return this.startBridge(t,e,n),this.doBridge(i)}}let h=this.path[this.pi];if(!h)return this.ctlObj.mx=this.ctlObj.mz=0,this.pathReached;let u=this.steer(h.x+.5,h.z+.5,i,!0,!0);return h.y>a.pos.y+.4&&a.onGround&&u<1.4&&(this.ctlObj.jump=!0),u<.32&&Math.abs(h.y-a.pos.y)<1.2&&this.pi++,this.pi>=this.path.length&&!this.pathReached&&o&&this.a.inv.blocks()>0&&!(this.noBridge>0)?(this.startBridge(t,e,n),!1):this.pi>=this.path.length&&this.pathReached}startBridge(t,e,n){let i=ki(this.a.pos);this.bridge={gx:t,gy:e,gz:n,y:i.y,cells:ed(i.x,i.z,t,n),i:0,t:0,placeT:0},this.path=null}doBridge(t){let e=this.a,n=this.m.world,i=this.bridge,r=this.ctlObj;if(i.t+=t,i.i!==i.lastI&&(i.lastI=i.i,i.prog=i.t),i.t-(i.prog||0)>6||e.pos.y<i.y-3)return this.bridge=null,this.goal=null,this.noBridge=5,!1;let o=ki(e.pos);e.onGround&&o.y!==i.y&&Math.abs(o.y-i.y)<=2&&(i.y=o.y);let a=i.cells[i.i];if(!a)return this.bridge=null,!0;let[l,c]=a,u=i.gy-i.y>=2&&i.i%2===1;if(!Mn(n,l,i.y,c)&&Mn(n,l,i.y+1,c))return this.steer(l+.5,c+.5,t,!1,!0),e.onGround&&(r.jump=!0),Math.abs(e.pos.x-(l+.5))<.35&&Math.abs(e.pos.z-(c+.5))<.35&&e.pos.y>i.y+.9&&(i.y+=1,i.i++),!1;if(ce(n.get(l,i.y,c))||ce(n.get(l,i.y+1,c))){let S=ce(n.get(l,i.y+1,c))?i.y+1:i.y;return r.mx=0,r.mz=0,this.m.mode.canBreak(e,l,S,c,n.get(l,S,c))?(this.selectKind("pick")||this.selectKind("axe"),this.aimAt(l+.5,S+.5,c+.5,t)<.3&&(r.attack=!0),!1):(this.bridge=null,this.goal=null,this.noBridge=5,!1)}if(Mn(n,l,i.y,c))return r.crouch=!0,this.steer(l+.5,c+.5,t,!1),r.mx*=.8,r.mz*=.8,Math.abs(e.pos.x-(l+.5))<.3&&Math.abs(e.pos.z-(c+.5))<.3&&(i.i++,(Math.hypot(l-i.gx,c-i.gz)<2.5||hi(n,i.cells[i.i]?.[0]??l,i.y,i.cells[i.i]?.[1]??c,1)!=null&&i.i>3)&&Tc(n,l,i.y,c,i.gx,i.gy,i.gz,{near:1,limit:600}).reached&&(this.bridge=null,this.path=null)),this.aimAt(l+.5,i.y-.5,c+.5,t),!1;if(u&&Mn(n,l,i.y+1,c))return r.jump=e.onGround,this.steer(l+.5,c+.5,t,!1),e.pos.y>i.y+.9&&(i.y+=1),!1;if(r.mx=0,r.mz=0,r.crouch=!0,r.sprint=!1,!this.selectBlocks())return this.bridge=null,!1;let f=l+.5-e.pos.x,d=c+.5-e.pos.z,g=Math.hypot(f,d)||1;(Math.abs(f)>Math.abs(d)?Math.abs(e.pos.x-(o.x+.5+Math.sign(f)*.28)):Math.abs(e.pos.z-(o.z+.5+Math.sign(d)*.28)))>.12&&o.x===Math.floor(e.pos.x)&&(r.mx=f/g*.5,r.mz=d/g*.5);let m=u?i.y:i.y-1,p=this.aimAt(l+.5,m+.5,c+.5,t);if(i.placeT+=t,i.placeT>.62-this.skill*.28&&p<.6){i.placeT=0;let S=e.inv.slots[r.sel??e.sel];S&&(e.sel=r.sel??e.sel,!ce(n.get(l,m-0+(u?-1:0),c))&&u?this.m.place(e,l,i.y-1,c,S.id):this.m.place(e,l,m,c,S.id))}return!1}lootChest(t,e){let n=this.a;return Math.hypot(t.x+.5-n.pos.x,t.z+.5-n.pos.z)<2.6&&Math.abs(t.y-n.pos.y)<2.5?(this.ctlObj.mx=this.ctlObj.mz=0,this.aimAt(t.x+.5,t.y+.5,t.z+.5,e),this.pause+=e,this.pause>1.1+(1-this.skill)*.9?(this.m.takeAll(n,t),this.pause=0,this.equip(),!0):!1):(this.goTo(t.x,t.y,t.z,e,1),!1)}equip(){this.selectKind("sword")||this.selectKind("axe")}nearestChest(t,e=()=>!0){let n=null,i=t;for(let r of this.m.map.chests){if(r.looted||!r.items.length||!e(r))continue;let o=this.dist({x:r.x,y:r.y,z:r.z});o<i&&(i=o,n=r)}return n}fight(t,e,n){let i=this.a,r=this.ctlObj;this.bridge=null,this.selectKind("sword")||this.selectKind("axe")||this.selectKind("pick");let o=this.aimAt(t.pos.x,t.pos.y+1.2,t.pos.z,n,this.aimErr),a=2.8+this.skill*.3;if(e>a-.4)if(Math.abs(t.pos.y-i.pos.y)<1.5&&e<6)this.steer(t.pos.x,t.pos.z,n),i.blocked&&i.onGround&&(r.jump=!0);else{let c=ki(t.pos),h=hi(this.m.world,c.x,c.y,c.z,4);this.goTo(c.x,h??c.y,c.z,n,1)}else{this.strafeT-=n,this.strafeT<=0&&(this.strafeT=.6+Math.random()*.9,this.strafe=Math.random()<.5?1:-1);let l=t.pos.x-i.pos.x,c=t.pos.z-i.pos.z,h=Math.hypot(l,c)||1,u=e>2.2?.7:-.1;r.mx=l/h*u+-c/h*this.strafe*.6,r.mz=c/h*u+l/h*this.strafe*.6,this.unsafeAhead(r.mx,r.mz)&&(r.mx=l/h*.4,r.mz=c/h*.4,this.unsafeAhead(r.mx,r.mz)&&(r.mx=r.mz=0),r.crouch=!0),r.sprint=e>1.8,this.jumpT-=n,this.jumpT<=0&&i.onGround&&Math.random()<this.skill*.6&&(r.jump=!0,this.jumpT=.9+Math.random())}this.clickT-=n,e<a+.5&&o<.45&&this.clickT<=0&&(r.attack=!0,r.attackPressed=!0,this.clickT=1/this.cps)}tryThrow(t,e,n){let i=this.a;if(this.throwT-=n,this.throwT>0||e<5||e>16||i.inv.count(131)===0||!this.visible(t))return!1;this.throwT=2.5+Math.random()*3;let r=i.inv.slots.findIndex(l=>l&&l.id===131);if(r<0)return!1;i.sel=r,this.ctlObj.sel=r;let o=e/22;return this.aimAt(t.pos.x+t.vel.x*o,t.pos.y+1.3+e*.06,t.pos.z+t.vel.z*o,1,0)<.5?(this.ctlObj.use=!0,!0):!1}heal(t){let e=this.a;if(e.hp>9)return!1;let n=e.inv.slots.findIndex(i=>i&&te[i.id].kind==="food");return n<0?!1:(this.ctlObj.sel=n,this.ctlObj.useHeld=!0,!0)}clutch(){let t=this.a,e=this.m.world;if(t.onGround||t.vel.y>-6||this.skill<.35)return;let n=ki(t.pos);if(hi(e,n.x,n.y,n.z,5)!=null||Math.random()>this.skill*.08)return;let i=t.inv.blockSlot();i<0||(t.sel=i,this.m.place(t,n.x,n.y-1,n.z,t.inv.slots[i].id))}tick(t){let e=this.a,n=this.m,i=this.ctlObj;if(this.noBridge=(this.noBridge||0)-t,i.jump=!1,i.attack=!1,i.attackPressed=!1,i.use=!1,i.useHeld=!1,i.crouch=!1,i.mx=0,i.mz=0,n.state!=="play")return i;this.clutch();let r=Math.hypot(e.pos.x-this.lastPos.x,e.pos.z-this.lastPos.z);this.lastPos={...e.pos};let o=this.path&&this.pi<this.path.length||!!this.bridge||this.goal&&this.goal.t!=="idle";this.stuckT=r<.4*t&&o&&!this.bridge?this.stuckT+t:Math.max(0,this.stuckT-t),this.stuckT>1.2&&(i.jump=!0,this.path=null),this.stuckT>3.5&&(this.stuckT=0,this.goal=null,this.bridge=null),r>.6*t&&(this.lostT=0);let a=this.nearestEnemy(30);if(a){this.noticeT+=t;let c=a.d<3||this.visible(a.o),h=n.mode.id==="sky"&&n.time<100&&!a.o.local;if(a.d<(this.bridge?4:h?4+this.brave*3:9+this.brave*8)&&c&&Math.abs(a.o.pos.y-e.pos.y)<5&&this.noticeT>this.react)return!(a.d<3.5)&&this.heal(t)||this.tryThrow(a.o,a.d,t)||this.fight(a.o,a.d,t),i}else this.noticeT=0;return this.heal(t)?i:(n.mode.id==="egg"?this.planEgg(t):this.planSky(t))||i}planSky(t){let e=this.a,n=this.m,i=this.ctlObj,r=n.mode;if(r.rising&&e.pos.y<n.map.voidY+5&&this.tower(t))return i;if(r.border<r.radius&&Math.hypot(e.pos.x,e.pos.z)>r.border-5)return this.goal={t:"center"},this.goTo(0,n.map.center.y-2,0,t,3),i;let o=e.home,a=this.nearestChest(14,h=>Math.hypot(h.x-o.x,h.z-o.z)<9);if(a)return this.goal={t:"loot"},this.lootChest(a,t),i;if(e.inv.blocks()<8){let h=this.nearestChest(12);if(h)return this.goal={t:"loot"},this.lootChest(h,t),i;if(this.mineForBlocks(t))return i}let c=e.inv.armorPoints()+(e.inv.best("sword")>=0?4:0);if(!this.goal||this.goal.t==="loot"||this.goal.t==="idle"||(this.goalT-=t)<=0){this.goalT=6+Math.random()*6;let h=n.map.chests.some(f=>f.tier==="mid"&&!f.looted&&f.items.length),u=this.nearestEnemy(999);n.time<this.patience*(c<10?1:.75)?this.goal={t:h&&n.time>25&&this.greed>.8?"mid":"idle"}:h&&(this.greed>.6||c<5)&&(n.time<150||r.refilled&&n.time<r.borderAt&&Math.random()<.5)?this.goal={t:"mid"}:u?this.goal={t:"hunt",o:u.o}:this.goal={t:"mid"}}if(this.goal.t==="idle")return this.goalT=Math.min(this.goalT,3),this.wander(t),i;if(this.goal.t==="mid"){let h=this.nearestChest(80,u=>u.tier!=="spawn"||Math.hypot(u.x-o.x,u.z-o.z)<9);return h&&this.dist(h)<60?(this.lootChest(h,t),i):(this.goTo(0,n.map.center.y-2,0,t,2),i)}if(this.goal.t==="hunt"){let h=this.goal.o;if(!h||!h.alive)return this.goal=null,i;if(h.pos.y-e.pos.y>1.8&&Math.hypot(h.pos.x-e.pos.x,h.pos.z-e.pos.z)<5&&this.tower(t))return i;let u=ki(h.pos),f=hi(n.world,u.x,u.y,u.z,6);return this.goTo(u.x,f??u.y,u.z,t,1),i}return i}tower(t){let e=this.a,n=this.ctlObj,i=this.m.world;if(!this.selectBlocks())return!1;let r=Math.floor(e.pos.x),o=Math.floor(e.pos.z),a=Math.floor(e.pos.y+.01);if(ce(i.get(r,a+2,o)))return!1;if(n.mx=(r+.5-e.pos.x)*2,n.mz=(o+.5-e.pos.z)*2,this.aimAt(r+.5,e.pos.y-1,o+.5+.001,t),e.onGround)return n.jump=!0,this.towerY=a,!0;if(this.towerY!=null&&e.pos.y>=this.towerY+1.05&&!i.get(r,this.towerY,o)){let l=e.inv.slots[n.sel??e.sel];l&&(e.sel=n.sel??e.sel,this.m.place(e,r,this.towerY,o,l.id)),this.towerY=null}return!0}steerOrPath(t,e,n,i){let r=this.a;if(Math.abs(r.pos.y-e)<.6&&Math.hypot(t+.5-r.pos.x,n+.5-r.pos.z)<2.5){this.steer(t+.5,n+.5,i,!1);return}this.goTo(t,e,n,i,0,!1)}giveUp(t){let e=this.a;if(this.lostT=(this.lostT||0)+t,this.lostT<12)return!1;let n=this.m.map.center,i=e.pos.x-n.x,r=e.pos.z-n.z,o=Math.hypot(i,r)||1;return this.ctlObj.mx=i/o,this.ctlObj.mz=r/o,this.ctlObj.sprint=!0,e.blocked&&(this.ctlObj.jump=!0),!0}wander(t){let e=this.a;if(this.wanderT-=t,this.wanderT<=0||!this.wanderTo){this.wanderT=2+Math.random()*3;let i=e.home;this.wanderTo={x:i.x+(Math.random()-.5)*5,z:i.z+(Math.random()-.5)*5}}this.steer(this.wanderTo.x,this.wanderTo.z,t,!1)<.5&&(this.ctlObj.mx=this.ctlObj.mz=0,this.aimAt(0,e.pos.y+1,0,t*.3))}mineForBlocks(t){let e=this.a,n=this.m.world,i=ki(e.pos);if(!this.mineTarget||!n.get(this.mineTarget.x,this.mineTarget.y,this.mineTarget.z)){this.mineTarget=null;t:for(let a=1;a<=5;a++)for(let l=0;l<=2;l++)for(let c=-a;c<=a;c++)for(let h=-a;h<=a;h++){let u=i.x+h,f=i.y+l-(l===2?3:0),d=i.z+c;if(h===0&&c===0)continue;let g=n.get(u,f,d);if(g&&[2,3,4,5,6,8,9,18,28].includes(g)&&this.m.mode.canBreak(e,u,f,d,g)&&f>=i.y-1){this.mineTarget={x:u,y:f,z:d};break t}}}let r=this.mineTarget;return r?(this.aimAt(r.x+.5,r.y+.5,r.z+.5,t)<.25&&(this.ctlObj.attack=!0,this.selectKind("pick")||this.selectKind("axe")),!0):!1}planEgg(t){return(this.m.mode.botPlan?this.m.mode.botPlan(this,t):null)||this.ctlObj}};var Jt=1.8/32,$0=s=>{let t=s>>>0||7;return()=>(t^=t<<13,t^=t>>>17,t^=t<<5,(t>>>0)/4294967296)},Es=(s,t)=>t[Math.floor(s()*t.length)],Y0=["#f2c9a0","#e8b48a","#d49a6a","#b07a4a","#8a5a36","#6a4026","#f5d5b5"],Z0=["#2a1a10","#4a2a14","#7a4a1e","#c89a4a","#e8d080","#1a1a1a","#a0302a","#e0e0e0","#3a5ad8","#d84a9a"],J0=["#d83a3a","#3a7ad8","#3aa84a","#e8c83a","#8a3ad8","#e8823a","#2ab8c0","#e86aa8","#3a3a3a","#e8e8e8","#4a5a7a","#7a4a2a"],K0=["#2a3a6a","#3a3a3a","#5a4a3a","#2a2a2a","#4a5a3a","#6a6a7a","#1a2a4a"];function Rc(s,t=-1){let e=$0(s*9973+17),n=document.createElement("canvas");n.width=64,n.height=64;let i=n.getContext("2d"),r=Es(e,Y0),o=Es(e,Z0),a=t>=0?_e[t].hex:Es(e,J0),l=Es(e,K0),c=Es(e,["#2a2a2a","#4a3020","#e8e8e8","#3a3a5a"]),h=(p,S)=>{let y=parseInt(p.slice(1),16),v=T=>Math.max(0,Math.min(255,Math.round(T*S)));return`rgb(${v(y>>16)},${v(y>>8&255)},${v(y&255)})`},u=(p,S,y,v,T,E=.06)=>{for(let C=S;C<S+v;C++)for(let I=p;I<p+y;I++)i.fillStyle=h(T,1-E+e()*E*2),i.fillRect(I,C,1,1)},f=(p,S,y)=>{i.fillStyle=y,i.fillRect(p,S,1,1)};u(0,0,32,16,r,.04),u(8,0,8,8,o),u(16,0,8,8,r);let d=Math.floor(e()*4);u(0,8,32,d===0?2:d===1?3:4,o),u(24,8,8,8,o),d>=2&&(u(0,8,8,6,o),u(16,8,8,6,o)),d===3&&(u(8,8,1,4,o),u(15,8,1,4,o));let g=Es(e,["#3a6ad8","#3a2a1a","#2a8a4a","#5a3a2a","#6a6a6a"]);f(9,12,"#ffffff"),f(10,12,g),f(13,12,g),f(14,12,"#ffffff"),e()<.6&&(f(10,11,h(o,.8)),f(13,11,h(o,.8))),u(11,14,2,1,h(r,.7),0),f(10,14,h(r,.82)),f(13,14,h(r,.82)),e()<.2&&u(9,14,6,2,o),u(16,16,24,16,a),u(20,16,8,4,a),u(28,16,8,4,h(a,.85));let x=Math.floor(e()*5);if(x===1&&u(20,22,8,2,"#ffffff",.02),x===2&&u(23,20,2,12,h(a,.7)),x===3)for(let p=0;p<8;p++)f(20+p,20+p%2,h(a,1.25));x===4&&u(20,26,8,6,h(a,.75)),u(22,20,4,2,h(r,.95),0),u(40,16,16,16,a),u(44,26,4,6,r),u(40,26,16,6,r),u(40,20,16,2,h(a,.8)),u(0,16,16,16,l),u(0,28,16,4,c),u(4,16,8,4,l),t>=0&&u(20,26,8,2,h(a,.6));let m=new us(n);return m.magFilter=Te,m.minFilter=Te,m.colorSpace=Re,m}function j0(s,t,e,n,i,r){let a=[[t,e+r,r,i],[t+r+n,e+r,r,i],[t+r,e,n,r],[t+r+n,e,n,r],[t+2*r+n,e+r,n,i],[t+r,e+r,n,i]],l=s.attributes.uv;for(let c=0;c<6;c++){let[h,u,f,d]=a[c],g=h/64,x=(h+f)/64,m=1-u/64,p=1-(u+d)/64,S=c*4;l.setXY(S,g,m),l.setXY(S+1,x,m),l.setXY(S+2,g,p),l.setXY(S+3,x,p)}return l.needsUpdate=!0,s}function Ts(s,t,e,n,i,r,o){let a=j0(new Oe(t*Jt,e*Jt,n*Jt),i,r,t,e,n);a.translate(0,-e*Jt/2+o,0);let l=new ie(a,s),c=new Je;return c.add(l),c}var Q0=[9067056,11053232,14211288,5234904];function Ba(s,t=-1){let e=Rc(s,t),n=new Vn({map:e}),i=new Je,r=new Je;i.add(r);let o=Ts(n,8,8,8,0,0,4*Jt);o.position.y=24*Jt+0,o.children[0].geometry.translate(0,4*Jt,0);let a=Ts(n,8,12,4,16,16,6*Jt);a.position.y=18*Jt;let l=Ts(n,4,12,4,40,16,2*Jt);l.position.set(6*Jt,22*Jt,0);let c=Ts(n,4,12,4,40,16,2*Jt);c.position.set(-6*Jt,22*Jt,0);let h=Ts(n,4,12,4,0,16,0);h.position.set(2*Jt,12*Jt,0);let u=Ts(n,4,12,4,0,16,0);u.position.set(-2*Jt,12*Jt,0),r.add(o,a,l,c,h,u);let f=new Je;f.position.set(0,-10*Jt,-2*Jt),l.add(f);let d=Q0.map(m=>new Vn({color:m})),g=(m,p,S,y,v)=>{let T=new ie(new Oe(m*Jt,p*Jt,S*Jt),d[0]);return T.position.y=y,T.visible=!1,v.add(T),T},x=[[g(9,9,9,4*Jt,o)],[g(9,13,5,0,a),g(5,6,5,-1*Jt,l),g(5,6,5,-1*Jt,c)],[g(5,8,5,-4*Jt,h),g(5,8,5,-4*Jt,u)],[g(5,4,5,-10.5*Jt,h),g(5,4,5,-10.5*Jt,u)]];return{root:i,body:r,head:o,torso:a,armR:l,armL:c,legR:h,legL:u,hand:f,mat:n,armor:x,armorMats:d,heldId:null,tex:e}}function sd(s,t){for(let e=0;e<4;e++){let n=t.armor[e];for(let i of s.armor[e])i.visible=!!n,n&&(i.material=s.armorMats[te[n].tier])}}function rd(s,t,e){let n=Math.sin(t.walkPhase*1.6)*Math.min(1,t.moveAmt/4)*.9;s.legR.rotation.x=n,s.legL.rotation.x=-n,s.armL.rotation.x=-n*.8;let i=t.swingT>0?Math.sin((1-t.swingT/.25)*Math.PI):0;s.armR.rotation.x=n*.8-i*1.6-(t.heldBlock?.3:0),s.armR.rotation.z=-i*.25,s.head.rotation.x=-t.pitch*.9,s.body.position.y=t.crouch?-.18:0,s.torso.rotation.x=t.crouch?.45:0,s.head.position.z=t.crouch?-.2:0,s.armR.position.z=s.armL.position.z=t.crouch?-.15:0;let r=t.hurtT>.2;s.mat.emissive&&s.mat.emissive.setRGB(r?.6:0,0,0)}var Cc=new Map;function za(s,t,e){if(Cc.has(s))return Cc.get(s).clone();let n=te[s],i;if(n&&n.kind==="block"){let r=Zt[n.block],o=new Oe(1,1,1),a=o.attributes.uv,l=["side","side","top","bottom","side","side"];for(let u=0;u<6;u++){let[f,d,g,x]=t.uv(r.tex[l[u]]);for(let m=0;m<4;m++){let p=u*4+m;a.setXY(p,f+a.getX(p)*g,d+(1-a.getY(p))*x)}}let c=[.8,.8,1,.55,.68,.68],h=[];for(let u=0;u<6;u++)for(let f=0;f<4;f++)h.push(c[u],c[u],c[u]);o.setAttribute("color",new he(h,3)),i=new ie(o,new Ae({map:e,vertexColors:!0,alphaTest:.5,transparent:r.id===11})),i.scale.setScalar(.32),i.userData.block=!0}else{let r=n?n.icon:"snowball",[o,a,l,c]=t.uv(r),h=t.width,u=Math.round(o*h),f=Math.round(a*t.height),d=[],g=[],x=[],m=1/16,p=(y,v)=>y>=0&&v>=0&&y<16&&v<16&&t.data[((f+v)*h+u+y)*4+3]>100;for(let y=0;y<16;y++)for(let v=0;v<16;v++){if(!p(v,y))continue;let T=((f+y)*h+u+v)*4,E=[t.data[T]/255,t.data[T+1]/255,t.data[T+2]/255].map(P=>Math.pow(P,2.2)),C=(v-8)*m,I=(7-y)*m,M=m*.5,w=[[[0,0,M],[m,0,M],[m,m,M],[0,m,M],1],[[m,0,-M],[0,0,-M],[0,m,-M],[m,m,-M],.75]];p(v,y-1)||w.push([[0,m,M],[m,m,M],[m,m,-M],[0,m,-M],.95]),p(v,y+1)||w.push([[0,0,-M],[m,0,-M],[m,0,M],[0,0,M],.6]),p(v-1,y)||w.push([[0,0,-M],[0,0,M],[0,m,M],[0,m,-M],.7]),p(v+1,y)||w.push([[m,0,M],[m,0,-M],[m,m,-M],[m,m,M],.8]);for(let P of w){let k=d.length/3;for(let H=0;H<4;H++)d.push(C+P[H][0],I+P[H][1],P[H][2]),g.push(E[0]*P[4],E[1]*P[4],E[2]*P[4]);x.push(k,k+1,k+2,k,k+2,k+3)}}let S=new ke;S.setAttribute("position",new he(d,3)),S.setAttribute("color",new he(g,3)),S.setIndex(x),i=new ie(S,new Ae({vertexColors:!0})),i.scale.setScalar(.62)}return Cc.set(s,i),i.clone()}function od(s){let t=[];for(let a=0;a<=12;a++){let l=a/12,c=l*.95,h=Math.sin(Math.PI*Math.pow(l,.8))*.36*(1-l*.15);t.push(new Nt(Math.max(.001,h),c))}let e=new rr(t,14),n=new Lt(_e[s].hex),i=[],r=e.attributes.position;for(let a=0;a<r.count;a++){let l=(Math.sin(r.getX(a)*40)*Math.cos(r.getY(a)*31+r.getZ(a)*27)+1)/2,c=l>.8?1.35:.85+l*.25;i.push(n.r*c,n.g*c,n.b*c)}return e.setAttribute("color",new he(i,3)),new ie(e,new Vn({vertexColors:!0,emissive:n,emissiveIntensity:.25}))}function Ic(s,t="#ffffff"){let e=document.createElement("canvas"),n=e.getContext("2d");n.font="bold 30px system-ui, sans-serif";let i=Math.ceil(n.measureText(s).width)+20;e.width=i,e.height=42,n.font="bold 30px system-ui, sans-serif",n.fillStyle="rgba(0,0,0,0.45)",n.fillRect(0,0,i,42),n.fillStyle=t,n.textBaseline="middle",n.fillText(s,10,22);let r=new us(e);r.colorSpace=Re;let o=new tr(new as({map:r,depthWrite:!1,transparent:!0}));return o.scale.set(i/190,.22,1),o.renderOrder=5,o}var tx={shoulder:[.5,-.62,-.18],dir:[-.2,.5,-1],roll:.5,scale:1,block:{scale:.24,rot:[0,.8,0],off:[-.05,.07,-.08]},tool:{scale:.5,rot:[0,-.8,.2],off:[-.08,.12,-.1]}},Ha=class{constructor(t,e){this.R=t,this.atlas=e,this.scene=t.scene,this.chars=new Map,this.dropMeshes=new Map,this.projMeshes=new Map,this.eggs=[],this.npcs=[],this.particles=[];let n=new Oe(.12,.12,.12);this.pMesh=new wi(n,new Ae({vertexColors:!1}),400),this.pMesh.instanceMatrix.setUsage(Zl),this.pMesh.count=0,this.pMesh.frustumCulled=!1,this.pColors=new Float32Array(400*3),this.pMesh.instanceColor=new Si(this.pColors,3),this.scene.add(this.pMesh),this.vmScene=new bi,this.vmCam=new Ue(70,1,.01,10),this.vmScene.add(new Ci(16777215,7829367,2.2));let i=new Ri(16777215,1.2);i.position.set(.3,1,.5),this.vmScene.add(i),this.vm=new Je,this.vmScene.add(this.vm),this.vmHeld=null,this.vmHeldId=-1,this.vmSwing=0,this.vmBob=0,this.vmCfg=JSON.parse(JSON.stringify(tx))}setMatch(t,e){this.clear(),this.m=t,this.local=e;for(let n of t.actors){let i=Ba(n.skin,t.mode.id==="egg"?n.team:-1),r=n.team>=0?_e[n.team].hex:"#ffffff";i.tag=Ic(n.name,r),i.tag.position.y=2.15,i.root.add(i.tag),this.scene.add(i.root),this.chars.set(n.id,i),n===e&&(i.root.visible=!1)}if(t.mode.teams)for(let n of t.mode.teams){let i=od(n.i);i.position.set(n.egg.x+.5,n.egg.y,n.egg.z+.5),this.scene.add(i),this.eggs.push({t:n,mesh:i})}for(let n of t.npcs){let i=Ba(4242+n.team*7,-1);i.root.position.set(n.x,n.y,n.z),i.root.rotation.y=n.yaw;let r=Ic("SHOP","#ffe066");r.position.y=2.15,i.root.add(r);let o=new ie(new Oe(.47,.5,.05),new Vn({color:n.team>=0?_e[n.team].hex:"#3a6ad8"}));o.position.set(0,.95,-.15),i.root.add(o),this.scene.add(i.root),this.npcs.push({n,ch:i})}this.buildViewmodelArm()}clear(){for(let t of this.chars.values())this.scene.remove(t.root);for(let t of this.dropMeshes.values())this.scene.remove(t);for(let t of this.projMeshes.values())this.scene.remove(t);for(let t of this.eggs)this.scene.remove(t.mesh);for(let t of this.npcs)this.scene.remove(t.ch.root);this.voidPlane&&(this.scene.remove(this.voidPlane),this.voidPlane=null),this.chars.clear(),this.dropMeshes.clear(),this.projMeshes.clear(),this.eggs=[],this.npcs=[],this.particles=[],this.pMesh.count=0}buildViewmodelArm(){this.vmArm&&this.vm.remove(this.vmArm);let t=Ba(this.local?this.local.skin:1,this.m&&this.m.mode.id==="egg"&&this.local?this.local.team:-1);this.vmArm=new ie(t.armR.children[0].geometry.clone(),t.mat),this.vm.add(this.vmArm),this.placeArm()}placeArm(){let t=this.vmCfg,e=new D(...t.dir).normalize();this.vmArm.position.set(...t.shoulder),this.vmArm.quaternion.setFromUnitVectors(new D(0,-1,0),e),this.vmArm.rotateY(t.roll),this.vmArm.scale.setScalar(t.scale),this.vmHandPos=new D(...t.shoulder).addScaledVector(e,.675*t.scale*.92)}heldModel(t){let e=za(t,this.atlas,this.R.atlasTex);return te[t].kind==="block"?(e.scale.setScalar(.24),e.position.set(0,-.05,-.08),e.rotation.set(.3,.6,0)):(e.scale.setScalar(.55),e.rotation.set(0,Math.PI/2,-.8),e.position.set(0,-.04,-.18)),e}burst(t,e,n,i){let r=Zt[i],o=new Lt(r?r.color:"#888");for(let a=0;a<10;a++)this.particles.length>=400&&this.particles.shift(),this.particles.push({x:t+.2+Math.random()*.6,y:e+.2+Math.random()*.6,z:n+.2+Math.random()*.6,vx:(Math.random()-.5)*3,vy:Math.random()*3+1,vz:(Math.random()-.5)*3,life:.5+Math.random()*.4,r:o.r*(.8+Math.random()*.3),g:o.g*(.8+Math.random()*.3),b:o.b*(.8+Math.random()*.3),s:.6+Math.random()*.6})}sparks(t,e,n,i=16777215,r=8){let o=new Lt(i);for(let a=0;a<r;a++)this.particles.push({x:t,y:e,z:n,vx:(Math.random()-.5)*4,vy:Math.random()*3,vz:(Math.random()-.5)*4,life:.4+Math.random()*.3,r:o.r,g:o.g,b:o.b,s:.5})}update(t,e){let n=this.m;if(!n)return;let i=n.time;for(let f of n.actors){let d=this.chars.get(f.id);if(!d)continue;if(f===this.local&&!this.thirdPerson){d.root.visible=!1;continue}if(!f.alive){d.root.visible&&(d.deathT=(d.deathT||0)+t,d.root.rotation.z=Math.min(Math.PI/2,d.deathT*6),d.deathT>.6&&(d.root.visible=!1));continue}d.deathT=0,d.root.rotation.z=0,d.root.visible=!0,d.root.position.set(f.pos.x,f.pos.y,f.pos.z),d.root.rotation.y=f.yaw;let g=f.inv.slots[f.sel],x=g?g.id:0;f.heldBlock=x&&te[x].kind==="block",d.heldId!==x&&(d.hand.clear(),x&&d.hand.add(this.heldModel(x)),d.heldId=x),rd(d,f,i);let m=f.inv.armor.join(",");d.armorSig!==m&&(d.armorSig=m,sd(d,f.inv)),d.mat.color&&d.mat.color.setRGB((f.hurtT>.25,1),f.hurtT>.25?.45:1,f.hurtT>.25?.45:1),d.tag.visible=e?Math.hypot(e.position.x-f.pos.x,e.position.z-f.pos.z)<40:!0}n.mode.rising&&(this.voidPlane||(this.voidPlane=new ie(new Ei(400,400),new Ae({color:1706538,transparent:!0,opacity:.82,fog:!1,depthWrite:!1})),this.voidPlane.rotation.x=-Math.PI/2,this.voidPlane.renderOrder=3,this.scene.add(this.voidPlane)),this.voidPlane.position.y=n.map.voidY+Math.sin(i*2)*.05);for(let{n:f,ch:d}of this.npcs)d.head.rotation.y=Math.sin(i*.7+f.team)*.4;for(let f of this.eggs)f.mesh.visible=f.t.eggAlive,f.mesh.rotation.y=i*.6,f.mesh.position.y=f.t.egg.y+.03+Math.sin(i*2)*.03;let r=new Set;for(let f of n.drops){r.add(f.key);let d=this.dropMeshes.get(f.key);d||(d=za(f.id,this.atlas,this.R.atlasTex),te[f.id].kind!=="block"?d.scale.setScalar(.42):d.scale.setScalar(.25),this.scene.add(d),this.dropMeshes.set(f.key,d)),d.position.set(f.x,f.y-.05+Math.sin(i*3+f.key*10)*.06,f.z),d.rotation.y=i*1.6+f.key*6}for(let[f,d]of this.dropMeshes)r.has(f)||(this.scene.remove(d),this.dropMeshes.delete(f));let o=new Set;for(let f of n.projectiles){o.add(f);let d=this.projMeshes.get(f);d||(d=new ie(new Ti(.11,8,6),new Ae({color:f.id===132?2808008:16055039})),this.scene.add(d),this.projMeshes.set(f,d)),d.position.set(f.x,f.y,f.z)}for(let[f,d]of this.projMeshes)o.has(f)||(this.scene.remove(d),d.geometry.dispose(),this.projMeshes.delete(f));let a=new Qt,l=new sn,c=new D,h=new D,u=0;for(let f=this.particles.length-1;f>=0;f--){let d=this.particles[f];if(d.life-=t,d.life<=0){this.particles.splice(f,1);continue}d.vy-=14*t,d.x+=d.vx*t,d.y+=d.vy*t,d.z+=d.vz*t,n.world.solidAt(Math.floor(d.x),Math.floor(d.y),Math.floor(d.z))&&(d.y=Math.floor(d.y)+1.06,d.vy=0,d.vx*=.5,d.vz*=.5),h.set(d.x,d.y,d.z),c.setScalar(d.s*Math.min(1,d.life*3)),a.compose(h,l,c),this.pMesh.setMatrixAt(u,a),this.pColors[u*3]=d.r,this.pColors[u*3+1]=d.g,this.pColors[u*3+2]=d.b,u++}this.pMesh.count=u,this.pMesh.instanceMatrix.needsUpdate=!0,this.pMesh.instanceColor.needsUpdate=!0}updateViewmodel(t,e,n){if(!e)return;let i=e.inv.slots[e.sel],r=i?i.id:0;if(r!==this.vmHeldId&&(this.vmHeld&&this.vm.remove(this.vmHeld),this.vmHeld=null,this.vmHeldId=r,this.vmEquip=.25,r)){let h=za(r,this.atlas,this.R.atlasTex),u=te[r].kind==="block"?this.vmCfg.block:this.vmCfg.tool;h.scale.setScalar(u.scale),h.rotation.set(...u.rot,"YXZ"),h.position.copy(this.vmHandPos).add(new D(...u.off)),this.vmHeld=h,this.vm.add(h)}e.swingT>.2&&this.vmSwing<=0&&(this.vmSwing=.28),this.vmSwing=Math.max(0,this.vmSwing-t),this.vmEquip=Math.max(0,(this.vmEquip||0)-t);let o=this.vmSwing>0?Math.sin((1-this.vmSwing/.28)*Math.PI):0,a=e.onGround?Math.min(1,e.moveAmt/4.3):0;this.vmBob+=t*(e.sprint?13:9)*a;let l=Math.sin(this.vmBob)*.025*a,c=Math.abs(Math.cos(this.vmBob))*.03*a;this.vm.position.set(l-o*.15,-c-o*.12-this.vmEquip*1.2+(e.eatT>0?Math.sin(e.eatT*30)*.03+.12:0),o*-.1),this.vm.rotation.set(-o*.9,o*.35,o*.2)}};var ad=["Pixel","Blocky","Shadow","Turbo","Lucky","Frosty","Sneaky","Crafty","Mighty","Swift","Cosmic","Rusty","Golden","Silent","Hyper","Mini","Mega","Fuzzy","Crispy","Wild","Stormy","Zippy","Noble","Dizzy","Epic","Neon","Lazy","Brave","Sly","Jolly"],vr=["Fox","Ninja","Creeper","Builder","Knight","Dragon","Panda","Wolf","Miner","Pirate","Rocket","Taco","Wizard","Bandit","Gamer","Tiger","Beast","Hero","Golem","Raven","Cookie","Bunny","Shark","Viking","Penguin","Hunter","Comet","Llama","Phantom","Otter"],ld=["Leo","Mia","Noah","Ava","Liam","Zoe","Kai","Ivy","Max","Luna","Eli","Nia","Sam","Ana","Theo","Ella","Jay","Ruby","Finn","Lola","Omar","Sara","Yuki","Ines","Tomas","Amara","Dani","Rafa","Chloe","Malik"];function Pc(s=Math.random){let t=n=>n[Math.floor(s()*n.length)],e=Math.floor(s()*100);switch(Math.floor(s()*6)){case 0:return`${t(ad)}${t(vr)}${e>40?e:""}`;case 1:return`${t(ad)}_${t(vr)}`;case 2:return`${t(ld)}${2e3+Math.floor(s()*25)}`;case 3:return`x${t(vr)}x${e<30?e:""}`;case 4:return`${t(ld)}_${t(vr).toLowerCase()}`;default:return`${t(vr)}${t(["Pro","YT","King","Queen","HD","TV","99","777"])}`}}var ex={sky:{id:"sky",players:8,teams:0,maps:[{id:"meadow",theme:"meadow",seed:7},{id:"dunes",theme:"desert",seed:12},{id:"dusk",theme:"meadow",seed:21,sky:"dusk"}]},egg:{id:"egg",players:8,teams:4,teamSize:2,maps:[{id:"frost",theme:"snow",seed:4},{id:"ember",theme:"volcano",seed:6}]}},Va=class{constructor(t,e,n={}){this.mode=ex[t],this.slots=[e],this.t=0,this.state="search",this.firstWait=n.firstWait??2.2,this.gap=n.gap??[.35,1.3],this.next=this.firstWait,this.countdown=n.countdown??4,this.names=new Set([e.name]),this.fast=!!n.fast,this.map=n.map?this.mode.maps.find(i=>i.id===n.map):this.mode.maps[Math.floor(Math.random()*this.mode.maps.length)]}update(t){if(this.t+=t,this.state==="search"){for(this.next-=t;this.next<=0&&this.slots.length<this.mode.players;){let e;do e=Pc();while(this.names.has(e));this.names.add(e),this.slots.push({name:e,bot:!0,skin:Math.floor(Math.random()*1e5),skill:.25+Math.random()*.6});let n=this.mode.players-this.slots.length;this.next+=this.fast?0:n>3?this.gap[0]+Math.random()*(this.gap[1]-this.gap[0]):.25+Math.random()*.5}this.slots.length>=this.mode.players&&(this.state="countdown",this.cd=this.countdown)}else this.state==="countdown"&&(this.cd-=t,this.cd<=0&&(this.state="go"))}};var As=[{id:0,seed:1,price:0},{id:1,seed:77,price:0},{id:2,seed:311,price:150},{id:3,seed:902,price:150},{id:4,seed:1450,price:250},{id:5,seed:2203,price:250},{id:6,seed:3517,price:400},{id:7,seed:4099,price:400},{id:8,seed:5821,price:600},{id:9,seed:7013,price:600},{id:10,seed:8888,price:900},{id:11,seed:9601,price:900}],cd={sens:1,fov:75,quality:"auto",volume:.8,music:.5,lang:"auto",invert:!1,viewBob:!0},Ga=s=>100+(s-1)*60,Wa=class{constructor(t){this.p=t,this.data={v:1,coins:0,xp:0,level:1,skin:0,owned:[0,1],stats:{games:0,wins:0,kills:0,deaths:0,eggs:0},best:{},settings:{...cd},tutorial:!1}}async load(){try{let t=await this.p.loadData();if(t){let e=JSON.parse(t);e&&e.v===1&&(this.data={...this.data,...e,stats:{...this.data.stats,...e.stats||{}},settings:{...cd,...e.settings||{}}})}}catch{}this.data.coins=Math.max(0,this.data.coins|0),Array.isArray(this.data.owned)||(this.data.owned=[0,1]),this.data.owned.includes(this.data.skin)||(this.data.skin=0)}persist(){clearTimeout(this.t),this.t=setTimeout(()=>this.p.saveData(JSON.stringify(this.data)),250)}get settings(){return this.data.settings}addXp(t){let e=this.data;e.xp+=t;let n=0;for(;e.xp>=Ga(e.level);)e.xp-=Ga(e.level),e.level++,n++,e.coins+=25;return n}};var Xa={voidRise:"The void is rising!",play:"PLAY",chooseGame:"Choose a game",skins:"Skins",settings:"Settings",howto:"How to play",back:"Back",level:"Level {n}",loading:"Loading\u2026",sky:"Sky Islands",skyDesc:"Loot your island, bridge across the sky and knock everyone into the void. Last one standing wins!",solo8:"Solo \xB7 8 players",egg:"Egg Defense",eggDesc:"Guard your team egg, buy gear with iron & gold, then go break the enemy eggs!",teams4x2:"4 teams of 2",soon:"Coming soon",race:"Block Race",raceDesc:"Parkour sprint over floating blocks.",spleef:"Spleef Arena",spleefDesc:"Dig the floor out from under your rivals.",finding:"Finding players\u2026",starting:"Starting in {n}",cancel:"Cancel",you:"You",yourTeam:"Your team: {team}",go:"GO!",alive:"{n} players left",refillIn:"Chest refill {t}",borderIn:"Border {t}",borderNow:"Border closing!",refilled:"Chests refilled!",borderMsg:"The border is closing in!",suddenIn:"Eggs crumble {t}",sudden:"Sudden death! All eggs are gone!",eggGone:"{team} egg destroyed!",yourEgg:"Your egg was destroyed!",noRespawn:"You will no longer respawn",teamOut:"{team} team eliminated!",died:"You died!",respawnIn:"Respawning in {n}",fell:"fell into the void",border:"was caught by the border",diedMsg:"died",victory:"VICTORY!",gameOver:"GAME OVER",placeOf:"You placed #{n} of {m}",teamWins:"{team} team wins!",winnerIs:"{name} wins!",kills:"Kills",reward:"Coins",xp:"XP",playAgain:"Play again",changeGame:"Change game",doubleCoins:"Double coins",spectate:"Spectate",spectating:"Spectating {name}",leave:"Leave",paused:"Paused",resume:"Resume",leaveMatch:"Leave match",clickToPlay:"Click to play",sens:"Look sensitivity",fov:"Field of view",quality:"Graphics",qAuto:"Auto",qLow:"Low",qHigh:"High",volume:"Sound",music:"Music",language:"Language",invert:"Invert look",on:"On",off:"Off",auto:"Auto",chest:"Chest",takeAll:"Take all",inventory:"Inventory",shop:"Shop",cBlocks:"Blocks",cCombat:"Combat",cArmor:"Armor",cTools:"Tools",cUtility:"Utility",wool:"Wool",chainSet:"Chain armor",ironSet:"Iron armor",diamondSet:"Diamond armor",notEnough:"Not enough",bought:"Bought!",equip:"Equip",equipped:"Equipped",levelUp:"Level up! +25 coins",kill1:"+1 kill",team_0:"Red",team_1:"Blue",team_2:"Green",team_3:"Yellow",team_4:"Purple",team_5:"Orange",team_6:"Cyan",team_7:"Pink",h1:"Move with WASD, jump with Space, sprint with Ctrl or double-tap W.",h2:"Hold Shift to sneak: you will not fall off edges, perfect for bridging.",h3:"Left click breaks blocks and attacks. Right click places blocks, opens chests and eats.",h4:"On mobile: left stick to move, drag to look, buttons to break, place and jump. Tap the world to place a block.",h5:"Sky Islands: loot your chests, build bridges to other islands, be the last one standing.",h6:"Egg Defense: collect iron and gold at your generator, buy gear from the shopkeeper and protect your egg. While your egg survives, you respawn!"},nx={voidRise:"\xA1El vac\xEDo est\xE1 subiendo!",play:"JUGAR",chooseGame:"Elige un juego",skins:"Aspectos",settings:"Ajustes",howto:"C\xF3mo jugar",back:"Volver",level:"Nivel {n}",loading:"Cargando\u2026",sky:"Islas del Cielo",skyDesc:"Saquea tu isla, construye puentes y tira a todos al vac\xEDo. \xA1Gana el \xFAltimo en pie!",solo8:"Solo \xB7 8 jugadores",egg:"Defensa del Huevo",eggDesc:"Protege el huevo de tu equipo, compra equipo con hierro y oro y rompe los huevos rivales.",teams4x2:"4 equipos de 2",soon:"Pr\xF3ximamente",race:"Carrera de Bloques",raceDesc:"Parkour sobre bloques flotantes.",spleef:"Arena Spleef",spleefDesc:"Rompe el suelo bajo tus rivales.",finding:"Buscando jugadores\u2026",starting:"Empieza en {n}",cancel:"Cancelar",you:"T\xFA",yourTeam:"Tu equipo: {team}",go:"\xA1YA!",alive:"Quedan {n} jugadores",refillIn:"Recarga de cofres {t}",borderIn:"Borde {t}",borderNow:"\xA1El borde se cierra!",refilled:"\xA1Cofres recargados!",borderMsg:"\xA1El borde se est\xE1 cerrando!",suddenIn:"Los huevos caen {t}",sudden:"\xA1Muerte s\xFAbita! \xA1No quedan huevos!",eggGone:"\xA1Huevo {team} destruido!",yourEgg:"\xA1Tu huevo fue destruido!",noRespawn:"Ya no reaparecer\xE1s",teamOut:"\xA1Equipo {team} eliminado!",died:"\xA1Has muerto!",respawnIn:"Reapareces en {n}",fell:"cay\xF3 al vac\xEDo",border:"fue atrapado por el borde",diedMsg:"muri\xF3",victory:"\xA1VICTORIA!",gameOver:"FIN DEL JUEGO",placeOf:"Quedaste #{n} de {m}",teamWins:"\xA1Gana el equipo {team}!",winnerIs:"\xA1{name} gana!",kills:"Bajas",reward:"Monedas",xp:"XP",playAgain:"Jugar otra vez",changeGame:"Cambiar juego",doubleCoins:"Doblar monedas",spectate:"Observar",spectating:"Observando a {name}",leave:"Salir",paused:"Pausa",resume:"Continuar",leaveMatch:"Salir de la partida",clickToPlay:"Haz clic para jugar",sens:"Sensibilidad",fov:"Campo de visi\xF3n",quality:"Gr\xE1ficos",qAuto:"Auto",qLow:"Bajo",qHigh:"Alto",volume:"Sonido",music:"M\xFAsica",language:"Idioma",invert:"Invertir vista",on:"S\xED",off:"No",auto:"Auto",chest:"Cofre",takeAll:"Tomar todo",inventory:"Inventario",shop:"Tienda",cBlocks:"Bloques",cCombat:"Combate",cArmor:"Armadura",cTools:"Herramientas",cUtility:"Utilidad",wool:"Lana",chainSet:"Armadura de malla",ironSet:"Armadura de hierro",diamondSet:"Armadura de diamante",notEnough:"No alcanza",bought:"\xA1Comprado!",equip:"Usar",equipped:"En uso",levelUp:"\xA1Subiste de nivel! +25 monedas",kill1:"+1 baja",team_0:"Rojo",team_1:"Azul",team_2:"Verde",team_3:"Amarillo",team_4:"Morado",team_5:"Naranja",team_6:"Cian",team_7:"Rosa",h1:"Mu\xE9vete con WASD, salta con Espacio, corre con Ctrl o doble toque en W.",h2:"Mant\xE9n Shift para agacharte: no caer\xE1s por los bordes, ideal para construir puentes.",h3:"Clic izquierdo rompe bloques y ataca. Clic derecho coloca bloques, abre cofres y come.",h4:"En m\xF3vil: joystick para moverte, desliza para mirar y usa los botones para romper, colocar y saltar. Toca el mundo para colocar un bloque.",h5:"Islas del Cielo: saquea tus cofres, construye puentes y s\xE9 el \xFAltimo en pie.",h6:"Defensa del Huevo: junta hierro y oro en tu generador, compra equipo al tendero y protege tu huevo. \xA1Mientras viva, reapareces!"},ix={voidRise:"O vazio est\xE1 subindo!",play:"JOGAR",chooseGame:"Escolha um jogo",skins:"Visuais",settings:"Ajustes",howto:"Como jogar",back:"Voltar",level:"N\xEDvel {n}",loading:"Carregando\u2026",sky:"Ilhas do C\xE9u",skyDesc:"Saqueie sua ilha, construa pontes e derrube todos no vazio. O \xFAltimo de p\xE9 vence!",solo8:"Solo \xB7 8 jogadores",egg:"Defesa do Ovo",eggDesc:"Proteja o ovo do seu time, compre equipamentos com ferro e ouro e quebre os ovos inimigos!",teams4x2:"4 times de 2",soon:"Em breve",race:"Corrida de Blocos",raceDesc:"Parkour sobre blocos flutuantes.",spleef:"Arena Spleef",spleefDesc:"Quebre o ch\xE3o debaixo dos rivais.",finding:"Procurando jogadores\u2026",starting:"Come\xE7a em {n}",cancel:"Cancelar",you:"Voc\xEA",yourTeam:"Seu time: {team}",go:"J\xC1!",alive:"Restam {n} jogadores",refillIn:"Ba\xFAs recarregam {t}",borderIn:"Borda {t}",borderNow:"A borda est\xE1 fechando!",refilled:"Ba\xFAs recarregados!",borderMsg:"A borda est\xE1 se fechando!",suddenIn:"Ovos caem {t}",sudden:"Morte s\xFAbita! Todos os ovos se foram!",eggGone:"Ovo {team} destru\xEDdo!",yourEgg:"Seu ovo foi destru\xEDdo!",noRespawn:"Voc\xEA n\xE3o vai mais renascer",teamOut:"Time {team} eliminado!",died:"Voc\xEA morreu!",respawnIn:"Renascendo em {n}",fell:"caiu no vazio",border:"foi pego pela borda",diedMsg:"morreu",victory:"VIT\xD3RIA!",gameOver:"FIM DE JOGO",placeOf:"Voc\xEA ficou em #{n} de {m}",teamWins:"Time {team} vence!",winnerIs:"{name} venceu!",kills:"Abates",reward:"Moedas",xp:"XP",playAgain:"Jogar de novo",changeGame:"Trocar jogo",doubleCoins:"Dobrar moedas",spectate:"Assistir",spectating:"Assistindo {name}",leave:"Sair",paused:"Pausado",resume:"Continuar",leaveMatch:"Sair da partida",clickToPlay:"Clique para jogar",sens:"Sensibilidade",fov:"Campo de vis\xE3o",quality:"Gr\xE1ficos",qAuto:"Auto",qLow:"Baixo",qHigh:"Alto",volume:"Som",music:"M\xFAsica",language:"Idioma",invert:"Inverter vis\xE3o",on:"Sim",off:"N\xE3o",auto:"Auto",chest:"Ba\xFA",takeAll:"Pegar tudo",inventory:"Invent\xE1rio",shop:"Loja",cBlocks:"Blocos",cCombat:"Combate",cArmor:"Armadura",cTools:"Ferramentas",cUtility:"Utilidades",wool:"L\xE3",chainSet:"Armadura de malha",ironSet:"Armadura de ferro",diamondSet:"Armadura de diamante",notEnough:"Insuficiente",bought:"Comprado!",equip:"Usar",equipped:"Em uso",levelUp:"Subiu de n\xEDvel! +25 moedas",kill1:"+1 abate",team_0:"Vermelho",team_1:"Azul",team_2:"Verde",team_3:"Amarelo",team_4:"Roxo",team_5:"Laranja",team_6:"Ciano",team_7:"Rosa",h1:"Mova-se com WASD, pule com Espa\xE7o, corra com Ctrl ou toque duplo no W.",h2:"Segure Shift para agachar: voc\xEA n\xE3o cai das bordas, perfeito para construir pontes.",h3:"Clique esquerdo quebra blocos e ataca. Clique direito coloca blocos, abre ba\xFAs e come.",h4:"No celular: anal\xF3gico para andar, arraste para olhar e use os bot\xF5es para quebrar, colocar e pular. Toque no mundo para colocar um bloco.",h5:"Ilhas do C\xE9u: saqueie seus ba\xFAs, construa pontes e seja o \xFAltimo de p\xE9.",h6:"Defesa do Ovo: colete ferro e ouro no gerador, compre equipamentos com o lojista e proteja seu ovo. Enquanto ele existir, voc\xEA renasce!"},sx={voidRise:"Le vide monte !",play:"JOUER",chooseGame:"Choisis un jeu",skins:"Skins",settings:"Options",howto:"Comment jouer",back:"Retour",level:"Niveau {n}",loading:"Chargement\u2026",sky:"\xCEles C\xE9lestes",skyDesc:"Pille ton \xEEle, construis des ponts et pousse tout le monde dans le vide. Le dernier debout gagne !",solo8:"Solo \xB7 8 joueurs",egg:"D\xE9fense de l\u2019\u0152uf",eggDesc:"Prot\xE8ge l\u2019\u0153uf de ton \xE9quipe, ach\xE8te de l\u2019\xE9quipement avec du fer et de l\u2019or, puis casse les \u0153ufs ennemis !",teams4x2:"4 \xE9quipes de 2",soon:"Bient\xF4t",race:"Course de Blocs",raceDesc:"Parkour sur des blocs flottants.",spleef:"Ar\xE8ne Spleef",spleefDesc:"Creuse le sol sous tes rivaux.",finding:"Recherche de joueurs\u2026",starting:"D\xE9but dans {n}",cancel:"Annuler",you:"Toi",yourTeam:"Ton \xE9quipe : {team}",go:"GO !",alive:"{n} joueurs restants",refillIn:"Recharge des coffres {t}",borderIn:"Bordure {t}",borderNow:"La bordure se resserre !",refilled:"Coffres recharg\xE9s !",borderMsg:"La bordure se resserre !",suddenIn:"Fin des \u0153ufs {t}",sudden:"Mort subite ! Plus aucun \u0153uf !",eggGone:"\u0152uf {team} d\xE9truit !",yourEgg:"Ton \u0153uf a \xE9t\xE9 d\xE9truit !",noRespawn:"Tu ne r\xE9appara\xEEtras plus",teamOut:"\xC9quipe {team} \xE9limin\xE9e !",died:"Tu es mort !",respawnIn:"R\xE9apparition dans {n}",fell:"est tomb\xE9 dans le vide",border:"a \xE9t\xE9 pris par la bordure",diedMsg:"est mort",victory:"VICTOIRE !",gameOver:"PARTIE TERMIN\xC9E",placeOf:"Tu es #{n} sur {m}",teamWins:"L\u2019\xE9quipe {team} gagne !",winnerIs:"{name} gagne !",kills:"\xC9liminations",reward:"Pi\xE8ces",xp:"XP",playAgain:"Rejouer",changeGame:"Changer de jeu",doubleCoins:"Doubler les pi\xE8ces",spectate:"Regarder",spectating:"Tu regardes {name}",leave:"Quitter",paused:"Pause",resume:"Reprendre",leaveMatch:"Quitter la partie",clickToPlay:"Clique pour jouer",sens:"Sensibilit\xE9",fov:"Champ de vision",quality:"Graphismes",qAuto:"Auto",qLow:"Bas",qHigh:"Haut",volume:"Son",music:"Musique",language:"Langue",invert:"Inverser la vue",on:"Oui",off:"Non",auto:"Auto",chest:"Coffre",takeAll:"Tout prendre",inventory:"Inventaire",shop:"Boutique",cBlocks:"Blocs",cCombat:"Combat",cArmor:"Armure",cTools:"Outils",cUtility:"Divers",wool:"Laine",chainSet:"Armure de mailles",ironSet:"Armure de fer",diamondSet:"Armure de diamant",notEnough:"Pas assez",bought:"Achet\xE9 !",equip:"Choisir",equipped:"Choisi",levelUp:"Niveau sup\xE9rieur ! +25 pi\xE8ces",kill1:"+1 \xE9limination",team_0:"Rouge",team_1:"Bleue",team_2:"Verte",team_3:"Jaune",team_4:"Violette",team_5:"Orange",team_6:"Cyan",team_7:"Rose",h1:"D\xE9place-toi avec ZQSD/WASD, saute avec Espace, cours avec Ctrl ou double appui sur avancer.",h2:"Maintiens Maj pour t\u2019accroupir : tu ne tomberas pas des bords, parfait pour construire des ponts.",h3:"Clic gauche casse les blocs et attaque. Clic droit pose des blocs, ouvre les coffres et mange.",h4:"Sur mobile : joystick pour bouger, glisse pour regarder, boutons pour casser, poser et sauter. Touche le monde pour poser un bloc.",h5:"\xCEles C\xE9lestes : pille tes coffres, construis des ponts et sois le dernier debout.",h6:"D\xE9fense de l\u2019\u0152uf : r\xE9cup\xE8re du fer et de l\u2019or au g\xE9n\xE9rateur, ach\xE8te de l\u2019\xE9quipement au marchand et prot\xE8ge ton \u0153uf. Tant qu\u2019il vit, tu r\xE9apparais !"},hd={en:Xa,es:nx,pt:ix,fr:sx},ud={en:"English",es:"Espa\xF1ol",pt:"Portugu\xEAs",fr:"Fran\xE7ais"},dd=Xa;function fd(s){return dd=hd[s]||Xa,hd[s]?s:"en"}function J(s,t){let e=dd[s]??Xa[s]??s;if(t)for(let n in t)e=e.replace(`{${n}}`,t[n]);return e}var Cs=null,qa=null,Yn=new Map;function md(s){qa=s,Cs=document.createElement("canvas"),Cs.width=s.width,Cs.height=s.height,Cs.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(s.data),s.width,s.height),0,0)}var pd=s=>{let[t,e]=qa.uv(s);return[Math.round(t*qa.width),Math.round(e*qa.height)]};function Fe(s){if(Yn.has(s))return Yn.get(s);let t=document.createElement("canvas");t.width=t.height=48;let e=t.getContext("2d");e.imageSmoothingEnabled=!1;let n=te[s];if(n&&n.kind==="block"&&!Zt[n.block].cross){let r=Zt[n.block],o=(c,h,u)=>{let[f,d]=pd(c);e.setTransform(...h),e.drawImage(Cs,f,d,16,16,-.02,-.02,16.04,16.04),u&&(e.globalCompositeOperation="source-atop",e.fillStyle=`rgba(0,0,0,${u})`,e.fillRect(0,0,16,16),e.globalCompositeOperation="source-over")};o(r.tex.side,[22/16,11/16,0,24/16,2,12],0),o(r.tex.side,[22/16,-11/16,0,24/16,24,23],0),e.setTransform(1,0,0,1,0,0);let a=document.createElement("canvas");a.width=a.height=48;let l=a.getContext("2d");l.fillStyle="rgba(0,0,0,0.22)",l.beginPath(),l.moveTo(2,12),l.lineTo(24,23),l.lineTo(24,47),l.lineTo(2,36),l.fill(),l.fillStyle="rgba(0,0,0,0.4)",l.beginPath(),l.moveTo(24,23),l.lineTo(46,12),l.lineTo(46,36),l.lineTo(24,47),l.fill(),e.globalCompositeOperation="source-atop",e.drawImage(a,0,0),e.globalCompositeOperation="source-over",o(r.tex.top,[22/16,-11/16,22/16,11/16,2,12],0)}else{let[r,o]=pd(n?n.kind==="block"?Zt[n.block].tex.side:n.icon:"snowball");e.drawImage(Cs,r,o,16,16,0,0,48,48)}let i=t.toDataURL();return Yn.set(s,i),i}var Lc=new Map;function $a(s,t=-1){let e=s+":"+t;if(Lc.has(e))return Lc.get(e);let n=Rc(s,t).image,i=document.createElement("canvas");i.width=16,i.height=32;let r=i.getContext("2d");r.drawImage(n,8,8,8,8,4,0,8,8),r.drawImage(n,20,20,8,12,4,8,8,12),r.drawImage(n,44,20,4,12,0,8,4,12),r.drawImage(n,44,20,4,12,12,8,4,12),r.drawImage(n,4,20,4,12,4,20,4,12),r.drawImage(n,4,20,4,12,8,20,4,12);let o=i.toDataURL();return Lc.set(e,o),o}var rx={heart:[".##.##.","#######","#######",".#####.","..###..","...#..."],armor:["##.##","#####",".###.",".###.",".###."]};function ui(s,t,e,n=!1){let i=s+t+e+n;if(Yn.has(i))return Yn.get(i);let r=rx[s],o=r[0].length,a=r.length,l=3,c=document.createElement("canvas");c.width=(o+2)*l,c.height=(a+2)*l;let h=c.getContext("2d"),u=(d,g)=>g>=0&&g<a&&d>=0&&d<o&&r[g][d]==="#";for(let d=-1;d<=a;d++)for(let g=-1;g<=o;g++)u(g,d)?(h.fillStyle=n&&g>=o/2?e:t,h.fillRect((g+1)*l,(d+1)*l,l,l)):(u(g+1,d)||u(g-1,d)||u(g,d+1)||u(g,d-1))&&(h.fillStyle="#111",h.fillRect((g+1)*l,(d+1)*l,l,l));t!==e&&(h.fillStyle="rgba(255,255,255,0.55)",h.fillRect(2*l,2*l,l,l));let f=c.toDataURL();return Yn.set(i,f),f}function Dc(s){let t="egg"+s;if(Yn.has(t))return Yn.get(t);let e=document.createElement("canvas");e.width=24,e.height=28;let n=e.getContext("2d");n.fillStyle="#111",n.beginPath(),n.ellipse(12,15,10,12.5,0,0,Math.PI*2),n.fill(),n.fillStyle=s,n.beginPath(),n.ellipse(12,15,8,10.5,0,0,Math.PI*2),n.fill(),n.fillStyle="rgba(255,255,255,0.5)",n.beginPath(),n.ellipse(9,10,2.2,3.4,-.4,0,Math.PI*2),n.fill();let i=e.toDataURL();return Yn.set(t,i),i}var yr=s=>String(s).replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t]),Uc=s=>(s=Math.max(0,Math.ceil(s)),`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`),ox=s=>J("team_"+s),ax={meadow:"Meadow Isles",dunes:"Sun Dunes",dusk:"Dusk Peaks",frost:"Frostbite",ember:"Ember Rock"},gd={wool:"wool",chain_set:"chainSet",iron_set:"ironSet",diamond_set:"diamondSet"},lx=[["blocks","cBlocks"],["combat","cCombat"],["armor","cArmor"],["tools","cTools"],["utility","cUtility"]],Ya=class{constructor(t,e){this.root=t,this.app=e,t.innerHTML='<div id="screen"></div><div id="hud" class="off"></div><div id="panel" class="off"></div><div id="toasts"></div><div id="fade"></div>',this.screenEl=t.querySelector("#screen"),this.hudEl=t.querySelector("#hud"),this.panelEl=t.querySelector("#panel"),this.toastEl=t.querySelector("#toasts"),this.sig={},this.screen=null,this.shopCat="blocks",t.addEventListener("click",n=>{let i=n.target.closest("[data-act]");!i||i.disabled||(n.preventDefault(),this.app.act(i.dataset.act,i.dataset))}),t.addEventListener("pointerover",n=>{let i=n.target.closest("button");i&&i!==this.lastHover&&(this.lastHover=i,this.app.audio.hover())}),t.addEventListener("input",n=>{let i=n.target;i.dataset.set&&this.app.setSetting(i.dataset.set,i.type==="range"?+i.value:i.value)}),t.addEventListener("change",n=>{let i=n.target;i.dataset.set&&i.tagName==="SELECT"&&this.app.setSetting(i.dataset.set,i.value)})}show(t,e){this.screen=t,this.screenEl.className=t?"on scr-"+t:"",this.screenEl.innerHTML=t?e:""}coinsHtml(t){return`<span class="coins"><i class="coin"></i>${t}</span>`}profileHtml(){let t=this.app.save.data,e=Math.min(100,t.xp/Ga(t.level)*100);return`<div class="topbar"><div class="profile"><img class="pix" src="${$a(As[t.skin].seed)}"><div><b>${J("level",{n:t.level})}</b><div class="xpbar"><i style="width:${e}%"></i></div></div></div>${this.coinsHtml(t.coins)}</div>`}menu(){this.show("menu",`${this.profileHtml()}
      <div class="logo"><span>VOXEL</span><span>ISLES</span></div>
      <div class="menu-btns">
        <button class="btn big green" data-act="modes">${J("play")}</button>
        <div class="row"><button class="btn" data-act="skins">${J("skins")}</button><button class="btn" data-act="settings">${J("settings")}</button><button class="btn" data-act="howto">${J("howto")}</button></div>
      </div>`)}modes(){let t=(n,i,r)=>`<button class="card c-${n}" data-act="mode" data-mode="${n}"><div class="art"><img class="pix" src="${i}"></div><h2>${J(n)}</h2><div class="tag">${J(r)}</div><p>${J(n+"Desc")}</p></button>`,e=(n,i)=>`<div class="card soon"><div class="art"><img class="pix" src="${i}"></div><h2>${J(n)}</h2><div class="tag">${J("soon")}</div><p>${J(n+"Desc")}</p></div>`;this.show("modes",`${this.profileHtml()}<h1>${J("chooseGame")}</h1>
      <div class="cards">${t("sky",Fe(1),"solo8")}${t("egg",Dc(_e[1].hex),"teams4x2")}${e("race",Fe(14))}${e("spleef",Fe(10))}</div>
      <button class="btn back" data-act="menu">${J("back")}</button>`)}lobby(t){let e=t.mode,n=e.id==="egg";this.show("lobby",`<div class="lpanel"><h1>${J(e.id)}</h1><div class="mapname">${ax[t.map.id]||""}</div>
      <div class="status"></div><div class="slots ${n?"teams":""}"></div>
      <button class="btn small" data-act="cancelLobby">${J("cancel")}</button></div>`),this.sig.lobby="",this.updateLobby(t)}updateLobby(t){if(this.screen!=="lobby")return;let e=t.state+t.slots.length+(t.state==="countdown"?Math.ceil(t.cd):"");if(e===this.sig.lobby)return;this.sig.lobby=e;let n=this.screenEl.querySelector(".status");n.innerHTML=t.state==="search"?`<span class="spin"></span>${J("finding")} <b>${t.slots.length}/${t.mode.players}</b>`:`<b class="cd">${J("starting",{n:Math.max(1,Math.ceil(t.cd))})}</b>`;let i=[],r=t.mode.id==="egg";for(let a=0;a<t.mode.players;a++){let l=t.slots[a],c=r?Math.floor(a/2):-1,h=c>=0?_e[c].hex:"";i.push(l?`<div class="slot ${l.bot?"":"me"} pop" style="${h?`--tc:${h}`:""}"><img class="pix" src="${$a(l.skinSeed??l.skin,c)}"><span>${yr(l.name)}</span></div>`:`<div class="slot empty" style="${h?`--tc:${h}`:""}"><i></i><span>\u2026</span></div>`)}let o=this.screenEl.querySelector(".slots");o.innerHTML=r?[0,1,2,3].map(a=>`<div class="tcol" style="--tc:${_e[a].hex}"><div class="tname">${ox(a)}</div>${i[a*2]}${i[a*2+1]}</div>`).join(""):i.join("")}results(t){let e=t.canDouble&&!t.doubled;this.show("results",`<div class="rpanel ${t.win?"won":""}">
      <h1>${t.win?J("victory"):J("gameOver")}</h1>
      <div class="sub">${yr(t.sub)}</div>
      <div class="rows"><div><span>${J("kills")}</span><b>${t.kills}</b></div><div><span>${J("reward")}</span><b>${this.coinsHtml("+"+t.coins)}</b></div><div><span>${J("xp")}</span><b>+${t.xp}</b></div></div>
      ${this.profileHtml()}
      <div class="btns">
        <button class="btn green" data-act="again">${J("playAgain")}</button>
        <button class="btn" data-act="modes">${J("changeGame")}</button>
        ${e?`<button class="btn gold" data-act="double"><i class="ad"></i>${J("doubleCoins")}</button>`:""}
        ${t.canSpectate?`<button class="btn" data-act="spectate">${J("spectate")}</button>`:""}
      </div></div>`)}pause(){this.show("pause",`<div class="ppanel"><h1>${J("paused")}</h1>
      <button class="btn green" data-act="resume">${J("resume")}</button>
      <button class="btn" data-act="settings">${J("settings")}</button>
      <button class="btn" data-act="howto">${J("howto")}</button>
      <button class="btn red" data-act="leave">${J("leaveMatch")}</button></div>`)}settings(){let t=this.app.save.settings,e=(i,r,o,a,l,c)=>`<label><span>${J(r)}</span><input type="range" data-set="${i}" min="${o}" max="${a}" step="${l}" value="${t[i]}"><em>${c(t[i])}</em></label>`,n=(i,r,o)=>`<label><span>${J(r)}</span><div class="seg">${o.map(([a,l])=>`<button class="${String(t[i])===String(a)?"on":""}" data-act="set" data-k="${i}" data-v="${a}">${l}</button>`).join("")}</div></label>`;this.show("settings",`<div class="spanel"><h1>${J("settings")}</h1>
      ${e("sens","sens",.2,3,.05,i=>i.toFixed(2))}
      ${e("fov","fov",60,100,1,i=>i)}
      ${e("volume","volume",0,1,.05,i=>Math.round(i*100)+"%")}
      ${e("music","music",0,1,.05,i=>Math.round(i*100)+"%")}
      ${n("quality","quality",[["auto",J("qAuto")],["low",J("qLow")],["high",J("qHigh")]])}
      ${n("invert","invert",[[!1,J("off")],[!0,J("on")]])}
      <label><span>${J("language")}</span><select data-set="lang"><option value="auto" ${t.lang==="auto"?"selected":""}>${J("auto")}</option>${Object.entries(ud).map(([i,r])=>`<option value="${i}" ${t.lang===i?"selected":""}>${r}</option>`).join("")}</select></label>
      <button class="btn" data-act="back">${J("back")}</button></div>`),this.screenEl.querySelectorAll("input[type=range]").forEach(i=>i.addEventListener("input",()=>{let r=i.nextElementSibling,o=i.dataset.set,a=+i.value;r.textContent=o==="sens"?a.toFixed(2):o==="fov"?a:Math.round(a*100)+"%"}))}skins(){let t=this.app.save.data;this.show("skins",`${this.profileHtml()}<h1>${J("skins")}</h1><div class="skingrid">${As.map(e=>{let n=t.owned.includes(e.id),i=t.skin===e.id,r=i?`<button class="btn small on" disabled>${J("equipped")}</button>`:n?`<button class="btn small" data-act="equip" data-id="${e.id}">${J("equip")}</button>`:`<button class="btn small gold" data-act="buySkin" data-id="${e.id}" ${t.coins<e.price?"disabled":""}>${this.coinsHtml(e.price)}</button>`;return`<div class="skin ${i?"eq":""}"><img class="pix" src="${$a(e.seed)}">${r}</div>`}).join("")}</div><button class="btn back" data-act="back">${J("back")}</button>`)}howto(){this.show("howto",`<div class="spanel how"><h1>${J("howto")}</h1>${["h1","h2","h3","h4","h5","h6"].map(t=>`<p>${J(t)}</p>`).join("")}<button class="btn" data-act="back">${J("back")}</button></div>`)}buildHud(t){let e=Array.from({length:9},(n,i)=>`<div class="hs" data-act="sel" data-i="${i}"><img><b></b><em>${i+1}</em></div>`).join("");return this.hudEl.innerHTML=`
      <div class="hurt"></div><div class="xhair"></div>
      <div class="info"></div><div class="eggs"></div><div class="feed"></div>
      <div class="title"><div class="big"></div><div class="sub"></div></div>
      <div class="itemname"></div>
      <div class="bottom"><div class="stats"><div class="armor"></div><div class="hearts"></div></div><div class="hotbar">${e}</div></div>
      <button class="pausebtn" data-act="pause"><i></i><i></i></button>
      <div class="lockhint">${J("clickToPlay")}</div>
      <div class="spec"><span></span><button class="btn small green" data-act="again">${J("playAgain")}</button><button class="btn small" data-act="leave">${J("leave")}</button></div>
      <div class="touch">
        <div class="look-zone"></div>
        <div class="joy-zone"><div class="joy"><div class="knob"></div></div></div>
        <div class="tb tb-attack"><img class="pix" src="${Fe(101)}"></div>
        <div class="tb tb-place"><img class="pix" src="${Fe(5)}"></div>
        <div class="tb tb-jump"><i class="arrow up"></i></div>
        <div class="tb tb-crouch"><i class="arrow down"></i></div>
      </div>`,this.hudEl.classList.toggle("is-touch",!!t),this.h={hurt:this.hudEl.querySelector(".hurt"),info:this.hudEl.querySelector(".info"),eggs:this.hudEl.querySelector(".eggs"),feed:this.hudEl.querySelector(".feed"),big:this.hudEl.querySelector(".title .big"),sub:this.hudEl.querySelector(".title .sub"),title:this.hudEl.querySelector(".title"),itemname:this.hudEl.querySelector(".itemname"),armor:this.hudEl.querySelector(".armor"),hearts:this.hudEl.querySelector(".hearts"),slots:[...this.hudEl.querySelectorAll(".hs")],lock:this.hudEl.querySelector(".lockhint"),spec:this.hudEl.querySelector(".spec"),xhair:this.hudEl.querySelector(".xhair"),place:this.hudEl.querySelector(".tb-place img")},this.sig={},this.hudEl}setTouch(t){this.hudEl.classList.toggle("is-touch",t)}hud(t){this.hudEl.classList.toggle("off",!t)}updateHud(t,e,n){let i=this.h,r=this.sig,o=e.inv,a=o.slots.map(d=>d?d.id+"x"+d.count:"-").join(",")+"|"+e.sel;if(a!==r.hot){let d=r.sel;r.hot=a,r.sel=e.sel,o.slots.forEach((p,S)=>{let y=i.slots[S];y.classList.toggle("on",S===e.sel);let v=y.firstElementChild,T=v.nextElementSibling,E=p?Fe(p.id):"";v.dataset.src!==E&&(v.dataset.src=E,E&&(v.src=E),v.style.visibility=E?"":"hidden"),T.textContent=p&&p.count>1?p.count:""});let g=o.slots[e.sel];(d!==e.sel||(g?g.id:0)!==r.heldId)&&(r.heldId=g?g.id:0,i.itemname.textContent=g?te[g.id].name:"",i.itemname.classList.remove("show"),i.itemname.offsetWidth,g&&i.itemname.classList.add("show"));let x=o.blockSlot(),m=x>=0?o.slots[x].id:5;i.place.dataset.id!==String(m)&&(i.place.dataset.id=m,i.place.src=Fe(m))}let l=Math.max(0,Math.ceil(e.hp)),c=Math.ceil(e.absorb||0);if(r.hp!==l+":"+c){r.hp=l+":"+c;let d="";for(let g=0;g<10;g++){let x=l-g*2;d+=`<img src="${x>=2?ui("heart","#e8322a","#3a1414"):x===1?ui("heart","#e8322a","#3a1414",!0):ui("heart","#3a1414","#3a1414")}">`}for(let g=0;g<Math.ceil(c/2);g++)d+=`<img src="${ui("heart","#f5cf3d","#f5cf3d")}">`;i.hearts.innerHTML=d,i.hearts.classList.toggle("low",l<=6&&l>0)}let h=o.armorPoints();if(r.ap!==h){r.ap=h;let d="";if(h>0)for(let g=0;g<10;g++){let x=h-g*2;d+=`<img src="${x>=2?ui("armor","#dfe6ee","#3a3a44"):x===1?ui("armor","#dfe6ee","#3a3a44",!0):ui("armor","#3a3a44","#3a3a44")}">`}i.armor.innerHTML=d}let u="",f=t.mode.info();if(t.state==="countdown")u="";else if(t.mode.id==="sky")u=`<div><b>${J("alive",{n:f.alive})}</b></div>`,f.refillIn>0&&(u+=`<div>${J("refillIn",{t:Uc(f.refillIn)})}</div>`),u+=f.rising?`<div class="warn">${J("voidRise")}</div>`:f.borderIn>0?`<div>${J("borderIn",{t:Uc(f.borderIn)})}</div>`:`<div class="warn">${J("borderNow")}</div>`;else{f.suddenIn>0&&(u=`<div>${J("suddenIn",{t:Uc(f.suddenIn)})}</div>`);let d=o.count(170)+":"+o.count(171)+":"+o.count(172),[g,x,m]=d.split(":");u+=`<div class="cur"><span><img src="${Fe(170)}">${g}</span><span><img src="${Fe(171)}">${x}</span><span><img src="${Fe(172)}">${m}</span></div>`;let p=f.teams.map(S=>`<div class="eg ${S.out?"out":""} ${S.i===e.team?"mine":""}" style="--tc:${_e[S.i].hex}"><img src="${Dc(_e[S.i].hex)}" class="${S.egg?"":"gone"}"><b>${S.out?"\u2715":S.alive}</b></div>`).join("");p!==r.eggs&&(r.eggs=p,i.eggs.innerHTML=p)}u!==r.info&&(r.info=u,i.info.innerHTML=u)}title(t,e="",n=2.2,i=""){let r=this.h;r.big.textContent=t,r.sub.textContent=e,r.title.className="title show "+i,clearTimeout(this.titleT),n>0&&(this.titleT=setTimeout(()=>{r.title.className="title"},n*1e3))}clearTitle(){clearTimeout(this.titleT),this.h&&(this.h.title.className="title")}feed(t){let e=document.createElement("div");for(e.className="fe",e.innerHTML=t,this.h.feed.appendChild(e);this.h.feed.children.length>5;)this.h.feed.firstChild.remove();setTimeout(()=>{e.classList.add("fade"),setTimeout(()=>e.remove(),500)},5e3)}name(t,e){return`<b style="color:${t.team>=0?_e[t.team].hex:t===e?"#7dff6a":"#fff"}">${yr(t.name)}</b>`}toast(t,e=""){let n=document.createElement("div");for(n.className="toast "+e,n.textContent=t,this.toastEl.appendChild(n);this.toastEl.children.length>3;)this.toastEl.firstChild.remove();setTimeout(()=>{n.classList.add("fade"),setTimeout(()=>n.remove(),400)},2600)}hurtFlash(){let t=this.h.hurt;t.classList.remove("on"),t.offsetWidth,t.classList.add("on")}lockHint(t){this.h&&this.h.lock.classList.toggle("on",t)}spectate(t){this.h&&(this.h.spec.classList.toggle("on",!!t),t&&(this.h.spec.firstElementChild.textContent=J("spectating",{name:t})),this.hudEl.classList.toggle("specmode",!!t))}openPanel(t,e){this.panelEl.className="on "+e,this.panelEl.innerHTML=t,this.panelOpen=e}closePanel(){this.panelEl.className="off",this.panelEl.innerHTML="",this.panelOpen=null}invRow(t){let e=t.inv.slots.map((i,r)=>`<div class="is ${r===t.sel?"on":""}">${i?`<img class="pix" src="${Fe(i.id)}"><b>${i.count>1?i.count:""}</b>`:""}</div>`).join(""),n=t.inv.armor.map(i=>`<div class="is ar">${i?`<img class="pix" src="${Fe(i)}">`:""}</div>`).join("");return`<div class="invrow"><div class="lbl">${J("inventory")}</div><div class="isrow">${e}</div><div class="isrow armor">${n}</div></div>`}chest(t,e){let n=Array.from({length:12},(i,r)=>{let o=t.items[r];return`<div class="is ${o?"has":""}" ${o?`data-act="take" data-i="${r}"`:""} title="${o?yr(te[o.id].name):""}">${o?`<img class="pix" src="${Fe(o.id)}"><b>${o.count>1?o.count:""}</b>`:""}</div>`}).join("");this.openPanel(`<div class="box"><div class="head"><h2>${J("chest")}</h2><button class="x" data-act="closePanel">\u2715</button></div>
      <div class="grid c12">${n}</div>
      <button class="btn green small" data-act="takeAll" ${t.items.length?"":"disabled"}>${J("takeAll")}</button>
      ${this.invRow(e)}</div>`,"chest")}shop(t,e){let n=(r,o)=>`<span class="cost ${t.inv.count(r)>=o?"":"no"}"><img src="${Fe(r)}">${o}</span>`,i=Na.filter(r=>r.cat===this.shopCat).map(r=>{let o=r.give[0][0]==="wool"?_e[t.team].wool:r.give[0][0],a=gd[r.id]?J(gd[r.id]):te[o].name,l=r.give[0][1];return`<button class="offer ${t.inv.count(r.cost[0])>=r.cost[1]?"":"cant"}" data-act="buy" data-id="${r.id}"><img class="pix" src="${Fe(o)}"><span class="nm">${yr(a)}${l>1&&r.cat!=="armor"?` \xD7${l}`:""}</span>${n(r.cost[0],r.cost[1])}</button>`}).join("");this.openPanel(`<div class="box wide"><div class="head"><h2>${J("shop")}</h2><div class="wallet">${n(170,0)}${n(171,0)}${n(172,0)}</div><button class="x" data-act="closePanel">\u2715</button></div>
      <div class="tabs">${lx.map(([r,o])=>`<button class="${r===this.shopCat?"on":""}" data-act="shopCat" data-c="${r}">${J(o)}</button>`).join("")}</div>
      <div class="offers">${i}</div>${this.invRow(t)}</div>`,"shop"),this.panelEl.querySelectorAll(".wallet .cost").forEach((r,o)=>{r.lastChild.textContent=t.inv.count(170+o),r.classList.remove("no")})}};var cx=(s,t,e)=>Math.max(t,Math.min(e,s)),Nc=class{async boot(){await Se.init();try{Se.loadingStart()}catch{}this.save=new Wa(Se),await this.save.load(),this.save.data.name||(this.save.data.name=Pc(),this.save.persist()),await this.applyLang(),this.canvas=document.getElementById("view"),this.R=new Ca(this.canvas),this.atlas=Yc(Zu()),this.R.setAtlas(this.atlas),md(this.atlas),this.view=new Ha(this.R,this.atlas),this.audio=new Ia,this.input=new Ra(this.canvas,document.getElementById("ui")),this.ui=new Ya(document.getElementById("ui"),this),this.input.wireTouch(this.ui.buildHud(this.input.touch)),this.input.onTouch=()=>this.ui.setTouch(!0),this.input.onUnlock=()=>{this.state==="play"&&!this.ui.panelOpen&&!this.spectating&&this.me&&this.me.alive&&this.pause()};let t=()=>{this.audio.unlock(),!this.audio.musicOn&&this.save.settings.music>0&&this.audio.startMusic("calm")};for(let e of["pointerdown","keydown","touchstart"])addEventListener(e,t,{capture:!0,passive:!0});this.audio.setVolume(this.save.settings.volume,this.save.settings.music);try{this.audio.setMuted(!Se.isAudioEnabled()),Se.onAudioEnabledChange(e=>this.audio.setMuted(!e))}catch{}Se.onPause(()=>{this.hidden=!0,this.state==="play"&&!this.spectating&&this.pause(),this.audio.suspend(!0)}),Se.onResume(()=>{this.hidden=!1,this.audio.suspend(!1)}),this.pc={mx:0,mz:0,yaw:0,pitch:0,jump:!1,crouch:!1,sprint:!1,attack:!1,attackPressed:!1,use:!1,useHeld:!1,sel:null},this.menuMap=bc(7,"meadow"),this.pixel=1,this.ft=[],this.camEye=1.62,this.fov=75,this.orbit=0,this.useT=0,this.lastW=-1,addEventListener("resize",()=>this.resize()),this.applyQuality(),this.toMenu(),this.last=performance.now(),requestAnimationFrame(e=>this.frame(e)),window.__vi=this}async applyLang(){let t=this.save.settings.lang,e=t;if(t==="auto")try{e=await Se.getLanguage()}catch{e="en"}this.lang=fd(String(e||"en").slice(0,2).toLowerCase()),document.documentElement.lang=this.lang}resize(){let t=innerWidth,e=innerHeight;this.R.resize(t,e,this.pixel),this.view.vmCam.aspect=t/e,this.view.vmCam.updateProjectionMatrix()}applyQuality(){let t=this.save.settings.quality,e=devicePixelRatio||1;this.maxPixel=t==="low"?Math.min(e,.75):t==="high"?Math.min(e,2):Math.min(e,this.input.touch?1.25:1.5),this.pixel=this.maxPixel,this.resize()}adapt(t){if(this.save.settings.quality!=="auto"||this.hidden||(this.ft.push(t),this.ft.length<90))return;let e=this.ft.reduce((n,i)=>n+i,0)/this.ft.length;this.ft.length=0,e>.024&&this.pixel>.6?(this.pixel=Math.max(.6,this.pixel*.85),this.resize()):e<.0135&&this.pixel<this.maxPixel&&(this.pixel=Math.min(this.maxPixel,this.pixel*1.1),this.resize())}setScene(t,e){this.R.setTheme(e),this.R.setWorld(t.world),this.bgMap=t}toMenu(t="menu"){this.endMatch(),this.state="menu",this.lobby=null,this.ui.hud(!1),this.ui.closePanel(),this.bgMap!==this.menuMap&&this.setScene(this.menuMap,"meadow"),this.screens=[],t==="modes"?this.ui.modes():this.ui.menu()}endMatch(){if(this.m)try{Se.gameplayStop()}catch{}this.m=null,this.me=null,this.spectating=null,this.ui.spectate(null),this.view.clear(),this.R.outline.visible=!1,this.R.setCrack(0,0,0,-1),this.input.enable(!1),this.input.exitLock(),this.ui.clearTitle()}startLobby(t,e){this.endMatch(),this.lastMode=t;let n=this.save.data;this.lobby=new Va(t,{name:n.name,bot:!1,skin:As[n.skin].seed},e),this.state="lobby",this.ui.hud(!1),this.ui.lobby(this.lobby);let i=this.lobby;setTimeout(()=>{if(this.lobby!==i)return;let r=i.map;i.built=i.mode.id==="sky"?bc(r.seed,r.theme):Ku(r.seed,r.theme),this.setScene(i.built,r.sky||r.theme)},40)}startMatch(){let t=this.lobby,e=t.mode.id==="sky"?new Ua:new Fa,n=new La(t.built,e,{seed:Math.random()*1e9|0,countdown:5}),i=t.slots.map((o,a)=>{let l=n.add(new ka({name:o.name,bot:o.bot,skin:o.skin,team:t.mode.teams?Math.floor(a/2):-1,local:!o.bot}));return o.bot&&new Oa(l,n,o.skill),l}),r=i[0];r.autoSwing=!0,r.ctl=()=>this.pc,e.setup(i),this.m=n,this.me=r,this.lobby=null,this.awarded=!1,this.myEggs=0,this.lastCd=-1,this.resultT=0,this.pc.yaw=r.yaw,this.pc.pitch=r.pitch,this.view.setMatch(n,r),this.state="play",this.ui.show(null),this.ui.hud(!0),this.ui.sig={},this.input.enable(!0),this.input.requestLock(),n.mode.id==="egg"&&this.ui.title(J("yourTeam",{team:J("team_"+r.team)}),"",3,"team"),this.audio.setMusicStyle("calm");try{Se.gameplayStart()}catch{}}pause(){if(this.state==="play"){this.state="paused",this.input.enable(!1),this.input.exitLock(),this.ui.closePanel(),this.ui.pause();try{Se.gameplayStop()}catch{}}}resume(){if(this.state==="paused"){this.state="play",this.ui.show(null),this.input.enable(!0),this.input.requestLock();try{Se.gameplayStart()}catch{}}}async ad(t){this.input.enable(!1),this.audio.suspend(!0);let e=!1;try{e=t==="reward"?await Se.ads.rewarded():await Se.ads.midgame()}catch{}return this.hidden||this.audio.suspend(!1),e}async act(t,e){switch(this.audio.unlock(),this.audio.click(),t){case"menu":this.ui.menu();break;case"modes":this.state==="results"&&(this.state="busy",await this.ad("mid")),this.toMenu("modes");break;case"mode":this.startLobby(e.mode);break;case"cancelLobby":this.lobby=null,this.toMenu("modes");break;case"skins":case"settings":case"howto":this.screens.push(this.ui.screen),this.ui[t]();break;case"back":{let n=this.screens.pop();this.state==="paused"?this.ui.pause():n==="modes"?this.ui.modes():this.ui.menu();break}case"set":this.setSetting(e.k,e.v==="true"?!0:e.v==="false"?!1:e.v),this.ui.settings();break;case"equip":this.save.data.skin=+e.id,this.save.persist(),this.ui.skins();break;case"buySkin":{let n=As[+e.id],i=this.save.data;i.coins>=n.price&&!i.owned.includes(n.id)&&(i.coins-=n.price,i.owned.push(n.id),i.skin=n.id,this.save.persist(),this.audio.levelUp()),this.ui.skins();break}case"again":if(this.state==="busy")break;this.state="busy",await this.ad("mid"),this.startLobby(this.lastMode);break;case"double":{await this.ad("reward")&&this.lastResult&&!this.lastResult.doubled&&(this.lastResult.doubled=!0,this.save.data.coins+=this.lastResult.coins,this.lastResult.coins*=2,this.save.persist(),this.audio.levelUp()),this.state==="results"&&this.ui.results(this.lastResult);break}case"spectate":this.startSpectate();break;case"pause":this.state==="play"&&!this.spectating&&this.pause();break;case"resume":this.resume();break;case"leave":this.toMenu();break;case"sel":this.me&&(this.me.sel=+e.i,this.me.mine=null);break;case"closePanel":this.closePanel();break;case"take":this.chest&&this.m.takeFromChest(this.me,this.chest,+e.i)&&this.ui.chest(this.chest,this.me);break;case"takeAll":this.chest&&(this.m.takeAll(this.me,this.chest),this.ui.chest(this.chest,this.me));break;case"shopCat":this.ui.shopCat=e.c,this.ui.shop(this.me,this.m.mode);break;case"buy":this.m&&this.m.mode.buy(this.me,e.id)?(this.audio.pickup(),this.ui.shop(this.me,this.m.mode)):(this.audio.beep(!1),this.ui.toast(J("notEnough"),"bad"));break}}setSetting(t,e){let n=this.save.settings;n[t]=e,(t==="volume"||t==="music")&&(this.audio.setVolume(n.volume,n.music),t==="music"&&e>0&&this.audio.ctx&&!this.audio.musicOn&&this.audio.startMusic("calm"),t==="music"&&e===0&&this.audio.stopMusic()),t==="quality"&&this.applyQuality(),t==="lang"&&this.applyLang().then(()=>{this.ui.settings(),this.relabel()}),this.save.persist()}relabel(){let t=this.ui.h;t.lock.textContent=J("clickToPlay");let e=t.spec.querySelectorAll("button");e[0].textContent=J("playAgain"),e[1].textContent=J("leave")}openChest(t){this.chest=t,this.ui.chest(t,this.me),this.input.enable(!1),this.input.exitLock()}openShop(){this.ui.shop(this.me,this.m.mode),this.input.enable(!1),this.input.exitLock()}closePanel(){this.ui.panelOpen&&(this.ui.closePanel(),this.chest=null,this.state==="play"&&(this.input.enable(!0),this.input.requestLock()))}updatePlayer(t,e){let n=this.me,i=this.pc,r=this.save.settings;if(i.mx=i.mz=0,i.jump=i.crouch=i.sprint=i.attack=i.attackPressed=i.use=i.useHeld=!1,i.sel=null,!n.alive||this.ui.panelOpen)return;let o=.0022*r.sens;n.yaw-=e.lookX*o,n.pitch=cx(n.pitch-e.lookY*o*(r.invert?-1:1),-1.55,1.55),i.yaw=n.yaw,i.pitch=n.pitch,e.sel!=null&&(n.sel=e.sel,n.mine=null),e.wheel&&(n.sel=((n.sel+e.wheel)%9+9)%9,n.mine=null);let a=performance.now()/1e3;e.pressed.has("KeyW")&&(a-this.lastW<.3&&(this.sprintLatch=!0),this.lastW=a),e.my<=.1&&(this.sprintLatch=!1);let l=Math.sin(n.yaw),c=Math.cos(n.yaw);i.mx=-l*e.my+c*e.mx,i.mz=-c*e.my-l*e.mx,i.jump=e.jump,i.crouch=e.crouch,i.sprint=(e.sprint||this.sprintLatch)&&e.my>.1,i.attack=e.attack,i.attackPressed=e.attackPressed,i.use=e.use,i.useHeld=e.useHeld;let h=n.held();e.useHeld&&h&&h.kind==="block"?(this.useT+=t,this.useT>.24&&(this.useT=0,i.use=!0)):this.useT=0,e.use&&(this.useT=0)}startSpectate(){this.m&&(this.state="play",this.ui.show(null),this.ui.hud(!0),this.pickSpecTarget(),this.input.enable(!1),this.input.exitLock())}pickSpecTarget(){let t=this.m.actors.filter(e=>e.alive&&e!==this.me);this.spectating=t.sort((e,n)=>n.kills-e.kills)[0]||null,this.view.thirdPerson=!1,this.ui.spectate(this.spectating?this.spectating.name:null)}showResults(){let t=this.m,e=this.me;if(!t)return;let n=t.mode.id==="egg";if(!this.awarded){this.awarded=!0;let r=t.over&&(n?t.winner===e.team:t.winner===e),o=n?t.mode.teams.length:t.actors.length,a=r?1:e.rank||(n?t.mode.teams.filter(f=>!f.out).length:t.actors.filter(f=>f.alive).length+1),l=10+e.kills*5+this.myEggs*15+(r?50:a<=3?15:0),c=25+e.kills*15+this.myEggs*20+(r?60:0),h=this.save.data;h.coins+=l,h.stats.games++,h.stats.kills+=e.kills,h.stats.deaths+=e.deaths,h.stats.eggs+=this.myEggs,r&&h.stats.wins++;let u=this.save.addXp(c);if(this.save.persist(),u&&(this.audio.levelUp(),this.ui.toast(J("levelUp"),"gold")),r)try{Se.happytime()}catch{}this.lastResult={win:r,coins:l,xp:c,kills:e.kills,sub:r?n?J("teamWins",{team:J("team_"+e.team)}):J("placeOf",{n:1,m:o}):J("placeOf",{n:a,m:o})}}let i=this.lastResult;i.canDouble=(()=>{try{return Se.ads.canReward()}catch{return!1}})(),i.canSpectate=!t.over&&t.actors.some(r=>r.alive&&r!==e),this.state="results",this.spectating=null,this.ui.spectate(null),this.ui.closePanel(),this.ui.hud(!1),this.ui.clearTitle(),this.input.enable(!1),this.input.exitLock(),this.ui.results(i);try{Se.gameplayStop()}catch{}}events(){let t=this.m,e=this.me,n=this.audio,i=this.view,r=this.ui,o=a=>a&&a.pos;for(let a of t.events)switch(a.t){case"swing":a.a!==e&&n.swing(o(a.a));break;case"dig":n.block(Zt[a.id].sound,"dig",{x:a.x+.5,y:a.y+.5,z:a.z+.5});break;case"break":n.block(Zt[a.id].sound,"break",{x:a.x+.5,y:a.y+.5,z:a.z+.5}),i.burst(a.x,a.y,a.z,a.id);break;case"place":n.block(Zt[a.id].sound,"place",{x:a.x+.5,y:a.y+.5,z:a.z+.5});break;case"hurt":a.a===e?(n.hurt(!0),r.hurtFlash(),this.shake=.25):(n.hit(o(a.a),a.crit),a.crit&&i.sparks(a.a.pos.x,a.a.pos.y+1.4,a.a.pos.z,16773280,10),a.by===e&&(this.hitmark=.15));break;case"kill":{let l=a.a,c=a.by,h=a.cause==="void"?"fell":a.cause==="border"?"border":"diedMsg";r.feed(c?`${r.name(c,e)} <img class="pix" src="${Fe(101)}"> ${r.name(l,e)}${a.cause==="void"?' <span class="void">\u25BC</span>':""}`:`${r.name(l,e)} <span>${J(h)}</span>`),c===e&&(n.kill(),r.toast(J("kill1"),"kill")),l===e?(n.death(),this.deathT=0,this.deathYaw=e.yaw):Math.hypot(l.pos.x-e.pos.x,l.pos.z-e.pos.z)<30&&n.hurt(!1),l===this.spectating&&setTimeout(()=>this.spectating&&!this.spectating.alive&&this.pickSpecTarget(),1200);break}case"eat":a.a===e&&n.eat();break;case"chest":a.a===e&&this.openChest(a.chest);break;case"npc":a.a===e&&this.openShop();break;case"throw":n.throwS();break;case"warp":n.warp();break;case"pickup":a.a===e&&n.pickup();break;case"refill":r.toast(J("refilled"),"gold"),n.beep(!0);break;case"border":r.toast(J("borderMsg"),"bad"),n.beep(!1),n.setMusicStyle("tense");break;case"egg":{n.egg(t.mode.teams[a.team].egg),a.by===e&&this.myEggs++,a.team===e.team?r.title(J("yourEgg"),J("noRespawn"),3.5,"bad"):r.toast(J("eggGone",{team:J("team_"+a.team)}),"bad");break}case"voidrise":r.toast(J("voidRise"),"bad"),n.beep(!1);break;case"sudden":r.toast(J("sudden"),"bad"),n.setMusicStyle("tense");break;case"teamout":r.feed(`<b style="color:${_e[a.team].hex}">${J("teamOut",{team:J("team_"+a.team)})}</b>`);break;case"respawning":a.a===e&&r.title(J("died"),J("respawnIn",{n:5}),0,"bad");break;case"respawn":a.a===e&&(r.clearTitle(),e.pitch=-.1);break;case"start":r.title(J("go"),"",1.2,"go"),n.beep(!0);break;case"over":{let l=t.mode.id==="egg",c=l?a.winner===e.team:a.winner===e;c&&n.win();let h=c?J("victory"):l?a.winner!=null?J("teamWins",{team:J("team_"+a.winner)}):J("gameOver"):a.winner?J("winnerIs",{name:a.winner.name}):J("gameOver");this.state==="play"&&r.title(h,"",3,c?"go":""),this.resultT=3;break}}t.events.length=0}steps(){let t=this.m;for(let e of t.actors){if(!e.alive||!e.onGround||e.moveAmt<1||e.crouch)continue;let n=Math.floor(e.walkPhase/Math.PI);if(e._st===n)continue;e._st=n;let i=t.world.get(Math.floor(e.pos.x),Math.floor(e.pos.y-.1),Math.floor(e.pos.z));i&&Zt[i]&&this.audio.block(Zt[i].sound,"step",e.pos)}}camera(t,e){let n=this.R.camera,i=this.save.settings,r=i.fov;if(this.m&&this.me&&this.state!=="lobby"){let o=this.me,a=this.m,l=this.spectating;if(l&&l.alive){let c=l.yaw,h=l.pos.x,u=l.pos.y+1.6,f=l.pos.z,d=Math.sin(c)*4.2,g=1.4,x=Math.cos(c)*4.2,m=Math.hypot(d,g,x),p=a.world.raycast(h,u,f,d/m,g/m,x/m,m,C=>C&&Zt[C].solid),S=p?Math.max(.15,(p.t-.3)/m):1,y=h+d*S,v=u+g*S,T=f+x*S,E=p?1:Math.min(1,t*5);n.position.x+=(y-n.position.x)*E,n.position.y+=(v-n.position.y)*E,n.position.z+=(T-n.position.z)*E,n.lookAt(l.pos.x,l.pos.y+1.4,l.pos.z)}else if(o.alive||this.deathT<.01){this.camEye+=(qn(o)-this.camEye)*Math.min(1,t*14);let c=0;i.viewBob&&o.onGround&&(c=Math.abs(Math.sin(o.walkPhase))*.045*Math.min(1,o.moveAmt/4.3)),n.position.set(o.pos.x,o.pos.y+this.camEye+c,o.pos.z),this.shake=Math.max(0,(this.shake||0)-t),n.rotation.set(o.pitch,o.yaw,this.shake*Math.sin(a.time*60)*.06,"YXZ"),o.sprint&&o.moveAmt>4.5&&(r+=8)}else this.deathT+=t,n.position.y+=(o.pos.y+.4-n.position.y)*Math.min(1,t*3),n.rotation.set(Math.min(-.2,-this.deathT*.3),this.deathYaw,Math.min(.5,this.deathT),"YXZ")}else{let o=this.bgMap||this.menuMap;this.orbit+=t*.05;let a=o===this.menuMap?74:80;n.position.set(Math.cos(this.orbit)*a,o.top+26,Math.sin(this.orbit)*a),n.lookAt(0,o.top-2,0)}this.fov+=(r-this.fov)*Math.min(1,t*8),Math.abs(n.fov-this.fov)>.05&&(n.fov=this.fov,n.updateProjectionMatrix())}overlays(){let t=this.R,e=this.me,n=this.m,i=!1;if(n&&e&&e.alive&&!this.spectating&&this.state==="play"&&!this.ui.panelOpen){let r=n.lookHit(e);r&&!n.lookActor(e)&&(i=!0,t.outline.position.set(r.x+.5,r.y+.5,r.z+.5),e.mine&&e.mine.x===r.x&&e.mine.y===r.y&&e.mine.z===r.z?t.setCrack(r.x,r.y,r.z,Math.floor(e.mine.p/e.mine.need*4)):t.setCrack(0,0,0,-1))}t.outline.visible=i,i||t.setCrack(0,0,0,-1)}frame(t){requestAnimationFrame(o=>this.frame(o));let e=Math.min(.05,(t-this.last)/1e3);this.last=t;let n=this.input.sample(),i=this.m,r=this.me;if(this.lobby&&this.state==="lobby"){if(this.lobby.update(e),this.ui.updateLobby(this.lobby),this.lobby.state==="countdown"&&this.lobby.built){let o=Math.ceil(this.lobby.cd);o!==this.lobbyBeep&&(this.lobbyBeep=o,this.audio.beep(!1))}this.lobby.state==="go"&&this.lobby.built&&this.startMatch()}if(i&&(this.state==="play"||this.state==="results"||this.state==="busy")){if(this.state==="play"&&!this.spectating?(this.updatePlayer(e,n),this.ui.panelOpen&&(n.pressed.has("Escape")||n.pressed.has("KeyE"))&&this.closePanel(),this.ui.panelOpen&&(!r.alive||this.chest&&Math.hypot(this.chest.x+.5-r.pos.x,this.chest.z+.5-r.pos.z)>6)&&this.closePanel()):this.updatePlayer(e,{lookX:0,lookY:0,mx:0,my:0,pressed:new Set}),this.state==="play"&&n.pressed.has("Escape")&&!this.input.locked&&!this.ui.panelOpen&&r.alive&&this.pause(),i.update(e),i.state==="countdown"){let o=Math.ceil(i.countdown);o!==this.lastCd&&o>0&&(this.lastCd=o,this.audio.beep(!1),this.state==="play"&&this.ui.title(String(o),"",.9,"count"))}if(this.events(),this.steps(),!r.alive&&r.respawnT>0&&this.state==="play"){let o=Math.ceil(r.respawnT);o!==this.respN&&(this.respN=o,this.ui.title(J("died"),J("respawnIn",{n:o}),0,"bad"))}!r.alive&&r.eliminated&&!this.awarded&&this.state==="play"&&(this.elimT=(this.elimT||0)+e,this.elimT>2&&(this.elimT=0,this.showResults())),i.over&&this.resultT>0&&(this.resultT-=e,this.resultT<=0&&this.state==="play"&&this.showResults())}if(this.camera(e,n),this.audio.listener=this.R.camera.position,i&&r&&(this.view.update(e,this.R.camera),this.overlays(),this.state==="play")){this.ui.updateHud(i,r,this.view);let o=!this.input.touch&&!this.input.locked&&!this.ui.panelOpen&&!this.spectating&&r.alive;this.ui.lockHint(o),this.hitmark>0&&(this.hitmark-=e,this.ui.h.xhair.classList.toggle("hit",this.hitmark>0))}if(this.R.flush(this.state==="play"?4:16),this.R.render(e),i&&r&&r.alive&&!this.spectating&&this.state==="play"){this.view.updateViewmodel(e,r,n);let o=this.R.renderer;o.autoClear=!1,o.clearDepth(),o.render(this.view.vmScene,this.view.vmCam),o.autoClear=!0}if(this.adapt(e),!this.firstFramed){this.firstFramed=!0;try{Se.firstFrame(),Se.gameReady()}catch{}}}};new Nc().boot();})();
