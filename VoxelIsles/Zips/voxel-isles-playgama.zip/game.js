(()=>{var yf=Object.defineProperty;var _f=(s,t,e)=>t in s?yf(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var Yr=(s,t,e)=>_f(s,typeof t!="symbol"?t+"":t,e);var on=(s,t)=>{try{return s()}catch{return t}},Mf=s=>new Promise(t=>setTimeout(t,s)),Zr="voxelisles.save",Se=null,Xn=!1,Jr=!1,jr=!1,bh=0,Kr=!0,Sh=[],wh=[],Th=[],Pl=s=>{Xn&&on(()=>Se.platform.sendMessage(s).catch(()=>{}))},Te={async init(){if(Se=window.bridge,!!Se){try{await Promise.race([Se.initialize(),Mf(8e3).then(()=>{throw new Error("bridge timeout")})]),Xn=!0}catch{Xn=!1;return}Kr=on(()=>Se.platform.isAudioEnabled!==!1,!0),on(()=>Se.platform.on(Se.EVENT_NAME.AUDIO_STATE_CHANGED,s=>{Kr=!!s;for(let t of Sh)t(Kr)})),on(()=>Se.platform.on(Se.EVENT_NAME.PAUSE_STATE_CHANGED,s=>{for(let t of s?wh:Th)t()}))}},get sdkReady(){return Xn},loadingStart(){},firstFrame(){},gameReady(){Pl("game_ready")},gameplayStart(){Jr||(Jr=!0,Pl("gameplay_started"))},gameplayStop(){Jr&&(Jr=!1,Pl("gameplay_stopped"))},happytime(){},async getLanguage(){let s=Xn&&on(()=>Se.platform.language,"")||navigator.language||"en";return String(s).toLowerCase().slice(0,2)},isAudioEnabled(){return Kr},onAudioEnabledChange(s){Sh.push(s)},onPause(s){wh.push(s),document.addEventListener("visibilitychange",()=>document.hidden&&s())},onResume(s){Th.push(s),document.addEventListener("visibilitychange",()=>!document.hidden&&s())},async loadData(){if(Xn){let s=await Promise.resolve(on(()=>Se.storage.get(Zr,!1),null)).catch(()=>null);if(s!=null&&s!=="")return String(s)}return on(()=>localStorage.getItem(Zr)||"","")},async saveData(s){on(()=>localStorage.setItem(Zr,s)),Xn&&await Promise.resolve(on(()=>Se.storage.set(Zr,s),null)).catch(()=>{})},ads:{canReward(){return Xn&&!jr&&performance.now()>bh&&on(()=>Se.advertisement.isRewardedSupported,!1)},request(s){let t=s==="rewarded";return!Xn||jr||!on(()=>t?Se.advertisement.isRewardedSupported:Se.advertisement.isInterstitialSupported,!1)?Promise.resolve(!1):(jr=!0,new Promise(e=>{let n=!1,i=!1,r=!1,o=t?Se.EVENT_NAME.REWARDED_STATE_CHANGED:Se.EVENT_NAME.INTERSTITIAL_STATE_CHANGED,a=h=>{i||(i=!0,jr=!1,on(()=>Se.advertisement.off(o,l)),!h&&t&&(bh=performance.now()+12e4),e(h))},l=h=>{h==="opened"?n=!0:h==="rewarded"?r=!0:h==="closed"?a(t?r:!0):h==="failed"&&a(!1)};on(()=>(Se.advertisement.on(o,l),t?Se.advertisement.showRewarded():Se.advertisement.showInterstitial(),!0),!1)||a(!1),setTimeout(()=>{n||a(!1)},3e4)}))},midgame(){return this.request("interstitial").then(()=>{})},rewarded(){return this.request("rewarded")}}};var Gt=[{id:"red",name:"Red",hex:"#e2453c",wool:30},{id:"blue",name:"Blue",hex:"#3c6ee2",wool:31},{id:"green",name:"Green",hex:"#4fbf3a",wool:32},{id:"yellow",name:"Yellow",hex:"#f2cc2e",wool:33},{id:"purple",name:"Purple",hex:"#9b4fd8",wool:34},{id:"orange",name:"Orange",hex:"#f08a2a",wool:35},{id:"cyan",name:"Cyan",hex:"#2fc3c9",wool:36},{id:"pink",name:"Pink",hex:"#ef7fb8",wool:37}],as=[],St=(s,t,e,n={})=>{let i=typeof e=="string"?{top:e,side:e,bottom:e}:e;as[s]={id:s,name:t,tex:i,solid:n.solid!==!1,transparent:!!n.transparent,cross:!!n.cross,hardness:n.hardness??1,tool:n.tool||"pick",unbreakable:!!n.unbreakable,light:n.light||0,sound:n.sound||"stone",color:n.color||"#888",invisible:!!n.invisible,box:n.box||null,pick:!!(n.pick||n.cross),trans:!!n.trans,bounce:n.bounce||0}},Eh=[1/16,0,1/16,15/16,1/16,15/16],bf=[5/16,0,5/16,11/16,3/16,11/16];St(1,"Grass",{top:"grass_top",side:"grass_side",bottom:"dirt"},{hardness:.6,tool:"shovel",sound:"grass",color:"#5fa83a"});St(2,"Dirt","dirt",{hardness:.5,tool:"shovel",sound:"gravel",color:"#8a5a36"});St(3,"Stone","stone",{hardness:1.5,sound:"stone",color:"#8c8c8c"});St(4,"Cobblestone","cobble",{hardness:2,sound:"stone",color:"#7a7a7a"});St(5,"Planks","planks",{hardness:1.2,tool:"axe",sound:"wood",color:"#b4874c"});St(6,"Log",{top:"log_top",side:"log_side",bottom:"log_top"},{hardness:1.6,tool:"axe",sound:"wood",color:"#6b4a2b"});St(7,"Leaves","leaves",{hardness:.2,transparent:!0,tool:"none",sound:"grass",color:"#3f8f2a"});St(8,"Sand","sand",{hardness:.5,tool:"shovel",sound:"sand",color:"#e3d394"});St(9,"Sandstone",{top:"sandstone_top",side:"sandstone_side",bottom:"sandstone_top"},{hardness:.9,sound:"stone",color:"#d8c47e"});St(10,"Snow",{top:"snow",side:"snow_side",bottom:"dirt"},{hardness:.4,tool:"shovel",sound:"snow",color:"#f2f6fa"});St(11,"Ice","ice",{hardness:.5,transparent:!0,sound:"glass",color:"#a9d4f5"});St(12,"Glass","glass",{hardness:.3,transparent:!0,tool:"none",sound:"glass",color:"#cfe8f2"});St(13,"Obsidian","obsidian",{hardness:12,sound:"stone",color:"#231a33"});St(14,"Gold Block","gold_block",{hardness:3,sound:"metal",color:"#f5cf3d"});St(15,"Iron Block","iron_block",{hardness:3,sound:"metal",color:"#d8d8d8"});St(16,"Diamond Block","diamond_block",{hardness:3,sound:"metal",color:"#5fe0d8"});St(17,"Chest",{top:"chest_top",side:"chest_side",bottom:"chest_top"},{hardness:1.5,tool:"axe",sound:"wood",unbreakable:!0,color:"#9a6a32"});St(18,"Basalt",{top:"basalt_top",side:"basalt_side",bottom:"basalt_top"},{hardness:1.4,sound:"stone",color:"#3e3c42"});St(19,"Magma","magma",{hardness:1,sound:"stone",light:1,color:"#c8501e"});St(20,"Moonstone","moonstone",{hardness:2,sound:"stone",color:"#efe9b8"});St(21,"Bricks","bricks",{hardness:2,sound:"stone",color:"#a1503a"});St(22,"Terracotta","terracotta",{hardness:1.3,sound:"stone",color:"#b06a48"});St(23,"Core","core",{unbreakable:!0,sound:"stone",color:"#2a2a30"});St(24,"Iron Ore","iron_ore",{unbreakable:!0,sound:"stone",color:"#9a8a80"});St(25,"Gold Ore","gold_ore",{unbreakable:!0,sound:"stone",color:"#a69a60"});St(26,"Diamond Ore","diamond_ore",{unbreakable:!0,sound:"stone",color:"#7fa6a8"});St(27,"Lantern","lantern",{hardness:.5,sound:"metal",light:1,color:"#ffd27a"});St(28,"Mossy Stone","mossy",{hardness:1.5,sound:"stone",color:"#6f8a5a"});St(29,"Pumpkin",{top:"pumpkin_top",side:"pumpkin_side",bottom:"pumpkin_top"},{hardness:1,tool:"axe",sound:"wood",color:"#e08a1e"});for(let s of Gt)St(s.wool,`${s.name} Wool`,`wool_${s.id}`,{hardness:.35,tool:"shears",sound:"cloth",color:s.hex});St(38,"White Wool","wool_white",{hardness:.35,tool:"shears",sound:"cloth",color:"#eeeeee"});St(40,"Tall Grass","tallgrass",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#6bbf3a"});St(41,"Red Flower","flower_red",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#e23c3c"});St(42,"Yellow Flower","flower_yellow",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#f2d22e"});St(43,"Dead Bush","deadbush",{solid:!1,cross:!0,hardness:0,tool:"none",sound:"grass",transparent:!0,color:"#8a6a3a"});St(44,"Cactus",{top:"cactus_top",side:"cactus_side",bottom:"cactus_top"},{hardness:.4,tool:"none",sound:"cloth",color:"#4f8a2a"});St(45,"Egg","core",{invisible:!0,transparent:!0,hardness:1.2,tool:"none",sound:"egg",color:"#c86ae0"});St(46,"Barrier","glass",{invisible:!0,transparent:!0,unbreakable:!0,sound:"glass",color:"#ffffff"});St(47,"Stone Bricks","stonebrick",{hardness:1.8,sound:"stone",color:"#8a8a8e"});St(48,"Mossy Stone Bricks","stonebrick_mossy",{hardness:1.8,sound:"stone",color:"#6f8466"});St(49,"Cracked Stone Bricks","stonebrick_cracked",{hardness:1.6,sound:"stone",color:"#7e7e82"});St(50,"Dark Planks","planks_dark",{hardness:1.2,tool:"axe",sound:"wood",color:"#5a3c22"});St(51,"White Stone",{top:"whitestone_top",side:"whitestone_side",bottom:"whitestone_top"},{hardness:1.6,sound:"stone",color:"#ece6da"});St(52,"Polished Stone","polished",{hardness:1.6,sound:"stone",color:"#9a9c9e"});St(53,"Roof Tiles","roof",{hardness:1.4,sound:"stone",color:"#8a3a2e"});St(54,"Iron Bars","ironbars",{hardness:2,transparent:!0,sound:"metal",color:"#9a9a9a"});St(55,"Hay Bale",{top:"hay_top",side:"hay_side",bottom:"hay_top"},{hardness:.5,tool:"none",sound:"grass",color:"#d8b43a"});St(56,"Bookshelf",{top:"planks",side:"bookshelf",bottom:"planks"},{hardness:1.2,tool:"axe",sound:"wood",color:"#8a5a32"});St(57,"Portal","portal",{solid:!1,trans:!0,transparent:!0,unbreakable:!0,light:1,sound:"glass",color:"#9a4fff"});St(58,"Checkpoint","checkpoint",{solid:!1,transparent:!0,unbreakable:!0,box:Eh,pick:!0,light:1,sound:"metal",color:"#ffd84a"});St(59,"Finish","finish",{solid:!1,transparent:!0,unbreakable:!0,box:Eh,pick:!0,light:1,sound:"metal",color:"#ffffff"});St(60,"Trap Button","button",{solid:!1,transparent:!0,unbreakable:!0,box:bf,pick:!0,sound:"stone",color:"#d83a2a"});St(61,"Bounce Pad",{top:"bounce_top",side:"bounce_side",bottom:"bounce_side"},{hardness:1,unbreakable:!0,bounce:13.5,sound:"cloth",color:"#5fd34a"});St(62,"Flag Base",{top:"flagbase_top",side:"whitestone_side",bottom:"whitestone_top"},{unbreakable:!0,sound:"stone",color:"#ece6da"});St(63,"Trap Floor","trapfloor",{unbreakable:!0,sound:"wood",color:"#a07a44"});St(64,"Sea Stone","seastone",{hardness:1.6,sound:"stone",color:"#5aa8a0"});St(65,"Red Sandstone",{top:"redsand_top",side:"redsand_side",bottom:"redsand_top"},{hardness:.9,sound:"stone",color:"#c86a3a"});St(66,"Lava Rock","lavarock",{unbreakable:!0,light:1,sound:"stone",color:"#ff6a1e"});var Yt=as,ci=new Uint8Array(256);for(let s=1;s<256;s++)as[s]&&as[s].solid&&(ci[s]=1);var Pe=s=>s!==0&&as[s]&&as[s].solid;var ft=16,$n=16;function Sf(s){let t=s>>>0||1;return()=>(t^=t<<13,t^=t>>>17,t^=t<<5,(t>>>0)%1e5/1e5)}var wf=s=>{let t=2166136261;for(let e=0;e<s.length;e++)t^=s.charCodeAt(e),t=Math.imul(t,16777619);return t>>>0},O=s=>[parseInt(s.slice(1,3),16),parseInt(s.slice(3,5),16),parseInt(s.slice(5,7),16)],we=(s,t)=>s.map(e=>Math.max(0,Math.min(255,Math.round(e*t)))),Ah=(s,t,e)=>s.map((n,i)=>Math.round(n+(t[i]-n)*e)),Ll=class{constructor(t){this.px=new Uint8ClampedArray(ft*ft*4),this.r=Sf(wf(t))}set(t,e,n,i=255){if(t<0||e<0||t>=ft||e>=ft)return;let r=(e*ft+t)*4;this.px[r]=n[0],this.px[r+1]=n[1],this.px[r+2]=n[2],this.px[r+3]=i}get(t,e){let n=(e*ft+t)*4;return[this.px[n],this.px[n+1],this.px[n+2],this.px[n+3]]}noise(t,e=.12,n=255){for(let i=0;i<ft;i++)for(let r=0;r<ft;r++)this.set(r,i,we(t,1-e+this.r()*e*2),n);return this}palette(t,e=255){for(let n=0;n<ft;n++)for(let i=0;i<ft;i++)this.set(i,n,t[Math.floor(this.r()*t.length)],e);return this}specks(t,e){for(let n=0;n<e;n++)this.set(Math.floor(this.r()*ft),Math.floor(this.r()*ft),we(t,.85+this.r()*.3));return this}blobs(t,e,n=2){for(let i=0;i<e;i++){let r=Math.floor(this.r()*ft),o=Math.floor(this.r()*ft);for(let a=0;a<n;a++)for(let l=0;l<n;l++)this.r()>.25&&this.set((r+l)%ft,(o+a)%ft,we(t,.9+this.r()*.2))}return this}rect(t,e,n,i,r){for(let o=e;o<e+i;o++)for(let a=t;a<t+n;a++)this.set(a,o,r);return this}border(t){for(let e=0;e<ft;e++)this.set(e,0,t),this.set(e,ft-1,t),this.set(0,e,t),this.set(ft-1,e,t);return this}clear(){return this.px.fill(0),this}},Mn={grass:["#5fa83a","#6bb842","#559c33","#78c04a","#4f9030"].map(O),dirt:["#8a5a36","#7a4e2e","#94643c","#6e4428","#9c6c44"].map(O),stone:["#8c8c8c","#7f7f7f","#999999","#858585","#a3a3a3"].map(O),sand:["#e3d394","#dccb88","#ead9a0","#d6c47e"].map(O),snow:["#f2f6fa","#e8eef5","#ffffff","#dfe8f0"].map(O)},rt={};rt.dirt=s=>s.palette(Mn.dirt).specks(O("#5c3a20"),10);rt.grass_top=s=>s.palette(Mn.grass).specks(O("#8ad05a"),14).specks(O("#447f28"),10);rt.grass_side=s=>{rt.dirt(s);for(let t=0;t<ft;t++){let e=3+Math.floor(s.r()*3);for(let n=0;n<e;n++)s.set(t,n,Mn.grass[Math.floor(s.r()*Mn.grass.length)])}return s};rt.stone=s=>s.palette(Mn.stone).blobs(O("#727272"),7,3).specks(O("#b0b0b0"),8);rt.cobble=s=>{s.noise(O("#7a7a7a"),.1);for(let t=0;t<9;t++){let e=Math.floor(s.r()*13),n=Math.floor(s.r()*13),i=3+Math.floor(s.r()*3);s.rect(e,n,i,i-1,we(O("#9a9a9a"),.9+s.r()*.25))}for(let t=0;t<26;t++)s.set(Math.floor(s.r()*16),Math.floor(s.r()*16),O("#555555"));return s};rt.planks=s=>{s.noise(O("#b4874c"),.08);for(let t=0;t<ft;t+=4){for(let n=0;n<ft;n++)s.set(n,t,O("#7d5a2e"));let e=t/4%2?4:12;s.set(e,t+1,O("#7d5a2e")),s.set(e,t+2,O("#7d5a2e")),s.set(e,t+3,O("#7d5a2e"))}return s.specks(O("#9c7340"),12)};rt.log_side=s=>{for(let t=0;t<ft;t++){let e=we(O("#6b4a2b"),t%4===0?.75:.95+s.r()*.15);for(let n=0;n<ft;n++)s.set(t,n,we(e,.94+s.r()*.1))}return s};rt.log_top=s=>{s.noise(O("#b08a54"),.06);for(let t=0;t<8;t++){let e=t%2?O("#9a7444"):O("#c09a62");for(let n=0;n<64;n++){let i=Math.round(7.5+Math.cos(n/10.2)*t),r=Math.round(7.5+Math.sin(n/10.2)*t);s.set(i,r,e)}}return s.border(O("#6b4a2b"))};rt.leaves=s=>{for(let t=0;t<ft;t++)for(let e=0;e<ft;e++){let n=s.r();n<.16?s.set(e,t,[0,0,0],0):s.set(e,t,we(O("#3f8f2a"),.7+n*.5))}return s};rt.sand=s=>s.palette(Mn.sand).specks(O("#c2b070"),10);rt.sandstone_side=s=>{s.palette(Mn.sand);for(let t of[0,5,11])for(let e=0;e<ft;e++)s.set(e,t,O("#c7b46e"));return s.specks(O("#cbb878"),8)};rt.sandstone_top=s=>s.palette(Mn.sand).border(O("#cbb878"));rt.snow=s=>s.palette(Mn.snow).specks(O("#d0dce8"),6);rt.snow_side=s=>{rt.dirt(s);for(let t=0;t<ft;t++){let e=3+Math.floor(s.r()*3);for(let n=0;n<e;n++)s.set(t,n,Mn.snow[Math.floor(s.r()*Mn.snow.length)])}return s};rt.ice=s=>{s.noise(O("#a9d4f5"),.06,200);for(let t=0;t<4;t++){let e=Math.floor(s.r()*12);for(let n=0;n<5;n++)s.set(e+n,3+t*3+n%2,O("#e6f4ff"),220)}return s};rt.glass=s=>(s.clear(),s.border(O("#cfe8f2")),s.set(3,3,O("#ffffff")),s.set(4,4,O("#ffffff")),s.set(4,3,O("#ffffff")),s.set(10,9,O("#e8f6ff")),s.set(11,10,O("#e8f6ff")),s);rt.obsidian=s=>s.noise(O("#231a33"),.15).blobs(O("#3a2a55"),6,2).specks(O("#5a3a8a"),6);var Dl=(s,t,e)=>n=>(n.noise(O(s),.05),n.rect(1,1,14,1,O(t)),n.rect(1,1,1,14,O(t)),n.rect(1,14,14,1,O(e)),n.rect(14,1,1,14,O(e)),n.border(O(e)),n.specks(O(t),6));rt.gold_block=Dl("#f5cf3d","#fff3a0","#c89a1a");rt.iron_block=Dl("#d8d8d8","#ffffff","#a8a8a8");rt.diamond_block=Dl("#5fe0d8","#c8fffb","#2aa8a0");rt.chest_side=s=>{s.noise(O("#9a6a32"),.08);for(let t=0;t<ft;t+=5)for(let e=0;e<ft;e++)s.set(e,t,O("#5e3e18"));return s.border(O("#4a3010")),s.rect(7,5,2,4,O("#d8d8d8")),s.set(7,8,O("#7a7a7a")),s};rt.chest_top=s=>{s.noise(O("#a8743a"),.08),s.border(O("#4a3010"));for(let t=1;t<15;t++)s.set(t,7,O("#6e4a20"));return s};rt.basalt_side=s=>{for(let t=0;t<ft;t++){let e=t%3===0?.7:.95+s.r()*.15;for(let n=0;n<ft;n++)s.set(t,n,we(O("#3e3c42"),e*(.92+s.r()*.12)))}return s};rt.basalt_top=s=>s.noise(O("#4a474e"),.12).blobs(O("#2e2c32"),5,3);rt.magma=s=>{s.noise(O("#7a2a12"),.15);for(let t=0;t<6;t++){let e=Math.floor(s.r()*16),n=Math.floor(s.r()*16);for(let i=0;i<7;i++)s.set(e,n,i%2?O("#ffb040"):O("#ff7a1e")),e+=Math.round(s.r()*2-1),n+=1}return s};rt.moonstone=s=>s.palette(["#efe9b8","#e6dfa8","#f5f0c8","#ddd59a"].map(O)).blobs(O("#cfc68a"),6,2);rt.bricks=s=>{s.noise(O("#a1503a"),.1);for(let t=0;t<ft;t+=4){for(let n=0;n<ft;n++)s.set(n,t,O("#c8bba8"));let e=t/4%2?0:8;for(let n=1;n<4;n++)s.set(e,t+n,O("#c8bba8")),s.set((e+8)%16,t+n,O("#c8bba8"))}return s};rt.terracotta=s=>s.noise(O("#b06a48"),.07).specks(O("#9a5a3a"),10);rt.core=s=>s.noise(O("#2a2a30"),.25).specks(O("#4a4a55"),14).specks(O("#111114"),10);var kl=s=>t=>{rt.stone(t);for(let e=0;e<6;e++){let n=1+Math.floor(t.r()*13),i=1+Math.floor(t.r()*13);t.set(n,i,O(s)),t.set(n+1,i,we(O(s),.8)),t.set(n,i+1,we(O(s),1.15))}return t};rt.iron_ore=kl("#e0b090");rt.gold_ore=kl("#f5d53d");rt.diamond_ore=kl("#5fe8e0");rt.lantern=s=>(s.noise(O("#3a3a3a"),.1),s.rect(3,3,10,10,O("#ffd27a")),s.rect(5,5,6,6,O("#fff2c0")),s.border(O("#2a2a2a")));rt.mossy=s=>(rt.cobble(s),s.blobs(O("#4f7a3a"),9,2));rt.pumpkin_side=s=>{for(let t=0;t<ft;t++){let e=t%4===0?.8:1;for(let n=0;n<ft;n++)s.set(t,n,we(O("#e08a1e"),e*(.92+s.r()*.12)))}return s};rt.pumpkin_top=s=>(s.noise(O("#d07a18"),.1),s.rect(7,7,2,2,O("#5a7a2a")),s);var Ch=s=>t=>{t.noise(O(s),.07);for(let e=0;e<18;e++){let n=Math.floor(t.r()*15),i=Math.floor(t.r()*16);t.set(n,i,we(O(s),.85)),t.set(n+1,i,we(O(s),1.1))}return t};for(let s of Gt)rt[`wool_${s.id}`]=Ch(s.hex);rt.wool_white=Ch("#eeeeee");var Ul=s=>t=>(t.clear(),s(t),t);rt.tallgrass=Ul(s=>{for(let t=0;t<9;t++){let e=1+Math.floor(s.r()*14),n=5+Math.floor(s.r()*9);for(let i=0;i<n;i++)s.set(e+(i>n-3?t%2?1:-1:0),15-i,we(O("#6bbf3a"),.7+s.r()*.5))}});var Rh=s=>Ul(t=>{for(let e=6;e<16;e++)t.set(7,e,O("#3f8f2a"));t.set(6,11,O("#3f8f2a")),t.set(5,10,O("#3f8f2a")),t.set(8,12,O("#3f8f2a")),t.set(9,11,O("#3f8f2a"));for(let[e,n]of[[0,-1],[-1,0],[1,0],[0,1],[-1,-1],[1,1],[1,-1],[-1,1]])t.set(7+e,4+n,we(O(s),.85+t.r()*.3));t.set(7,4,O("#f5e050"))});rt.flower_red=Rh("#e23c3c");rt.flower_yellow=Rh("#f2d22e");rt.deadbush=Ul(s=>{let t=O("#8a6a3a");for(let e=8;e<16;e++)s.set(7,e,t);for(let e=0;e<4;e++)s.set(7-e,8-e,t),s.set(8+e,9-e,t),s.set(6-e,12-e,t),s.set(9+e,12-e,t)});rt.cactus_side=s=>{s.noise(O("#4f8a2a"),.08);for(let t=0;t<ft;t++)s.set(1,t,O("#3a6a1e")),s.set(14,t,O("#3a6a1e"));for(let t=0;t<6;t++)s.set(2+Math.floor(s.r()*12),Math.floor(s.r()*16),O("#e8e0a0"));return s};rt.cactus_top=s=>s.noise(O("#5a9a32"),.08).border(O("#3a6a1e"));var Tf=(s,t,e,n=4,i=8)=>{s.noise(O(t),.08);for(let r=0;r<ft;r+=n){for(let a=0;a<ft;a++)s.set(a,r+n-1,O(e));let o=r/n%2?0:i/2;for(let a=0;a<n;a++)for(let l=o;l<ft;l+=i)s.set(l,r+a,O(e))}return s};rt.stonebrick=s=>{Tf(s,"#8a8a8e","#5e5e62",8,16);for(let t=0;t<16;t+=8)for(let e=0;e<16;e++)s.set(e,t,we(O("#a6a6aa"),.95+s.r()*.1));return s.specks(O("#76767a"),14)};rt.stonebrick_mossy=s=>(rt.stonebrick(s),s.blobs(O("#5a7a42"),8,2).specks(O("#4a6a32"),10));rt.stonebrick_cracked=s=>{rt.stonebrick(s);let t=3,e=1;for(let n=0;n<14;n++)s.set(t,e,O("#3e3e42")),t+=Math.round(s.r()*2-.6),e++;t=12,e=9;for(let n=0;n<6;n++)s.set(t,e,O("#3e3e42")),t--,e+=s.r()>.5?1:0;return s};rt.planks_dark=s=>{s.noise(O("#5a3c22"),.08);for(let t=0;t<ft;t+=4){for(let n=0;n<ft;n++)s.set(n,t,O("#3a2614"));let e=t/4%2?5:11;for(let n=1;n<4;n++)s.set(e,t+n,O("#3a2614"))}return s.specks(O("#6a4a2c"),12)};rt.whitestone_side=s=>{s.noise(O("#ece6da"),.04);for(let t=0;t<ft;t++)s.set(0,t,O("#d2cabb")),s.set(15,t,O("#d2cabb")),s.set(3,t,O("#f8f4ea"));return s};rt.whitestone_top=s=>s.noise(O("#ece6da"),.04).border(O("#d2cabb")).rect(4,4,8,8,O("#f4efe4"));rt.polished=s=>s.noise(O("#9a9c9e"),.05).border(O("#7a7c7e")).specks(O("#b0b2b4"),8);rt.roof=s=>{for(let t=0;t<ft;t++)for(let e=0;e<ft;e++){let n=Math.floor(t/4),i=n%2?2:0,r=(e+i)%4===0||t%4===3;s.set(e,t,we(O("#8a3a2e"),r?.7:.92+s.r()*.16))}return s};rt.ironbars=s=>{s.clear();for(let t of[1,5,10,14])for(let e=0;e<ft;e++)s.set(t,e,we(O("#9a9a9a"),.85+s.r()*.3));for(let t of[0,15])for(let e=0;e<ft;e++)s.set(e,t,O("#7a7a7a"));return s};rt.hay_side=s=>{for(let t=0;t<ft;t++)for(let e=0;e<ft;e++)s.set(t,e,we(O("#d8b43a"),(e%5===0?.75:.9)+s.r()*.2));for(let t of[3,12])for(let e=0;e<ft;e++)s.set(e,t,O("#8a2a1e"));return s};rt.hay_top=s=>{s.noise(O("#c8a42e"),.12);for(let t=1;t<8;t+=2)for(let e=0;e<40;e++)s.set(Math.round(7.5+Math.cos(e/6.4)*t),Math.round(7.5+Math.sin(e/6.4)*t),O("#a8841e"));return s};rt.bookshelf=s=>{s.noise(O("#8a5a32"),.06);let t=["#a83a2a","#2a5aa8","#3a8a3a","#d8b43a","#6a3a8a","#2a2a2a"];for(let e of[1,9]){s.rect(0,e-1,16,1,O("#5a3a1a"));for(let n=1;n<15;n++){let i=O(t[Math.floor(s.r()*t.length)]),r=5+Math.floor(s.r()*2);for(let o=0;o<r;o++)s.set(n,e+6-o,we(i,.85+s.r()*.2))}}return s.border(O("#5a3a1a"))};rt.portal=s=>{for(let t=0;t<ft;t++)for(let e=0;e<ft;e++){let n=Math.sin(e*.9+t*.4)+Math.sin(t*1.1-e*.3)+s.r()*.8;s.set(e,t,Ah(O("#4a1a9a"),O("#c87aff"),Math.max(0,Math.min(1,(n+2)/4.8))),210)}return s};rt.checkpoint=s=>s.noise(O("#ffd84a"),.08).border(O("#c89a1a")).rect(6,6,4,4,O("#fff3a0"));rt.finish=s=>{for(let t=0;t<ft;t++)for(let e=0;e<ft;e++)s.set(e,t,(Math.floor(e/4)+Math.floor(t/4))%2?O("#1a1a1a"):O("#f4f4f4"));return s};rt.button=s=>s.noise(O("#d83a2a"),.08).border(O("#8a1a12"));rt.bounce_top=s=>(s.noise(O("#5fd34a"),.08),s.rect(3,3,10,10,O("#8ff07a")),s.rect(6,6,4,4,O("#c8ffb8")),s.border(O("#2a8a1e")));rt.bounce_side=s=>{s.noise(O("#4fbf3a"),.08);for(let t=0;t<ft;t++)s.set(t,0,O("#8ff07a"));for(let t=4;t<ft;t+=4)for(let e=0;e<ft;e++)s.set(e,t,O("#3a9a2a"));return s};rt.flagbase_top=s=>(s.noise(O("#ece6da"),.04).border(O("#c8a42e")),s.rect(5,5,6,6,O("#c8a42e")),s.rect(7,7,2,2,O("#fff3a0")));rt.trapfloor=s=>(rt.planks(s),s.specks(O("#8a6a3a"),4));rt.seastone=s=>s.palette(["#5aa8a0","#4a9890","#6ab8ae","#3f8a84"].map(O)).blobs(O("#2f6a66"),5,2);rt.redsand_side=s=>{s.palette(["#c86a3a","#b85e30","#d47a48"].map(O));for(let t of[0,5,11])for(let e=0;e<ft;e++)s.set(e,t,O("#a8542a"));return s};rt.redsand_top=s=>s.palette(["#c86a3a","#b85e30","#d47a48"].map(O)).border(O("#a8542a"));rt.lavarock=s=>{s.noise(O("#d8501a"),.1);for(let t=0;t<8;t++){let e=Math.floor(s.r()*16),n=Math.floor(s.r()*16);for(let i=0;i<6;i++)s.set(e,n,O("#ffd060")),e=(e+1)%16,n=(n+Math.round(s.r()))%16}return s};rt.crack0=s=>Qr(s,3);rt.crack1=s=>Qr(s,6);rt.crack2=s=>Qr(s,10);rt.crack3=s=>Qr(s,15);function Qr(s,t){s.clear();for(let e=0;e<t;e++){let n=8,i=8,r=s.r()*Math.PI*2;for(let o=0;o<8;o++)s.set(Math.round(n),Math.round(i),[20,20,20],170),n+=Math.cos(r),i+=Math.sin(r),r+=(s.r()-.5)*1.2}return s}function Ih(s={}){let t=[...Object.keys(rt),...Object.keys(s)],e=Math.ceil(t.length/$n),n=ft*$n,i=ft*Math.max($n,e),r=new Uint8ClampedArray(n*i*4),o={};return t.forEach((a,l)=>{let c=new Ll(a);(rt[a]||s[a])(c,{hex:O,shade:we,mix:Ah});let h=l%$n*ft,d=Math.floor(l/$n)*ft;for(let f=0;f<ft;f++)for(let p=0;p<ft;p++){let m=(f*ft+p)*4,x=((d+f)*n+h+p)*4;r[x]=c.px[m],r[x+1]=c.px[m+1],r[x+2]=c.px[m+2],r[x+3]=c.px[m+3]}o[a]=l}),{data:r,width:n,height:i,index:o,uv:a=>{let l=o[a]??0;return[l%$n/$n,Math.floor(l/$n)/(i/ft),1/$n,1/(i/ft)]}}}var su=0,mc=1,ru=2;var gc=1,ou=2,Vn=3,ti=0,Ve=1,vn=2,ii=0,Ni=1,xc=2,vc=3,yc=4,au=5,vi=100,lu=101,cu=102,hu=103,uu=104,du=200,fu=201,pu=202,mu=203,Io=204,Po=205,gu=206,xu=207,vu=208,yu=209,_u=210,Mu=211,bu=212,Su=213,wu=214,sa=0,ra=1,oa=2,Fi=3,aa=4,la=5,ca=6,ha=7,ua=0,Tu=1,Eu=2,si=0,Au=1,Cu=2,Ru=3,Iu=4,Pu=5,Lu=6,Du=7;var _c=300,$i=301,Yi=302,da=303,fa=304,Dr=306,Lo=1e3,gi=1001,Do=1002,Ce=1003,ku=1004;var kr=1005;var En=1006,pa=1007;var Mi=1008;var In=1009,Mc=1010,bc=1011,Us=1012,ma=1013,bi=1014,Pn=1015,Ns=1016,ga=1017,xa=1018,Fs=1020,Sc=35902,wc=35899,Tc=1021,Ec=1022,tn=1023,Es=1026,Os=1027,va=1028,ya=1029,Ac=1030,_a=1031;var Ma=1033,Ur=33776,Nr=33777,Fr=33778,Or=33779,ba=35840,Sa=35841,wa=35842,Ta=35843,Ea=36196,Aa=37492,Ca=37496,Ra=37808,Ia=37809,Pa=37810,La=37811,Da=37812,ka=37813,Ua=37814,Na=37815,Fa=37816,Oa=37817,Ba=37818,za=37819,Ha=37820,Va=37821,Ga=36492,Wa=36494,qa=36495,Xa=36283,$a=36284,Ya=36285,Za=36286;var ur=2300,ko=2301,Co=2302,lc=2400,cc=2401,hc=2402;var Uu=3200,Nu=3201;var Cc=0,Fu=1,ri="",Le="srgb",Oi="srgb-linear",dr="linear",se="srgb";var Ui=7680;var uc=519,Ou=512,Bu=513,zu=514,Rc=515,Hu=516,Vu=517,Gu=518,Wu=519,Uo=35044,Ic=35048;var Pc="300 es",Tn=2e3,fr=2001;var ei=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){let n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){let n=this._listeners;if(n===void 0)return;let i=n[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){let e=this._listeners;if(e===void 0)return;let n=e[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,o=i.length;r<o;r++)i[r].call(this,t);t.target=null}}},qe=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var Ro=Math.PI/180,No=180/Math.PI;function xi(){let s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(qe[s&255]+qe[s>>8&255]+qe[s>>16&255]+qe[s>>24&255]+"-"+qe[t&255]+qe[t>>8&255]+"-"+qe[t>>16&15|64]+qe[t>>24&255]+"-"+qe[e&63|128]+qe[e>>8&255]+"-"+qe[e>>16&255]+qe[e>>24&255]+qe[n&255]+qe[n>>8&255]+qe[n>>16&255]+qe[n>>24&255]).toLowerCase()}function Xt(s,t,e){return Math.max(t,Math.min(e,s))}function Ef(s,t){return(s%t+t)%t}function Nl(s,t,e){return(1-e)*s+e*t}function Fn(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function ae(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}var Nt=class s{constructor(t=0,e=0){s.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Xt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*i+t.x,this.y=r*i+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},cn=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,o,a){let l=n[i+0],c=n[i+1],h=n[i+2],d=n[i+3],f=r[o+0],p=r[o+1],m=r[o+2],x=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=d;return}if(a===1){t[e+0]=f,t[e+1]=p,t[e+2]=m,t[e+3]=x;return}if(d!==x||l!==f||c!==p||h!==m){let g=1-a,u=l*f+c*p+h*m+d*x,v=u>=0?1:-1,_=1-u*u;if(_>Number.EPSILON){let A=Math.sqrt(_),b=Math.atan2(A,u*v);g=Math.sin(g*b)/A,a=Math.sin(a*b)/A}let M=a*v;if(l=l*g+f*M,c=c*g+p*M,h=h*g+m*M,d=d*g+x*M,g===1-a){let A=1/Math.sqrt(l*l+c*c+h*h+d*d);l*=A,c*=A,h*=A,d*=A}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,r,o){let a=n[i],l=n[i+1],c=n[i+2],h=n[i+3],d=r[o],f=r[o+1],p=r[o+2],m=r[o+3];return t[e]=a*m+h*d+l*p-c*f,t[e+1]=l*m+h*f+c*d-a*p,t[e+2]=c*m+h*p+a*f-l*d,t[e+3]=h*m-a*d-l*f-c*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(i/2),d=a(r/2),f=l(n/2),p=l(i/2),m=l(r/2);switch(o){case"XYZ":this._x=f*h*d+c*p*m,this._y=c*p*d-f*h*m,this._z=c*h*m+f*p*d,this._w=c*h*d-f*p*m;break;case"YXZ":this._x=f*h*d+c*p*m,this._y=c*p*d-f*h*m,this._z=c*h*m-f*p*d,this._w=c*h*d+f*p*m;break;case"ZXY":this._x=f*h*d-c*p*m,this._y=c*p*d+f*h*m,this._z=c*h*m+f*p*d,this._w=c*h*d-f*p*m;break;case"ZYX":this._x=f*h*d-c*p*m,this._y=c*p*d+f*h*m,this._z=c*h*m-f*p*d,this._w=c*h*d+f*p*m;break;case"YZX":this._x=f*h*d+c*p*m,this._y=c*p*d+f*h*m,this._z=c*h*m-f*p*d,this._w=c*h*d-f*p*m;break;case"XZY":this._x=f*h*d-c*p*m,this._y=c*p*d-f*h*m,this._z=c*h*m+f*p*d,this._w=c*h*d+f*p*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],d=e[10],f=n+a+d;if(f>0){let p=.5/Math.sqrt(f+1);this._w=.25/p,this._x=(h-l)*p,this._y=(r-c)*p,this._z=(o-i)*p}else if(n>a&&n>d){let p=2*Math.sqrt(1+n-a-d);this._w=(h-l)/p,this._x=.25*p,this._y=(i+o)/p,this._z=(r+c)/p}else if(a>d){let p=2*Math.sqrt(1+a-n-d);this._w=(r-c)/p,this._x=(i+o)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+d-n-a);this._w=(o-i)/p,this._x=(r+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Xt(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+o*a+i*c-r*l,this._y=i*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-i*a,this._w=o*h-n*a-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,i=this._y,r=this._z,o=this._w,a=o*t._w+n*t._x+i*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=n,this._y=i,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let p=1-e;return this._w=p*o+e*this._w,this._x=p*n+e*this._x,this._y=p*i+e*this._y,this._z=p*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),d=Math.sin((1-e)*h)/c,f=Math.sin(e*h)/c;return this._w=o*d+this._w*f,this._x=n*d+this._x*f,this._y=i*d+this._y*f,this._z=r*d+this._z*f,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},U=class s{constructor(t=0,e=0,n=0){s.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Ph.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Ph.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*o,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*i-a*n),h=2*(a*e-r*i),d=2*(r*n-o*e);return this.x=e+l*c+o*d-a*h,this.y=n+l*h+a*c-r*d,this.z=i+l*d+r*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=i*l-r*a,this.y=r*o-n*l,this.z=n*a-i*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Fl.copy(this).projectOnVector(t),this.sub(Fl)}reflect(t){return this.sub(Fl.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Xt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Fl=new U,Ph=new cn,Bt=class s{constructor(t,e,n,i,r,o,a,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,l,c)}set(t,e,n,i,r,o,a,l,c){let h=this.elements;return h[0]=t,h[1]=i,h[2]=a,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],d=n[7],f=n[2],p=n[5],m=n[8],x=i[0],g=i[3],u=i[6],v=i[1],_=i[4],M=i[7],A=i[2],b=i[5],T=i[8];return r[0]=o*x+a*v+l*A,r[3]=o*g+a*_+l*b,r[6]=o*u+a*M+l*T,r[1]=c*x+h*v+d*A,r[4]=c*g+h*_+d*b,r[7]=c*u+h*M+d*T,r[2]=f*x+p*v+m*A,r[5]=f*g+p*_+m*b,r[8]=f*u+p*M+m*T,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-n*r*h+n*a*l+i*r*c-i*o*l}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],d=h*o-a*c,f=a*l-h*r,p=c*r-o*l,m=e*d+n*f+i*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/m;return t[0]=d*x,t[1]=(i*c-h*n)*x,t[2]=(a*n-i*o)*x,t[3]=f*x,t[4]=(h*e-i*l)*x,t[5]=(i*r-a*e)*x,t[6]=p*x,t[7]=(n*l-c*e)*x,t[8]=(o*e-n*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+t,-i*c,i*l,-i*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(Ol.makeScale(t,e)),this}rotate(t){return this.premultiply(Ol.makeRotation(-t)),this}translate(t,e){return this.premultiply(Ol.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Ol=new Bt;function Lc(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function pr(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function qu(){let s=pr("canvas");return s.style.display="block",s}var Lh={};function As(s){s in Lh||(Lh[s]=!0,console.warn(s))}function Xu(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}var Dh=new Bt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),kh=new Bt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Af(){let s={enabled:!0,workingColorSpace:Oi,spaces:{},convert:function(i,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===se&&(i.r=Qn(i.r),i.g=Qn(i.g),i.b=Qn(i.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===se&&(i.r=Ts(i.r),i.g=Ts(i.g),i.b=Ts(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===ri?dr:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,o){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return As("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return As("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[Oi]:{primaries:t,whitePoint:n,transfer:dr,toXYZ:Dh,fromXYZ:kh,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Le},outputColorSpaceConfig:{drawingBufferColorSpace:Le}},[Le]:{primaries:t,whitePoint:n,transfer:se,toXYZ:Dh,fromXYZ:kh,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Le}}}),s}var Zt=Af();function Qn(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Ts(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}var ls,Fo=class{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{ls===void 0&&(ls=pr("canvas")),ls.width=t.width,ls.height=t.height;let i=ls.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=ls}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=pr("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let o=0;o<r.length;o++)r[o]=Qn(r[o]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Qn(e[n]/255)*255):e[n]=Qn(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Cf=0,Cs=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Cf++}),this.uuid=xi(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){let e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?r.push(Bl(i[o].image)):r.push(Bl(i[o]))}else r=Bl(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function Bl(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Fo.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Rf=0,zl=new U,je=class s extends ei{constructor(t=s.DEFAULT_IMAGE,e=s.DEFAULT_MAPPING,n=gi,i=gi,r=En,o=Mi,a=tn,l=In,c=s.DEFAULT_ANISOTROPY,h=ri){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Rf++}),this.uuid=xi(),this.name="",this.source=new Cs(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Nt(0,0),this.repeat=new Nt(1,1),this.center=new Nt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Bt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(zl).x}get height(){return this.source.getSize(zl).y}get depth(){return this.source.getSize(zl).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==_c)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Lo:t.x=t.x-Math.floor(t.x);break;case gi:t.x=t.x<0?0:1;break;case Do:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Lo:t.y=t.y-Math.floor(t.y);break;case gi:t.y=t.y<0?0:1;break;case Do:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};je.DEFAULT_IMAGE=null;je.DEFAULT_MAPPING=_c;je.DEFAULT_ANISOTROPY=1;var _e=class s{constructor(t=0,e=0,n=0,i=1){s.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*i+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*i+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*i+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*i+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,l=t.elements,c=l[0],h=l[4],d=l[8],f=l[1],p=l[5],m=l[9],x=l[2],g=l[6],u=l[10];if(Math.abs(h-f)<.01&&Math.abs(d-x)<.01&&Math.abs(m-g)<.01){if(Math.abs(h+f)<.1&&Math.abs(d+x)<.1&&Math.abs(m+g)<.1&&Math.abs(c+p+u-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let _=(c+1)/2,M=(p+1)/2,A=(u+1)/2,b=(h+f)/4,T=(d+x)/4,I=(m+g)/4;return _>M&&_>A?_<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(_),i=b/n,r=T/n):M>A?M<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(M),n=b/i,r=I/i):A<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(A),n=T/r,i=I/r),this.set(n,i,r,e),this}let v=Math.sqrt((g-m)*(g-m)+(d-x)*(d-x)+(f-h)*(f-h));return Math.abs(v)<.001&&(v=1),this.x=(g-m)/v,this.y=(d-x)/v,this.z=(f-h)/v,this.w=Math.acos((c+p+u-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Xt(this.x,t.x,e.x),this.y=Xt(this.y,t.y,e.y),this.z=Xt(this.z,t.z,e.z),this.w=Xt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Xt(this.x,t,e),this.y=Xt(this.y,t,e),this.z=Xt(this.z,t,e),this.w=Xt(this.w,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Xt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Oo=class extends ei{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:En,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new _e(0,0,t,e),this.scissorTest=!1,this.viewport=new _e(0,0,t,e);let i={width:t,height:e,depth:n.depth},r=new je(i);this.textures=[];let o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){let e={minFilter:En,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isArrayTexture=this.textures[i].image.depth>1;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;let i=Object.assign({},t.textures[e].image);this.textures[e].source=new Cs(i)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Bn=class extends Oo{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},mr=class extends je{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ce,this.minFilter=Ce,this.wrapR=gi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var Bo=class extends je{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=Ce,this.minFilter=Ce,this.wrapR=gi,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var zn=class{constructor(t=new U(1/0,1/0,1/0),e=new U(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(bn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(bn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=bn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,bn):bn.fromBufferAttribute(r,o),bn.applyMatrix4(t.matrixWorld),this.expandByPoint(bn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),to.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),to.copy(n.boundingBox)),to.applyMatrix4(t.matrixWorld),this.union(to)}let i=t.children;for(let r=0,o=i.length;r<o;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,bn),bn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(er),eo.subVectors(this.max,er),cs.subVectors(t.a,er),hs.subVectors(t.b,er),us.subVectors(t.c,er),hi.subVectors(hs,cs),ui.subVectors(us,hs),Pi.subVectors(cs,us);let e=[0,-hi.z,hi.y,0,-ui.z,ui.y,0,-Pi.z,Pi.y,hi.z,0,-hi.x,ui.z,0,-ui.x,Pi.z,0,-Pi.x,-hi.y,hi.x,0,-ui.y,ui.x,0,-Pi.y,Pi.x,0];return!Hl(e,cs,hs,us,eo)||(e=[1,0,0,0,1,0,0,0,1],!Hl(e,cs,hs,us,eo))?!1:(no.crossVectors(hi,ui),e=[no.x,no.y,no.z],Hl(e,cs,hs,us,eo))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,bn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(bn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Yn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Yn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Yn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Yn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Yn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Yn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Yn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Yn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Yn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}},Yn=[new U,new U,new U,new U,new U,new U,new U,new U],bn=new U,to=new zn,cs=new U,hs=new U,us=new U,hi=new U,ui=new U,Pi=new U,er=new U,eo=new U,no=new U,Li=new U;function Hl(s,t,e,n,i){for(let r=0,o=s.length-3;r<=o;r+=3){Li.fromArray(s,r);let a=i.x*Math.abs(Li.x)+i.y*Math.abs(Li.y)+i.z*Math.abs(Li.z),l=t.dot(Li),c=e.dot(Li),h=n.dot(Li);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var If=new zn,nr=new U,Vl=new U,ni=class{constructor(t=new U,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):If.setFromPoints(t).getCenter(n);let i=0;for(let r=0,o=t.length;r<o;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;nr.subVectors(t,this.center);let e=nr.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(nr,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Vl.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(nr.copy(t.center).add(Vl)),this.expandByPoint(nr.copy(t.center).sub(Vl))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}},Zn=new U,Gl=new U,io=new U,di=new U,Wl=new U,so=new U,ql=new U,gr=class{constructor(t=new U,e=new U(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Zn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Zn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Zn.copy(this.origin).addScaledVector(this.direction,e),Zn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){Gl.copy(t).add(e).multiplyScalar(.5),io.copy(e).sub(t).normalize(),di.copy(this.origin).sub(Gl);let r=t.distanceTo(e)*.5,o=-this.direction.dot(io),a=di.dot(this.direction),l=-di.dot(io),c=di.lengthSq(),h=Math.abs(1-o*o),d,f,p,m;if(h>0)if(d=o*l-a,f=o*a-l,m=r*h,d>=0)if(f>=-m)if(f<=m){let x=1/h;d*=x,f*=x,p=d*(d+o*f+2*a)+f*(o*d+f+2*l)+c}else f=r,d=Math.max(0,-(o*f+a)),p=-d*d+f*(f+2*l)+c;else f=-r,d=Math.max(0,-(o*f+a)),p=-d*d+f*(f+2*l)+c;else f<=-m?(d=Math.max(0,-(-o*r+a)),f=d>0?-r:Math.min(Math.max(-r,-l),r),p=-d*d+f*(f+2*l)+c):f<=m?(d=0,f=Math.min(Math.max(-r,-l),r),p=f*(f+2*l)+c):(d=Math.max(0,-(o*r+a)),f=d>0?r:Math.min(Math.max(-r,-l),r),p=-d*d+f*(f+2*l)+c);else f=o>0?-r:r,d=Math.max(0,-(o*f+a)),p=-d*d+f*(f+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,d),i&&i.copy(Gl).addScaledVector(io,f),p}intersectSphere(t,e){Zn.subVectors(t.center,this.origin);let n=Zn.dot(this.direction),i=Zn.dot(Zn)-n*n,r=t.radius*t.radius;if(i>r)return null;let o=Math.sqrt(r-i),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,f=this.origin;return c>=0?(n=(t.min.x-f.x)*c,i=(t.max.x-f.x)*c):(n=(t.max.x-f.x)*c,i=(t.min.x-f.x)*c),h>=0?(r=(t.min.y-f.y)*h,o=(t.max.y-f.y)*h):(r=(t.max.y-f.y)*h,o=(t.min.y-f.y)*h),n>o||r>i||((r>n||isNaN(n))&&(n=r),(o<i||isNaN(i))&&(i=o),d>=0?(a=(t.min.z-f.z)*d,l=(t.max.z-f.z)*d):(a=(t.max.z-f.z)*d,l=(t.min.z-f.z)*d),n>l||a>i)||((a>n||n!==n)&&(n=a),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Zn)!==null}intersectTriangle(t,e,n,i,r){Wl.subVectors(e,t),so.subVectors(n,t),ql.crossVectors(Wl,so);let o=this.direction.dot(ql),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;di.subVectors(this.origin,t);let l=a*this.direction.dot(so.crossVectors(di,so));if(l<0)return null;let c=a*this.direction.dot(Wl.cross(di));if(c<0||l+c>o)return null;let h=-a*di.dot(ql);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},ee=class s{constructor(t,e,n,i,r,o,a,l,c,h,d,f,p,m,x,g){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,l,c,h,d,f,p,m,x,g)}set(t,e,n,i,r,o,a,l,c,h,d,f,p,m,x,g){let u=this.elements;return u[0]=t,u[4]=e,u[8]=n,u[12]=i,u[1]=r,u[5]=o,u[9]=a,u[13]=l,u[2]=c,u[6]=h,u[10]=d,u[14]=f,u[3]=p,u[7]=m,u[11]=x,u[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,i=1/ds.setFromMatrixColumn(t,0).length(),r=1/ds.setFromMatrixColumn(t,1).length(),o=1/ds.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),d=Math.sin(r);if(t.order==="XYZ"){let f=o*h,p=o*d,m=a*h,x=a*d;e[0]=l*h,e[4]=-l*d,e[8]=c,e[1]=p+m*c,e[5]=f-x*c,e[9]=-a*l,e[2]=x-f*c,e[6]=m+p*c,e[10]=o*l}else if(t.order==="YXZ"){let f=l*h,p=l*d,m=c*h,x=c*d;e[0]=f+x*a,e[4]=m*a-p,e[8]=o*c,e[1]=o*d,e[5]=o*h,e[9]=-a,e[2]=p*a-m,e[6]=x+f*a,e[10]=o*l}else if(t.order==="ZXY"){let f=l*h,p=l*d,m=c*h,x=c*d;e[0]=f-x*a,e[4]=-o*d,e[8]=m+p*a,e[1]=p+m*a,e[5]=o*h,e[9]=x-f*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let f=o*h,p=o*d,m=a*h,x=a*d;e[0]=l*h,e[4]=m*c-p,e[8]=f*c+x,e[1]=l*d,e[5]=x*c+f,e[9]=p*c-m,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let f=o*l,p=o*c,m=a*l,x=a*c;e[0]=l*h,e[4]=x-f*d,e[8]=m*d+p,e[1]=d,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=p*d+m,e[10]=f-x*d}else if(t.order==="XZY"){let f=o*l,p=o*c,m=a*l,x=a*c;e[0]=l*h,e[4]=-d,e[8]=c*h,e[1]=f*d+x,e[5]=o*h,e[9]=p*d-m,e[2]=m*d-p,e[6]=a*h,e[10]=x*d+f}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Pf,t,Lf)}lookAt(t,e,n){let i=this.elements;return an.subVectors(t,e),an.lengthSq()===0&&(an.z=1),an.normalize(),fi.crossVectors(n,an),fi.lengthSq()===0&&(Math.abs(n.z)===1?an.x+=1e-4:an.z+=1e-4,an.normalize(),fi.crossVectors(n,an)),fi.normalize(),ro.crossVectors(an,fi),i[0]=fi.x,i[4]=ro.x,i[8]=an.x,i[1]=fi.y,i[5]=ro.y,i[9]=an.y,i[2]=fi.z,i[6]=ro.z,i[10]=an.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],d=n[5],f=n[9],p=n[13],m=n[2],x=n[6],g=n[10],u=n[14],v=n[3],_=n[7],M=n[11],A=n[15],b=i[0],T=i[4],I=i[8],y=i[12],w=i[1],C=i[5],L=i[9],B=i[13],H=i[2],G=i[6],X=i[10],Q=i[14],V=i[3],ot=i[7],ct=i[11],gt=i[15];return r[0]=o*b+a*w+l*H+c*V,r[4]=o*T+a*C+l*G+c*ot,r[8]=o*I+a*L+l*X+c*ct,r[12]=o*y+a*B+l*Q+c*gt,r[1]=h*b+d*w+f*H+p*V,r[5]=h*T+d*C+f*G+p*ot,r[9]=h*I+d*L+f*X+p*ct,r[13]=h*y+d*B+f*Q+p*gt,r[2]=m*b+x*w+g*H+u*V,r[6]=m*T+x*C+g*G+u*ot,r[10]=m*I+x*L+g*X+u*ct,r[14]=m*y+x*B+g*Q+u*gt,r[3]=v*b+_*w+M*H+A*V,r[7]=v*T+_*C+M*G+A*ot,r[11]=v*I+_*L+M*X+A*ct,r[15]=v*y+_*B+M*Q+A*gt,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],d=t[6],f=t[10],p=t[14],m=t[3],x=t[7],g=t[11],u=t[15];return m*(+r*l*d-i*c*d-r*a*f+n*c*f+i*a*p-n*l*p)+x*(+e*l*p-e*c*f+r*o*f-i*o*p+i*c*h-r*l*h)+g*(+e*c*d-e*a*p-r*o*d+n*o*p+r*a*h-n*c*h)+u*(-i*a*h-e*l*d+e*a*f+i*o*d-n*o*f+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],d=t[9],f=t[10],p=t[11],m=t[12],x=t[13],g=t[14],u=t[15],v=d*g*c-x*f*c+x*l*p-a*g*p-d*l*u+a*f*u,_=m*f*c-h*g*c-m*l*p+o*g*p+h*l*u-o*f*u,M=h*x*c-m*d*c+m*a*p-o*x*p-h*a*u+o*d*u,A=m*d*l-h*x*l-m*a*f+o*x*f+h*a*g-o*d*g,b=e*v+n*_+i*M+r*A;if(b===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let T=1/b;return t[0]=v*T,t[1]=(x*f*r-d*g*r-x*i*p+n*g*p+d*i*u-n*f*u)*T,t[2]=(a*g*r-x*l*r+x*i*c-n*g*c-a*i*u+n*l*u)*T,t[3]=(d*l*r-a*f*r-d*i*c+n*f*c+a*i*p-n*l*p)*T,t[4]=_*T,t[5]=(h*g*r-m*f*r+m*i*p-e*g*p-h*i*u+e*f*u)*T,t[6]=(m*l*r-o*g*r-m*i*c+e*g*c+o*i*u-e*l*u)*T,t[7]=(o*f*r-h*l*r+h*i*c-e*f*c-o*i*p+e*l*p)*T,t[8]=M*T,t[9]=(m*d*r-h*x*r-m*n*p+e*x*p+h*n*u-e*d*u)*T,t[10]=(o*x*r-m*a*r+m*n*c-e*x*c-o*n*u+e*a*u)*T,t[11]=(h*a*r-o*d*r-h*n*c+e*d*c+o*n*p-e*a*p)*T,t[12]=A*T,t[13]=(h*x*i-m*d*i+m*n*f-e*x*f-h*n*g+e*d*g)*T,t[14]=(m*a*i-o*x*i-m*n*l+e*x*l+o*n*g-e*a*g)*T,t[15]=(o*d*i-h*a*i+h*n*l-e*d*l-o*n*f+e*a*f)*T,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,o=t.x,a=t.y,l=t.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-i*l,c*l+i*a,0,c*a+i*l,h*a+n,h*l-i*o,0,c*l-i*a,h*l+i*o,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,o){return this.set(1,n,r,0,t,1,o,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,h=o+o,d=a+a,f=r*c,p=r*h,m=r*d,x=o*h,g=o*d,u=a*d,v=l*c,_=l*h,M=l*d,A=n.x,b=n.y,T=n.z;return i[0]=(1-(x+u))*A,i[1]=(p+M)*A,i[2]=(m-_)*A,i[3]=0,i[4]=(p-M)*b,i[5]=(1-(f+u))*b,i[6]=(g+v)*b,i[7]=0,i[8]=(m+_)*T,i[9]=(g-v)*T,i[10]=(1-(f+x))*T,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements,r=ds.set(i[0],i[1],i[2]).length(),o=ds.set(i[4],i[5],i[6]).length(),a=ds.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],Sn.copy(this);let c=1/r,h=1/o,d=1/a;return Sn.elements[0]*=c,Sn.elements[1]*=c,Sn.elements[2]*=c,Sn.elements[4]*=h,Sn.elements[5]*=h,Sn.elements[6]*=h,Sn.elements[8]*=d,Sn.elements[9]*=d,Sn.elements[10]*=d,e.setFromRotationMatrix(Sn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,i,r,o,a=Tn,l=!1){let c=this.elements,h=2*r/(e-t),d=2*r/(n-i),f=(e+t)/(e-t),p=(n+i)/(n-i),m,x;if(l)m=r/(o-r),x=o*r/(o-r);else if(a===Tn)m=-(o+r)/(o-r),x=-2*o*r/(o-r);else if(a===fr)m=-o/(o-r),x=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=f,c[12]=0,c[1]=0,c[5]=d,c[9]=p,c[13]=0,c[2]=0,c[6]=0,c[10]=m,c[14]=x,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,r,o,a=Tn,l=!1){let c=this.elements,h=2/(e-t),d=2/(n-i),f=-(e+t)/(e-t),p=-(n+i)/(n-i),m,x;if(l)m=1/(o-r),x=o/(o-r);else if(a===Tn)m=-2/(o-r),x=-(o+r)/(o-r);else if(a===fr)m=-1/(o-r),x=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=0,c[12]=f,c[1]=0,c[5]=d,c[9]=0,c[13]=p,c[2]=0,c[6]=0,c[10]=m,c[14]=x,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},ds=new U,Sn=new ee,Pf=new U(0,0,0),Lf=new U(1,1,1),fi=new U,ro=new U,an=new U,Uh=new ee,Nh=new cn,An=class s{constructor(t=0,e=0,n=0,i=s.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],o=i[4],a=i[8],l=i[1],c=i[5],h=i[9],d=i[2],f=i[6],p=i[10];switch(e){case"XYZ":this._y=Math.asin(Xt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(f,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Xt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(Xt(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(-d,p),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Xt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(f,p),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Xt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(a,p));break;case"XZY":this._z=Math.asin(-Xt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(f,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Uh.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Uh,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Nh.setFromEuler(this),this.setFromQuaternion(Nh,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};An.DEFAULT_ORDER="XYZ";var xr=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Df=0,Fh=new U,fs=new cn,Jn=new ee,oo=new U,ir=new U,kf=new U,Uf=new cn,Oh=new U(1,0,0),Bh=new U(0,1,0),zh=new U(0,0,1),Hh={type:"added"},Nf={type:"removed"},ps={type:"childadded",child:null},Xl={type:"childremoved",child:null},ze=class s extends ei{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Df++}),this.uuid=xi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let t=new U,e=new An,n=new cn,i=new U(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new ee},normalMatrix:{value:new Bt}}),this.matrix=new ee,this.matrixWorld=new ee,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new xr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return fs.setFromAxisAngle(t,e),this.quaternion.multiply(fs),this}rotateOnWorldAxis(t,e){return fs.setFromAxisAngle(t,e),this.quaternion.premultiply(fs),this}rotateX(t){return this.rotateOnAxis(Oh,t)}rotateY(t){return this.rotateOnAxis(Bh,t)}rotateZ(t){return this.rotateOnAxis(zh,t)}translateOnAxis(t,e){return Fh.copy(t).applyQuaternion(this.quaternion),this.position.add(Fh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Oh,t)}translateY(t){return this.translateOnAxis(Bh,t)}translateZ(t){return this.translateOnAxis(zh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Jn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?oo.copy(t):oo.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),ir.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Jn.lookAt(ir,oo,this.up):Jn.lookAt(oo,ir,this.up),this.quaternion.setFromRotationMatrix(Jn),i&&(Jn.extractRotation(i.matrixWorld),fs.setFromRotationMatrix(Jn),this.quaternion.premultiply(fs.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Hh),ps.child=t,this.dispatchEvent(ps),ps.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Nf),Xl.child=t,this.dispatchEvent(Xl),Xl.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Jn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Jn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Jn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Hh),ps.child=t,this.dispatchEvent(ps),ps.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ir,t,kf),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ir,Uf,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(a=>({...a})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let d=l[c];r(t.shapes,d)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));i.material=a}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];i.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),d=o(t.shapes),f=o(t.skeletons),p=o(t.animations),m=o(t.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),f.length>0&&(n.skeletons=f),p.length>0&&(n.animations=p),m.length>0&&(n.nodes=m)}return n.object=i,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}};ze.DEFAULT_UP=new U(0,1,0);ze.DEFAULT_MATRIX_AUTO_UPDATE=!0;ze.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var wn=new U,jn=new U,$l=new U,Kn=new U,ms=new U,gs=new U,Vh=new U,Yl=new U,Zl=new U,Jl=new U,jl=new _e,Kl=new _e,Ql=new _e,On=class s{constructor(t=new U,e=new U,n=new U){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),wn.subVectors(t,e),i.cross(wn);let r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){wn.subVectors(i,e),jn.subVectors(n,e),$l.subVectors(t,e);let o=wn.dot(wn),a=wn.dot(jn),l=wn.dot($l),c=jn.dot(jn),h=jn.dot($l),d=o*c-a*a;if(d===0)return r.set(0,0,0),null;let f=1/d,p=(c*l-a*h)*f,m=(o*h-a*l)*f;return r.set(1-p-m,m,p)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Kn)===null?!1:Kn.x>=0&&Kn.y>=0&&Kn.x+Kn.y<=1}static getInterpolation(t,e,n,i,r,o,a,l){return this.getBarycoord(t,e,n,i,Kn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Kn.x),l.addScaledVector(o,Kn.y),l.addScaledVector(a,Kn.z),l)}static getInterpolatedAttribute(t,e,n,i,r,o){return jl.setScalar(0),Kl.setScalar(0),Ql.setScalar(0),jl.fromBufferAttribute(t,e),Kl.fromBufferAttribute(t,n),Ql.fromBufferAttribute(t,i),o.setScalar(0),o.addScaledVector(jl,r.x),o.addScaledVector(Kl,r.y),o.addScaledVector(Ql,r.z),o}static isFrontFacing(t,e,n,i){return wn.subVectors(n,e),jn.subVectors(t,e),wn.cross(jn).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return wn.subVectors(this.c,this.b),jn.subVectors(this.a,this.b),wn.cross(jn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return s.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return s.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return s.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return s.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,i=this.b,r=this.c,o,a;ms.subVectors(i,n),gs.subVectors(r,n),Yl.subVectors(t,n);let l=ms.dot(Yl),c=gs.dot(Yl);if(l<=0&&c<=0)return e.copy(n);Zl.subVectors(t,i);let h=ms.dot(Zl),d=gs.dot(Zl);if(h>=0&&d<=h)return e.copy(i);let f=l*d-h*c;if(f<=0&&l>=0&&h<=0)return o=l/(l-h),e.copy(n).addScaledVector(ms,o);Jl.subVectors(t,r);let p=ms.dot(Jl),m=gs.dot(Jl);if(m>=0&&p<=m)return e.copy(r);let x=p*c-l*m;if(x<=0&&c>=0&&m<=0)return a=c/(c-m),e.copy(n).addScaledVector(gs,a);let g=h*m-p*d;if(g<=0&&d-h>=0&&p-m>=0)return Vh.subVectors(r,i),a=(d-h)/(d-h+(p-m)),e.copy(i).addScaledVector(Vh,a);let u=1/(g+x+f);return o=x*u,a=f*u,e.copy(n).addScaledVector(ms,o).addScaledVector(gs,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},$u={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},pi={h:0,s:0,l:0},ao={h:0,s:0,l:0};function tc(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}var kt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Le){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Zt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=Zt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Zt.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=Zt.workingColorSpace){if(t=Ef(t,1),e=Xt(e,0,1),n=Xt(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=tc(o,r,t+1/3),this.g=tc(o,r,t),this.b=tc(o,r,t-1/3)}return Zt.colorSpaceToWorking(this,i),this}setStyle(t,e=Le){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Le){let n=$u[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Qn(t.r),this.g=Qn(t.g),this.b=Qn(t.b),this}copyLinearToSRGB(t){return this.r=Ts(t.r),this.g=Ts(t.g),this.b=Ts(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Le){return Zt.workingToColorSpace(Xe.copy(this),t),Math.round(Xt(Xe.r*255,0,255))*65536+Math.round(Xt(Xe.g*255,0,255))*256+Math.round(Xt(Xe.b*255,0,255))}getHexString(t=Le){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Zt.workingColorSpace){Zt.workingToColorSpace(Xe.copy(this),e);let n=Xe.r,i=Xe.g,r=Xe.b,o=Math.max(n,i,r),a=Math.min(n,i,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let d=o-a;switch(c=h<=.5?d/(o+a):d/(2-o-a),o){case n:l=(i-r)/d+(i<r?6:0);break;case i:l=(r-n)/d+2;break;case r:l=(n-i)/d+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Zt.workingColorSpace){return Zt.workingToColorSpace(Xe.copy(this),e),t.r=Xe.r,t.g=Xe.g,t.b=Xe.b,t}getStyle(t=Le){Zt.workingToColorSpace(Xe.copy(this),t);let e=Xe.r,n=Xe.g,i=Xe.b;return t!==Le?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(pi),this.setHSL(pi.h+t,pi.s+e,pi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(pi),t.getHSL(ao);let n=Nl(pi.h,ao.h,e),i=Nl(pi.s,ao.s,e),r=Nl(pi.l,ao.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Xe=new kt;kt.NAMES=$u;var Ff=0,Hn=class extends ei{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Ff++}),this.uuid=xi(),this.name="",this.type="Material",this.blending=Ni,this.side=ti,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Io,this.blendDst=Po,this.blendEquation=vi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new kt(0,0,0),this.blendAlpha=0,this.depthFunc=Fi,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=uc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ui,this.stencilZFail=Ui,this.stencilZPass=Ui,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ni&&(n.blending=this.blending),this.side!==ti&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Io&&(n.blendSrc=this.blendSrc),this.blendDst!==Po&&(n.blendDst=this.blendDst),this.blendEquation!==vi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Fi&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==uc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ui&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ui&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ui&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=i(t.textures),o=i(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Re=class extends Hn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new kt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new An,this.combine=ua,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Ee=new U,lo=new Nt,Of=0,Ae=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Of++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Uo,this.updateRanges=[],this.gpuType=Pn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)lo.fromBufferAttribute(this,e),lo.applyMatrix3(t),this.setXY(e,lo.x,lo.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix3(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix4(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyNormalMatrix(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.transformDirection(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Fn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ae(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Fn(e,this.array)),e}setX(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Fn(e,this.array)),e}setY(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Fn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Fn(e,this.array)),e}setW(t,e){return this.normalized&&(e=ae(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array),r=ae(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Uo&&(t.usage=this.usage),t}};var vr=class extends Ae{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var yr=class extends Ae{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var ue=class extends Ae{constructor(t,e,n){super(new Float32Array(t),e,n)}},Bf=0,xn=new ee,ec=new ze,xs=new U,ln=new zn,sr=new zn,Oe=new U,He=class s extends ei{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Bf++}),this.uuid=xi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Lc(t)?yr:vr)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Bt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return xn.makeRotationFromQuaternion(t),this.applyMatrix4(xn),this}rotateX(t){return xn.makeRotationX(t),this.applyMatrix4(xn),this}rotateY(t){return xn.makeRotationY(t),this.applyMatrix4(xn),this}rotateZ(t){return xn.makeRotationZ(t),this.applyMatrix4(xn),this}translate(t,e,n){return xn.makeTranslation(t,e,n),this.applyMatrix4(xn),this}scale(t,e,n){return xn.makeScale(t,e,n),this.applyMatrix4(xn),this}lookAt(t){return ec.lookAt(t),ec.updateMatrix(),this.applyMatrix4(ec.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(xs).negate(),this.translate(xs.x,xs.y,xs.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let i=0,r=t.length;i<r;i++){let o=t[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new ue(n,3))}else{let n=Math.min(t.length,e.count);for(let i=0;i<n;i++){let r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new zn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new U(-1/0,-1/0,-1/0),new U(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];ln.setFromBufferAttribute(r),this.morphTargetsRelative?(Oe.addVectors(this.boundingBox.min,ln.min),this.boundingBox.expandByPoint(Oe),Oe.addVectors(this.boundingBox.max,ln.max),this.boundingBox.expandByPoint(Oe)):(this.boundingBox.expandByPoint(ln.min),this.boundingBox.expandByPoint(ln.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ni);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new U,1/0);return}if(t){let n=this.boundingSphere.center;if(ln.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];sr.setFromBufferAttribute(a),this.morphTargetsRelative?(Oe.addVectors(ln.min,sr.min),ln.expandByPoint(Oe),Oe.addVectors(ln.max,sr.max),ln.expandByPoint(Oe)):(ln.expandByPoint(sr.min),ln.expandByPoint(sr.max))}ln.getCenter(n);let i=0;for(let r=0,o=t.count;r<o;r++)Oe.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Oe));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)Oe.fromBufferAttribute(a,c),l&&(xs.fromBufferAttribute(t,c),Oe.add(xs)),i=Math.max(i,n.distanceToSquared(Oe))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ae(new Float32Array(4*n.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let I=0;I<n.count;I++)a[I]=new U,l[I]=new U;let c=new U,h=new U,d=new U,f=new Nt,p=new Nt,m=new Nt,x=new U,g=new U;function u(I,y,w){c.fromBufferAttribute(n,I),h.fromBufferAttribute(n,y),d.fromBufferAttribute(n,w),f.fromBufferAttribute(r,I),p.fromBufferAttribute(r,y),m.fromBufferAttribute(r,w),h.sub(c),d.sub(c),p.sub(f),m.sub(f);let C=1/(p.x*m.y-m.x*p.y);isFinite(C)&&(x.copy(h).multiplyScalar(m.y).addScaledVector(d,-p.y).multiplyScalar(C),g.copy(d).multiplyScalar(p.x).addScaledVector(h,-m.x).multiplyScalar(C),a[I].add(x),a[y].add(x),a[w].add(x),l[I].add(g),l[y].add(g),l[w].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:t.count}]);for(let I=0,y=v.length;I<y;++I){let w=v[I],C=w.start,L=w.count;for(let B=C,H=C+L;B<H;B+=3)u(t.getX(B+0),t.getX(B+1),t.getX(B+2))}let _=new U,M=new U,A=new U,b=new U;function T(I){A.fromBufferAttribute(i,I),b.copy(A);let y=a[I];_.copy(y),_.sub(A.multiplyScalar(A.dot(y))).normalize(),M.crossVectors(b,y);let C=M.dot(l[I])<0?-1:1;o.setXYZW(I,_.x,_.y,_.z,C)}for(let I=0,y=v.length;I<y;++I){let w=v[I],C=w.start,L=w.count;for(let B=C,H=C+L;B<H;B+=3)T(t.getX(B+0)),T(t.getX(B+1)),T(t.getX(B+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Ae(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let f=0,p=n.count;f<p;f++)n.setXYZ(f,0,0,0);let i=new U,r=new U,o=new U,a=new U,l=new U,c=new U,h=new U,d=new U;if(t)for(let f=0,p=t.count;f<p;f+=3){let m=t.getX(f+0),x=t.getX(f+1),g=t.getX(f+2);i.fromBufferAttribute(e,m),r.fromBufferAttribute(e,x),o.fromBufferAttribute(e,g),h.subVectors(o,r),d.subVectors(i,r),h.cross(d),a.fromBufferAttribute(n,m),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,g),a.add(h),l.add(h),c.add(h),n.setXYZ(m,a.x,a.y,a.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let f=0,p=e.count;f<p;f+=3)i.fromBufferAttribute(e,f+0),r.fromBufferAttribute(e,f+1),o.fromBufferAttribute(e,f+2),h.subVectors(o,r),d.subVectors(i,r),h.cross(d),n.setXYZ(f+0,h.x,h.y,h.z),n.setXYZ(f+1,h.x,h.y,h.z),n.setXYZ(f+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Oe.fromBufferAttribute(t,e),Oe.normalize(),t.setXYZ(e,Oe.x,Oe.y,Oe.z)}toNonIndexed(){function t(a,l){let c=a.array,h=a.itemSize,d=a.normalized,f=new c.constructor(l.length*h),p=0,m=0;for(let x=0,g=l.length;x<g;x++){a.isInterleavedBufferAttribute?p=l[x]*a.data.stride+a.offset:p=l[x]*h;for(let u=0;u<h;u++)f[m++]=c[p++]}return new Ae(f,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new s,n=this.index.array,i=this.attributes;for(let a in i){let l=i[a],c=t(l,n);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,d=c.length;h<d;h++){let f=c[h],p=t(f,n);l.push(p)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let i={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let d=0,f=c.length;d<f;d++){let p=c[d];h.push(p.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone());let i=t.attributes;for(let c in i){let h=i[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],d=r[c];for(let f=0,p=d.length;f<p;f++)h.push(d[f].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,h=o.length;c<h;c++){let d=o[c];this.addGroup(d.start,d.count,d.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Gh=new ee,Di=new gr,co=new ni,Wh=new U,ho=new U,uo=new U,fo=new U,nc=new U,po=new U,qh=new U,mo=new U,jt=class extends ze{constructor(t=new He,e=new Re){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){let a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(i,t);let a=this.morphTargetInfluences;if(r&&a){po.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],d=r[l];h!==0&&(nc.fromBufferAttribute(d,t),o?po.addScaledVector(nc,h):po.addScaledVector(nc.sub(e),h))}e.add(po)}return e}raycast(t,e){let n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),co.copy(n.boundingSphere),co.applyMatrix4(r),Di.copy(t.ray).recast(t.near),!(co.containsPoint(Di.origin)===!1&&(Di.intersectSphere(co,Wh)===null||Di.origin.distanceToSquared(Wh)>(t.far-t.near)**2))&&(Gh.copy(r).invert(),Di.copy(t.ray).applyMatrix4(Gh),!(n.boundingBox!==null&&Di.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,Di)))}_computeIntersections(t,e,n){let i,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,d=r.attributes.normal,f=r.groups,p=r.drawRange;if(a!==null)if(Array.isArray(o))for(let m=0,x=f.length;m<x;m++){let g=f[m],u=o[g.materialIndex],v=Math.max(g.start,p.start),_=Math.min(a.count,Math.min(g.start+g.count,p.start+p.count));for(let M=v,A=_;M<A;M+=3){let b=a.getX(M),T=a.getX(M+1),I=a.getX(M+2);i=go(this,u,t,n,c,h,d,b,T,I),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=g.materialIndex,e.push(i))}}else{let m=Math.max(0,p.start),x=Math.min(a.count,p.start+p.count);for(let g=m,u=x;g<u;g+=3){let v=a.getX(g),_=a.getX(g+1),M=a.getX(g+2);i=go(this,o,t,n,c,h,d,v,_,M),i&&(i.faceIndex=Math.floor(g/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(o))for(let m=0,x=f.length;m<x;m++){let g=f[m],u=o[g.materialIndex],v=Math.max(g.start,p.start),_=Math.min(l.count,Math.min(g.start+g.count,p.start+p.count));for(let M=v,A=_;M<A;M+=3){let b=M,T=M+1,I=M+2;i=go(this,u,t,n,c,h,d,b,T,I),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=g.materialIndex,e.push(i))}}else{let m=Math.max(0,p.start),x=Math.min(l.count,p.start+p.count);for(let g=m,u=x;g<u;g+=3){let v=g,_=g+1,M=g+2;i=go(this,o,t,n,c,h,d,v,_,M),i&&(i.faceIndex=Math.floor(g/3),e.push(i))}}}};function zf(s,t,e,n,i,r,o,a){let l;if(t.side===Ve?l=n.intersectTriangle(o,r,i,!0,a):l=n.intersectTriangle(i,r,o,t.side===ti,a),l===null)return null;mo.copy(a),mo.applyMatrix4(s.matrixWorld);let c=e.ray.origin.distanceTo(mo);return c<e.near||c>e.far?null:{distance:c,point:mo.clone(),object:s}}function go(s,t,e,n,i,r,o,a,l,c){s.getVertexPosition(a,ho),s.getVertexPosition(l,uo),s.getVertexPosition(c,fo);let h=zf(s,t,e,n,ho,uo,fo,qh);if(h){let d=new U;On.getBarycoord(qh,ho,uo,fo,d),i&&(h.uv=On.getInterpolatedAttribute(i,a,l,c,d,new Nt)),r&&(h.uv1=On.getInterpolatedAttribute(r,a,l,c,d,new Nt)),o&&(h.normal=On.getInterpolatedAttribute(o,a,l,c,d,new U),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let f={a,b:l,c,normal:new U,materialIndex:0};On.getNormal(ho,uo,fo,f.normal),h.face=f,h.barycoord=d}return h}var De=class s extends He{constructor(t=1,e=1,n=1,i=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:o};let a=this;i=Math.floor(i),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],d=[],f=0,p=0;m("z","y","x",-1,-1,n,e,t,o,r,0),m("z","y","x",1,-1,n,e,-t,o,r,1),m("x","z","y",1,1,t,n,e,i,o,2),m("x","z","y",1,-1,t,n,-e,i,o,3),m("x","y","z",1,-1,t,e,n,i,r,4),m("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new ue(c,3)),this.setAttribute("normal",new ue(h,3)),this.setAttribute("uv",new ue(d,2));function m(x,g,u,v,_,M,A,b,T,I,y){let w=M/T,C=A/I,L=M/2,B=A/2,H=b/2,G=T+1,X=I+1,Q=0,V=0,ot=new U;for(let ct=0;ct<X;ct++){let gt=ct*C-B;for(let Ht=0;Ht<G;Ht++){let ie=Ht*w-L;ot[x]=ie*v,ot[g]=gt*_,ot[u]=H,c.push(ot.x,ot.y,ot.z),ot[x]=0,ot[g]=0,ot[u]=b>0?1:-1,h.push(ot.x,ot.y,ot.z),d.push(Ht/T),d.push(1-ct/I),Q+=1}}for(let ct=0;ct<I;ct++)for(let gt=0;gt<T;gt++){let Ht=f+gt+G*ct,ie=f+gt+G*(ct+1),ce=f+(gt+1)+G*(ct+1),Qt=f+(gt+1)+G*ct;l.push(Ht,ie,Qt),l.push(ie,ce,Qt),V+=6}a.addGroup(p,V,y),p+=V,f+=Q}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Zi(s){let t={};for(let e in s){t[e]={};for(let n in s[e]){let i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function $e(s){let t={};for(let e=0;e<s.length;e++){let n=Zi(s[e]);for(let i in n)t[i]=n[i]}return t}function Hf(s){let t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function Dc(s){let t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Zt.workingColorSpace}var Yu={clone:Zi,merge:$e},Vf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Gf=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Cn=class extends Hn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Vf,this.fragmentShader=Gf,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Zi(t.uniforms),this.uniformsGroups=Hf(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let i in this.uniforms){let o=this.uniforms[i].value;o&&o.isTexture?e.uniforms[i]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[i]={type:"m4",value:o.toArray()}:e.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},_r=class extends ze{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ee,this.projectionMatrix=new ee,this.projectionMatrixInverse=new ee,this.coordinateSystem=Tn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},mi=new U,Xh=new Nt,$h=new Nt,Be=class extends _r{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=No*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Ro*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return No*2*Math.atan(Math.tan(Ro*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){mi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(mi.x,mi.y).multiplyScalar(-t/mi.z),mi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(mi.x,mi.y).multiplyScalar(-t/mi.z)}getViewSize(t,e){return this.getViewBounds(t,Xh,$h),e.subVectors($h,Xh)}setViewOffset(t,e,n,i,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Ro*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*i/l,e-=o.offsetY*n/c,i*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},vs=-90,ys=1,zo=class extends ze{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Be(vs,ys,t,e);i.layers=this.layers,this.add(i);let r=new Be(vs,ys,t,e);r.layers=this.layers,this.add(r);let o=new Be(vs,ys,t,e);o.layers=this.layers,this.add(o);let a=new Be(vs,ys,t,e);a.layers=this.layers,this.add(a);let l=new Be(vs,ys,t,e);l.layers=this.layers,this.add(l);let c=new Be(vs,ys,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,i,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===Tn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===fr)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,d=t.getRenderTarget(),f=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),m=t.xr.enabled;t.xr.enabled=!1;let x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,o),t.setRenderTarget(n,2,i),t.render(e,a),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=x,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(d,f,p),t.xr.enabled=m,n.texture.needsPMREMUpdate=!0}},Mr=class extends je{constructor(t=[],e=$i,n,i,r,o,a,l,c,h){super(t,e,n,i,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Ho=class extends Bn{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new Mr(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new De(5,5,5),r=new Cn({name:"CubemapFromEquirect",uniforms:Zi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ve,blending:ii});r.uniforms.tEquirect.value=e;let o=new jt(i,r),a=e.minFilter;return e.minFilter===Mi&&(e.minFilter=En),new zo(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,i);t.setRenderTarget(r)}},Je=class extends ze{constructor(){super(),this.isGroup=!0,this.type="Group"}},Wf={type:"move"},Rs=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Je,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Je,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new U,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new U),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Je,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new U,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new U),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,n),u=this._getHandJoint(c,x);g!==null&&(u.matrix.fromArray(g.transform.matrix),u.matrix.decompose(u.position,u.rotation,u.scale),u.matrixWorldNeedsUpdate=!0,u.jointRadius=g.radius),u.visible=g!==null}let h=c.joints["index-finger-tip"],d=c.joints["thumb-tip"],f=h.position.distanceTo(d.position),p=.02,m=.005;c.inputState.pinching&&f>p+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&f<=p-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Wf)))}return a!==null&&(a.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Je;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}};var br=class s{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new kt(t),this.near=e,this.far=n}clone(){return new s(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Bi=class extends ze{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new An,this.environmentIntensity=1,this.environmentRotation=new An,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},Vo=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Uo,this.updateRanges=[],this.version=0,this.uuid=xi()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,r=this.stride;i<r;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=xi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=xi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Ze=new U,Sr=class s{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)Ze.fromBufferAttribute(this,e),Ze.applyMatrix4(t),this.setXYZ(e,Ze.x,Ze.y,Ze.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ze.fromBufferAttribute(this,e),Ze.applyNormalMatrix(t),this.setXYZ(e,Ze.x,Ze.y,Ze.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ze.fromBufferAttribute(this,e),Ze.transformDirection(t),this.setXYZ(e,Ze.x,Ze.y,Ze.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=Fn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ae(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ae(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=Fn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=Fn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=Fn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=Fn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=ae(e,this.array),n=ae(n,this.array),i=ae(i,this.array),r=ae(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return new Ae(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new s(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Is=class extends Hn{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new kt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},_s,rr=new U,Ms=new U,bs=new U,Ss=new Nt,or=new Nt,Zu=new ee,xo=new U,ar=new U,vo=new U,Yh=new Nt,ic=new Nt,Zh=new Nt,wr=class extends ze{constructor(t=new Is){if(super(),this.isSprite=!0,this.type="Sprite",_s===void 0){_s=new He;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Vo(e,5);_s.setIndex([0,1,2,0,2,3]),_s.setAttribute("position",new Sr(n,3,0,!1)),_s.setAttribute("uv",new Sr(n,2,3,!1))}this.geometry=_s,this.material=t,this.center=new Nt(.5,.5),this.count=1}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ms.setFromMatrixScale(this.matrixWorld),Zu.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),bs.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ms.multiplyScalar(-bs.z);let n=this.material.rotation,i,r;n!==0&&(r=Math.cos(n),i=Math.sin(n));let o=this.center;yo(xo.set(-.5,-.5,0),bs,o,Ms,i,r),yo(ar.set(.5,-.5,0),bs,o,Ms,i,r),yo(vo.set(.5,.5,0),bs,o,Ms,i,r),Yh.set(0,0),ic.set(1,0),Zh.set(1,1);let a=t.ray.intersectTriangle(xo,ar,vo,!1,rr);if(a===null&&(yo(ar.set(-.5,.5,0),bs,o,Ms,i,r),ic.set(0,1),a=t.ray.intersectTriangle(xo,vo,ar,!1,rr),a===null))return;let l=t.ray.origin.distanceTo(rr);l<t.near||l>t.far||e.push({distance:l,point:rr.clone(),uv:On.getInterpolation(rr,xo,ar,vo,Yh,ic,Zh,new Nt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function yo(s,t,e,n,i,r){Ss.subVectors(s,e).addScalar(.5).multiply(n),i!==void 0?(or.x=r*Ss.x-i*Ss.y,or.y=i*Ss.x+r*Ss.y):or.copy(Ss),s.copy(t),s.x+=or.x,s.y+=or.y,s.applyMatrix4(Zu)}var Ps=class extends je{constructor(t=null,e=1,n=1,i,r,o,a,l,c=Ce,h=Ce,d,f){super(null,o,a,l,c,h,i,r,d,f),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var zi=class extends Ae{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},ws=new ee,Jh=new ee,_o=[],jh=new zn,qf=new ee,lr=new jt,cr=new ni,Hi=class extends jt{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new zi(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,qf)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new zn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ws),jh.copy(t.boundingBox).applyMatrix4(ws),this.boundingBox.union(jh)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new ni),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,ws),cr.copy(t.boundingSphere).applyMatrix4(ws),this.boundingSphere.union(cr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=i[o+a]}raycast(t,e){let n=this.matrixWorld,i=this.count;if(lr.geometry=this.geometry,lr.material=this.material,lr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cr.copy(this.boundingSphere),cr.applyMatrix4(n),t.ray.intersectsSphere(cr)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,ws),Jh.multiplyMatrices(n,ws),lr.matrixWorld=Jh,lr.raycast(t,_o);for(let o=0,a=_o.length;o<a;o++){let l=_o[o];l.instanceId=r,l.object=this,e.push(l)}_o.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new zi(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new Ps(new Float32Array(i*this.count),i,this.count,va,Pn));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=i*t;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},sc=new U,Xf=new U,$f=new Bt,Nn=class{constructor(t=new U(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let i=sc.subVectors(n,e).cross(Xf.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta(sc),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||$f.getNormalMatrix(t),i=this.coplanarPoint(sc).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ki=new ni,Yf=new Nt(.5,.5),Mo=new U,Ls=class{constructor(t=new Nn,e=new Nn,n=new Nn,i=new Nn,r=new Nn,o=new Nn){this.planes=[t,e,n,i,r,o]}set(t,e,n,i,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(i),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Tn,n=!1){let i=this.planes,r=t.elements,o=r[0],a=r[1],l=r[2],c=r[3],h=r[4],d=r[5],f=r[6],p=r[7],m=r[8],x=r[9],g=r[10],u=r[11],v=r[12],_=r[13],M=r[14],A=r[15];if(i[0].setComponents(c-o,p-h,u-m,A-v).normalize(),i[1].setComponents(c+o,p+h,u+m,A+v).normalize(),i[2].setComponents(c+a,p+d,u+x,A+_).normalize(),i[3].setComponents(c-a,p-d,u-x,A-_).normalize(),n)i[4].setComponents(l,f,g,M).normalize(),i[5].setComponents(c-l,p-f,u-g,A-M).normalize();else if(i[4].setComponents(c-l,p-f,u-g,A-M).normalize(),e===Tn)i[5].setComponents(c+l,p+f,u+g,A+M).normalize();else if(e===fr)i[5].setComponents(l,f,g,M).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ki.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ki.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ki)}intersectsSprite(t){ki.center.set(0,0,0);let e=Yf.distanceTo(t.center);return ki.radius=.7071067811865476+e,ki.applyMatrix4(t.matrixWorld),this.intersectsSphere(ki)}intersectsSphere(t){let e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let i=e[n];if(Mo.x=i.normal.x>0?t.max.x:t.min.x,Mo.y=i.normal.y>0?t.max.y:t.min.y,Mo.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(Mo)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};var Ds=class extends Hn{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new kt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},Go=new U,Wo=new U,Kh=new ee,hr=new gr,bo=new ni,rc=new U,Qh=new U,qo=class extends ze{constructor(t=new He,e=new Ds){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[0];for(let i=1,r=e.count;i<r;i++)Go.fromBufferAttribute(e,i-1),Wo.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=Go.distanceTo(Wo);t.setAttribute("lineDistance",new ue(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),bo.copy(n.boundingSphere),bo.applyMatrix4(i),bo.radius+=r,t.ray.intersectsSphere(bo)===!1)return;Kh.copy(i).invert(),hr.copy(t.ray).applyMatrix4(Kh);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,f=n.attributes.position;if(h!==null){let p=Math.max(0,o.start),m=Math.min(h.count,o.start+o.count);for(let x=p,g=m-1;x<g;x+=c){let u=h.getX(x),v=h.getX(x+1),_=So(this,t,hr,l,u,v,x);_&&e.push(_)}if(this.isLineLoop){let x=h.getX(m-1),g=h.getX(p),u=So(this,t,hr,l,x,g,m-1);u&&e.push(u)}}else{let p=Math.max(0,o.start),m=Math.min(f.count,o.start+o.count);for(let x=p,g=m-1;x<g;x+=c){let u=So(this,t,hr,l,x,x+1,x);u&&e.push(u)}if(this.isLineLoop){let x=So(this,t,hr,l,m-1,p,m-1);x&&e.push(x)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){let a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function So(s,t,e,n,i,r,o){let a=s.geometry.attributes.position;if(Go.fromBufferAttribute(a,i),Wo.fromBufferAttribute(a,r),e.distanceSqToSegment(Go,Wo,rc,Qh)>n)return;rc.applyMatrix4(s.matrixWorld);let c=t.ray.origin.distanceTo(rc);if(!(c<t.near||c>t.far))return{distance:c,point:Qh.clone().applyMatrix4(s.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:s}}var tu=new U,eu=new U,Tr=class extends qo{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[];for(let i=0,r=e.count;i<r;i+=2)tu.fromBufferAttribute(e,i),eu.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+tu.distanceTo(eu);t.setAttribute("lineDistance",new ue(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var ks=class extends je{constructor(t,e,n,i,r,o,a,l,c){super(t,e,n,i,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Er=class extends je{constructor(t,e,n=bi,i,r,o,a=Ce,l=Ce,c,h=Es,d=1){if(h!==Es&&h!==Os)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let f={width:t,height:e,depth:d};super(f,i,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Cs(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},Ar=class extends je{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}};var wo=new U,To=new U,oc=new U,Eo=new On,Cr=class extends He{constructor(t=null,e=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},t!==null){let i=Math.pow(10,4),r=Math.cos(Ro*e),o=t.getIndex(),a=t.getAttribute("position"),l=o?o.count:a.count,c=[0,0,0],h=["a","b","c"],d=new Array(3),f={},p=[];for(let m=0;m<l;m+=3){o?(c[0]=o.getX(m),c[1]=o.getX(m+1),c[2]=o.getX(m+2)):(c[0]=m,c[1]=m+1,c[2]=m+2);let{a:x,b:g,c:u}=Eo;if(x.fromBufferAttribute(a,c[0]),g.fromBufferAttribute(a,c[1]),u.fromBufferAttribute(a,c[2]),Eo.getNormal(oc),d[0]=`${Math.round(x.x*i)},${Math.round(x.y*i)},${Math.round(x.z*i)}`,d[1]=`${Math.round(g.x*i)},${Math.round(g.y*i)},${Math.round(g.z*i)}`,d[2]=`${Math.round(u.x*i)},${Math.round(u.y*i)},${Math.round(u.z*i)}`,!(d[0]===d[1]||d[1]===d[2]||d[2]===d[0]))for(let v=0;v<3;v++){let _=(v+1)%3,M=d[v],A=d[_],b=Eo[h[v]],T=Eo[h[_]],I=`${M}_${A}`,y=`${A}_${M}`;y in f&&f[y]?(oc.dot(f[y].normal)<=r&&(p.push(b.x,b.y,b.z),p.push(T.x,T.y,T.z)),f[y]=null):I in f||(f[I]={index0:c[v],index1:c[_],normal:oc.clone()})}}for(let m in f)if(f[m]){let{index0:x,index1:g}=f[m];wo.fromBufferAttribute(a,x),To.fromBufferAttribute(a,g),p.push(wo.x,wo.y,wo.z),p.push(To.x,To.y,To.z)}this.setAttribute("position",new ue(p,3))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}};var Rr=class s extends He{constructor(t=[new Nt(0,-.5),new Nt(.5,0),new Nt(0,.5)],e=12,n=0,i=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:i},e=Math.floor(e),i=Xt(i,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/e,d=new U,f=new Nt,p=new U,m=new U,x=new U,g=0,u=0;for(let v=0;v<=t.length-1;v++)switch(v){case 0:g=t[v+1].x-t[v].x,u=t[v+1].y-t[v].y,p.x=u*1,p.y=-g,p.z=u*0,x.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case t.length-1:l.push(x.x,x.y,x.z);break;default:g=t[v+1].x-t[v].x,u=t[v+1].y-t[v].y,p.x=u*1,p.y=-g,p.z=u*0,m.copy(p),p.x+=x.x,p.y+=x.y,p.z+=x.z,p.normalize(),l.push(p.x,p.y,p.z),x.copy(m)}for(let v=0;v<=e;v++){let _=n+v*h*i,M=Math.sin(_),A=Math.cos(_);for(let b=0;b<=t.length-1;b++){d.x=t[b].x*M,d.y=t[b].y,d.z=t[b].x*A,o.push(d.x,d.y,d.z),f.x=v/e,f.y=b/(t.length-1),a.push(f.x,f.y);let T=l[3*b+0]*M,I=l[3*b+1],y=l[3*b+0]*A;c.push(T,I,y)}}for(let v=0;v<e;v++)for(let _=0;_<t.length-1;_++){let M=_+v*t.length,A=M,b=M+t.length,T=M+t.length+1,I=M+1;r.push(A,b,I),r.push(T,I,b)}this.setIndex(r),this.setAttribute("position",new ue(o,3)),this.setAttribute("uv",new ue(a,2)),this.setAttribute("normal",new ue(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.points,t.segments,t.phiStart,t.phiLength)}};var Vi=class s extends He{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};let r=t/2,o=e/2,a=Math.floor(n),l=Math.floor(i),c=a+1,h=l+1,d=t/a,f=e/l,p=[],m=[],x=[],g=[];for(let u=0;u<h;u++){let v=u*f-o;for(let _=0;_<c;_++){let M=_*d-r;m.push(M,-v,0),x.push(0,0,1),g.push(_/a),g.push(1-u/l)}}for(let u=0;u<l;u++)for(let v=0;v<a;v++){let _=v+c*u,M=v+c*(u+1),A=v+1+c*(u+1),b=v+1+c*u;p.push(_,M,b),p.push(M,A,b)}this.setIndex(p),this.setAttribute("position",new ue(m,3)),this.setAttribute("normal",new ue(x,3)),this.setAttribute("uv",new ue(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.widthSegments,t.heightSegments)}};var Gi=class s extends He{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],d=new U,f=new U,p=[],m=[],x=[],g=[];for(let u=0;u<=n;u++){let v=[],_=u/n,M=0;u===0&&o===0?M=.5/e:u===n&&l===Math.PI&&(M=-.5/e);for(let A=0;A<=e;A++){let b=A/e;d.x=-t*Math.cos(i+b*r)*Math.sin(o+_*a),d.y=t*Math.cos(o+_*a),d.z=t*Math.sin(i+b*r)*Math.sin(o+_*a),m.push(d.x,d.y,d.z),f.copy(d).normalize(),x.push(f.x,f.y,f.z),g.push(b+M,1-_),v.push(c++)}h.push(v)}for(let u=0;u<n;u++)for(let v=0;v<e;v++){let _=h[u][v+1],M=h[u][v],A=h[u+1][v],b=h[u+1][v+1];(u!==0||o>0)&&p.push(_,M,b),(u!==n-1||l<Math.PI)&&p.push(M,A,b)}this.setIndex(p),this.setAttribute("position",new ue(m,3)),this.setAttribute("normal",new ue(x,3)),this.setAttribute("uv",new ue(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var Rn=class extends Hn{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new kt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new kt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Cc,this.normalScale=new Nt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new An,this.combine=ua,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},Xo=class extends Hn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Uu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},$o=class extends Hn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}};function Ao(s,t){return!s||s.constructor===t?s:typeof t.BYTES_PER_ELEMENT=="number"?new t(s):Array.prototype.slice.call(s)}function Zf(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var Wi=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];t:{e:{let o;n:{i:if(!(t<i)){for(let a=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=i,i=e[++n],t<i)break e}o=e.length;break n}if(!(t>=r)){let a=e[1];t<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=r,r=e[--n-1],t>=r)break e}o=n,n=0;break n}break t}for(;n<o;){let a=n+o>>>1;t<e[a]?o=a:n=a+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let o=0;o!==i;++o)e[o]=n[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Yo=class extends Wi{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:lc,endingEnd:lc}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,o=t+1,a=i[r],l=i[o];if(a===void 0)switch(this.getSettings_().endingStart){case cc:r=t,a=2*e-n;break;case hc:r=i.length-2,a=e+i[r]-i[r+1];break;default:r=t,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case cc:o=t,l=2*n-e;break;case hc:o=1,l=n+i[1]-i[0];break;default:o=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=this._offsetPrev,d=this._offsetNext,f=this._weightPrev,p=this._weightNext,m=(n-e)/(i-e),x=m*m,g=x*m,u=-f*g+2*f*x-f*m,v=(1+f)*g+(-1.5-2*f)*x+(-.5+f)*m+1,_=(-1-p)*g+(1.5+p)*x+.5*m,M=p*g-p*x;for(let A=0;A!==a;++A)r[A]=u*o[h+A]+v*o[c+A]+_*o[l+A]+M*o[d+A];return r}},Zo=class extends Wi{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=(n-e)/(i-e),d=1-h;for(let f=0;f!==a;++f)r[f]=o[c+f]*d+o[l+f]*h;return r}},Jo=class extends Wi{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},hn=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Ao(e,this.TimeBufferType),this.values=Ao(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:Ao(t.times,Array),values:Ao(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Jo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Zo(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Yo(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ur:e=this.InterpolantFactoryMethodDiscrete;break;case ko:e=this.InterpolantFactoryMethodLinear;break;case Co:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ur;case this.InterpolantFactoryMethodLinear:return ko;case this.InterpolantFactoryMethodSmooth:return Co}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t}return this}trim(t,e){let n=this.times,i=n.length,r=0,o=i-1;for(;r!==i&&n[r]<t;)++r;for(;o!==-1&&n[o]>e;)--o;if(++o,r!==0||o!==i){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(i!==void 0&&Zf(i))for(let a=0,l=i.length;a!==l;++a){let c=i[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Co,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],h=t[a+1];if(c!==h&&(a!==1||c!==t[0]))if(i)l=!0;else{let d=a*n,f=d-n,p=d+n;for(let m=0;m!==n;++m){let x=e[d+m];if(x!==e[f+m]||x!==e[p+m]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let d=a*n,f=o*n;for(let p=0;p!==n;++p)e[f+p]=e[d+p]}++o}}if(r>0){t[o]=t[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,i}};hn.prototype.ValueTypeName="";hn.prototype.TimeBufferType=Float32Array;hn.prototype.ValueBufferType=Float32Array;hn.prototype.DefaultInterpolation=ko;var yi=class extends hn{constructor(t,e,n){super(t,e,n)}};yi.prototype.ValueTypeName="bool";yi.prototype.ValueBufferType=Array;yi.prototype.DefaultInterpolation=ur;yi.prototype.InterpolantFactoryMethodLinear=void 0;yi.prototype.InterpolantFactoryMethodSmooth=void 0;var jo=class extends hn{constructor(t,e,n,i){super(t,e,n,i)}};jo.prototype.ValueTypeName="color";var Ko=class extends hn{constructor(t,e,n,i){super(t,e,n,i)}};Ko.prototype.ValueTypeName="number";var Qo=class extends Wi{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-e)/(i-e),c=t*a;for(let h=c+a;c!==h;c+=4)cn.slerpFlat(r,0,o,c-a,o,c,l);return r}},Ir=class extends hn{constructor(t,e,n,i){super(t,e,n,i)}InterpolantFactoryMethodLinear(t){return new Qo(this.times,this.values,this.getValueSize(),t)}};Ir.prototype.ValueTypeName="quaternion";Ir.prototype.InterpolantFactoryMethodSmooth=void 0;var _i=class extends hn{constructor(t,e,n){super(t,e,n)}};_i.prototype.ValueTypeName="string";_i.prototype.ValueBufferType=Array;_i.prototype.DefaultInterpolation=ur;_i.prototype.InterpolantFactoryMethodLinear=void 0;_i.prototype.InterpolantFactoryMethodSmooth=void 0;var ta=class extends hn{constructor(t,e,n,i){super(t,e,n,i)}};ta.prototype.ValueTypeName="vector";var ea=class{constructor(t,e,n){let i=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.abortController=new AbortController,this.itemStart=function(h){a++,r===!1&&i.onStart!==void 0&&i.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,i.onProgress!==void 0&&i.onProgress(h,o,a),o===a&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,d){return c.push(h,d),this},this.removeHandler=function(h){let d=c.indexOf(h);return d!==-1&&c.splice(d,2),this},this.getHandler=function(h){for(let d=0,f=c.length;d<f;d+=2){let p=c[d],m=c[d+1];if(p.global&&(p.lastIndex=0),p.test(h))return m}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}},Ju=new ea,na=class{constructor(t){this.manager=t!==void 0?t:Ju,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}abort(){return this}};na.DEFAULT_MATERIAL_NAME="__DEFAULT";var Pr=class extends ze{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new kt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},qi=class extends Pr{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ze.DEFAULT_UP),this.updateMatrix(),this.groundColor=new kt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},ac=new ee,nu=new U,iu=new U,dc=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Nt(512,512),this.mapType=In,this.map=null,this.mapPass=null,this.matrix=new ee,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ls,this._frameExtents=new Nt(1,1),this._viewportCount=1,this._viewports=[new _e(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;nu.setFromMatrixPosition(t.matrixWorld),e.position.copy(nu),iu.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(iu),e.updateMatrixWorld(),ac.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ac,e.coordinateSystem,e.reversedDepth),e.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(ac)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var Lr=class extends _r{constructor(t=-1,e=1,n=1,i=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,r=n-t,o=n+t,a=i+e,l=i-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},fc=class extends dc{constructor(){super(new Lr(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Xi=class extends Pr{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ze.DEFAULT_UP),this.updateMatrix(),this.target=new ze,this.shadow=new fc}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var ia=class extends Be{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}};var kc="\\[\\]\\.:\\/",Jf=new RegExp("["+kc+"]","g"),Uc="[^"+kc+"]",jf="[^"+kc.replace("\\.","")+"]",Kf=/((?:WC+[\/:])*)/.source.replace("WC",Uc),Qf=/(WCOD+)?/.source.replace("WCOD",jf),tp=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Uc),ep=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Uc),np=new RegExp("^"+Kf+Qf+tp+ep+"$"),ip=["material","materials","bones","map"],pc=class{constructor(t,e,n){let i=n||fe.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},fe=class s{constructor(t,e,n){this.path=e,this.parsedPath=n||s.parseTrackName(e),this.node=s.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new s.Composite(t,e,n):new s(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(Jf,"")}static parseTrackName(t){let e=np.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);ip.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=n(a.children);if(l)return l}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=s.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[i];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?a=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};fe.Composite=pc;fe.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};fe.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};fe.prototype.GetterByBindingType=[fe.prototype._getValue_direct,fe.prototype._getValue_array,fe.prototype._getValue_arrayElement,fe.prototype._getValue_toArray];fe.prototype.SetterByBindingTypeAndVersioning=[[fe.prototype._setValue_direct,fe.prototype._setValue_direct_setNeedsUpdate,fe.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_array,fe.prototype._setValue_array_setNeedsUpdate,fe.prototype._setValue_array_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_arrayElement,fe.prototype._setValue_arrayElement_setNeedsUpdate,fe.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[fe.prototype._setValue_fromArray,fe.prototype._setValue_fromArray_setNeedsUpdate,fe.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var _v=new Float32Array(1);function Nc(s,t,e,n){let i=sp(n);switch(e){case Tc:return s*t;case va:return s*t/i.components*i.byteLength;case ya:return s*t/i.components*i.byteLength;case Ac:return s*t*2/i.components*i.byteLength;case _a:return s*t*2/i.components*i.byteLength;case Ec:return s*t*3/i.components*i.byteLength;case tn:return s*t*4/i.components*i.byteLength;case Ma:return s*t*4/i.components*i.byteLength;case Ur:case Nr:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Fr:case Or:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Sa:case Ta:return Math.max(s,16)*Math.max(t,8)/4;case ba:case wa:return Math.max(s,8)*Math.max(t,8)/2;case Ea:case Aa:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Ca:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Ra:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Ia:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Pa:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case La:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case Da:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case ka:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case Ua:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case Na:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case Fa:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case Oa:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case Ba:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case za:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case Ha:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case Va:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case Ga:case Wa:case qa:return Math.ceil(s/4)*Math.ceil(t/4)*16;case Xa:case $a:return Math.ceil(s/4)*Math.ceil(t/4)*8;case Ya:case Za:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function sp(s){switch(s){case In:case Mc:return{byteLength:1,components:1};case Us:case bc:case Ns:return{byteLength:2,components:1};case ga:case xa:return{byteLength:2,components:4};case bi:case ma:case Pn:return{byteLength:4,components:1};case Sc:case wc:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"180"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="180");function _d(){let s=null,t=!1,e=null,n=null;function i(r,o){e(r,o),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function op(s){let t=new WeakMap;function e(a,l){let c=a.array,h=a.usage,d=c.byteLength,f=s.createBuffer();s.bindBuffer(l,f),s.bufferData(l,c,h),a.onUploadCallback();let p;if(c instanceof Float32Array)p=s.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)p=s.HALF_FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?p=s.HALF_FLOAT:p=s.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=s.SHORT;else if(c instanceof Uint32Array)p=s.UNSIGNED_INT;else if(c instanceof Int32Array)p=s.INT;else if(c instanceof Int8Array)p=s.BYTE;else if(c instanceof Uint8Array)p=s.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)p=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:f,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:d}}function n(a,l,c){let h=l.array,d=l.updateRanges;if(s.bindBuffer(c,a),d.length===0)s.bufferSubData(c,0,h);else{d.sort((p,m)=>p.start-m.start);let f=0;for(let p=1;p<d.length;p++){let m=d[f],x=d[p];x.start<=m.start+m.count+1?m.count=Math.max(m.count,x.start+x.count-m.start):(++f,d[f]=x)}d.length=f+1;for(let p=0,m=d.length;p<m;p++){let x=d[p];s.bufferSubData(c,x.start*h.BYTES_PER_ELEMENT,h,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=t.get(a);l&&(s.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:i,remove:r,update:o}}var ap=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,lp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,cp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,hp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,up=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,dp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,fp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,pp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,mp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,gp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,xp=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,vp=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,yp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,_p=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Mp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,bp=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Sp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,wp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Tp=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ep=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Ap=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Cp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Rp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Ip=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Pp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Lp=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Dp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,kp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Up=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Np=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Fp="gl_FragColor = linearToOutputTexel( gl_FragColor );",Op=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Bp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,zp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Hp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Vp=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Gp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Wp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,qp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Xp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,$p=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Yp=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Zp=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Jp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,jp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Kp=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Qp=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,tm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,em=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,nm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,im=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,rm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,om=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,am=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,cm=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,hm=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,um=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,dm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,fm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,pm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,mm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,gm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,vm=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,ym=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,_m=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Mm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,bm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Sm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Tm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Em=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Am=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Cm=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Rm=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Im=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Pm=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Lm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Dm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,km=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Um=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Nm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Fm=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Om=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Bm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,zm=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Hm=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Vm=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Gm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Wm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,qm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Xm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,$m=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ym=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Zm=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Jm=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,jm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Km=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Qm=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,tg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,eg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,ng=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ig=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,rg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,og=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,ag=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cg=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ug=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,fg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,pg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,mg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,gg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,xg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,yg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,_g=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Mg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Sg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Tg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Eg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Ag=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Cg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ig=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Pg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Dg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Ug=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ng=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Og=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Bg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Wt={alphahash_fragment:ap,alphahash_pars_fragment:lp,alphamap_fragment:cp,alphamap_pars_fragment:hp,alphatest_fragment:up,alphatest_pars_fragment:dp,aomap_fragment:fp,aomap_pars_fragment:pp,batching_pars_vertex:mp,batching_vertex:gp,begin_vertex:xp,beginnormal_vertex:vp,bsdfs:yp,iridescence_fragment:_p,bumpmap_pars_fragment:Mp,clipping_planes_fragment:bp,clipping_planes_pars_fragment:Sp,clipping_planes_pars_vertex:wp,clipping_planes_vertex:Tp,color_fragment:Ep,color_pars_fragment:Ap,color_pars_vertex:Cp,color_vertex:Rp,common:Ip,cube_uv_reflection_fragment:Pp,defaultnormal_vertex:Lp,displacementmap_pars_vertex:Dp,displacementmap_vertex:kp,emissivemap_fragment:Up,emissivemap_pars_fragment:Np,colorspace_fragment:Fp,colorspace_pars_fragment:Op,envmap_fragment:Bp,envmap_common_pars_fragment:zp,envmap_pars_fragment:Hp,envmap_pars_vertex:Vp,envmap_physical_pars_fragment:Qp,envmap_vertex:Gp,fog_vertex:Wp,fog_pars_vertex:qp,fog_fragment:Xp,fog_pars_fragment:$p,gradientmap_pars_fragment:Yp,lightmap_pars_fragment:Zp,lights_lambert_fragment:Jp,lights_lambert_pars_fragment:jp,lights_pars_begin:Kp,lights_toon_fragment:tm,lights_toon_pars_fragment:em,lights_phong_fragment:nm,lights_phong_pars_fragment:im,lights_physical_fragment:sm,lights_physical_pars_fragment:rm,lights_fragment_begin:om,lights_fragment_maps:am,lights_fragment_end:lm,logdepthbuf_fragment:cm,logdepthbuf_pars_fragment:hm,logdepthbuf_pars_vertex:um,logdepthbuf_vertex:dm,map_fragment:fm,map_pars_fragment:pm,map_particle_fragment:mm,map_particle_pars_fragment:gm,metalnessmap_fragment:xm,metalnessmap_pars_fragment:vm,morphinstance_vertex:ym,morphcolor_vertex:_m,morphnormal_vertex:Mm,morphtarget_pars_vertex:bm,morphtarget_vertex:Sm,normal_fragment_begin:wm,normal_fragment_maps:Tm,normal_pars_fragment:Em,normal_pars_vertex:Am,normal_vertex:Cm,normalmap_pars_fragment:Rm,clearcoat_normal_fragment_begin:Im,clearcoat_normal_fragment_maps:Pm,clearcoat_pars_fragment:Lm,iridescence_pars_fragment:Dm,opaque_fragment:km,packing:Um,premultiplied_alpha_fragment:Nm,project_vertex:Fm,dithering_fragment:Om,dithering_pars_fragment:Bm,roughnessmap_fragment:zm,roughnessmap_pars_fragment:Hm,shadowmap_pars_fragment:Vm,shadowmap_pars_vertex:Gm,shadowmap_vertex:Wm,shadowmask_pars_fragment:qm,skinbase_vertex:Xm,skinning_pars_vertex:$m,skinning_vertex:Ym,skinnormal_vertex:Zm,specularmap_fragment:Jm,specularmap_pars_fragment:jm,tonemapping_fragment:Km,tonemapping_pars_fragment:Qm,transmission_fragment:tg,transmission_pars_fragment:eg,uv_pars_fragment:ng,uv_pars_vertex:ig,uv_vertex:sg,worldpos_vertex:rg,background_vert:og,background_frag:ag,backgroundCube_vert:lg,backgroundCube_frag:cg,cube_vert:hg,cube_frag:ug,depth_vert:dg,depth_frag:fg,distanceRGBA_vert:pg,distanceRGBA_frag:mg,equirect_vert:gg,equirect_frag:xg,linedashed_vert:vg,linedashed_frag:yg,meshbasic_vert:_g,meshbasic_frag:Mg,meshlambert_vert:bg,meshlambert_frag:Sg,meshmatcap_vert:wg,meshmatcap_frag:Tg,meshnormal_vert:Eg,meshnormal_frag:Ag,meshphong_vert:Cg,meshphong_frag:Rg,meshphysical_vert:Ig,meshphysical_frag:Pg,meshtoon_vert:Lg,meshtoon_frag:Dg,points_vert:kg,points_frag:Ug,shadow_vert:Ng,shadow_frag:Fg,sprite_vert:Og,sprite_frag:Bg},lt={common:{diffuse:{value:new kt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Bt},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Bt}},envmap:{envMap:{value:null},envMapRotation:{value:new Bt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Bt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Bt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Bt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Bt},normalScale:{value:new Nt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Bt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Bt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Bt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Bt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new kt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new kt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0},uvTransform:{value:new Bt}},sprite:{diffuse:{value:new kt(16777215)},opacity:{value:1},center:{value:new Nt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Bt},alphaMap:{value:null},alphaMapTransform:{value:new Bt},alphaTest:{value:0}}},Gn={basic:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.fog]),vertexShader:Wt.meshbasic_vert,fragmentShader:Wt.meshbasic_frag},lambert:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new kt(0)}}]),vertexShader:Wt.meshlambert_vert,fragmentShader:Wt.meshlambert_frag},phong:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new kt(0)},specular:{value:new kt(1118481)},shininess:{value:30}}]),vertexShader:Wt.meshphong_vert,fragmentShader:Wt.meshphong_frag},standard:{uniforms:$e([lt.common,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.roughnessmap,lt.metalnessmap,lt.fog,lt.lights,{emissive:{value:new kt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Wt.meshphysical_vert,fragmentShader:Wt.meshphysical_frag},toon:{uniforms:$e([lt.common,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.gradientmap,lt.fog,lt.lights,{emissive:{value:new kt(0)}}]),vertexShader:Wt.meshtoon_vert,fragmentShader:Wt.meshtoon_frag},matcap:{uniforms:$e([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,{matcap:{value:null}}]),vertexShader:Wt.meshmatcap_vert,fragmentShader:Wt.meshmatcap_frag},points:{uniforms:$e([lt.points,lt.fog]),vertexShader:Wt.points_vert,fragmentShader:Wt.points_frag},dashed:{uniforms:$e([lt.common,lt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Wt.linedashed_vert,fragmentShader:Wt.linedashed_frag},depth:{uniforms:$e([lt.common,lt.displacementmap]),vertexShader:Wt.depth_vert,fragmentShader:Wt.depth_frag},normal:{uniforms:$e([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,{opacity:{value:1}}]),vertexShader:Wt.meshnormal_vert,fragmentShader:Wt.meshnormal_frag},sprite:{uniforms:$e([lt.sprite,lt.fog]),vertexShader:Wt.sprite_vert,fragmentShader:Wt.sprite_frag},background:{uniforms:{uvTransform:{value:new Bt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Wt.background_vert,fragmentShader:Wt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Bt}},vertexShader:Wt.backgroundCube_vert,fragmentShader:Wt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Wt.cube_vert,fragmentShader:Wt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Wt.equirect_vert,fragmentShader:Wt.equirect_frag},distanceRGBA:{uniforms:$e([lt.common,lt.displacementmap,{referencePosition:{value:new U},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Wt.distanceRGBA_vert,fragmentShader:Wt.distanceRGBA_frag},shadow:{uniforms:$e([lt.lights,lt.fog,{color:{value:new kt(0)},opacity:{value:1}}]),vertexShader:Wt.shadow_vert,fragmentShader:Wt.shadow_frag}};Gn.physical={uniforms:$e([Gn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Bt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Bt},clearcoatNormalScale:{value:new Nt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Bt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Bt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Bt},sheen:{value:0},sheenColor:{value:new kt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Bt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Bt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Bt},transmissionSamplerSize:{value:new Nt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Bt},attenuationDistance:{value:0},attenuationColor:{value:new kt(0)},specularColor:{value:new kt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Bt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Bt},anisotropyVector:{value:new Nt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Bt}}]),vertexShader:Wt.meshphysical_vert,fragmentShader:Wt.meshphysical_frag};var Ja={r:0,b:0,g:0},Ji=new An,zg=new ee;function Hg(s,t,e,n,i,r,o){let a=new kt(0),l=r===!0?0:1,c,h,d=null,f=0,p=null;function m(_){let M=_.isScene===!0?_.background:null;return M&&M.isTexture&&(M=(_.backgroundBlurriness>0?e:t).get(M)),M}function x(_){let M=!1,A=m(_);A===null?u(a,l):A&&A.isColor&&(u(A,1),M=!0);let b=s.xr.getEnvironmentBlendMode();b==="additive"?n.buffers.color.setClear(0,0,0,1,o):b==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(s.autoClear||M)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function g(_,M){let A=m(M);A&&(A.isCubeTexture||A.mapping===Dr)?(h===void 0&&(h=new jt(new De(1,1,1),new Cn({name:"BackgroundCubeMaterial",uniforms:Zi(Gn.backgroundCube.uniforms),vertexShader:Gn.backgroundCube.vertexShader,fragmentShader:Gn.backgroundCube.fragmentShader,side:Ve,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(b,T,I){this.matrixWorld.copyPosition(I.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),Ji.copy(M.backgroundRotation),Ji.x*=-1,Ji.y*=-1,Ji.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(Ji.y*=-1,Ji.z*=-1),h.material.uniforms.envMap.value=A,h.material.uniforms.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=M.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(zg.makeRotationFromEuler(Ji)),h.material.toneMapped=Zt.getTransfer(A.colorSpace)!==se,(d!==A||f!==A.version||p!==s.toneMapping)&&(h.material.needsUpdate=!0,d=A,f=A.version,p=s.toneMapping),h.layers.enableAll(),_.unshift(h,h.geometry,h.material,0,0,null)):A&&A.isTexture&&(c===void 0&&(c=new jt(new Vi(2,2),new Cn({name:"BackgroundMaterial",uniforms:Zi(Gn.background.uniforms),vertexShader:Gn.background.vertexShader,fragmentShader:Gn.background.fragmentShader,side:ti,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=A,c.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,c.material.toneMapped=Zt.getTransfer(A.colorSpace)!==se,A.matrixAutoUpdate===!0&&A.updateMatrix(),c.material.uniforms.uvTransform.value.copy(A.matrix),(d!==A||f!==A.version||p!==s.toneMapping)&&(c.material.needsUpdate=!0,d=A,f=A.version,p=s.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null))}function u(_,M){_.getRGB(Ja,Dc(s)),n.buffers.color.setClear(Ja.r,Ja.g,Ja.b,M,o)}function v(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(_,M=1){a.set(_),l=M,u(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(_){l=_,u(a,l)},render:x,addToRenderList:g,dispose:v}}function Vg(s,t){let e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=f(null),r=i,o=!1;function a(w,C,L,B,H){let G=!1,X=d(B,L,C);r!==X&&(r=X,c(r.object)),G=p(w,B,L,H),G&&m(w,B,L,H),H!==null&&t.update(H,s.ELEMENT_ARRAY_BUFFER),(G||o)&&(o=!1,M(w,C,L,B),H!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(H).buffer))}function l(){return s.createVertexArray()}function c(w){return s.bindVertexArray(w)}function h(w){return s.deleteVertexArray(w)}function d(w,C,L){let B=L.wireframe===!0,H=n[w.id];H===void 0&&(H={},n[w.id]=H);let G=H[C.id];G===void 0&&(G={},H[C.id]=G);let X=G[B];return X===void 0&&(X=f(l()),G[B]=X),X}function f(w){let C=[],L=[],B=[];for(let H=0;H<e;H++)C[H]=0,L[H]=0,B[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:L,attributeDivisors:B,object:w,attributes:{},index:null}}function p(w,C,L,B){let H=r.attributes,G=C.attributes,X=0,Q=L.getAttributes();for(let V in Q)if(Q[V].location>=0){let ct=H[V],gt=G[V];if(gt===void 0&&(V==="instanceMatrix"&&w.instanceMatrix&&(gt=w.instanceMatrix),V==="instanceColor"&&w.instanceColor&&(gt=w.instanceColor)),ct===void 0||ct.attribute!==gt||gt&&ct.data!==gt.data)return!0;X++}return r.attributesNum!==X||r.index!==B}function m(w,C,L,B){let H={},G=C.attributes,X=0,Q=L.getAttributes();for(let V in Q)if(Q[V].location>=0){let ct=G[V];ct===void 0&&(V==="instanceMatrix"&&w.instanceMatrix&&(ct=w.instanceMatrix),V==="instanceColor"&&w.instanceColor&&(ct=w.instanceColor));let gt={};gt.attribute=ct,ct&&ct.data&&(gt.data=ct.data),H[V]=gt,X++}r.attributes=H,r.attributesNum=X,r.index=B}function x(){let w=r.newAttributes;for(let C=0,L=w.length;C<L;C++)w[C]=0}function g(w){u(w,0)}function u(w,C){let L=r.newAttributes,B=r.enabledAttributes,H=r.attributeDivisors;L[w]=1,B[w]===0&&(s.enableVertexAttribArray(w),B[w]=1),H[w]!==C&&(s.vertexAttribDivisor(w,C),H[w]=C)}function v(){let w=r.newAttributes,C=r.enabledAttributes;for(let L=0,B=C.length;L<B;L++)C[L]!==w[L]&&(s.disableVertexAttribArray(L),C[L]=0)}function _(w,C,L,B,H,G,X){X===!0?s.vertexAttribIPointer(w,C,L,H,G):s.vertexAttribPointer(w,C,L,B,H,G)}function M(w,C,L,B){x();let H=B.attributes,G=L.getAttributes(),X=C.defaultAttributeValues;for(let Q in G){let V=G[Q];if(V.location>=0){let ot=H[Q];if(ot===void 0&&(Q==="instanceMatrix"&&w.instanceMatrix&&(ot=w.instanceMatrix),Q==="instanceColor"&&w.instanceColor&&(ot=w.instanceColor)),ot!==void 0){let ct=ot.normalized,gt=ot.itemSize,Ht=t.get(ot);if(Ht===void 0)continue;let ie=Ht.buffer,ce=Ht.type,Qt=Ht.bytesPerElement,Z=ce===s.INT||ce===s.UNSIGNED_INT||ot.gpuType===ma;if(ot.isInterleavedBufferAttribute){let K=ot.data,xt=K.stride,Ut=ot.offset;if(K.isInstancedInterleavedBuffer){for(let At=0;At<V.locationSize;At++)u(V.location+At,K.meshPerAttribute);w.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let At=0;At<V.locationSize;At++)g(V.location+At);s.bindBuffer(s.ARRAY_BUFFER,ie);for(let At=0;At<V.locationSize;At++)_(V.location+At,gt/V.locationSize,ce,ct,xt*Qt,(Ut+gt/V.locationSize*At)*Qt,Z)}else{if(ot.isInstancedBufferAttribute){for(let K=0;K<V.locationSize;K++)u(V.location+K,ot.meshPerAttribute);w.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=ot.meshPerAttribute*ot.count)}else for(let K=0;K<V.locationSize;K++)g(V.location+K);s.bindBuffer(s.ARRAY_BUFFER,ie);for(let K=0;K<V.locationSize;K++)_(V.location+K,gt/V.locationSize,ce,ct,gt*Qt,gt/V.locationSize*K*Qt,Z)}}else if(X!==void 0){let ct=X[Q];if(ct!==void 0)switch(ct.length){case 2:s.vertexAttrib2fv(V.location,ct);break;case 3:s.vertexAttrib3fv(V.location,ct);break;case 4:s.vertexAttrib4fv(V.location,ct);break;default:s.vertexAttrib1fv(V.location,ct)}}}}v()}function A(){I();for(let w in n){let C=n[w];for(let L in C){let B=C[L];for(let H in B)h(B[H].object),delete B[H];delete C[L]}delete n[w]}}function b(w){if(n[w.id]===void 0)return;let C=n[w.id];for(let L in C){let B=C[L];for(let H in B)h(B[H].object),delete B[H];delete C[L]}delete n[w.id]}function T(w){for(let C in n){let L=n[C];if(L[w.id]===void 0)continue;let B=L[w.id];for(let H in B)h(B[H].object),delete B[H];delete L[w.id]}}function I(){y(),o=!0,r!==i&&(r=i,c(r.object))}function y(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:I,resetDefaultState:y,dispose:A,releaseStatesOfGeometry:b,releaseStatesOfProgram:T,initAttributes:x,enableAttribute:g,disableUnusedAttributes:v}}function Gg(s,t,e){let n;function i(c){n=c}function r(c,h){s.drawArrays(n,c,h),e.update(h,n,1)}function o(c,h,d){d!==0&&(s.drawArraysInstanced(n,c,h,d),e.update(h,n,d))}function a(c,h,d){if(d===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,d);let p=0;for(let m=0;m<d;m++)p+=h[m];e.update(p,n,1)}function l(c,h,d,f){if(d===0)return;let p=t.get("WEBGL_multi_draw");if(p===null)for(let m=0;m<c.length;m++)o(c[m],h[m],f[m]);else{p.multiDrawArraysInstancedWEBGL(n,c,0,h,0,f,0,d);let m=0;for(let x=0;x<d;x++)m+=h[x]*f[x];e.update(m,n,1)}}this.setMode=i,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function Wg(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let T=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(T){return!(T!==tn&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){let I=T===Ns&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(T!==In&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==Pn&&!I)}function l(T){if(T==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let d=e.logarithmicDepthBuffer===!0,f=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),p=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),m=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=s.getParameter(s.MAX_TEXTURE_SIZE),g=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),u=s.getParameter(s.MAX_VERTEX_ATTRIBS),v=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),_=s.getParameter(s.MAX_VARYING_VECTORS),M=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),A=m>0,b=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:g,maxAttributes:u,maxVertexUniforms:v,maxVaryings:_,maxFragmentUniforms:M,vertexTextures:A,maxSamples:b}}function qg(s){let t=this,e=null,n=0,i=!1,r=!1,o=new Nn,a=new Bt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(d,f){let p=d.length!==0||f||n!==0||i;return i=f,n=d.length,p},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,f){e=h(d,f,0)},this.setState=function(d,f,p){let m=d.clippingPlanes,x=d.clipIntersection,g=d.clipShadows,u=s.get(d);if(!i||m===null||m.length===0||r&&!g)r?h(null):c();else{let v=r?0:n,_=v*4,M=u.clippingState||null;l.value=M,M=h(m,f,_,p);for(let A=0;A!==_;++A)M[A]=e[A];u.clippingState=M,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(d,f,p,m){let x=d!==null?d.length:0,g=null;if(x!==0){if(g=l.value,m!==!0||g===null){let u=p+x*4,v=f.matrixWorldInverse;a.getNormalMatrix(v),(g===null||g.length<u)&&(g=new Float32Array(u));for(let _=0,M=p;_!==x;++_,M+=4)o.copy(d[_]).applyMatrix4(v,a),o.normal.toArray(g,M),g[M+3]=o.constant}l.value=g,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function Xg(s){let t=new WeakMap;function e(o,a){return a===da?o.mapping=$i:a===fa&&(o.mapping=Yi),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===da||a===fa)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Ho(l.height);return c.fromEquirectangularTexture(s,o),t.set(o,c),o.addEventListener("dispose",i),e(c.texture,o.mapping)}else return null}}return o}function i(o){let a=o.target;a.removeEventListener("dispose",i);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var zs=4,ju=[.125,.215,.35,.446,.526,.582],Qi=20,Fc=new Lr,Ku=new kt,Oc=null,Bc=0,zc=0,Hc=!1,Ki=(1+Math.sqrt(5))/2,Bs=1/Ki,Qu=[new U(-Ki,Bs,0),new U(Ki,Bs,0),new U(-Bs,0,Ki),new U(Bs,0,Ki),new U(0,Ki,-Bs),new U(0,Ki,Bs),new U(-1,1,-1),new U(1,1,-1),new U(-1,1,1),new U(1,1,1)],$g=new U,Qa=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100,r={}){let{size:o=256,position:a=$g}=r;Oc=this._renderer.getRenderTarget(),Bc=this._renderer.getActiveCubeFace(),zc=this._renderer.getActiveMipmapLevel(),Hc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);let l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(t,n,i,l,a),e>0&&this._blur(l,0,0,e),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=nd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ed(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Oc,Bc,zc),this._renderer.xr.enabled=Hc,t.scissorTest=!1,ja(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===$i||t.mapping===Yi?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Oc=this._renderer.getRenderTarget(),Bc=this._renderer.getActiveCubeFace(),zc=this._renderer.getActiveMipmapLevel(),Hc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:En,minFilter:En,generateMipmaps:!1,type:Ns,format:tn,colorSpace:Oi,depthBuffer:!1},i=td(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=td(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Yg(r)),this._blurMaterial=Zg(r,t,e)}return i}_compileMaterial(t){let e=new jt(this._lodPlanes[0],t);this._renderer.compile(e,Fc)}_sceneToCubeUV(t,e,n,i,r){let l=new Be(90,1,e,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],d=this._renderer,f=d.autoClear,p=d.toneMapping;d.getClearColor(Ku),d.toneMapping=si,d.autoClear=!1,d.state.buffers.depth.getReversed()&&(d.setRenderTarget(i),d.clearDepth(),d.setRenderTarget(null));let x=new Re({name:"PMREM.Background",side:Ve,depthWrite:!1,depthTest:!1}),g=new jt(new De,x),u=!1,v=t.background;v?v.isColor&&(x.color.copy(v),t.background=null,u=!0):(x.color.copy(Ku),u=!0);for(let _=0;_<6;_++){let M=_%3;M===0?(l.up.set(0,c[_],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+h[_],r.y,r.z)):M===1?(l.up.set(0,0,c[_]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+h[_],r.z)):(l.up.set(0,c[_],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+h[_]));let A=this._cubeSize;ja(i,M*A,_>2?A:0,A,A),d.setRenderTarget(i),u&&d.render(g,l),d.render(t,l)}g.geometry.dispose(),g.material.dispose(),d.toneMapping=p,d.autoClear=f,t.background=v}_textureToCubeUV(t,e){let n=this._renderer,i=t.mapping===$i||t.mapping===Yi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=nd()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ed());let r=i?this._cubemapMaterial:this._equirectMaterial,o=new jt(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;ja(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(o,Fc)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let i=this._lodPlanes.length;for(let r=1;r<i;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=Qu[(i-r-1)%Qu.length];this._blur(t,r-1,r,o,a)}e.autoClear=n}_blur(t,e,n,i,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,i,"latitudinal",r),this._halfBlur(o,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,d=new jt(this._lodPlanes[i],c),f=c.uniforms,p=this._sizeLods[n]-1,m=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*Qi-1),x=r/m,g=isFinite(r)?1+Math.floor(h*x):Qi;g>Qi&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${Qi}`);let u=[],v=0;for(let T=0;T<Qi;++T){let I=T/x,y=Math.exp(-I*I/2);u.push(y),T===0?v+=y:T<g&&(v+=2*y)}for(let T=0;T<u.length;T++)u[T]=u[T]/v;f.envMap.value=t.texture,f.samples.value=g,f.weights.value=u,f.latitudinal.value=o==="latitudinal",a&&(f.poleAxis.value=a);let{_lodMax:_}=this;f.dTheta.value=m,f.mipInt.value=_-n;let M=this._sizeLods[i],A=3*M*(i>_-zs?i-_+zs:0),b=4*(this._cubeSize-M);ja(e,A,b,3*M,2*M),l.setRenderTarget(e),l.render(d,Fc)}};function Yg(s){let t=[],e=[],n=[],i=s,r=s-zs+1+ju.length;for(let o=0;o<r;o++){let a=Math.pow(2,i);e.push(a);let l=1/a;o>s-zs?l=ju[o-s+zs-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,d=1+c,f=[h,h,d,h,d,d,h,h,d,d,h,d],p=6,m=6,x=3,g=2,u=1,v=new Float32Array(x*m*p),_=new Float32Array(g*m*p),M=new Float32Array(u*m*p);for(let b=0;b<p;b++){let T=b%3*2/3-1,I=b>2?0:-1,y=[T,I,0,T+2/3,I,0,T+2/3,I+1,0,T,I,0,T+2/3,I+1,0,T,I+1,0];v.set(y,x*m*b),_.set(f,g*m*b);let w=[b,b,b,b,b,b];M.set(w,u*m*b)}let A=new He;A.setAttribute("position",new Ae(v,x)),A.setAttribute("uv",new Ae(_,g)),A.setAttribute("faceIndex",new Ae(M,u)),t.push(A),i>zs&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function td(s,t,e){let n=new Bn(s,t,e);return n.texture.mapping=Dr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ja(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function Zg(s,t,e){let n=new Float32Array(Qi),i=new U(0,1,0);return new Cn({name:"SphericalGaussianBlur",defines:{n:Qi,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:ii,depthTest:!1,depthWrite:!1})}function ed(){return new Cn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:ii,depthTest:!1,depthWrite:!1})}function nd(){return new Cn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:ii,depthTest:!1,depthWrite:!1})}function jc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Jg(s){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===da||l===fa,h=l===$i||l===Yi;if(c||h){let d=t.get(a),f=d!==void 0?d.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==f)return e===null&&(e=new Qa(s)),d=c?e.fromEquirectangular(a,d):e.fromCubemap(a,d),d.texture.pmremVersion=a.pmremVersion,t.set(a,d),d.texture;if(d!==void 0)return d.texture;{let p=a.image;return c&&p&&p.height>0||h&&p&&i(p)?(e===null&&(e=new Qa(s)),d=c?e.fromEquirectangular(a):e.fromCubemap(a),d.texture.pmremVersion=a.pmremVersion,t.set(a,d),a.addEventListener("dispose",r),d.texture):null}}}return a}function i(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function jg(s){let t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let i=e(n);return i===null&&As("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function Kg(s,t,e,n){let i={},r=new WeakMap;function o(d){let f=d.target;f.index!==null&&t.remove(f.index);for(let m in f.attributes)t.remove(f.attributes[m]);f.removeEventListener("dispose",o),delete i[f.id];let p=r.get(f);p&&(t.remove(p),r.delete(f)),n.releaseStatesOfGeometry(f),f.isInstancedBufferGeometry===!0&&delete f._maxInstanceCount,e.memory.geometries--}function a(d,f){return i[f.id]===!0||(f.addEventListener("dispose",o),i[f.id]=!0,e.memory.geometries++),f}function l(d){let f=d.attributes;for(let p in f)t.update(f[p],s.ARRAY_BUFFER)}function c(d){let f=[],p=d.index,m=d.attributes.position,x=0;if(p!==null){let v=p.array;x=p.version;for(let _=0,M=v.length;_<M;_+=3){let A=v[_+0],b=v[_+1],T=v[_+2];f.push(A,b,b,T,T,A)}}else if(m!==void 0){let v=m.array;x=m.version;for(let _=0,M=v.length/3-1;_<M;_+=3){let A=_+0,b=_+1,T=_+2;f.push(A,b,b,T,T,A)}}else return;let g=new(Lc(f)?yr:vr)(f,1);g.version=x;let u=r.get(d);u&&t.remove(u),r.set(d,g)}function h(d){let f=r.get(d);if(f){let p=d.index;p!==null&&f.version<p.version&&c(d)}else c(d);return r.get(d)}return{get:a,update:l,getWireframeAttribute:h}}function Qg(s,t,e){let n;function i(f){n=f}let r,o;function a(f){r=f.type,o=f.bytesPerElement}function l(f,p){s.drawElements(n,p,r,f*o),e.update(p,n,1)}function c(f,p,m){m!==0&&(s.drawElementsInstanced(n,p,r,f*o,m),e.update(p,n,m))}function h(f,p,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,r,f,0,m);let g=0;for(let u=0;u<m;u++)g+=p[u];e.update(g,n,1)}function d(f,p,m,x){if(m===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let u=0;u<f.length;u++)c(f[u]/o,p[u],x[u]);else{g.multiDrawElementsInstancedWEBGL(n,p,0,r,f,0,x,0,m);let u=0;for(let v=0;v<m;v++)u+=p[v]*x[v];e.update(u,n,1)}}this.setMode=i,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=d}function t0(s){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case s.TRIANGLES:e.triangles+=a*(r/3);break;case s.LINES:e.lines+=a*(r/2);break;case s.LINE_STRIP:e.lines+=a*(r-1);break;case s.LINE_LOOP:e.lines+=a*r;break;case s.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function e0(s,t,e){let n=new WeakMap,i=new _e;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=h!==void 0?h.length:0,f=n.get(a);if(f===void 0||f.count!==d){let y=function(){T.dispose(),n.delete(a),a.removeEventListener("dispose",y)};f!==void 0&&f.texture.dispose();let p=a.morphAttributes.position!==void 0,m=a.morphAttributes.normal!==void 0,x=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],u=a.morphAttributes.normal||[],v=a.morphAttributes.color||[],_=0;p===!0&&(_=1),m===!0&&(_=2),x===!0&&(_=3);let M=a.attributes.position.count*_,A=1;M>t.maxTextureSize&&(A=Math.ceil(M/t.maxTextureSize),M=t.maxTextureSize);let b=new Float32Array(M*A*4*d),T=new mr(b,M,A,d);T.type=Pn,T.needsUpdate=!0;let I=_*4;for(let w=0;w<d;w++){let C=g[w],L=u[w],B=v[w],H=M*A*4*w;for(let G=0;G<C.count;G++){let X=G*I;p===!0&&(i.fromBufferAttribute(C,G),b[H+X+0]=i.x,b[H+X+1]=i.y,b[H+X+2]=i.z,b[H+X+3]=0),m===!0&&(i.fromBufferAttribute(L,G),b[H+X+4]=i.x,b[H+X+5]=i.y,b[H+X+6]=i.z,b[H+X+7]=0),x===!0&&(i.fromBufferAttribute(B,G),b[H+X+8]=i.x,b[H+X+9]=i.y,b[H+X+10]=i.z,b[H+X+11]=B.itemSize===4?i.w:1)}}f={count:d,texture:T,size:new Nt(M,A)},n.set(a,f),a.addEventListener("dispose",y)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(s,"morphTexture",o.morphTexture,e);else{let p=0;for(let x=0;x<c.length;x++)p+=c[x];let m=a.morphTargetsRelative?1:1-p;l.getUniforms().setValue(s,"morphTargetBaseInfluence",m),l.getUniforms().setValue(s,"morphTargetInfluences",c)}l.getUniforms().setValue(s,"morphTargetsTexture",f.texture,e),l.getUniforms().setValue(s,"morphTargetsTextureSize",f.size)}return{update:r}}function n0(s,t,e,n){let i=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,d=t.get(l,h);if(i.get(d)!==c&&(t.update(d),i.set(d,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),i.get(l)!==c&&(e.update(l.instanceMatrix,s.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,s.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){let f=l.skeleton;i.get(f)!==c&&(f.update(),i.set(f,c))}return d}function o(){i=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var Md=new je,id=new Er(1,1),bd=new mr,Sd=new Bo,wd=new Mr,sd=[],rd=[],od=new Float32Array(16),ad=new Float32Array(9),ld=new Float32Array(4);function Vs(s,t,e){let n=s[0];if(n<=0||n>0)return s;let i=t*e,r=sd[i];if(r===void 0&&(r=new Float32Array(i),sd[i]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,s[o].toArray(r,a)}return r}function ke(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Ue(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function el(s,t){let e=rd[t];e===void 0&&(e=new Int32Array(t),rd[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function i0(s,t){let e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function s0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ke(e,t))return;s.uniform2fv(this.addr,t),Ue(e,t)}}function r0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(ke(e,t))return;s.uniform3fv(this.addr,t),Ue(e,t)}}function o0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ke(e,t))return;s.uniform4fv(this.addr,t),Ue(e,t)}}function a0(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ke(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Ue(e,t)}else{if(ke(e,n))return;ld.set(n),s.uniformMatrix2fv(this.addr,!1,ld),Ue(e,n)}}function l0(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ke(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Ue(e,t)}else{if(ke(e,n))return;ad.set(n),s.uniformMatrix3fv(this.addr,!1,ad),Ue(e,n)}}function c0(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(ke(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Ue(e,t)}else{if(ke(e,n))return;od.set(n),s.uniformMatrix4fv(this.addr,!1,od),Ue(e,n)}}function h0(s,t){let e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function u0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ke(e,t))return;s.uniform2iv(this.addr,t),Ue(e,t)}}function d0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ke(e,t))return;s.uniform3iv(this.addr,t),Ue(e,t)}}function f0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ke(e,t))return;s.uniform4iv(this.addr,t),Ue(e,t)}}function p0(s,t){let e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function m0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(ke(e,t))return;s.uniform2uiv(this.addr,t),Ue(e,t)}}function g0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(ke(e,t))return;s.uniform3uiv(this.addr,t),Ue(e,t)}}function x0(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(ke(e,t))return;s.uniform4uiv(this.addr,t),Ue(e,t)}}function v0(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(id.compareFunction=Rc,r=id):r=Md,e.setTexture2D(t||r,i)}function y0(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Sd,i)}function _0(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||wd,i)}function M0(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||bd,i)}function b0(s){switch(s){case 5126:return i0;case 35664:return s0;case 35665:return r0;case 35666:return o0;case 35674:return a0;case 35675:return l0;case 35676:return c0;case 5124:case 35670:return h0;case 35667:case 35671:return u0;case 35668:case 35672:return d0;case 35669:case 35673:return f0;case 5125:return p0;case 36294:return m0;case 36295:return g0;case 36296:return x0;case 35678:case 36198:case 36298:case 36306:case 35682:return v0;case 35679:case 36299:case 36307:return y0;case 35680:case 36300:case 36308:case 36293:return _0;case 36289:case 36303:case 36311:case 36292:return M0}}function S0(s,t){s.uniform1fv(this.addr,t)}function w0(s,t){let e=Vs(t,this.size,2);s.uniform2fv(this.addr,e)}function T0(s,t){let e=Vs(t,this.size,3);s.uniform3fv(this.addr,e)}function E0(s,t){let e=Vs(t,this.size,4);s.uniform4fv(this.addr,e)}function A0(s,t){let e=Vs(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function C0(s,t){let e=Vs(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function R0(s,t){let e=Vs(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function I0(s,t){s.uniform1iv(this.addr,t)}function P0(s,t){s.uniform2iv(this.addr,t)}function L0(s,t){s.uniform3iv(this.addr,t)}function D0(s,t){s.uniform4iv(this.addr,t)}function k0(s,t){s.uniform1uiv(this.addr,t)}function U0(s,t){s.uniform2uiv(this.addr,t)}function N0(s,t){s.uniform3uiv(this.addr,t)}function F0(s,t){s.uniform4uiv(this.addr,t)}function O0(s,t,e){let n=this.cache,i=t.length,r=el(e,i);ke(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture2D(t[o]||Md,r[o])}function B0(s,t,e){let n=this.cache,i=t.length,r=el(e,i);ke(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture3D(t[o]||Sd,r[o])}function z0(s,t,e){let n=this.cache,i=t.length,r=el(e,i);ke(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTextureCube(t[o]||wd,r[o])}function H0(s,t,e){let n=this.cache,i=t.length,r=el(e,i);ke(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture2DArray(t[o]||bd,r[o])}function V0(s){switch(s){case 5126:return S0;case 35664:return w0;case 35665:return T0;case 35666:return E0;case 35674:return A0;case 35675:return C0;case 35676:return R0;case 5124:case 35670:return I0;case 35667:case 35671:return P0;case 35668:case 35672:return L0;case 35669:case 35673:return D0;case 5125:return k0;case 36294:return U0;case 36295:return N0;case 36296:return F0;case 35678:case 36198:case 36298:case 36306:case 35682:return O0;case 35679:case 36299:case 36307:return B0;case 35680:case 36300:case 36308:case 36293:return z0;case 36289:case 36303:case 36311:case 36292:return H0}}var Gc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=b0(e.type)}},Wc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=V0(e.type)}},qc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let i=this.seq;for(let r=0,o=i.length;r!==o;++r){let a=i[r];a.setValue(t,e[a.id],n)}}},Vc=/(\w+)(\])?(\[|\.)?/g;function cd(s,t){s.seq.push(t),s.map[t.id]=t}function G0(s,t,e){let n=s.name,i=n.length;for(Vc.lastIndex=0;;){let r=Vc.exec(n),o=Vc.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===i){cd(e,c===void 0?new Gc(a,s,t):new Wc(a,s,t));break}else{let d=e.map[a];d===void 0&&(d=new qc(a),cd(e,d)),e=d}}}var Hs=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let r=t.getActiveUniform(e,i),o=t.getUniformLocation(e,r.name);G0(r,o,this)}}setValue(t,e,n,i){let r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){let i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,i)}}static seqWithValue(t,e){let n=[];for(let i=0,r=t.length;i!==r;++i){let o=t[i];o.id in e&&n.push(o)}return n}};function hd(s,t,e){let n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}var W0=37297,q0=0;function X0(s,t){let e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=i;o<r;o++){let a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}var ud=new Bt;function $0(s){Zt._getMatrix(ud,Zt.workingColorSpace,s);let t=`mat3( ${ud.elements.map(e=>e.toFixed(4))} )`;switch(Zt.getTransfer(s)){case dr:return[t,"LinearTransferOETF"];case se:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function dd(s,t,e){let n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";let o=/ERROR: 0:(\d+)/.exec(r);if(o){let a=parseInt(o[1]);return e.toUpperCase()+`

`+r+`

`+X0(s.getShaderSource(t),a)}else return r}function Y0(s,t){let e=$0(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Z0(s,t){let e;switch(t){case Au:e="Linear";break;case Cu:e="Reinhard";break;case Ru:e="Cineon";break;case Iu:e="ACESFilmic";break;case Lu:e="AgX";break;case Du:e="Neutral";break;case Pu:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var Ka=new U;function J0(){Zt.getLuminanceCoefficients(Ka);let s=Ka.x.toFixed(4),t=Ka.y.toFixed(4),e=Ka.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function j0(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Br).join(`
`)}function K0(s){let t=[];for(let e in s){let n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Q0(s,t){let e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let r=s.getActiveAttrib(t,i),o=r.name,a=1;r.type===s.FLOAT_MAT2&&(a=2),r.type===s.FLOAT_MAT3&&(a=3),r.type===s.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:s.getAttribLocation(t,o),locationSize:a}}return e}function Br(s){return s!==""}function fd(s,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function pd(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var tx=/^[ \t]*#include +<([\w\d./]+)>/gm;function Xc(s){return s.replace(tx,nx)}var ex=new Map;function nx(s,t){let e=Wt[t];if(e===void 0){let n=ex.get(t);if(n!==void 0)e=Wt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Xc(e)}var ix=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function md(s){return s.replace(ix,sx)}function sx(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function gd(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function rx(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===gc?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===ou?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Vn&&(t="SHADOWMAP_TYPE_VSM"),t}function ox(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case $i:case Yi:t="ENVMAP_TYPE_CUBE";break;case Dr:t="ENVMAP_TYPE_CUBE_UV";break}return t}function ax(s){let t="ENVMAP_MODE_REFLECTION";return s.envMap&&s.envMapMode===Yi&&(t="ENVMAP_MODE_REFRACTION"),t}function lx(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case ua:t="ENVMAP_BLENDING_MULTIPLY";break;case Tu:t="ENVMAP_BLENDING_MIX";break;case Eu:t="ENVMAP_BLENDING_ADD";break}return t}function cx(s){let t=s.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function hx(s,t,e,n){let i=s.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=rx(e),c=ox(e),h=ax(e),d=lx(e),f=cx(e),p=j0(e),m=K0(r),x=i.createProgram(),g,u,v=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(g=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(Br).join(`
`),g.length>0&&(g+=`
`),u=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(Br).join(`
`),u.length>0&&(u+=`
`)):(g=[gd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Br).join(`
`),u=[gd(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+d:"",f?"#define CUBEUV_TEXEL_WIDTH "+f.texelWidth:"",f?"#define CUBEUV_TEXEL_HEIGHT "+f.texelHeight:"",f?"#define CUBEUV_MAX_MIP "+f.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==si?"#define TONE_MAPPING":"",e.toneMapping!==si?Wt.tonemapping_pars_fragment:"",e.toneMapping!==si?Z0("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Wt.colorspace_pars_fragment,Y0("linearToOutputTexel",e.outputColorSpace),J0(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Br).join(`
`)),o=Xc(o),o=fd(o,e),o=pd(o,e),a=Xc(a),a=fd(a,e),a=pd(a,e),o=md(o),a=md(a),e.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,u=["#define varying in",e.glslVersion===Pc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Pc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+u);let _=v+g+o,M=v+u+a,A=hd(i,i.VERTEX_SHADER,_),b=hd(i,i.FRAGMENT_SHADER,M);i.attachShader(x,A),i.attachShader(x,b),e.index0AttributeName!==void 0?i.bindAttribLocation(x,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(x,0,"position"),i.linkProgram(x);function T(C){if(s.debug.checkShaderErrors){let L=i.getProgramInfoLog(x)||"",B=i.getShaderInfoLog(A)||"",H=i.getShaderInfoLog(b)||"",G=L.trim(),X=B.trim(),Q=H.trim(),V=!0,ot=!0;if(i.getProgramParameter(x,i.LINK_STATUS)===!1)if(V=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,x,A,b);else{let ct=dd(i,A,"vertex"),gt=dd(i,b,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(x,i.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+G+`
`+ct+`
`+gt)}else G!==""?console.warn("THREE.WebGLProgram: Program Info Log:",G):(X===""||Q==="")&&(ot=!1);ot&&(C.diagnostics={runnable:V,programLog:G,vertexShader:{log:X,prefix:g},fragmentShader:{log:Q,prefix:u}})}i.deleteShader(A),i.deleteShader(b),I=new Hs(i,x),y=Q0(i,x)}let I;this.getUniforms=function(){return I===void 0&&T(this),I};let y;this.getAttributes=function(){return y===void 0&&T(this),y};let w=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return w===!1&&(w=i.getProgramParameter(x,W0)),w},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(x),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=q0++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=A,this.fragmentShader=b,this}var ux=0,$c=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new Yc(t),e.set(t,n)),n}},Yc=class{constructor(t){this.id=ux++,this.code=t,this.usedTimes=0}};function dx(s,t,e,n,i,r,o){let a=new xr,l=new $c,c=new Set,h=[],d=i.logarithmicDepthBuffer,f=i.vertexTextures,p=i.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(y){return c.add(y),y===0?"uv":`uv${y}`}function g(y,w,C,L,B){let H=L.fog,G=B.geometry,X=y.isMeshStandardMaterial?L.environment:null,Q=(y.isMeshStandardMaterial?e:t).get(y.envMap||X),V=Q&&Q.mapping===Dr?Q.image.height:null,ot=m[y.type];y.precision!==null&&(p=i.getMaxPrecision(y.precision),p!==y.precision&&console.warn("THREE.WebGLProgram.getParameters:",y.precision,"not supported, using",p,"instead."));let ct=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,gt=ct!==void 0?ct.length:0,Ht=0;G.morphAttributes.position!==void 0&&(Ht=1),G.morphAttributes.normal!==void 0&&(Ht=2),G.morphAttributes.color!==void 0&&(Ht=3);let ie,ce,Qt,Z;if(ot){let te=Gn[ot];ie=te.vertexShader,ce=te.fragmentShader}else ie=y.vertexShader,ce=y.fragmentShader,l.update(y),Qt=l.getVertexShaderID(y),Z=l.getFragmentShaderID(y);let K=s.getRenderTarget(),xt=s.state.buffers.depth.getReversed(),Ut=B.isInstancedMesh===!0,At=B.isBatchedMesh===!0,$t=!!y.map,We=!!y.matcap,P=!!Q,pe=!!y.aoMap,Ot=!!y.lightMap,Lt=!!y.bumpMap,_t=!!y.normalMap,me=!!y.displacementMap,Mt=!!y.emissiveMap,Vt=!!y.metalnessMap,Fe=!!y.roughnessMap,be=y.anisotropy>0,R=y.clearcoat>0,S=y.dispersion>0,z=y.iridescence>0,Y=y.sheen>0,j=y.transmission>0,$=be&&!!y.anisotropyMap,Et=R&&!!y.clearcoatMap,st=R&&!!y.clearcoatNormalMap,bt=R&&!!y.clearcoatRoughnessMap,wt=z&&!!y.iridescenceMap,nt=z&&!!y.iridescenceThicknessMap,dt=Y&&!!y.sheenColorMap,Pt=Y&&!!y.sheenRoughnessMap,Tt=!!y.specularMap,ht=!!y.specularColorMap,zt=!!y.specularIntensityMap,D=j&&!!y.transmissionMap,it=j&&!!y.thicknessMap,at=!!y.gradientMap,mt=!!y.alphaMap,tt=y.alphaTest>0,J=!!y.alphaHash,yt=!!y.extensions,Ft=si;y.toneMapped&&(K===null||K.isXRRenderTarget===!0)&&(Ft=s.toneMapping);let he={shaderID:ot,shaderType:y.type,shaderName:y.name,vertexShader:ie,fragmentShader:ce,defines:y.defines,customVertexShaderID:Qt,customFragmentShaderID:Z,isRawShaderMaterial:y.isRawShaderMaterial===!0,glslVersion:y.glslVersion,precision:p,batching:At,batchingColor:At&&B._colorsTexture!==null,instancing:Ut,instancingColor:Ut&&B.instanceColor!==null,instancingMorph:Ut&&B.morphTexture!==null,supportsVertexTextures:f,outputColorSpace:K===null?s.outputColorSpace:K.isXRRenderTarget===!0?K.texture.colorSpace:Oi,alphaToCoverage:!!y.alphaToCoverage,map:$t,matcap:We,envMap:P,envMapMode:P&&Q.mapping,envMapCubeUVHeight:V,aoMap:pe,lightMap:Ot,bumpMap:Lt,normalMap:_t,displacementMap:f&&me,emissiveMap:Mt,normalMapObjectSpace:_t&&y.normalMapType===Fu,normalMapTangentSpace:_t&&y.normalMapType===Cc,metalnessMap:Vt,roughnessMap:Fe,anisotropy:be,anisotropyMap:$,clearcoat:R,clearcoatMap:Et,clearcoatNormalMap:st,clearcoatRoughnessMap:bt,dispersion:S,iridescence:z,iridescenceMap:wt,iridescenceThicknessMap:nt,sheen:Y,sheenColorMap:dt,sheenRoughnessMap:Pt,specularMap:Tt,specularColorMap:ht,specularIntensityMap:zt,transmission:j,transmissionMap:D,thicknessMap:it,gradientMap:at,opaque:y.transparent===!1&&y.blending===Ni&&y.alphaToCoverage===!1,alphaMap:mt,alphaTest:tt,alphaHash:J,combine:y.combine,mapUv:$t&&x(y.map.channel),aoMapUv:pe&&x(y.aoMap.channel),lightMapUv:Ot&&x(y.lightMap.channel),bumpMapUv:Lt&&x(y.bumpMap.channel),normalMapUv:_t&&x(y.normalMap.channel),displacementMapUv:me&&x(y.displacementMap.channel),emissiveMapUv:Mt&&x(y.emissiveMap.channel),metalnessMapUv:Vt&&x(y.metalnessMap.channel),roughnessMapUv:Fe&&x(y.roughnessMap.channel),anisotropyMapUv:$&&x(y.anisotropyMap.channel),clearcoatMapUv:Et&&x(y.clearcoatMap.channel),clearcoatNormalMapUv:st&&x(y.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:bt&&x(y.clearcoatRoughnessMap.channel),iridescenceMapUv:wt&&x(y.iridescenceMap.channel),iridescenceThicknessMapUv:nt&&x(y.iridescenceThicknessMap.channel),sheenColorMapUv:dt&&x(y.sheenColorMap.channel),sheenRoughnessMapUv:Pt&&x(y.sheenRoughnessMap.channel),specularMapUv:Tt&&x(y.specularMap.channel),specularColorMapUv:ht&&x(y.specularColorMap.channel),specularIntensityMapUv:zt&&x(y.specularIntensityMap.channel),transmissionMapUv:D&&x(y.transmissionMap.channel),thicknessMapUv:it&&x(y.thicknessMap.channel),alphaMapUv:mt&&x(y.alphaMap.channel),vertexTangents:!!G.attributes.tangent&&(_t||be),vertexColors:y.vertexColors,vertexAlphas:y.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,pointsUvs:B.isPoints===!0&&!!G.attributes.uv&&($t||mt),fog:!!H,useFog:y.fog===!0,fogExp2:!!H&&H.isFogExp2,flatShading:y.flatShading===!0&&y.wireframe===!1,sizeAttenuation:y.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:xt,skinning:B.isSkinnedMesh===!0,morphTargets:G.morphAttributes.position!==void 0,morphNormals:G.morphAttributes.normal!==void 0,morphColors:G.morphAttributes.color!==void 0,morphTargetsCount:gt,morphTextureStride:Ht,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:y.dithering,shadowMapEnabled:s.shadowMap.enabled&&C.length>0,shadowMapType:s.shadowMap.type,toneMapping:Ft,decodeVideoTexture:$t&&y.map.isVideoTexture===!0&&Zt.getTransfer(y.map.colorSpace)===se,decodeVideoTextureEmissive:Mt&&y.emissiveMap.isVideoTexture===!0&&Zt.getTransfer(y.emissiveMap.colorSpace)===se,premultipliedAlpha:y.premultipliedAlpha,doubleSided:y.side===vn,flipSided:y.side===Ve,useDepthPacking:y.depthPacking>=0,depthPacking:y.depthPacking||0,index0AttributeName:y.index0AttributeName,extensionClipCullDistance:yt&&y.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(yt&&y.extensions.multiDraw===!0||At)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:y.customProgramCacheKey()};return he.vertexUv1s=c.has(1),he.vertexUv2s=c.has(2),he.vertexUv3s=c.has(3),c.clear(),he}function u(y){let w=[];if(y.shaderID?w.push(y.shaderID):(w.push(y.customVertexShaderID),w.push(y.customFragmentShaderID)),y.defines!==void 0)for(let C in y.defines)w.push(C),w.push(y.defines[C]);return y.isRawShaderMaterial===!1&&(v(w,y),_(w,y),w.push(s.outputColorSpace)),w.push(y.customProgramCacheKey),w.join()}function v(y,w){y.push(w.precision),y.push(w.outputColorSpace),y.push(w.envMapMode),y.push(w.envMapCubeUVHeight),y.push(w.mapUv),y.push(w.alphaMapUv),y.push(w.lightMapUv),y.push(w.aoMapUv),y.push(w.bumpMapUv),y.push(w.normalMapUv),y.push(w.displacementMapUv),y.push(w.emissiveMapUv),y.push(w.metalnessMapUv),y.push(w.roughnessMapUv),y.push(w.anisotropyMapUv),y.push(w.clearcoatMapUv),y.push(w.clearcoatNormalMapUv),y.push(w.clearcoatRoughnessMapUv),y.push(w.iridescenceMapUv),y.push(w.iridescenceThicknessMapUv),y.push(w.sheenColorMapUv),y.push(w.sheenRoughnessMapUv),y.push(w.specularMapUv),y.push(w.specularColorMapUv),y.push(w.specularIntensityMapUv),y.push(w.transmissionMapUv),y.push(w.thicknessMapUv),y.push(w.combine),y.push(w.fogExp2),y.push(w.sizeAttenuation),y.push(w.morphTargetsCount),y.push(w.morphAttributeCount),y.push(w.numDirLights),y.push(w.numPointLights),y.push(w.numSpotLights),y.push(w.numSpotLightMaps),y.push(w.numHemiLights),y.push(w.numRectAreaLights),y.push(w.numDirLightShadows),y.push(w.numPointLightShadows),y.push(w.numSpotLightShadows),y.push(w.numSpotLightShadowsWithMaps),y.push(w.numLightProbes),y.push(w.shadowMapType),y.push(w.toneMapping),y.push(w.numClippingPlanes),y.push(w.numClipIntersection),y.push(w.depthPacking)}function _(y,w){a.disableAll(),w.supportsVertexTextures&&a.enable(0),w.instancing&&a.enable(1),w.instancingColor&&a.enable(2),w.instancingMorph&&a.enable(3),w.matcap&&a.enable(4),w.envMap&&a.enable(5),w.normalMapObjectSpace&&a.enable(6),w.normalMapTangentSpace&&a.enable(7),w.clearcoat&&a.enable(8),w.iridescence&&a.enable(9),w.alphaTest&&a.enable(10),w.vertexColors&&a.enable(11),w.vertexAlphas&&a.enable(12),w.vertexUv1s&&a.enable(13),w.vertexUv2s&&a.enable(14),w.vertexUv3s&&a.enable(15),w.vertexTangents&&a.enable(16),w.anisotropy&&a.enable(17),w.alphaHash&&a.enable(18),w.batching&&a.enable(19),w.dispersion&&a.enable(20),w.batchingColor&&a.enable(21),w.gradientMap&&a.enable(22),y.push(a.mask),a.disableAll(),w.fog&&a.enable(0),w.useFog&&a.enable(1),w.flatShading&&a.enable(2),w.logarithmicDepthBuffer&&a.enable(3),w.reversedDepthBuffer&&a.enable(4),w.skinning&&a.enable(5),w.morphTargets&&a.enable(6),w.morphNormals&&a.enable(7),w.morphColors&&a.enable(8),w.premultipliedAlpha&&a.enable(9),w.shadowMapEnabled&&a.enable(10),w.doubleSided&&a.enable(11),w.flipSided&&a.enable(12),w.useDepthPacking&&a.enable(13),w.dithering&&a.enable(14),w.transmission&&a.enable(15),w.sheen&&a.enable(16),w.opaque&&a.enable(17),w.pointsUvs&&a.enable(18),w.decodeVideoTexture&&a.enable(19),w.decodeVideoTextureEmissive&&a.enable(20),w.alphaToCoverage&&a.enable(21),y.push(a.mask)}function M(y){let w=m[y.type],C;if(w){let L=Gn[w];C=Yu.clone(L.uniforms)}else C=y.uniforms;return C}function A(y,w){let C;for(let L=0,B=h.length;L<B;L++){let H=h[L];if(H.cacheKey===w){C=H,++C.usedTimes;break}}return C===void 0&&(C=new hx(s,w,y,r),h.push(C)),C}function b(y){if(--y.usedTimes===0){let w=h.indexOf(y);h[w]=h[h.length-1],h.pop(),y.destroy()}}function T(y){l.remove(y)}function I(){l.dispose()}return{getParameters:g,getProgramCacheKey:u,getUniforms:M,acquireProgram:A,releaseProgram:b,releaseShaderCache:T,programs:h,dispose:I}}function fx(){let s=new WeakMap;function t(o){return s.has(o)}function e(o){let a=s.get(o);return a===void 0&&(a={},s.set(o,a)),a}function n(o){s.delete(o)}function i(o,a,l){s.get(o)[a]=l}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function px(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function xd(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function vd(){let s=[],t=0,e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function o(d,f,p,m,x,g){let u=s[t];return u===void 0?(u={id:d.id,object:d,geometry:f,material:p,groupOrder:m,renderOrder:d.renderOrder,z:x,group:g},s[t]=u):(u.id=d.id,u.object=d,u.geometry=f,u.material=p,u.groupOrder=m,u.renderOrder=d.renderOrder,u.z=x,u.group=g),t++,u}function a(d,f,p,m,x,g){let u=o(d,f,p,m,x,g);p.transmission>0?n.push(u):p.transparent===!0?i.push(u):e.push(u)}function l(d,f,p,m,x,g){let u=o(d,f,p,m,x,g);p.transmission>0?n.unshift(u):p.transparent===!0?i.unshift(u):e.unshift(u)}function c(d,f){e.length>1&&e.sort(d||px),n.length>1&&n.sort(f||xd),i.length>1&&i.sort(f||xd)}function h(){for(let d=t,f=s.length;d<f;d++){let p=s[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:a,unshift:l,finish:h,sort:c}}function mx(){let s=new WeakMap;function t(n,i){let r=s.get(n),o;return r===void 0?(o=new vd,s.set(n,[o])):i>=r.length?(o=new vd,r.push(o)):o=r[i],o}function e(){s=new WeakMap}return{get:t,dispose:e}}function gx(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new U,color:new kt};break;case"SpotLight":e={position:new U,direction:new U,color:new kt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new U,color:new kt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new U,skyColor:new kt,groundColor:new kt};break;case"RectAreaLight":e={color:new kt,position:new U,halfWidth:new U,halfHeight:new U};break}return s[t.id]=e,e}}}function xx(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Nt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}var vx=0;function yx(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function _x(s){let t=new gx,e=xx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new U);let i=new U,r=new ee,o=new ee;function a(c){let h=0,d=0,f=0;for(let y=0;y<9;y++)n.probe[y].set(0,0,0);let p=0,m=0,x=0,g=0,u=0,v=0,_=0,M=0,A=0,b=0,T=0;c.sort(yx);for(let y=0,w=c.length;y<w;y++){let C=c[y],L=C.color,B=C.intensity,H=C.distance,G=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)h+=L.r*B,d+=L.g*B,f+=L.b*B;else if(C.isLightProbe){for(let X=0;X<9;X++)n.probe[X].addScaledVector(C.sh.coefficients[X],B);T++}else if(C.isDirectionalLight){let X=t.get(C);if(X.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){let Q=C.shadow,V=e.get(C);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,n.directionalShadow[p]=V,n.directionalShadowMap[p]=G,n.directionalShadowMatrix[p]=C.shadow.matrix,v++}n.directional[p]=X,p++}else if(C.isSpotLight){let X=t.get(C);X.position.setFromMatrixPosition(C.matrixWorld),X.color.copy(L).multiplyScalar(B),X.distance=H,X.coneCos=Math.cos(C.angle),X.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),X.decay=C.decay,n.spot[x]=X;let Q=C.shadow;if(C.map&&(n.spotLightMap[A]=C.map,A++,Q.updateMatrices(C),C.castShadow&&b++),n.spotLightMatrix[x]=Q.matrix,C.castShadow){let V=e.get(C);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,n.spotShadow[x]=V,n.spotShadowMap[x]=G,M++}x++}else if(C.isRectAreaLight){let X=t.get(C);X.color.copy(L).multiplyScalar(B),X.halfWidth.set(C.width*.5,0,0),X.halfHeight.set(0,C.height*.5,0),n.rectArea[g]=X,g++}else if(C.isPointLight){let X=t.get(C);if(X.color.copy(C.color).multiplyScalar(C.intensity),X.distance=C.distance,X.decay=C.decay,C.castShadow){let Q=C.shadow,V=e.get(C);V.shadowIntensity=Q.intensity,V.shadowBias=Q.bias,V.shadowNormalBias=Q.normalBias,V.shadowRadius=Q.radius,V.shadowMapSize=Q.mapSize,V.shadowCameraNear=Q.camera.near,V.shadowCameraFar=Q.camera.far,n.pointShadow[m]=V,n.pointShadowMap[m]=G,n.pointShadowMatrix[m]=C.shadow.matrix,_++}n.point[m]=X,m++}else if(C.isHemisphereLight){let X=t.get(C);X.skyColor.copy(C.color).multiplyScalar(B),X.groundColor.copy(C.groundColor).multiplyScalar(B),n.hemi[u]=X,u++}}g>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=lt.LTC_FLOAT_1,n.rectAreaLTC2=lt.LTC_FLOAT_2):(n.rectAreaLTC1=lt.LTC_HALF_1,n.rectAreaLTC2=lt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=d,n.ambient[2]=f;let I=n.hash;(I.directionalLength!==p||I.pointLength!==m||I.spotLength!==x||I.rectAreaLength!==g||I.hemiLength!==u||I.numDirectionalShadows!==v||I.numPointShadows!==_||I.numSpotShadows!==M||I.numSpotMaps!==A||I.numLightProbes!==T)&&(n.directional.length=p,n.spot.length=x,n.rectArea.length=g,n.point.length=m,n.hemi.length=u,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=_,n.pointShadowMap.length=_,n.spotShadow.length=M,n.spotShadowMap.length=M,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=_,n.spotLightMatrix.length=M+A-b,n.spotLightMap.length=A,n.numSpotLightShadowsWithMaps=b,n.numLightProbes=T,I.directionalLength=p,I.pointLength=m,I.spotLength=x,I.rectAreaLength=g,I.hemiLength=u,I.numDirectionalShadows=v,I.numPointShadows=_,I.numSpotShadows=M,I.numSpotMaps=A,I.numLightProbes=T,n.version=vx++)}function l(c,h){let d=0,f=0,p=0,m=0,x=0,g=h.matrixWorldInverse;for(let u=0,v=c.length;u<v;u++){let _=c[u];if(_.isDirectionalLight){let M=n.directional[d];M.direction.setFromMatrixPosition(_.matrixWorld),i.setFromMatrixPosition(_.target.matrixWorld),M.direction.sub(i),M.direction.transformDirection(g),d++}else if(_.isSpotLight){let M=n.spot[p];M.position.setFromMatrixPosition(_.matrixWorld),M.position.applyMatrix4(g),M.direction.setFromMatrixPosition(_.matrixWorld),i.setFromMatrixPosition(_.target.matrixWorld),M.direction.sub(i),M.direction.transformDirection(g),p++}else if(_.isRectAreaLight){let M=n.rectArea[m];M.position.setFromMatrixPosition(_.matrixWorld),M.position.applyMatrix4(g),o.identity(),r.copy(_.matrixWorld),r.premultiply(g),o.extractRotation(r),M.halfWidth.set(_.width*.5,0,0),M.halfHeight.set(0,_.height*.5,0),M.halfWidth.applyMatrix4(o),M.halfHeight.applyMatrix4(o),m++}else if(_.isPointLight){let M=n.point[f];M.position.setFromMatrixPosition(_.matrixWorld),M.position.applyMatrix4(g),f++}else if(_.isHemisphereLight){let M=n.hemi[x];M.direction.setFromMatrixPosition(_.matrixWorld),M.direction.transformDirection(g),x++}}}return{setup:a,setupView:l,state:n}}function yd(s){let t=new _x(s),e=[],n=[];function i(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function Mx(s){let t=new WeakMap;function e(i,r=0){let o=t.get(i),a;return o===void 0?(a=new yd(s),t.set(i,[a])):r>=o.length?(a=new yd(s),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}var bx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Sx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function wx(s,t,e){let n=new Ls,i=new Nt,r=new Nt,o=new _e,a=new Xo({depthPacking:Nu}),l=new $o,c={},h=e.maxTextureSize,d={[ti]:Ve,[Ve]:ti,[vn]:vn},f=new Cn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Nt},radius:{value:4}},vertexShader:bx,fragmentShader:Sx}),p=f.clone();p.defines.HORIZONTAL_PASS=1;let m=new He;m.setAttribute("position",new Ae(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new jt(m,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=gc;let u=this.type;this.render=function(b,T,I){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||b.length===0)return;let y=s.getRenderTarget(),w=s.getActiveCubeFace(),C=s.getActiveMipmapLevel(),L=s.state;L.setBlending(ii),L.buffers.depth.getReversed()===!0?L.buffers.color.setClear(0,0,0,0):L.buffers.color.setClear(1,1,1,1),L.buffers.depth.setTest(!0),L.setScissorTest(!1);let B=u!==Vn&&this.type===Vn,H=u===Vn&&this.type!==Vn;for(let G=0,X=b.length;G<X;G++){let Q=b[G],V=Q.shadow;if(V===void 0){console.warn("THREE.WebGLShadowMap:",Q,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;i.copy(V.mapSize);let ot=V.getFrameExtents();if(i.multiply(ot),r.copy(V.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/ot.x),i.x=r.x*ot.x,V.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/ot.y),i.y=r.y*ot.y,V.mapSize.y=r.y)),V.map===null||B===!0||H===!0){let gt=this.type!==Vn?{minFilter:Ce,magFilter:Ce}:{};V.map!==null&&V.map.dispose(),V.map=new Bn(i.x,i.y,gt),V.map.texture.name=Q.name+".shadowMap",V.camera.updateProjectionMatrix()}s.setRenderTarget(V.map),s.clear();let ct=V.getViewportCount();for(let gt=0;gt<ct;gt++){let Ht=V.getViewport(gt);o.set(r.x*Ht.x,r.y*Ht.y,r.x*Ht.z,r.y*Ht.w),L.viewport(o),V.updateMatrices(Q,gt),n=V.getFrustum(),M(T,I,V.camera,Q,this.type)}V.isPointLightShadow!==!0&&this.type===Vn&&v(V,I),V.needsUpdate=!1}u=this.type,g.needsUpdate=!1,s.setRenderTarget(y,w,C)};function v(b,T){let I=t.update(x);f.defines.VSM_SAMPLES!==b.blurSamples&&(f.defines.VSM_SAMPLES=b.blurSamples,p.defines.VSM_SAMPLES=b.blurSamples,f.needsUpdate=!0,p.needsUpdate=!0),b.mapPass===null&&(b.mapPass=new Bn(i.x,i.y)),f.uniforms.shadow_pass.value=b.map.texture,f.uniforms.resolution.value=b.mapSize,f.uniforms.radius.value=b.radius,s.setRenderTarget(b.mapPass),s.clear(),s.renderBufferDirect(T,null,I,f,x,null),p.uniforms.shadow_pass.value=b.mapPass.texture,p.uniforms.resolution.value=b.mapSize,p.uniforms.radius.value=b.radius,s.setRenderTarget(b.map),s.clear(),s.renderBufferDirect(T,null,I,p,x,null)}function _(b,T,I,y){let w=null,C=I.isPointLight===!0?b.customDistanceMaterial:b.customDepthMaterial;if(C!==void 0)w=C;else if(w=I.isPointLight===!0?l:a,s.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){let L=w.uuid,B=T.uuid,H=c[L];H===void 0&&(H={},c[L]=H);let G=H[B];G===void 0&&(G=w.clone(),H[B]=G,T.addEventListener("dispose",A)),w=G}if(w.visible=T.visible,w.wireframe=T.wireframe,y===Vn?w.side=T.shadowSide!==null?T.shadowSide:T.side:w.side=T.shadowSide!==null?T.shadowSide:d[T.side],w.alphaMap=T.alphaMap,w.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,w.map=T.map,w.clipShadows=T.clipShadows,w.clippingPlanes=T.clippingPlanes,w.clipIntersection=T.clipIntersection,w.displacementMap=T.displacementMap,w.displacementScale=T.displacementScale,w.displacementBias=T.displacementBias,w.wireframeLinewidth=T.wireframeLinewidth,w.linewidth=T.linewidth,I.isPointLight===!0&&w.isMeshDistanceMaterial===!0){let L=s.properties.get(w);L.light=I}return w}function M(b,T,I,y,w){if(b.visible===!1)return;if(b.layers.test(T.layers)&&(b.isMesh||b.isLine||b.isPoints)&&(b.castShadow||b.receiveShadow&&w===Vn)&&(!b.frustumCulled||n.intersectsObject(b))){b.modelViewMatrix.multiplyMatrices(I.matrixWorldInverse,b.matrixWorld);let B=t.update(b),H=b.material;if(Array.isArray(H)){let G=B.groups;for(let X=0,Q=G.length;X<Q;X++){let V=G[X],ot=H[V.materialIndex];if(ot&&ot.visible){let ct=_(b,ot,y,w);b.onBeforeShadow(s,b,T,I,B,ct,V),s.renderBufferDirect(I,null,B,ct,b,V),b.onAfterShadow(s,b,T,I,B,ct,V)}}}else if(H.visible){let G=_(b,H,y,w);b.onBeforeShadow(s,b,T,I,B,G,null),s.renderBufferDirect(I,null,B,G,b,null),b.onAfterShadow(s,b,T,I,B,G,null)}}let L=b.children;for(let B=0,H=L.length;B<H;B++)M(L[B],T,I,y,w)}function A(b){b.target.removeEventListener("dispose",A);for(let I in c){let y=c[I],w=b.target.uuid;w in y&&(y[w].dispose(),delete y[w])}}}var Tx={[sa]:ra,[oa]:ca,[aa]:ha,[Fi]:la,[ra]:sa,[ca]:oa,[ha]:aa,[la]:Fi};function Ex(s,t){function e(){let D=!1,it=new _e,at=null,mt=new _e(0,0,0,0);return{setMask:function(tt){at!==tt&&!D&&(s.colorMask(tt,tt,tt,tt),at=tt)},setLocked:function(tt){D=tt},setClear:function(tt,J,yt,Ft,he){he===!0&&(tt*=Ft,J*=Ft,yt*=Ft),it.set(tt,J,yt,Ft),mt.equals(it)===!1&&(s.clearColor(tt,J,yt,Ft),mt.copy(it))},reset:function(){D=!1,at=null,mt.set(-1,0,0,0)}}}function n(){let D=!1,it=!1,at=null,mt=null,tt=null;return{setReversed:function(J){if(it!==J){let yt=t.get("EXT_clip_control");J?yt.clipControlEXT(yt.LOWER_LEFT_EXT,yt.ZERO_TO_ONE_EXT):yt.clipControlEXT(yt.LOWER_LEFT_EXT,yt.NEGATIVE_ONE_TO_ONE_EXT),it=J;let Ft=tt;tt=null,this.setClear(Ft)}},getReversed:function(){return it},setTest:function(J){J?K(s.DEPTH_TEST):xt(s.DEPTH_TEST)},setMask:function(J){at!==J&&!D&&(s.depthMask(J),at=J)},setFunc:function(J){if(it&&(J=Tx[J]),mt!==J){switch(J){case sa:s.depthFunc(s.NEVER);break;case ra:s.depthFunc(s.ALWAYS);break;case oa:s.depthFunc(s.LESS);break;case Fi:s.depthFunc(s.LEQUAL);break;case aa:s.depthFunc(s.EQUAL);break;case la:s.depthFunc(s.GEQUAL);break;case ca:s.depthFunc(s.GREATER);break;case ha:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}mt=J}},setLocked:function(J){D=J},setClear:function(J){tt!==J&&(it&&(J=1-J),s.clearDepth(J),tt=J)},reset:function(){D=!1,at=null,mt=null,tt=null,it=!1}}}function i(){let D=!1,it=null,at=null,mt=null,tt=null,J=null,yt=null,Ft=null,he=null;return{setTest:function(te){D||(te?K(s.STENCIL_TEST):xt(s.STENCIL_TEST))},setMask:function(te){it!==te&&!D&&(s.stencilMask(te),it=te)},setFunc:function(te,qn,Un){(at!==te||mt!==qn||tt!==Un)&&(s.stencilFunc(te,qn,Un),at=te,mt=qn,tt=Un)},setOp:function(te,qn,Un){(J!==te||yt!==qn||Ft!==Un)&&(s.stencilOp(te,qn,Un),J=te,yt=qn,Ft=Un)},setLocked:function(te){D=te},setClear:function(te){he!==te&&(s.clearStencil(te),he=te)},reset:function(){D=!1,it=null,at=null,mt=null,tt=null,J=null,yt=null,Ft=null,he=null}}}let r=new e,o=new n,a=new i,l=new WeakMap,c=new WeakMap,h={},d={},f=new WeakMap,p=[],m=null,x=!1,g=null,u=null,v=null,_=null,M=null,A=null,b=null,T=new kt(0,0,0),I=0,y=!1,w=null,C=null,L=null,B=null,H=null,G=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),X=!1,Q=0,V=s.getParameter(s.VERSION);V.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(V)[1]),X=Q>=1):V.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),X=Q>=2);let ot=null,ct={},gt=s.getParameter(s.SCISSOR_BOX),Ht=s.getParameter(s.VIEWPORT),ie=new _e().fromArray(gt),ce=new _e().fromArray(Ht);function Qt(D,it,at,mt){let tt=new Uint8Array(4),J=s.createTexture();s.bindTexture(D,J),s.texParameteri(D,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(D,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let yt=0;yt<at;yt++)D===s.TEXTURE_3D||D===s.TEXTURE_2D_ARRAY?s.texImage3D(it,0,s.RGBA,1,1,mt,0,s.RGBA,s.UNSIGNED_BYTE,tt):s.texImage2D(it+yt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,tt);return J}let Z={};Z[s.TEXTURE_2D]=Qt(s.TEXTURE_2D,s.TEXTURE_2D,1),Z[s.TEXTURE_CUBE_MAP]=Qt(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Z[s.TEXTURE_2D_ARRAY]=Qt(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Z[s.TEXTURE_3D]=Qt(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),K(s.DEPTH_TEST),o.setFunc(Fi),Lt(!1),_t(mc),K(s.CULL_FACE),pe(ii);function K(D){h[D]!==!0&&(s.enable(D),h[D]=!0)}function xt(D){h[D]!==!1&&(s.disable(D),h[D]=!1)}function Ut(D,it){return d[D]!==it?(s.bindFramebuffer(D,it),d[D]=it,D===s.DRAW_FRAMEBUFFER&&(d[s.FRAMEBUFFER]=it),D===s.FRAMEBUFFER&&(d[s.DRAW_FRAMEBUFFER]=it),!0):!1}function At(D,it){let at=p,mt=!1;if(D){at=f.get(it),at===void 0&&(at=[],f.set(it,at));let tt=D.textures;if(at.length!==tt.length||at[0]!==s.COLOR_ATTACHMENT0){for(let J=0,yt=tt.length;J<yt;J++)at[J]=s.COLOR_ATTACHMENT0+J;at.length=tt.length,mt=!0}}else at[0]!==s.BACK&&(at[0]=s.BACK,mt=!0);mt&&s.drawBuffers(at)}function $t(D){return m!==D?(s.useProgram(D),m=D,!0):!1}let We={[vi]:s.FUNC_ADD,[lu]:s.FUNC_SUBTRACT,[cu]:s.FUNC_REVERSE_SUBTRACT};We[hu]=s.MIN,We[uu]=s.MAX;let P={[du]:s.ZERO,[fu]:s.ONE,[pu]:s.SRC_COLOR,[Io]:s.SRC_ALPHA,[_u]:s.SRC_ALPHA_SATURATE,[vu]:s.DST_COLOR,[gu]:s.DST_ALPHA,[mu]:s.ONE_MINUS_SRC_COLOR,[Po]:s.ONE_MINUS_SRC_ALPHA,[yu]:s.ONE_MINUS_DST_COLOR,[xu]:s.ONE_MINUS_DST_ALPHA,[Mu]:s.CONSTANT_COLOR,[bu]:s.ONE_MINUS_CONSTANT_COLOR,[Su]:s.CONSTANT_ALPHA,[wu]:s.ONE_MINUS_CONSTANT_ALPHA};function pe(D,it,at,mt,tt,J,yt,Ft,he,te){if(D===ii){x===!0&&(xt(s.BLEND),x=!1);return}if(x===!1&&(K(s.BLEND),x=!0),D!==au){if(D!==g||te!==y){if((u!==vi||M!==vi)&&(s.blendEquation(s.FUNC_ADD),u=vi,M=vi),te)switch(D){case Ni:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case xc:s.blendFunc(s.ONE,s.ONE);break;case vc:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case yc:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case Ni:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case xc:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case vc:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case yc:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}v=null,_=null,A=null,b=null,T.set(0,0,0),I=0,g=D,y=te}return}tt=tt||it,J=J||at,yt=yt||mt,(it!==u||tt!==M)&&(s.blendEquationSeparate(We[it],We[tt]),u=it,M=tt),(at!==v||mt!==_||J!==A||yt!==b)&&(s.blendFuncSeparate(P[at],P[mt],P[J],P[yt]),v=at,_=mt,A=J,b=yt),(Ft.equals(T)===!1||he!==I)&&(s.blendColor(Ft.r,Ft.g,Ft.b,he),T.copy(Ft),I=he),g=D,y=!1}function Ot(D,it){D.side===vn?xt(s.CULL_FACE):K(s.CULL_FACE);let at=D.side===Ve;it&&(at=!at),Lt(at),D.blending===Ni&&D.transparent===!1?pe(ii):pe(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),o.setFunc(D.depthFunc),o.setTest(D.depthTest),o.setMask(D.depthWrite),r.setMask(D.colorWrite);let mt=D.stencilWrite;a.setTest(mt),mt&&(a.setMask(D.stencilWriteMask),a.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),a.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),Mt(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?K(s.SAMPLE_ALPHA_TO_COVERAGE):xt(s.SAMPLE_ALPHA_TO_COVERAGE)}function Lt(D){w!==D&&(D?s.frontFace(s.CW):s.frontFace(s.CCW),w=D)}function _t(D){D!==su?(K(s.CULL_FACE),D!==C&&(D===mc?s.cullFace(s.BACK):D===ru?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):xt(s.CULL_FACE),C=D}function me(D){D!==L&&(X&&s.lineWidth(D),L=D)}function Mt(D,it,at){D?(K(s.POLYGON_OFFSET_FILL),(B!==it||H!==at)&&(s.polygonOffset(it,at),B=it,H=at)):xt(s.POLYGON_OFFSET_FILL)}function Vt(D){D?K(s.SCISSOR_TEST):xt(s.SCISSOR_TEST)}function Fe(D){D===void 0&&(D=s.TEXTURE0+G-1),ot!==D&&(s.activeTexture(D),ot=D)}function be(D,it,at){at===void 0&&(ot===null?at=s.TEXTURE0+G-1:at=ot);let mt=ct[at];mt===void 0&&(mt={type:void 0,texture:void 0},ct[at]=mt),(mt.type!==D||mt.texture!==it)&&(ot!==at&&(s.activeTexture(at),ot=at),s.bindTexture(D,it||Z[D]),mt.type=D,mt.texture=it)}function R(){let D=ct[ot];D!==void 0&&D.type!==void 0&&(s.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function S(){try{s.compressedTexImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function z(){try{s.compressedTexImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Y(){try{s.texSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function j(){try{s.texSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function $(){try{s.compressedTexSubImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Et(){try{s.compressedTexSubImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function st(){try{s.texStorage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function bt(){try{s.texStorage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function wt(){try{s.texImage2D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function nt(){try{s.texImage3D(...arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function dt(D){ie.equals(D)===!1&&(s.scissor(D.x,D.y,D.z,D.w),ie.copy(D))}function Pt(D){ce.equals(D)===!1&&(s.viewport(D.x,D.y,D.z,D.w),ce.copy(D))}function Tt(D,it){let at=c.get(it);at===void 0&&(at=new WeakMap,c.set(it,at));let mt=at.get(D);mt===void 0&&(mt=s.getUniformBlockIndex(it,D.name),at.set(D,mt))}function ht(D,it){let mt=c.get(it).get(D);l.get(it)!==mt&&(s.uniformBlockBinding(it,mt,D.__bindingPointIndex),l.set(it,mt))}function zt(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),o.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},ot=null,ct={},d={},f=new WeakMap,p=[],m=null,x=!1,g=null,u=null,v=null,_=null,M=null,A=null,b=null,T=new kt(0,0,0),I=0,y=!1,w=null,C=null,L=null,B=null,H=null,ie.set(0,0,s.canvas.width,s.canvas.height),ce.set(0,0,s.canvas.width,s.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:K,disable:xt,bindFramebuffer:Ut,drawBuffers:At,useProgram:$t,setBlending:pe,setMaterial:Ot,setFlipSided:Lt,setCullFace:_t,setLineWidth:me,setPolygonOffset:Mt,setScissorTest:Vt,activeTexture:Fe,bindTexture:be,unbindTexture:R,compressedTexImage2D:S,compressedTexImage3D:z,texImage2D:wt,texImage3D:nt,updateUBOMapping:Tt,uniformBlockBinding:ht,texStorage2D:st,texStorage3D:bt,texSubImage2D:Y,texSubImage3D:j,compressedTexSubImage2D:$,compressedTexSubImage3D:Et,scissor:dt,viewport:Pt,reset:zt}}function Ax(s,t,e,n,i,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Nt,h=new WeakMap,d,f=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(R,S){return p?new OffscreenCanvas(R,S):pr("canvas")}function x(R,S,z){let Y=1,j=be(R);if((j.width>z||j.height>z)&&(Y=z/Math.max(j.width,j.height)),Y<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){let $=Math.floor(Y*j.width),Et=Math.floor(Y*j.height);d===void 0&&(d=m($,Et));let st=S?m($,Et):d;return st.width=$,st.height=Et,st.getContext("2d").drawImage(R,0,0,$,Et),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+j.width+"x"+j.height+") to ("+$+"x"+Et+")."),st}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+j.width+"x"+j.height+")."),R;return R}function g(R){return R.generateMipmaps}function u(R){s.generateMipmap(R)}function v(R){return R.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?s.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function _(R,S,z,Y,j=!1){if(R!==null){if(s[R]!==void 0)return s[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let $=S;if(S===s.RED&&(z===s.FLOAT&&($=s.R32F),z===s.HALF_FLOAT&&($=s.R16F),z===s.UNSIGNED_BYTE&&($=s.R8)),S===s.RED_INTEGER&&(z===s.UNSIGNED_BYTE&&($=s.R8UI),z===s.UNSIGNED_SHORT&&($=s.R16UI),z===s.UNSIGNED_INT&&($=s.R32UI),z===s.BYTE&&($=s.R8I),z===s.SHORT&&($=s.R16I),z===s.INT&&($=s.R32I)),S===s.RG&&(z===s.FLOAT&&($=s.RG32F),z===s.HALF_FLOAT&&($=s.RG16F),z===s.UNSIGNED_BYTE&&($=s.RG8)),S===s.RG_INTEGER&&(z===s.UNSIGNED_BYTE&&($=s.RG8UI),z===s.UNSIGNED_SHORT&&($=s.RG16UI),z===s.UNSIGNED_INT&&($=s.RG32UI),z===s.BYTE&&($=s.RG8I),z===s.SHORT&&($=s.RG16I),z===s.INT&&($=s.RG32I)),S===s.RGB_INTEGER&&(z===s.UNSIGNED_BYTE&&($=s.RGB8UI),z===s.UNSIGNED_SHORT&&($=s.RGB16UI),z===s.UNSIGNED_INT&&($=s.RGB32UI),z===s.BYTE&&($=s.RGB8I),z===s.SHORT&&($=s.RGB16I),z===s.INT&&($=s.RGB32I)),S===s.RGBA_INTEGER&&(z===s.UNSIGNED_BYTE&&($=s.RGBA8UI),z===s.UNSIGNED_SHORT&&($=s.RGBA16UI),z===s.UNSIGNED_INT&&($=s.RGBA32UI),z===s.BYTE&&($=s.RGBA8I),z===s.SHORT&&($=s.RGBA16I),z===s.INT&&($=s.RGBA32I)),S===s.RGB&&(z===s.UNSIGNED_INT_5_9_9_9_REV&&($=s.RGB9_E5),z===s.UNSIGNED_INT_10F_11F_11F_REV&&($=s.R11F_G11F_B10F)),S===s.RGBA){let Et=j?dr:Zt.getTransfer(Y);z===s.FLOAT&&($=s.RGBA32F),z===s.HALF_FLOAT&&($=s.RGBA16F),z===s.UNSIGNED_BYTE&&($=Et===se?s.SRGB8_ALPHA8:s.RGBA8),z===s.UNSIGNED_SHORT_4_4_4_4&&($=s.RGBA4),z===s.UNSIGNED_SHORT_5_5_5_1&&($=s.RGB5_A1)}return($===s.R16F||$===s.R32F||$===s.RG16F||$===s.RG32F||$===s.RGBA16F||$===s.RGBA32F)&&t.get("EXT_color_buffer_float"),$}function M(R,S){let z;return R?S===null||S===bi||S===Fs?z=s.DEPTH24_STENCIL8:S===Pn?z=s.DEPTH32F_STENCIL8:S===Us&&(z=s.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):S===null||S===bi||S===Fs?z=s.DEPTH_COMPONENT24:S===Pn?z=s.DEPTH_COMPONENT32F:S===Us&&(z=s.DEPTH_COMPONENT16),z}function A(R,S){return g(R)===!0||R.isFramebufferTexture&&R.minFilter!==Ce&&R.minFilter!==En?Math.log2(Math.max(S.width,S.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?S.mipmaps.length:1}function b(R){let S=R.target;S.removeEventListener("dispose",b),I(S),S.isVideoTexture&&h.delete(S)}function T(R){let S=R.target;S.removeEventListener("dispose",T),w(S)}function I(R){let S=n.get(R);if(S.__webglInit===void 0)return;let z=R.source,Y=f.get(z);if(Y){let j=Y[S.__cacheKey];j.usedTimes--,j.usedTimes===0&&y(R),Object.keys(Y).length===0&&f.delete(z)}n.remove(R)}function y(R){let S=n.get(R);s.deleteTexture(S.__webglTexture);let z=R.source,Y=f.get(z);delete Y[S.__cacheKey],o.memory.textures--}function w(R){let S=n.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),n.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let Y=0;Y<6;Y++){if(Array.isArray(S.__webglFramebuffer[Y]))for(let j=0;j<S.__webglFramebuffer[Y].length;j++)s.deleteFramebuffer(S.__webglFramebuffer[Y][j]);else s.deleteFramebuffer(S.__webglFramebuffer[Y]);S.__webglDepthbuffer&&s.deleteRenderbuffer(S.__webglDepthbuffer[Y])}else{if(Array.isArray(S.__webglFramebuffer))for(let Y=0;Y<S.__webglFramebuffer.length;Y++)s.deleteFramebuffer(S.__webglFramebuffer[Y]);else s.deleteFramebuffer(S.__webglFramebuffer);if(S.__webglDepthbuffer&&s.deleteRenderbuffer(S.__webglDepthbuffer),S.__webglMultisampledFramebuffer&&s.deleteFramebuffer(S.__webglMultisampledFramebuffer),S.__webglColorRenderbuffer)for(let Y=0;Y<S.__webglColorRenderbuffer.length;Y++)S.__webglColorRenderbuffer[Y]&&s.deleteRenderbuffer(S.__webglColorRenderbuffer[Y]);S.__webglDepthRenderbuffer&&s.deleteRenderbuffer(S.__webglDepthRenderbuffer)}let z=R.textures;for(let Y=0,j=z.length;Y<j;Y++){let $=n.get(z[Y]);$.__webglTexture&&(s.deleteTexture($.__webglTexture),o.memory.textures--),n.remove(z[Y])}n.remove(R)}let C=0;function L(){C=0}function B(){let R=C;return R>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+i.maxTextures),C+=1,R}function H(R){let S=[];return S.push(R.wrapS),S.push(R.wrapT),S.push(R.wrapR||0),S.push(R.magFilter),S.push(R.minFilter),S.push(R.anisotropy),S.push(R.internalFormat),S.push(R.format),S.push(R.type),S.push(R.generateMipmaps),S.push(R.premultiplyAlpha),S.push(R.flipY),S.push(R.unpackAlignment),S.push(R.colorSpace),S.join()}function G(R,S){let z=n.get(R);if(R.isVideoTexture&&Vt(R),R.isRenderTargetTexture===!1&&R.isExternalTexture!==!0&&R.version>0&&z.__version!==R.version){let Y=R.image;if(Y===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Y.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Z(z,R,S);return}}else R.isExternalTexture&&(z.__webglTexture=R.sourceTexture?R.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,z.__webglTexture,s.TEXTURE0+S)}function X(R,S){let z=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&z.__version!==R.version){Z(z,R,S);return}e.bindTexture(s.TEXTURE_2D_ARRAY,z.__webglTexture,s.TEXTURE0+S)}function Q(R,S){let z=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&z.__version!==R.version){Z(z,R,S);return}e.bindTexture(s.TEXTURE_3D,z.__webglTexture,s.TEXTURE0+S)}function V(R,S){let z=n.get(R);if(R.version>0&&z.__version!==R.version){K(z,R,S);return}e.bindTexture(s.TEXTURE_CUBE_MAP,z.__webglTexture,s.TEXTURE0+S)}let ot={[Lo]:s.REPEAT,[gi]:s.CLAMP_TO_EDGE,[Do]:s.MIRRORED_REPEAT},ct={[Ce]:s.NEAREST,[ku]:s.NEAREST_MIPMAP_NEAREST,[kr]:s.NEAREST_MIPMAP_LINEAR,[En]:s.LINEAR,[pa]:s.LINEAR_MIPMAP_NEAREST,[Mi]:s.LINEAR_MIPMAP_LINEAR},gt={[Ou]:s.NEVER,[Wu]:s.ALWAYS,[Bu]:s.LESS,[Rc]:s.LEQUAL,[zu]:s.EQUAL,[Gu]:s.GEQUAL,[Hu]:s.GREATER,[Vu]:s.NOTEQUAL};function Ht(R,S){if(S.type===Pn&&t.has("OES_texture_float_linear")===!1&&(S.magFilter===En||S.magFilter===pa||S.magFilter===kr||S.magFilter===Mi||S.minFilter===En||S.minFilter===pa||S.minFilter===kr||S.minFilter===Mi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(R,s.TEXTURE_WRAP_S,ot[S.wrapS]),s.texParameteri(R,s.TEXTURE_WRAP_T,ot[S.wrapT]),(R===s.TEXTURE_3D||R===s.TEXTURE_2D_ARRAY)&&s.texParameteri(R,s.TEXTURE_WRAP_R,ot[S.wrapR]),s.texParameteri(R,s.TEXTURE_MAG_FILTER,ct[S.magFilter]),s.texParameteri(R,s.TEXTURE_MIN_FILTER,ct[S.minFilter]),S.compareFunction&&(s.texParameteri(R,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(R,s.TEXTURE_COMPARE_FUNC,gt[S.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(S.magFilter===Ce||S.minFilter!==kr&&S.minFilter!==Mi||S.type===Pn&&t.has("OES_texture_float_linear")===!1)return;if(S.anisotropy>1||n.get(S).__currentAnisotropy){let z=t.get("EXT_texture_filter_anisotropic");s.texParameterf(R,z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(S.anisotropy,i.getMaxAnisotropy())),n.get(S).__currentAnisotropy=S.anisotropy}}}function ie(R,S){let z=!1;R.__webglInit===void 0&&(R.__webglInit=!0,S.addEventListener("dispose",b));let Y=S.source,j=f.get(Y);j===void 0&&(j={},f.set(Y,j));let $=H(S);if($!==R.__cacheKey){j[$]===void 0&&(j[$]={texture:s.createTexture(),usedTimes:0},o.memory.textures++,z=!0),j[$].usedTimes++;let Et=j[R.__cacheKey];Et!==void 0&&(j[R.__cacheKey].usedTimes--,Et.usedTimes===0&&y(S)),R.__cacheKey=$,R.__webglTexture=j[$].texture}return z}function ce(R,S,z){return Math.floor(Math.floor(R/z)/S)}function Qt(R,S,z,Y){let $=R.updateRanges;if($.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,S.width,S.height,z,Y,S.data);else{$.sort((nt,dt)=>nt.start-dt.start);let Et=0;for(let nt=1;nt<$.length;nt++){let dt=$[Et],Pt=$[nt],Tt=dt.start+dt.count,ht=ce(Pt.start,S.width,4),zt=ce(dt.start,S.width,4);Pt.start<=Tt+1&&ht===zt&&ce(Pt.start+Pt.count-1,S.width,4)===ht?dt.count=Math.max(dt.count,Pt.start+Pt.count-dt.start):(++Et,$[Et]=Pt)}$.length=Et+1;let st=s.getParameter(s.UNPACK_ROW_LENGTH),bt=s.getParameter(s.UNPACK_SKIP_PIXELS),wt=s.getParameter(s.UNPACK_SKIP_ROWS);s.pixelStorei(s.UNPACK_ROW_LENGTH,S.width);for(let nt=0,dt=$.length;nt<dt;nt++){let Pt=$[nt],Tt=Math.floor(Pt.start/4),ht=Math.ceil(Pt.count/4),zt=Tt%S.width,D=Math.floor(Tt/S.width),it=ht,at=1;s.pixelStorei(s.UNPACK_SKIP_PIXELS,zt),s.pixelStorei(s.UNPACK_SKIP_ROWS,D),e.texSubImage2D(s.TEXTURE_2D,0,zt,D,it,at,z,Y,S.data)}R.clearUpdateRanges(),s.pixelStorei(s.UNPACK_ROW_LENGTH,st),s.pixelStorei(s.UNPACK_SKIP_PIXELS,bt),s.pixelStorei(s.UNPACK_SKIP_ROWS,wt)}}function Z(R,S,z){let Y=s.TEXTURE_2D;(S.isDataArrayTexture||S.isCompressedArrayTexture)&&(Y=s.TEXTURE_2D_ARRAY),S.isData3DTexture&&(Y=s.TEXTURE_3D);let j=ie(R,S),$=S.source;e.bindTexture(Y,R.__webglTexture,s.TEXTURE0+z);let Et=n.get($);if($.version!==Et.__version||j===!0){e.activeTexture(s.TEXTURE0+z);let st=Zt.getPrimaries(Zt.workingColorSpace),bt=S.colorSpace===ri?null:Zt.getPrimaries(S.colorSpace),wt=S.colorSpace===ri||st===bt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,wt);let nt=x(S.image,!1,i.maxTextureSize);nt=Fe(S,nt);let dt=r.convert(S.format,S.colorSpace),Pt=r.convert(S.type),Tt=_(S.internalFormat,dt,Pt,S.colorSpace,S.isVideoTexture);Ht(Y,S);let ht,zt=S.mipmaps,D=S.isVideoTexture!==!0,it=Et.__version===void 0||j===!0,at=$.dataReady,mt=A(S,nt);if(S.isDepthTexture)Tt=M(S.format===Os,S.type),it&&(D?e.texStorage2D(s.TEXTURE_2D,1,Tt,nt.width,nt.height):e.texImage2D(s.TEXTURE_2D,0,Tt,nt.width,nt.height,0,dt,Pt,null));else if(S.isDataTexture)if(zt.length>0){D&&it&&e.texStorage2D(s.TEXTURE_2D,mt,Tt,zt[0].width,zt[0].height);for(let tt=0,J=zt.length;tt<J;tt++)ht=zt[tt],D?at&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,ht.width,ht.height,dt,Pt,ht.data):e.texImage2D(s.TEXTURE_2D,tt,Tt,ht.width,ht.height,0,dt,Pt,ht.data);S.generateMipmaps=!1}else D?(it&&e.texStorage2D(s.TEXTURE_2D,mt,Tt,nt.width,nt.height),at&&Qt(S,nt,dt,Pt)):e.texImage2D(s.TEXTURE_2D,0,Tt,nt.width,nt.height,0,dt,Pt,nt.data);else if(S.isCompressedTexture)if(S.isCompressedArrayTexture){D&&it&&e.texStorage3D(s.TEXTURE_2D_ARRAY,mt,Tt,zt[0].width,zt[0].height,nt.depth);for(let tt=0,J=zt.length;tt<J;tt++)if(ht=zt[tt],S.format!==tn)if(dt!==null)if(D){if(at)if(S.layerUpdates.size>0){let yt=Nc(ht.width,ht.height,S.format,S.type);for(let Ft of S.layerUpdates){let he=ht.data.subarray(Ft*yt/ht.data.BYTES_PER_ELEMENT,(Ft+1)*yt/ht.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,Ft,ht.width,ht.height,1,dt,he)}S.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,0,ht.width,ht.height,nt.depth,dt,ht.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,tt,Tt,ht.width,ht.height,nt.depth,0,ht.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else D?at&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,tt,0,0,0,ht.width,ht.height,nt.depth,dt,Pt,ht.data):e.texImage3D(s.TEXTURE_2D_ARRAY,tt,Tt,ht.width,ht.height,nt.depth,0,dt,Pt,ht.data)}else{D&&it&&e.texStorage2D(s.TEXTURE_2D,mt,Tt,zt[0].width,zt[0].height);for(let tt=0,J=zt.length;tt<J;tt++)ht=zt[tt],S.format!==tn?dt!==null?D?at&&e.compressedTexSubImage2D(s.TEXTURE_2D,tt,0,0,ht.width,ht.height,dt,ht.data):e.compressedTexImage2D(s.TEXTURE_2D,tt,Tt,ht.width,ht.height,0,ht.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):D?at&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,ht.width,ht.height,dt,Pt,ht.data):e.texImage2D(s.TEXTURE_2D,tt,Tt,ht.width,ht.height,0,dt,Pt,ht.data)}else if(S.isDataArrayTexture)if(D){if(it&&e.texStorage3D(s.TEXTURE_2D_ARRAY,mt,Tt,nt.width,nt.height,nt.depth),at)if(S.layerUpdates.size>0){let tt=Nc(nt.width,nt.height,S.format,S.type);for(let J of S.layerUpdates){let yt=nt.data.subarray(J*tt/nt.data.BYTES_PER_ELEMENT,(J+1)*tt/nt.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,J,nt.width,nt.height,1,dt,Pt,yt)}S.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,nt.width,nt.height,nt.depth,dt,Pt,nt.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,Tt,nt.width,nt.height,nt.depth,0,dt,Pt,nt.data);else if(S.isData3DTexture)D?(it&&e.texStorage3D(s.TEXTURE_3D,mt,Tt,nt.width,nt.height,nt.depth),at&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,nt.width,nt.height,nt.depth,dt,Pt,nt.data)):e.texImage3D(s.TEXTURE_3D,0,Tt,nt.width,nt.height,nt.depth,0,dt,Pt,nt.data);else if(S.isFramebufferTexture){if(it)if(D)e.texStorage2D(s.TEXTURE_2D,mt,Tt,nt.width,nt.height);else{let tt=nt.width,J=nt.height;for(let yt=0;yt<mt;yt++)e.texImage2D(s.TEXTURE_2D,yt,Tt,tt,J,0,dt,Pt,null),tt>>=1,J>>=1}}else if(zt.length>0){if(D&&it){let tt=be(zt[0]);e.texStorage2D(s.TEXTURE_2D,mt,Tt,tt.width,tt.height)}for(let tt=0,J=zt.length;tt<J;tt++)ht=zt[tt],D?at&&e.texSubImage2D(s.TEXTURE_2D,tt,0,0,dt,Pt,ht):e.texImage2D(s.TEXTURE_2D,tt,Tt,dt,Pt,ht);S.generateMipmaps=!1}else if(D){if(it){let tt=be(nt);e.texStorage2D(s.TEXTURE_2D,mt,Tt,tt.width,tt.height)}at&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,dt,Pt,nt)}else e.texImage2D(s.TEXTURE_2D,0,Tt,dt,Pt,nt);g(S)&&u(Y),Et.__version=$.version,S.onUpdate&&S.onUpdate(S)}R.__version=S.version}function K(R,S,z){if(S.image.length!==6)return;let Y=ie(R,S),j=S.source;e.bindTexture(s.TEXTURE_CUBE_MAP,R.__webglTexture,s.TEXTURE0+z);let $=n.get(j);if(j.version!==$.__version||Y===!0){e.activeTexture(s.TEXTURE0+z);let Et=Zt.getPrimaries(Zt.workingColorSpace),st=S.colorSpace===ri?null:Zt.getPrimaries(S.colorSpace),bt=S.colorSpace===ri||Et===st?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,bt);let wt=S.isCompressedTexture||S.image[0].isCompressedTexture,nt=S.image[0]&&S.image[0].isDataTexture,dt=[];for(let J=0;J<6;J++)!wt&&!nt?dt[J]=x(S.image[J],!0,i.maxCubemapSize):dt[J]=nt?S.image[J].image:S.image[J],dt[J]=Fe(S,dt[J]);let Pt=dt[0],Tt=r.convert(S.format,S.colorSpace),ht=r.convert(S.type),zt=_(S.internalFormat,Tt,ht,S.colorSpace),D=S.isVideoTexture!==!0,it=$.__version===void 0||Y===!0,at=j.dataReady,mt=A(S,Pt);Ht(s.TEXTURE_CUBE_MAP,S);let tt;if(wt){D&&it&&e.texStorage2D(s.TEXTURE_CUBE_MAP,mt,zt,Pt.width,Pt.height);for(let J=0;J<6;J++){tt=dt[J].mipmaps;for(let yt=0;yt<tt.length;yt++){let Ft=tt[yt];S.format!==tn?Tt!==null?D?at&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt,0,0,Ft.width,Ft.height,Tt,Ft.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt,zt,Ft.width,Ft.height,0,Ft.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt,0,0,Ft.width,Ft.height,Tt,ht,Ft.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt,zt,Ft.width,Ft.height,0,Tt,ht,Ft.data)}}}else{if(tt=S.mipmaps,D&&it){tt.length>0&&mt++;let J=be(dt[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,mt,zt,J.width,J.height)}for(let J=0;J<6;J++)if(nt){D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,dt[J].width,dt[J].height,Tt,ht,dt[J].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,zt,dt[J].width,dt[J].height,0,Tt,ht,dt[J].data);for(let yt=0;yt<tt.length;yt++){let he=tt[yt].image[J].image;D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt+1,0,0,he.width,he.height,Tt,ht,he.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt+1,zt,he.width,he.height,0,Tt,ht,he.data)}}else{D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,Tt,ht,dt[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,zt,Tt,ht,dt[J]);for(let yt=0;yt<tt.length;yt++){let Ft=tt[yt];D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt+1,0,0,Tt,ht,Ft.image[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,yt+1,zt,Tt,ht,Ft.image[J])}}}g(S)&&u(s.TEXTURE_CUBE_MAP),$.__version=j.version,S.onUpdate&&S.onUpdate(S)}R.__version=S.version}function xt(R,S,z,Y,j,$){let Et=r.convert(z.format,z.colorSpace),st=r.convert(z.type),bt=_(z.internalFormat,Et,st,z.colorSpace),wt=n.get(S),nt=n.get(z);if(nt.__renderTarget=S,!wt.__hasExternalTextures){let dt=Math.max(1,S.width>>$),Pt=Math.max(1,S.height>>$);j===s.TEXTURE_3D||j===s.TEXTURE_2D_ARRAY?e.texImage3D(j,$,bt,dt,Pt,S.depth,0,Et,st,null):e.texImage2D(j,$,bt,dt,Pt,0,Et,st,null)}e.bindFramebuffer(s.FRAMEBUFFER,R),Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,Y,j,nt.__webglTexture,0,me(S)):(j===s.TEXTURE_2D||j>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,Y,j,nt.__webglTexture,$),e.bindFramebuffer(s.FRAMEBUFFER,null)}function Ut(R,S,z){if(s.bindRenderbuffer(s.RENDERBUFFER,R),S.depthBuffer){let Y=S.depthTexture,j=Y&&Y.isDepthTexture?Y.type:null,$=M(S.stencilBuffer,j),Et=S.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,st=me(S);Mt(S)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,st,$,S.width,S.height):z?s.renderbufferStorageMultisample(s.RENDERBUFFER,st,$,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,$,S.width,S.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,Et,s.RENDERBUFFER,R)}else{let Y=S.textures;for(let j=0;j<Y.length;j++){let $=Y[j],Et=r.convert($.format,$.colorSpace),st=r.convert($.type),bt=_($.internalFormat,Et,st,$.colorSpace),wt=me(S);z&&Mt(S)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,wt,bt,S.width,S.height):Mt(S)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,wt,bt,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,bt,S.width,S.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function At(R,S){if(S&&S.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,R),!(S.depthTexture&&S.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let Y=n.get(S.depthTexture);Y.__renderTarget=S,(!Y.__webglTexture||S.depthTexture.image.width!==S.width||S.depthTexture.image.height!==S.height)&&(S.depthTexture.image.width=S.width,S.depthTexture.image.height=S.height,S.depthTexture.needsUpdate=!0),G(S.depthTexture,0);let j=Y.__webglTexture,$=me(S);if(S.depthTexture.format===Es)Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,j,0,$):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,j,0);else if(S.depthTexture.format===Os)Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,j,0,$):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,j,0);else throw new Error("Unknown depthTexture format")}function $t(R){let S=n.get(R),z=R.isWebGLCubeRenderTarget===!0;if(S.__boundDepthTexture!==R.depthTexture){let Y=R.depthTexture;if(S.__depthDisposeCallback&&S.__depthDisposeCallback(),Y){let j=()=>{delete S.__boundDepthTexture,delete S.__depthDisposeCallback,Y.removeEventListener("dispose",j)};Y.addEventListener("dispose",j),S.__depthDisposeCallback=j}S.__boundDepthTexture=Y}if(R.depthTexture&&!S.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");let Y=R.texture.mipmaps;Y&&Y.length>0?At(S.__webglFramebuffer[0],R):At(S.__webglFramebuffer,R)}else if(z){S.__webglDepthbuffer=[];for(let Y=0;Y<6;Y++)if(e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer[Y]),S.__webglDepthbuffer[Y]===void 0)S.__webglDepthbuffer[Y]=s.createRenderbuffer(),Ut(S.__webglDepthbuffer[Y],R,!1);else{let j=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,$=S.__webglDepthbuffer[Y];s.bindRenderbuffer(s.RENDERBUFFER,$),s.framebufferRenderbuffer(s.FRAMEBUFFER,j,s.RENDERBUFFER,$)}}else{let Y=R.texture.mipmaps;if(Y&&Y.length>0?e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer),S.__webglDepthbuffer===void 0)S.__webglDepthbuffer=s.createRenderbuffer(),Ut(S.__webglDepthbuffer,R,!1);else{let j=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,$=S.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,$),s.framebufferRenderbuffer(s.FRAMEBUFFER,j,s.RENDERBUFFER,$)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function We(R,S,z){let Y=n.get(R);S!==void 0&&xt(Y.__webglFramebuffer,R,R.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),z!==void 0&&$t(R)}function P(R){let S=R.texture,z=n.get(R),Y=n.get(S);R.addEventListener("dispose",T);let j=R.textures,$=R.isWebGLCubeRenderTarget===!0,Et=j.length>1;if(Et||(Y.__webglTexture===void 0&&(Y.__webglTexture=s.createTexture()),Y.__version=S.version,o.memory.textures++),$){z.__webglFramebuffer=[];for(let st=0;st<6;st++)if(S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer[st]=[];for(let bt=0;bt<S.mipmaps.length;bt++)z.__webglFramebuffer[st][bt]=s.createFramebuffer()}else z.__webglFramebuffer[st]=s.createFramebuffer()}else{if(S.mipmaps&&S.mipmaps.length>0){z.__webglFramebuffer=[];for(let st=0;st<S.mipmaps.length;st++)z.__webglFramebuffer[st]=s.createFramebuffer()}else z.__webglFramebuffer=s.createFramebuffer();if(Et)for(let st=0,bt=j.length;st<bt;st++){let wt=n.get(j[st]);wt.__webglTexture===void 0&&(wt.__webglTexture=s.createTexture(),o.memory.textures++)}if(R.samples>0&&Mt(R)===!1){z.__webglMultisampledFramebuffer=s.createFramebuffer(),z.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let st=0;st<j.length;st++){let bt=j[st];z.__webglColorRenderbuffer[st]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,z.__webglColorRenderbuffer[st]);let wt=r.convert(bt.format,bt.colorSpace),nt=r.convert(bt.type),dt=_(bt.internalFormat,wt,nt,bt.colorSpace,R.isXRRenderTarget===!0),Pt=me(R);s.renderbufferStorageMultisample(s.RENDERBUFFER,Pt,dt,R.width,R.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+st,s.RENDERBUFFER,z.__webglColorRenderbuffer[st])}s.bindRenderbuffer(s.RENDERBUFFER,null),R.depthBuffer&&(z.__webglDepthRenderbuffer=s.createRenderbuffer(),Ut(z.__webglDepthRenderbuffer,R,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if($){e.bindTexture(s.TEXTURE_CUBE_MAP,Y.__webglTexture),Ht(s.TEXTURE_CUBE_MAP,S);for(let st=0;st<6;st++)if(S.mipmaps&&S.mipmaps.length>0)for(let bt=0;bt<S.mipmaps.length;bt++)xt(z.__webglFramebuffer[st][bt],R,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+st,bt);else xt(z.__webglFramebuffer[st],R,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+st,0);g(S)&&u(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Et){for(let st=0,bt=j.length;st<bt;st++){let wt=j[st],nt=n.get(wt),dt=s.TEXTURE_2D;(R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(dt=R.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(dt,nt.__webglTexture),Ht(dt,wt),xt(z.__webglFramebuffer,R,wt,s.COLOR_ATTACHMENT0+st,dt,0),g(wt)&&u(dt)}e.unbindTexture()}else{let st=s.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(st=R.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(st,Y.__webglTexture),Ht(st,S),S.mipmaps&&S.mipmaps.length>0)for(let bt=0;bt<S.mipmaps.length;bt++)xt(z.__webglFramebuffer[bt],R,S,s.COLOR_ATTACHMENT0,st,bt);else xt(z.__webglFramebuffer,R,S,s.COLOR_ATTACHMENT0,st,0);g(S)&&u(st),e.unbindTexture()}R.depthBuffer&&$t(R)}function pe(R){let S=R.textures;for(let z=0,Y=S.length;z<Y;z++){let j=S[z];if(g(j)){let $=v(R),Et=n.get(j).__webglTexture;e.bindTexture($,Et),u($),e.unbindTexture()}}}let Ot=[],Lt=[];function _t(R){if(R.samples>0){if(Mt(R)===!1){let S=R.textures,z=R.width,Y=R.height,j=s.COLOR_BUFFER_BIT,$=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Et=n.get(R),st=S.length>1;if(st)for(let wt=0;wt<S.length;wt++)e.bindFramebuffer(s.FRAMEBUFFER,Et.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,Et.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,Et.__webglMultisampledFramebuffer);let bt=R.texture.mipmaps;bt&&bt.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Et.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Et.__webglFramebuffer);for(let wt=0;wt<S.length;wt++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(j|=s.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(j|=s.STENCIL_BUFFER_BIT)),st){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,Et.__webglColorRenderbuffer[wt]);let nt=n.get(S[wt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,nt,0)}s.blitFramebuffer(0,0,z,Y,0,0,z,Y,j,s.NEAREST),l===!0&&(Ot.length=0,Lt.length=0,Ot.push(s.COLOR_ATTACHMENT0+wt),R.depthBuffer&&R.resolveDepthBuffer===!1&&(Ot.push($),Lt.push($),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Lt)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,Ot))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),st)for(let wt=0;wt<S.length;wt++){e.bindFramebuffer(s.FRAMEBUFFER,Et.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.RENDERBUFFER,Et.__webglColorRenderbuffer[wt]);let nt=n.get(S[wt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,Et.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+wt,s.TEXTURE_2D,nt,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,Et.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&l){let S=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[S])}}}function me(R){return Math.min(i.maxSamples,R.samples)}function Mt(R){let S=n.get(R);return R.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&S.__useRenderToTexture!==!1}function Vt(R){let S=o.render.frame;h.get(R)!==S&&(h.set(R,S),R.update())}function Fe(R,S){let z=R.colorSpace,Y=R.format,j=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||z!==Oi&&z!==ri&&(Zt.getTransfer(z)===se?(Y!==tn||j!==In)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",z)),S}function be(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(c.width=R.naturalWidth||R.width,c.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(c.width=R.displayWidth,c.height=R.displayHeight):(c.width=R.width,c.height=R.height),c}this.allocateTextureUnit=B,this.resetTextureUnits=L,this.setTexture2D=G,this.setTexture2DArray=X,this.setTexture3D=Q,this.setTextureCube=V,this.rebindTextures=We,this.setupRenderTarget=P,this.updateRenderTargetMipmap=pe,this.updateMultisampleRenderTarget=_t,this.setupDepthRenderbuffer=$t,this.setupFrameBufferTexture=xt,this.useMultisampledRTT=Mt}function Cx(s,t){function e(n,i=ri){let r,o=Zt.getTransfer(i);if(n===In)return s.UNSIGNED_BYTE;if(n===ga)return s.UNSIGNED_SHORT_4_4_4_4;if(n===xa)return s.UNSIGNED_SHORT_5_5_5_1;if(n===Sc)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===wc)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===Mc)return s.BYTE;if(n===bc)return s.SHORT;if(n===Us)return s.UNSIGNED_SHORT;if(n===ma)return s.INT;if(n===bi)return s.UNSIGNED_INT;if(n===Pn)return s.FLOAT;if(n===Ns)return s.HALF_FLOAT;if(n===Tc)return s.ALPHA;if(n===Ec)return s.RGB;if(n===tn)return s.RGBA;if(n===Es)return s.DEPTH_COMPONENT;if(n===Os)return s.DEPTH_STENCIL;if(n===va)return s.RED;if(n===ya)return s.RED_INTEGER;if(n===Ac)return s.RG;if(n===_a)return s.RG_INTEGER;if(n===Ma)return s.RGBA_INTEGER;if(n===Ur||n===Nr||n===Fr||n===Or)if(o===se)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Ur)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Nr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Fr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Or)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Ur)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Nr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Fr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Or)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ba||n===Sa||n===wa||n===Ta)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===ba)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Sa)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===wa)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ta)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Ea||n===Aa||n===Ca)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Ea||n===Aa)return o===se?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Ca)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Ra||n===Ia||n===Pa||n===La||n===Da||n===ka||n===Ua||n===Na||n===Fa||n===Oa||n===Ba||n===za||n===Ha||n===Va)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Ra)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ia)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Pa)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===La)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Da)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===ka)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ua)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Na)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Fa)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Oa)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ba)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===za)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ha)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Va)return o===se?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ga||n===Wa||n===qa)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ga)return o===se?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Wa)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===qa)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Xa||n===$a||n===Ya||n===Za)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Xa)return r.COMPRESSED_RED_RGTC1_EXT;if(n===$a)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Ya)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Za)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Fs?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}var Rx=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Ix=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Zc=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){let n=new Ar(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new Cn({vertexShader:Rx,fragmentShader:Ix,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new jt(new Vi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Jc=class extends ei{constructor(t,e){super();let n=this,i=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,d=null,f=null,p=null,m=null,x=typeof XRWebGLBinding<"u",g=new Zc,u={},v=e.getContextAttributes(),_=null,M=null,A=[],b=[],T=new Nt,I=null,y=new Be;y.viewport=new _e;let w=new Be;w.viewport=new _e;let C=[y,w],L=new ia,B=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let K=A[Z];return K===void 0&&(K=new Rs,A[Z]=K),K.getTargetRaySpace()},this.getControllerGrip=function(Z){let K=A[Z];return K===void 0&&(K=new Rs,A[Z]=K),K.getGripSpace()},this.getHand=function(Z){let K=A[Z];return K===void 0&&(K=new Rs,A[Z]=K),K.getHandSpace()};function G(Z){let K=b.indexOf(Z.inputSource);if(K===-1)return;let xt=A[K];xt!==void 0&&(xt.update(Z.inputSource,Z.frame,c||o),xt.dispatchEvent({type:Z.type,data:Z.inputSource}))}function X(){i.removeEventListener("select",G),i.removeEventListener("selectstart",G),i.removeEventListener("selectend",G),i.removeEventListener("squeeze",G),i.removeEventListener("squeezestart",G),i.removeEventListener("squeezeend",G),i.removeEventListener("end",X),i.removeEventListener("inputsourceschange",Q);for(let Z=0;Z<A.length;Z++){let K=b[Z];K!==null&&(b[Z]=null,A[Z].disconnect(K))}B=null,H=null,g.reset();for(let Z in u)delete u[Z];t.setRenderTarget(_),p=null,f=null,d=null,i=null,M=null,Qt.stop(),n.isPresenting=!1,t.setPixelRatio(I),t.setSize(T.width,T.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){r=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){a=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return f!==null?f:p},this.getBinding=function(){return d===null&&x&&(d=new XRWebGLBinding(i,e)),d},this.getFrame=function(){return m},this.getSession=function(){return i},this.setSession=async function(Z){if(i=Z,i!==null){if(_=t.getRenderTarget(),i.addEventListener("select",G),i.addEventListener("selectstart",G),i.addEventListener("selectend",G),i.addEventListener("squeeze",G),i.addEventListener("squeezestart",G),i.addEventListener("squeezeend",G),i.addEventListener("end",X),i.addEventListener("inputsourceschange",Q),v.xrCompatible!==!0&&await e.makeXRCompatible(),I=t.getPixelRatio(),t.getSize(T),x&&"createProjectionLayer"in XRWebGLBinding.prototype){let xt=null,Ut=null,At=null;v.depth&&(At=v.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,xt=v.stencil?Os:Es,Ut=v.stencil?Fs:bi);let $t={colorFormat:e.RGBA8,depthFormat:At,scaleFactor:r};d=this.getBinding(),f=d.createProjectionLayer($t),i.updateRenderState({layers:[f]}),t.setPixelRatio(1),t.setSize(f.textureWidth,f.textureHeight,!1),M=new Bn(f.textureWidth,f.textureHeight,{format:tn,type:In,depthTexture:new Er(f.textureWidth,f.textureHeight,Ut,void 0,void 0,void 0,void 0,void 0,void 0,xt),stencilBuffer:v.stencil,colorSpace:t.outputColorSpace,samples:v.antialias?4:0,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}else{let xt={antialias:v.antialias,alpha:!0,depth:v.depth,stencil:v.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(i,e,xt),i.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),M=new Bn(p.framebufferWidth,p.framebufferHeight,{format:tn,type:In,colorSpace:t.outputColorSpace,stencilBuffer:v.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await i.requestReferenceSpace(a),Qt.setContext(i),Qt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return g.getDepthTexture()};function Q(Z){for(let K=0;K<Z.removed.length;K++){let xt=Z.removed[K],Ut=b.indexOf(xt);Ut>=0&&(b[Ut]=null,A[Ut].disconnect(xt))}for(let K=0;K<Z.added.length;K++){let xt=Z.added[K],Ut=b.indexOf(xt);if(Ut===-1){for(let $t=0;$t<A.length;$t++)if($t>=b.length){b.push(xt),Ut=$t;break}else if(b[$t]===null){b[$t]=xt,Ut=$t;break}if(Ut===-1)break}let At=A[Ut];At&&At.connect(xt)}}let V=new U,ot=new U;function ct(Z,K,xt){V.setFromMatrixPosition(K.matrixWorld),ot.setFromMatrixPosition(xt.matrixWorld);let Ut=V.distanceTo(ot),At=K.projectionMatrix.elements,$t=xt.projectionMatrix.elements,We=At[14]/(At[10]-1),P=At[14]/(At[10]+1),pe=(At[9]+1)/At[5],Ot=(At[9]-1)/At[5],Lt=(At[8]-1)/At[0],_t=($t[8]+1)/$t[0],me=We*Lt,Mt=We*_t,Vt=Ut/(-Lt+_t),Fe=Vt*-Lt;if(K.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(Fe),Z.translateZ(Vt),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),At[10]===-1)Z.projectionMatrix.copy(K.projectionMatrix),Z.projectionMatrixInverse.copy(K.projectionMatrixInverse);else{let be=We+Vt,R=P+Vt,S=me-Fe,z=Mt+(Ut-Fe),Y=pe*P/R*be,j=Ot*P/R*be;Z.projectionMatrix.makePerspective(S,z,Y,j,be,R),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function gt(Z,K){K===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(K.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(i===null)return;let K=Z.near,xt=Z.far;g.texture!==null&&(g.depthNear>0&&(K=g.depthNear),g.depthFar>0&&(xt=g.depthFar)),L.near=w.near=y.near=K,L.far=w.far=y.far=xt,(B!==L.near||H!==L.far)&&(i.updateRenderState({depthNear:L.near,depthFar:L.far}),B=L.near,H=L.far),L.layers.mask=Z.layers.mask|6,y.layers.mask=L.layers.mask&3,w.layers.mask=L.layers.mask&5;let Ut=Z.parent,At=L.cameras;gt(L,Ut);for(let $t=0;$t<At.length;$t++)gt(At[$t],Ut);At.length===2?ct(L,y,w):L.projectionMatrix.copy(y.projectionMatrix),Ht(Z,L,Ut)};function Ht(Z,K,xt){xt===null?Z.matrix.copy(K.matrixWorld):(Z.matrix.copy(xt.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(K.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(K.projectionMatrix),Z.projectionMatrixInverse.copy(K.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=No*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return L},this.getFoveation=function(){if(!(f===null&&p===null))return l},this.setFoveation=function(Z){l=Z,f!==null&&(f.fixedFoveation=Z),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=Z)},this.hasDepthSensing=function(){return g.texture!==null},this.getDepthSensingMesh=function(){return g.getMesh(L)},this.getCameraTexture=function(Z){return u[Z]};let ie=null;function ce(Z,K){if(h=K.getViewerPose(c||o),m=K,h!==null){let xt=h.views;p!==null&&(t.setRenderTargetFramebuffer(M,p.framebuffer),t.setRenderTarget(M));let Ut=!1;xt.length!==L.cameras.length&&(L.cameras.length=0,Ut=!0);for(let P=0;P<xt.length;P++){let pe=xt[P],Ot=null;if(p!==null)Ot=p.getViewport(pe);else{let _t=d.getViewSubImage(f,pe);Ot=_t.viewport,P===0&&(t.setRenderTargetTextures(M,_t.colorTexture,_t.depthStencilTexture),t.setRenderTarget(M))}let Lt=C[P];Lt===void 0&&(Lt=new Be,Lt.layers.enable(P),Lt.viewport=new _e,C[P]=Lt),Lt.matrix.fromArray(pe.transform.matrix),Lt.matrix.decompose(Lt.position,Lt.quaternion,Lt.scale),Lt.projectionMatrix.fromArray(pe.projectionMatrix),Lt.projectionMatrixInverse.copy(Lt.projectionMatrix).invert(),Lt.viewport.set(Ot.x,Ot.y,Ot.width,Ot.height),P===0&&(L.matrix.copy(Lt.matrix),L.matrix.decompose(L.position,L.quaternion,L.scale)),Ut===!0&&L.cameras.push(Lt)}let At=i.enabledFeatures;if(At&&At.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&x){d=n.getBinding();let P=d.getDepthInformation(xt[0]);P&&P.isValid&&P.texture&&g.init(P,i.renderState)}if(At&&At.includes("camera-access")&&x){t.state.unbindTexture(),d=n.getBinding();for(let P=0;P<xt.length;P++){let pe=xt[P].camera;if(pe){let Ot=u[pe];Ot||(Ot=new Ar,u[pe]=Ot);let Lt=d.getCameraImage(pe);Ot.sourceTexture=Lt}}}}for(let xt=0;xt<A.length;xt++){let Ut=b[xt],At=A[xt];Ut!==null&&At!==void 0&&At.update(Ut,K,c||o)}ie&&ie(Z,K),K.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:K}),m=null}let Qt=new _d;Qt.setAnimationLoop(ce),this.setAnimationLoop=function(Z){ie=Z},this.dispose=function(){}}},ji=new An,Px=new ee;function Lx(s,t){function e(g,u){g.matrixAutoUpdate===!0&&g.updateMatrix(),u.value.copy(g.matrix)}function n(g,u){u.color.getRGB(g.fogColor.value,Dc(s)),u.isFog?(g.fogNear.value=u.near,g.fogFar.value=u.far):u.isFogExp2&&(g.fogDensity.value=u.density)}function i(g,u,v,_,M){u.isMeshBasicMaterial||u.isMeshLambertMaterial?r(g,u):u.isMeshToonMaterial?(r(g,u),d(g,u)):u.isMeshPhongMaterial?(r(g,u),h(g,u)):u.isMeshStandardMaterial?(r(g,u),f(g,u),u.isMeshPhysicalMaterial&&p(g,u,M)):u.isMeshMatcapMaterial?(r(g,u),m(g,u)):u.isMeshDepthMaterial?r(g,u):u.isMeshDistanceMaterial?(r(g,u),x(g,u)):u.isMeshNormalMaterial?r(g,u):u.isLineBasicMaterial?(o(g,u),u.isLineDashedMaterial&&a(g,u)):u.isPointsMaterial?l(g,u,v,_):u.isSpriteMaterial?c(g,u):u.isShadowMaterial?(g.color.value.copy(u.color),g.opacity.value=u.opacity):u.isShaderMaterial&&(u.uniformsNeedUpdate=!1)}function r(g,u){g.opacity.value=u.opacity,u.color&&g.diffuse.value.copy(u.color),u.emissive&&g.emissive.value.copy(u.emissive).multiplyScalar(u.emissiveIntensity),u.map&&(g.map.value=u.map,e(u.map,g.mapTransform)),u.alphaMap&&(g.alphaMap.value=u.alphaMap,e(u.alphaMap,g.alphaMapTransform)),u.bumpMap&&(g.bumpMap.value=u.bumpMap,e(u.bumpMap,g.bumpMapTransform),g.bumpScale.value=u.bumpScale,u.side===Ve&&(g.bumpScale.value*=-1)),u.normalMap&&(g.normalMap.value=u.normalMap,e(u.normalMap,g.normalMapTransform),g.normalScale.value.copy(u.normalScale),u.side===Ve&&g.normalScale.value.negate()),u.displacementMap&&(g.displacementMap.value=u.displacementMap,e(u.displacementMap,g.displacementMapTransform),g.displacementScale.value=u.displacementScale,g.displacementBias.value=u.displacementBias),u.emissiveMap&&(g.emissiveMap.value=u.emissiveMap,e(u.emissiveMap,g.emissiveMapTransform)),u.specularMap&&(g.specularMap.value=u.specularMap,e(u.specularMap,g.specularMapTransform)),u.alphaTest>0&&(g.alphaTest.value=u.alphaTest);let v=t.get(u),_=v.envMap,M=v.envMapRotation;_&&(g.envMap.value=_,ji.copy(M),ji.x*=-1,ji.y*=-1,ji.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(ji.y*=-1,ji.z*=-1),g.envMapRotation.value.setFromMatrix4(Px.makeRotationFromEuler(ji)),g.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=u.reflectivity,g.ior.value=u.ior,g.refractionRatio.value=u.refractionRatio),u.lightMap&&(g.lightMap.value=u.lightMap,g.lightMapIntensity.value=u.lightMapIntensity,e(u.lightMap,g.lightMapTransform)),u.aoMap&&(g.aoMap.value=u.aoMap,g.aoMapIntensity.value=u.aoMapIntensity,e(u.aoMap,g.aoMapTransform))}function o(g,u){g.diffuse.value.copy(u.color),g.opacity.value=u.opacity,u.map&&(g.map.value=u.map,e(u.map,g.mapTransform))}function a(g,u){g.dashSize.value=u.dashSize,g.totalSize.value=u.dashSize+u.gapSize,g.scale.value=u.scale}function l(g,u,v,_){g.diffuse.value.copy(u.color),g.opacity.value=u.opacity,g.size.value=u.size*v,g.scale.value=_*.5,u.map&&(g.map.value=u.map,e(u.map,g.uvTransform)),u.alphaMap&&(g.alphaMap.value=u.alphaMap,e(u.alphaMap,g.alphaMapTransform)),u.alphaTest>0&&(g.alphaTest.value=u.alphaTest)}function c(g,u){g.diffuse.value.copy(u.color),g.opacity.value=u.opacity,g.rotation.value=u.rotation,u.map&&(g.map.value=u.map,e(u.map,g.mapTransform)),u.alphaMap&&(g.alphaMap.value=u.alphaMap,e(u.alphaMap,g.alphaMapTransform)),u.alphaTest>0&&(g.alphaTest.value=u.alphaTest)}function h(g,u){g.specular.value.copy(u.specular),g.shininess.value=Math.max(u.shininess,1e-4)}function d(g,u){u.gradientMap&&(g.gradientMap.value=u.gradientMap)}function f(g,u){g.metalness.value=u.metalness,u.metalnessMap&&(g.metalnessMap.value=u.metalnessMap,e(u.metalnessMap,g.metalnessMapTransform)),g.roughness.value=u.roughness,u.roughnessMap&&(g.roughnessMap.value=u.roughnessMap,e(u.roughnessMap,g.roughnessMapTransform)),u.envMap&&(g.envMapIntensity.value=u.envMapIntensity)}function p(g,u,v){g.ior.value=u.ior,u.sheen>0&&(g.sheenColor.value.copy(u.sheenColor).multiplyScalar(u.sheen),g.sheenRoughness.value=u.sheenRoughness,u.sheenColorMap&&(g.sheenColorMap.value=u.sheenColorMap,e(u.sheenColorMap,g.sheenColorMapTransform)),u.sheenRoughnessMap&&(g.sheenRoughnessMap.value=u.sheenRoughnessMap,e(u.sheenRoughnessMap,g.sheenRoughnessMapTransform))),u.clearcoat>0&&(g.clearcoat.value=u.clearcoat,g.clearcoatRoughness.value=u.clearcoatRoughness,u.clearcoatMap&&(g.clearcoatMap.value=u.clearcoatMap,e(u.clearcoatMap,g.clearcoatMapTransform)),u.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=u.clearcoatRoughnessMap,e(u.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),u.clearcoatNormalMap&&(g.clearcoatNormalMap.value=u.clearcoatNormalMap,e(u.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(u.clearcoatNormalScale),u.side===Ve&&g.clearcoatNormalScale.value.negate())),u.dispersion>0&&(g.dispersion.value=u.dispersion),u.iridescence>0&&(g.iridescence.value=u.iridescence,g.iridescenceIOR.value=u.iridescenceIOR,g.iridescenceThicknessMinimum.value=u.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=u.iridescenceThicknessRange[1],u.iridescenceMap&&(g.iridescenceMap.value=u.iridescenceMap,e(u.iridescenceMap,g.iridescenceMapTransform)),u.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=u.iridescenceThicknessMap,e(u.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),u.transmission>0&&(g.transmission.value=u.transmission,g.transmissionSamplerMap.value=v.texture,g.transmissionSamplerSize.value.set(v.width,v.height),u.transmissionMap&&(g.transmissionMap.value=u.transmissionMap,e(u.transmissionMap,g.transmissionMapTransform)),g.thickness.value=u.thickness,u.thicknessMap&&(g.thicknessMap.value=u.thicknessMap,e(u.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=u.attenuationDistance,g.attenuationColor.value.copy(u.attenuationColor)),u.anisotropy>0&&(g.anisotropyVector.value.set(u.anisotropy*Math.cos(u.anisotropyRotation),u.anisotropy*Math.sin(u.anisotropyRotation)),u.anisotropyMap&&(g.anisotropyMap.value=u.anisotropyMap,e(u.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=u.specularIntensity,g.specularColor.value.copy(u.specularColor),u.specularColorMap&&(g.specularColorMap.value=u.specularColorMap,e(u.specularColorMap,g.specularColorMapTransform)),u.specularIntensityMap&&(g.specularIntensityMap.value=u.specularIntensityMap,e(u.specularIntensityMap,g.specularIntensityMapTransform))}function m(g,u){u.matcap&&(g.matcap.value=u.matcap)}function x(g,u){let v=t.get(u).light;g.referencePosition.value.setFromMatrixPosition(v.matrixWorld),g.nearDistance.value=v.shadow.camera.near,g.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function Dx(s,t,e,n){let i={},r={},o=[],a=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function l(v,_){let M=_.program;n.uniformBlockBinding(v,M)}function c(v,_){let M=i[v.id];M===void 0&&(m(v),M=h(v),i[v.id]=M,v.addEventListener("dispose",g));let A=_.program;n.updateUBOMapping(v,A);let b=t.render.frame;r[v.id]!==b&&(f(v),r[v.id]=b)}function h(v){let _=d();v.__bindingPointIndex=_;let M=s.createBuffer(),A=v.__size,b=v.usage;return s.bindBuffer(s.UNIFORM_BUFFER,M),s.bufferData(s.UNIFORM_BUFFER,A,b),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,_,M),M}function d(){for(let v=0;v<a;v++)if(o.indexOf(v)===-1)return o.push(v),v;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function f(v){let _=i[v.id],M=v.uniforms,A=v.__cache;s.bindBuffer(s.UNIFORM_BUFFER,_);for(let b=0,T=M.length;b<T;b++){let I=Array.isArray(M[b])?M[b]:[M[b]];for(let y=0,w=I.length;y<w;y++){let C=I[y];if(p(C,b,y,A)===!0){let L=C.__offset,B=Array.isArray(C.value)?C.value:[C.value],H=0;for(let G=0;G<B.length;G++){let X=B[G],Q=x(X);typeof X=="number"||typeof X=="boolean"?(C.__data[0]=X,s.bufferSubData(s.UNIFORM_BUFFER,L+H,C.__data)):X.isMatrix3?(C.__data[0]=X.elements[0],C.__data[1]=X.elements[1],C.__data[2]=X.elements[2],C.__data[3]=0,C.__data[4]=X.elements[3],C.__data[5]=X.elements[4],C.__data[6]=X.elements[5],C.__data[7]=0,C.__data[8]=X.elements[6],C.__data[9]=X.elements[7],C.__data[10]=X.elements[8],C.__data[11]=0):(X.toArray(C.__data,H),H+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,L,C.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function p(v,_,M,A){let b=v.value,T=_+"_"+M;if(A[T]===void 0)return typeof b=="number"||typeof b=="boolean"?A[T]=b:A[T]=b.clone(),!0;{let I=A[T];if(typeof b=="number"||typeof b=="boolean"){if(I!==b)return A[T]=b,!0}else if(I.equals(b)===!1)return I.copy(b),!0}return!1}function m(v){let _=v.uniforms,M=0,A=16;for(let T=0,I=_.length;T<I;T++){let y=Array.isArray(_[T])?_[T]:[_[T]];for(let w=0,C=y.length;w<C;w++){let L=y[w],B=Array.isArray(L.value)?L.value:[L.value];for(let H=0,G=B.length;H<G;H++){let X=B[H],Q=x(X),V=M%A,ot=V%Q.boundary,ct=V+ot;M+=ot,ct!==0&&A-ct<Q.storage&&(M+=A-ct),L.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),L.__offset=M,M+=Q.storage}}}let b=M%A;return b>0&&(M+=A-b),v.__size=M,v.__cache={},this}function x(v){let _={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(_.boundary=4,_.storage=4):v.isVector2?(_.boundary=8,_.storage=8):v.isVector3||v.isColor?(_.boundary=16,_.storage=12):v.isVector4?(_.boundary=16,_.storage=16):v.isMatrix3?(_.boundary=48,_.storage=48):v.isMatrix4?(_.boundary=64,_.storage=64):v.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",v),_}function g(v){let _=v.target;_.removeEventListener("dispose",g);let M=o.indexOf(_.__bindingPointIndex);o.splice(M,1),s.deleteBuffer(i[_.id]),delete i[_.id],delete r[_.id]}function u(){for(let v in i)s.deleteBuffer(i[v]);o=[],i={},r={}}return{bind:l,update:c,dispose:u}}var tl=class{constructor(t={}){let{canvas:e=qu(),context:n=null,depth:i=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1,reversedDepthBuffer:f=!1}=t;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=o;let m=new Uint32Array(4),x=new Int32Array(4),g=null,u=null,v=[],_=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=si,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let M=this,A=!1;this._outputColorSpace=Le;let b=0,T=0,I=null,y=-1,w=null,C=new _e,L=new _e,B=null,H=new kt(0),G=0,X=e.width,Q=e.height,V=1,ot=null,ct=null,gt=new _e(0,0,X,Q),Ht=new _e(0,0,X,Q),ie=!1,ce=new Ls,Qt=!1,Z=!1,K=new ee,xt=new U,Ut=new _e,At={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},$t=!1;function We(){return I===null?V:1}let P=n;function pe(E,N){return e.getContext(E,N)}try{let E={alpha:!0,depth:i,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${"180"}`),e.addEventListener("webglcontextlost",at,!1),e.addEventListener("webglcontextrestored",mt,!1),e.addEventListener("webglcontextcreationerror",tt,!1),P===null){let N="webgl2";if(P=pe(N,E),P===null)throw pe(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(E){throw console.error("THREE.WebGLRenderer: "+E.message),E}let Ot,Lt,_t,me,Mt,Vt,Fe,be,R,S,z,Y,j,$,Et,st,bt,wt,nt,dt,Pt,Tt,ht,zt;function D(){Ot=new jg(P),Ot.init(),Tt=new Cx(P,Ot),Lt=new Wg(P,Ot,t,Tt),_t=new Ex(P,Ot),Lt.reversedDepthBuffer&&f&&_t.buffers.depth.setReversed(!0),me=new t0(P),Mt=new fx,Vt=new Ax(P,Ot,_t,Mt,Lt,Tt,me),Fe=new Xg(M),be=new Jg(M),R=new op(P),ht=new Vg(P,R),S=new Kg(P,R,me,ht),z=new n0(P,S,R,me),nt=new e0(P,Lt,Vt),st=new qg(Mt),Y=new dx(M,Fe,be,Ot,Lt,ht,st),j=new Lx(M,Mt),$=new mx,Et=new Mx(Ot),wt=new Hg(M,Fe,be,_t,z,p,l),bt=new wx(M,z,Lt),zt=new Dx(P,me,Lt,_t),dt=new Gg(P,Ot,me),Pt=new Qg(P,Ot,me),me.programs=Y.programs,M.capabilities=Lt,M.extensions=Ot,M.properties=Mt,M.renderLists=$,M.shadowMap=bt,M.state=_t,M.info=me}D();let it=new Jc(M,P);this.xr=it,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){let E=Ot.get("WEBGL_lose_context");E&&E.loseContext()},this.forceContextRestore=function(){let E=Ot.get("WEBGL_lose_context");E&&E.restoreContext()},this.getPixelRatio=function(){return V},this.setPixelRatio=function(E){E!==void 0&&(V=E,this.setSize(X,Q,!1))},this.getSize=function(E){return E.set(X,Q)},this.setSize=function(E,N,W=!0){if(it.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}X=E,Q=N,e.width=Math.floor(E*V),e.height=Math.floor(N*V),W===!0&&(e.style.width=E+"px",e.style.height=N+"px"),this.setViewport(0,0,E,N)},this.getDrawingBufferSize=function(E){return E.set(X*V,Q*V).floor()},this.setDrawingBufferSize=function(E,N,W){X=E,Q=N,V=W,e.width=Math.floor(E*W),e.height=Math.floor(N*W),this.setViewport(0,0,E,N)},this.getCurrentViewport=function(E){return E.copy(C)},this.getViewport=function(E){return E.copy(gt)},this.setViewport=function(E,N,W,q){E.isVector4?gt.set(E.x,E.y,E.z,E.w):gt.set(E,N,W,q),_t.viewport(C.copy(gt).multiplyScalar(V).round())},this.getScissor=function(E){return E.copy(Ht)},this.setScissor=function(E,N,W,q){E.isVector4?Ht.set(E.x,E.y,E.z,E.w):Ht.set(E,N,W,q),_t.scissor(L.copy(Ht).multiplyScalar(V).round())},this.getScissorTest=function(){return ie},this.setScissorTest=function(E){_t.setScissorTest(ie=E)},this.setOpaqueSort=function(E){ot=E},this.setTransparentSort=function(E){ct=E},this.getClearColor=function(E){return E.copy(wt.getClearColor())},this.setClearColor=function(){wt.setClearColor(...arguments)},this.getClearAlpha=function(){return wt.getClearAlpha()},this.setClearAlpha=function(){wt.setClearAlpha(...arguments)},this.clear=function(E=!0,N=!0,W=!0){let q=0;if(E){let F=!1;if(I!==null){let et=I.texture.format;F=et===Ma||et===_a||et===ya}if(F){let et=I.texture.type,ut=et===In||et===bi||et===Us||et===Fs||et===ga||et===xa,vt=wt.getClearColor(),pt=wt.getClearAlpha(),It=vt.r,Dt=vt.g,Ct=vt.b;ut?(m[0]=It,m[1]=Dt,m[2]=Ct,m[3]=pt,P.clearBufferuiv(P.COLOR,0,m)):(x[0]=It,x[1]=Dt,x[2]=Ct,x[3]=pt,P.clearBufferiv(P.COLOR,0,x))}else q|=P.COLOR_BUFFER_BIT}N&&(q|=P.DEPTH_BUFFER_BIT),W&&(q|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),P.clear(q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",at,!1),e.removeEventListener("webglcontextrestored",mt,!1),e.removeEventListener("webglcontextcreationerror",tt,!1),wt.dispose(),$.dispose(),Et.dispose(),Mt.dispose(),Fe.dispose(),be.dispose(),z.dispose(),ht.dispose(),zt.dispose(),Y.dispose(),it.dispose(),it.removeEventListener("sessionstart",Un),it.removeEventListener("sessionend",gh),Ri.stop()};function at(E){E.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),A=!0}function mt(){console.log("THREE.WebGLRenderer: Context Restored."),A=!1;let E=me.autoReset,N=bt.enabled,W=bt.autoUpdate,q=bt.needsUpdate,F=bt.type;D(),me.autoReset=E,bt.enabled=N,bt.autoUpdate=W,bt.needsUpdate=q,bt.type=F}function tt(E){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",E.statusMessage)}function J(E){let N=E.target;N.removeEventListener("dispose",J),yt(N)}function yt(E){Ft(E),Mt.remove(E)}function Ft(E){let N=Mt.get(E).programs;N!==void 0&&(N.forEach(function(W){Y.releaseProgram(W)}),E.isShaderMaterial&&Y.releaseShaderCache(E))}this.renderBufferDirect=function(E,N,W,q,F,et){N===null&&(N=At);let ut=F.isMesh&&F.matrixWorld.determinant()<0,vt=ff(E,N,W,q,F);_t.setMaterial(q,ut);let pt=W.index,It=1;if(q.wireframe===!0){if(pt=S.getWireframeAttribute(W),pt===void 0)return;It=2}let Dt=W.drawRange,Ct=W.attributes.position,qt=Dt.start*It,oe=(Dt.start+Dt.count)*It;et!==null&&(qt=Math.max(qt,et.start*It),oe=Math.min(oe,(et.start+et.count)*It)),pt!==null?(qt=Math.max(qt,0),oe=Math.min(oe,pt.count)):Ct!=null&&(qt=Math.max(qt,0),oe=Math.min(oe,Ct.count));let Me=oe-qt;if(Me<0||Me===1/0)return;ht.setup(F,q,vt,W,pt);let de,le=dt;if(pt!==null&&(de=R.get(pt),le=Pt,le.setIndex(de)),F.isMesh)q.wireframe===!0?(_t.setLineWidth(q.wireframeLinewidth*We()),le.setMode(P.LINES)):le.setMode(P.TRIANGLES);else if(F.isLine){let Rt=q.linewidth;Rt===void 0&&(Rt=1),_t.setLineWidth(Rt*We()),F.isLineSegments?le.setMode(P.LINES):F.isLineLoop?le.setMode(P.LINE_LOOP):le.setMode(P.LINE_STRIP)}else F.isPoints?le.setMode(P.POINTS):F.isSprite&&le.setMode(P.TRIANGLES);if(F.isBatchedMesh)if(F._multiDrawInstances!==null)As("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),le.renderMultiDrawInstances(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount,F._multiDrawInstances);else if(Ot.get("WEBGL_multi_draw"))le.renderMultiDraw(F._multiDrawStarts,F._multiDrawCounts,F._multiDrawCount);else{let Rt=F._multiDrawStarts,ve=F._multiDrawCounts,Jt=F._multiDrawCount,sn=pt?R.get(pt).bytesPerElement:1,os=Mt.get(q).currentProgram.getUniforms();for(let rn=0;rn<Jt;rn++)os.setValue(P,"_gl_DrawID",rn),le.render(Rt[rn]/sn,ve[rn])}else if(F.isInstancedMesh)le.renderInstances(qt,Me,F.count);else if(W.isInstancedBufferGeometry){let Rt=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,ve=Math.min(W.instanceCount,Rt);le.renderInstances(qt,Me,ve)}else le.render(qt,Me)};function he(E,N,W){E.transparent===!0&&E.side===vn&&E.forceSinglePass===!1?(E.side=Ve,E.needsUpdate=!0,$r(E,N,W),E.side=ti,E.needsUpdate=!0,$r(E,N,W),E.side=vn):$r(E,N,W)}this.compile=function(E,N,W=null){W===null&&(W=E),u=Et.get(W),u.init(N),_.push(u),W.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(u.pushLight(F),F.castShadow&&u.pushShadow(F))}),E!==W&&E.traverseVisible(function(F){F.isLight&&F.layers.test(N.layers)&&(u.pushLight(F),F.castShadow&&u.pushShadow(F))}),u.setupLights();let q=new Set;return E.traverse(function(F){if(!(F.isMesh||F.isPoints||F.isLine||F.isSprite))return;let et=F.material;if(et)if(Array.isArray(et))for(let ut=0;ut<et.length;ut++){let vt=et[ut];he(vt,W,F),q.add(vt)}else he(et,W,F),q.add(et)}),u=_.pop(),q},this.compileAsync=function(E,N,W=null){let q=this.compile(E,N,W);return new Promise(F=>{function et(){if(q.forEach(function(ut){Mt.get(ut).currentProgram.isReady()&&q.delete(ut)}),q.size===0){F(E);return}setTimeout(et,10)}Ot.get("KHR_parallel_shader_compile")!==null?et():setTimeout(et,10)})};let te=null;function qn(E){te&&te(E)}function Un(){Ri.stop()}function gh(){Ri.start()}let Ri=new _d;Ri.setAnimationLoop(qn),typeof self<"u"&&Ri.setContext(self),this.setAnimationLoop=function(E){te=E,it.setAnimationLoop(E),E===null?Ri.stop():Ri.start()},it.addEventListener("sessionstart",Un),it.addEventListener("sessionend",gh),this.render=function(E,N){if(N!==void 0&&N.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(A===!0)return;if(E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),it.enabled===!0&&it.isPresenting===!0&&(it.cameraAutoUpdate===!0&&it.updateCamera(N),N=it.getCamera()),E.isScene===!0&&E.onBeforeRender(M,E,N,I),u=Et.get(E,_.length),u.init(N),_.push(u),K.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),ce.setFromProjectionMatrix(K,Tn,N.reversedDepth),Z=this.localClippingEnabled,Qt=st.init(this.clippingPlanes,Z),g=$.get(E,v.length),g.init(),v.push(g),it.enabled===!0&&it.isPresenting===!0){let et=M.xr.getDepthSensingMesh();et!==null&&Rl(et,N,-1/0,M.sortObjects)}Rl(E,N,0,M.sortObjects),g.finish(),M.sortObjects===!0&&g.sort(ot,ct),$t=it.enabled===!1||it.isPresenting===!1||it.hasDepthSensing()===!1,$t&&wt.addToRenderList(g,E),this.info.render.frame++,Qt===!0&&st.beginShadows();let W=u.state.shadowsArray;bt.render(W,E,N),Qt===!0&&st.endShadows(),this.info.autoReset===!0&&this.info.reset();let q=g.opaque,F=g.transmissive;if(u.setupLights(),N.isArrayCamera){let et=N.cameras;if(F.length>0)for(let ut=0,vt=et.length;ut<vt;ut++){let pt=et[ut];vh(q,F,E,pt)}$t&&wt.render(E);for(let ut=0,vt=et.length;ut<vt;ut++){let pt=et[ut];xh(g,E,pt,pt.viewport)}}else F.length>0&&vh(q,F,E,N),$t&&wt.render(E),xh(g,E,N);I!==null&&T===0&&(Vt.updateMultisampleRenderTarget(I),Vt.updateRenderTargetMipmap(I)),E.isScene===!0&&E.onAfterRender(M,E,N),ht.resetDefaultState(),y=-1,w=null,_.pop(),_.length>0?(u=_[_.length-1],Qt===!0&&st.setGlobalState(M.clippingPlanes,u.state.camera)):u=null,v.pop(),v.length>0?g=v[v.length-1]:g=null};function Rl(E,N,W,q){if(E.visible===!1)return;if(E.layers.test(N.layers)){if(E.isGroup)W=E.renderOrder;else if(E.isLOD)E.autoUpdate===!0&&E.update(N);else if(E.isLight)u.pushLight(E),E.castShadow&&u.pushShadow(E);else if(E.isSprite){if(!E.frustumCulled||ce.intersectsSprite(E)){q&&Ut.setFromMatrixPosition(E.matrixWorld).applyMatrix4(K);let ut=z.update(E),vt=E.material;vt.visible&&g.push(E,ut,vt,W,Ut.z,null)}}else if((E.isMesh||E.isLine||E.isPoints)&&(!E.frustumCulled||ce.intersectsObject(E))){let ut=z.update(E),vt=E.material;if(q&&(E.boundingSphere!==void 0?(E.boundingSphere===null&&E.computeBoundingSphere(),Ut.copy(E.boundingSphere.center)):(ut.boundingSphere===null&&ut.computeBoundingSphere(),Ut.copy(ut.boundingSphere.center)),Ut.applyMatrix4(E.matrixWorld).applyMatrix4(K)),Array.isArray(vt)){let pt=ut.groups;for(let It=0,Dt=pt.length;It<Dt;It++){let Ct=pt[It],qt=vt[Ct.materialIndex];qt&&qt.visible&&g.push(E,ut,qt,W,Ut.z,Ct)}}else vt.visible&&g.push(E,ut,vt,W,Ut.z,null)}}let et=E.children;for(let ut=0,vt=et.length;ut<vt;ut++)Rl(et[ut],N,W,q)}function xh(E,N,W,q){let F=E.opaque,et=E.transmissive,ut=E.transparent;u.setupLightsView(W),Qt===!0&&st.setGlobalState(M.clippingPlanes,W),q&&_t.viewport(C.copy(q)),F.length>0&&Xr(F,N,W),et.length>0&&Xr(et,N,W),ut.length>0&&Xr(ut,N,W),_t.buffers.depth.setTest(!0),_t.buffers.depth.setMask(!0),_t.buffers.color.setMask(!0),_t.setPolygonOffset(!1)}function vh(E,N,W,q){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;u.state.transmissionRenderTarget[q.id]===void 0&&(u.state.transmissionRenderTarget[q.id]=new Bn(1,1,{generateMipmaps:!0,type:Ot.has("EXT_color_buffer_half_float")||Ot.has("EXT_color_buffer_float")?Ns:In,minFilter:Mi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Zt.workingColorSpace}));let et=u.state.transmissionRenderTarget[q.id],ut=q.viewport||C;et.setSize(ut.z*M.transmissionResolutionScale,ut.w*M.transmissionResolutionScale);let vt=M.getRenderTarget(),pt=M.getActiveCubeFace(),It=M.getActiveMipmapLevel();M.setRenderTarget(et),M.getClearColor(H),G=M.getClearAlpha(),G<1&&M.setClearColor(16777215,.5),M.clear(),$t&&wt.render(W);let Dt=M.toneMapping;M.toneMapping=si;let Ct=q.viewport;if(q.viewport!==void 0&&(q.viewport=void 0),u.setupLightsView(q),Qt===!0&&st.setGlobalState(M.clippingPlanes,q),Xr(E,W,q),Vt.updateMultisampleRenderTarget(et),Vt.updateRenderTargetMipmap(et),Ot.has("WEBGL_multisampled_render_to_texture")===!1){let qt=!1;for(let oe=0,Me=N.length;oe<Me;oe++){let de=N[oe],le=de.object,Rt=de.geometry,ve=de.material,Jt=de.group;if(ve.side===vn&&le.layers.test(q.layers)){let sn=ve.side;ve.side=Ve,ve.needsUpdate=!0,yh(le,W,q,Rt,ve,Jt),ve.side=sn,ve.needsUpdate=!0,qt=!0}}qt===!0&&(Vt.updateMultisampleRenderTarget(et),Vt.updateRenderTargetMipmap(et))}M.setRenderTarget(vt,pt,It),M.setClearColor(H,G),Ct!==void 0&&(q.viewport=Ct),M.toneMapping=Dt}function Xr(E,N,W){let q=N.isScene===!0?N.overrideMaterial:null;for(let F=0,et=E.length;F<et;F++){let ut=E[F],vt=ut.object,pt=ut.geometry,It=ut.group,Dt=ut.material;Dt.allowOverride===!0&&q!==null&&(Dt=q),vt.layers.test(W.layers)&&yh(vt,N,W,pt,Dt,It)}}function yh(E,N,W,q,F,et){E.onBeforeRender(M,N,W,q,F,et),E.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,E.matrixWorld),E.normalMatrix.getNormalMatrix(E.modelViewMatrix),F.onBeforeRender(M,N,W,q,E,et),F.transparent===!0&&F.side===vn&&F.forceSinglePass===!1?(F.side=Ve,F.needsUpdate=!0,M.renderBufferDirect(W,N,q,F,E,et),F.side=ti,F.needsUpdate=!0,M.renderBufferDirect(W,N,q,F,E,et),F.side=vn):M.renderBufferDirect(W,N,q,F,E,et),E.onAfterRender(M,N,W,q,F,et)}function $r(E,N,W){N.isScene!==!0&&(N=At);let q=Mt.get(E),F=u.state.lights,et=u.state.shadowsArray,ut=F.state.version,vt=Y.getParameters(E,F.state,et,N,W),pt=Y.getProgramCacheKey(vt),It=q.programs;q.environment=E.isMeshStandardMaterial?N.environment:null,q.fog=N.fog,q.envMap=(E.isMeshStandardMaterial?be:Fe).get(E.envMap||q.environment),q.envMapRotation=q.environment!==null&&E.envMap===null?N.environmentRotation:E.envMapRotation,It===void 0&&(E.addEventListener("dispose",J),It=new Map,q.programs=It);let Dt=It.get(pt);if(Dt!==void 0){if(q.currentProgram===Dt&&q.lightsStateVersion===ut)return Mh(E,vt),Dt}else vt.uniforms=Y.getUniforms(E),E.onBeforeCompile(vt,M),Dt=Y.acquireProgram(vt,pt),It.set(pt,Dt),q.uniforms=vt.uniforms;let Ct=q.uniforms;return(!E.isShaderMaterial&&!E.isRawShaderMaterial||E.clipping===!0)&&(Ct.clippingPlanes=st.uniform),Mh(E,vt),q.needsLights=mf(E),q.lightsStateVersion=ut,q.needsLights&&(Ct.ambientLightColor.value=F.state.ambient,Ct.lightProbe.value=F.state.probe,Ct.directionalLights.value=F.state.directional,Ct.directionalLightShadows.value=F.state.directionalShadow,Ct.spotLights.value=F.state.spot,Ct.spotLightShadows.value=F.state.spotShadow,Ct.rectAreaLights.value=F.state.rectArea,Ct.ltc_1.value=F.state.rectAreaLTC1,Ct.ltc_2.value=F.state.rectAreaLTC2,Ct.pointLights.value=F.state.point,Ct.pointLightShadows.value=F.state.pointShadow,Ct.hemisphereLights.value=F.state.hemi,Ct.directionalShadowMap.value=F.state.directionalShadowMap,Ct.directionalShadowMatrix.value=F.state.directionalShadowMatrix,Ct.spotShadowMap.value=F.state.spotShadowMap,Ct.spotLightMatrix.value=F.state.spotLightMatrix,Ct.spotLightMap.value=F.state.spotLightMap,Ct.pointShadowMap.value=F.state.pointShadowMap,Ct.pointShadowMatrix.value=F.state.pointShadowMatrix),q.currentProgram=Dt,q.uniformsList=null,Dt}function _h(E){if(E.uniformsList===null){let N=E.currentProgram.getUniforms();E.uniformsList=Hs.seqWithValue(N.seq,E.uniforms)}return E.uniformsList}function Mh(E,N){let W=Mt.get(E);W.outputColorSpace=N.outputColorSpace,W.batching=N.batching,W.batchingColor=N.batchingColor,W.instancing=N.instancing,W.instancingColor=N.instancingColor,W.instancingMorph=N.instancingMorph,W.skinning=N.skinning,W.morphTargets=N.morphTargets,W.morphNormals=N.morphNormals,W.morphColors=N.morphColors,W.morphTargetsCount=N.morphTargetsCount,W.numClippingPlanes=N.numClippingPlanes,W.numIntersection=N.numClipIntersection,W.vertexAlphas=N.vertexAlphas,W.vertexTangents=N.vertexTangents,W.toneMapping=N.toneMapping}function ff(E,N,W,q,F){N.isScene!==!0&&(N=At),Vt.resetTextureUnits();let et=N.fog,ut=q.isMeshStandardMaterial?N.environment:null,vt=I===null?M.outputColorSpace:I.isXRRenderTarget===!0?I.texture.colorSpace:Oi,pt=(q.isMeshStandardMaterial?be:Fe).get(q.envMap||ut),It=q.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Dt=!!W.attributes.tangent&&(!!q.normalMap||q.anisotropy>0),Ct=!!W.morphAttributes.position,qt=!!W.morphAttributes.normal,oe=!!W.morphAttributes.color,Me=si;q.toneMapped&&(I===null||I.isXRRenderTarget===!0)&&(Me=M.toneMapping);let de=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,le=de!==void 0?de.length:0,Rt=Mt.get(q),ve=u.state.lights;if(Qt===!0&&(Z===!0||E!==w)){let Ye=E===w&&q.id===y;st.setState(q,E,Ye)}let Jt=!1;q.version===Rt.__version?(Rt.needsLights&&Rt.lightsStateVersion!==ve.state.version||Rt.outputColorSpace!==vt||F.isBatchedMesh&&Rt.batching===!1||!F.isBatchedMesh&&Rt.batching===!0||F.isBatchedMesh&&Rt.batchingColor===!0&&F.colorTexture===null||F.isBatchedMesh&&Rt.batchingColor===!1&&F.colorTexture!==null||F.isInstancedMesh&&Rt.instancing===!1||!F.isInstancedMesh&&Rt.instancing===!0||F.isSkinnedMesh&&Rt.skinning===!1||!F.isSkinnedMesh&&Rt.skinning===!0||F.isInstancedMesh&&Rt.instancingColor===!0&&F.instanceColor===null||F.isInstancedMesh&&Rt.instancingColor===!1&&F.instanceColor!==null||F.isInstancedMesh&&Rt.instancingMorph===!0&&F.morphTexture===null||F.isInstancedMesh&&Rt.instancingMorph===!1&&F.morphTexture!==null||Rt.envMap!==pt||q.fog===!0&&Rt.fog!==et||Rt.numClippingPlanes!==void 0&&(Rt.numClippingPlanes!==st.numPlanes||Rt.numIntersection!==st.numIntersection)||Rt.vertexAlphas!==It||Rt.vertexTangents!==Dt||Rt.morphTargets!==Ct||Rt.morphNormals!==qt||Rt.morphColors!==oe||Rt.toneMapping!==Me||Rt.morphTargetsCount!==le)&&(Jt=!0):(Jt=!0,Rt.__version=q.version);let sn=Rt.currentProgram;Jt===!0&&(sn=$r(q,N,F));let os=!1,rn=!1,tr=!1,ye=sn.getUniforms(),mn=Rt.uniforms;if(_t.useProgram(sn.program)&&(os=!0,rn=!0,tr=!0),q.id!==y&&(y=q.id,rn=!0),os||w!==E){_t.buffers.depth.getReversed()&&E.reversedDepth!==!0&&(E._reversedDepth=!0,E.updateProjectionMatrix()),ye.setValue(P,"projectionMatrix",E.projectionMatrix),ye.setValue(P,"viewMatrix",E.matrixWorldInverse);let Qe=ye.map.cameraPosition;Qe!==void 0&&Qe.setValue(P,xt.setFromMatrixPosition(E.matrixWorld)),Lt.logarithmicDepthBuffer&&ye.setValue(P,"logDepthBufFC",2/(Math.log(E.far+1)/Math.LN2)),(q.isMeshPhongMaterial||q.isMeshToonMaterial||q.isMeshLambertMaterial||q.isMeshBasicMaterial||q.isMeshStandardMaterial||q.isShaderMaterial)&&ye.setValue(P,"isOrthographic",E.isOrthographicCamera===!0),w!==E&&(w=E,rn=!0,tr=!0)}if(F.isSkinnedMesh){ye.setOptional(P,F,"bindMatrix"),ye.setOptional(P,F,"bindMatrixInverse");let Ye=F.skeleton;Ye&&(Ye.boneTexture===null&&Ye.computeBoneTexture(),ye.setValue(P,"boneTexture",Ye.boneTexture,Vt))}F.isBatchedMesh&&(ye.setOptional(P,F,"batchingTexture"),ye.setValue(P,"batchingTexture",F._matricesTexture,Vt),ye.setOptional(P,F,"batchingIdTexture"),ye.setValue(P,"batchingIdTexture",F._indirectTexture,Vt),ye.setOptional(P,F,"batchingColorTexture"),F._colorsTexture!==null&&ye.setValue(P,"batchingColorTexture",F._colorsTexture,Vt));let gn=W.morphAttributes;if((gn.position!==void 0||gn.normal!==void 0||gn.color!==void 0)&&nt.update(F,W,sn),(rn||Rt.receiveShadow!==F.receiveShadow)&&(Rt.receiveShadow=F.receiveShadow,ye.setValue(P,"receiveShadow",F.receiveShadow)),q.isMeshGouraudMaterial&&q.envMap!==null&&(mn.envMap.value=pt,mn.flipEnvMap.value=pt.isCubeTexture&&pt.isRenderTargetTexture===!1?-1:1),q.isMeshStandardMaterial&&q.envMap===null&&N.environment!==null&&(mn.envMapIntensity.value=N.environmentIntensity),rn&&(ye.setValue(P,"toneMappingExposure",M.toneMappingExposure),Rt.needsLights&&pf(mn,tr),et&&q.fog===!0&&j.refreshFogUniforms(mn,et),j.refreshMaterialUniforms(mn,q,V,Q,u.state.transmissionRenderTarget[E.id]),Hs.upload(P,_h(Rt),mn,Vt)),q.isShaderMaterial&&q.uniformsNeedUpdate===!0&&(Hs.upload(P,_h(Rt),mn,Vt),q.uniformsNeedUpdate=!1),q.isSpriteMaterial&&ye.setValue(P,"center",F.center),ye.setValue(P,"modelViewMatrix",F.modelViewMatrix),ye.setValue(P,"normalMatrix",F.normalMatrix),ye.setValue(P,"modelMatrix",F.matrixWorld),q.isShaderMaterial||q.isRawShaderMaterial){let Ye=q.uniformsGroups;for(let Qe=0,Il=Ye.length;Qe<Il;Qe++){let Ii=Ye[Qe];zt.update(Ii,sn),zt.bind(Ii,sn)}}return sn}function pf(E,N){E.ambientLightColor.needsUpdate=N,E.lightProbe.needsUpdate=N,E.directionalLights.needsUpdate=N,E.directionalLightShadows.needsUpdate=N,E.pointLights.needsUpdate=N,E.pointLightShadows.needsUpdate=N,E.spotLights.needsUpdate=N,E.spotLightShadows.needsUpdate=N,E.rectAreaLights.needsUpdate=N,E.hemisphereLights.needsUpdate=N}function mf(E){return E.isMeshLambertMaterial||E.isMeshToonMaterial||E.isMeshPhongMaterial||E.isMeshStandardMaterial||E.isShadowMaterial||E.isShaderMaterial&&E.lights===!0}this.getActiveCubeFace=function(){return b},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return I},this.setRenderTargetTextures=function(E,N,W){let q=Mt.get(E);q.__autoAllocateDepthBuffer=E.resolveDepthBuffer===!1,q.__autoAllocateDepthBuffer===!1&&(q.__useRenderToTexture=!1),Mt.get(E.texture).__webglTexture=N,Mt.get(E.depthTexture).__webglTexture=q.__autoAllocateDepthBuffer?void 0:W,q.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(E,N){let W=Mt.get(E);W.__webglFramebuffer=N,W.__useDefaultFramebuffer=N===void 0};let gf=P.createFramebuffer();this.setRenderTarget=function(E,N=0,W=0){I=E,b=N,T=W;let q=!0,F=null,et=!1,ut=!1;if(E){let pt=Mt.get(E);if(pt.__useDefaultFramebuffer!==void 0)_t.bindFramebuffer(P.FRAMEBUFFER,null),q=!1;else if(pt.__webglFramebuffer===void 0)Vt.setupRenderTarget(E);else if(pt.__hasExternalTextures)Vt.rebindTextures(E,Mt.get(E.texture).__webglTexture,Mt.get(E.depthTexture).__webglTexture);else if(E.depthBuffer){let Ct=E.depthTexture;if(pt.__boundDepthTexture!==Ct){if(Ct!==null&&Mt.has(Ct)&&(E.width!==Ct.image.width||E.height!==Ct.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Vt.setupDepthRenderbuffer(E)}}let It=E.texture;(It.isData3DTexture||It.isDataArrayTexture||It.isCompressedArrayTexture)&&(ut=!0);let Dt=Mt.get(E).__webglFramebuffer;E.isWebGLCubeRenderTarget?(Array.isArray(Dt[N])?F=Dt[N][W]:F=Dt[N],et=!0):E.samples>0&&Vt.useMultisampledRTT(E)===!1?F=Mt.get(E).__webglMultisampledFramebuffer:Array.isArray(Dt)?F=Dt[W]:F=Dt,C.copy(E.viewport),L.copy(E.scissor),B=E.scissorTest}else C.copy(gt).multiplyScalar(V).floor(),L.copy(Ht).multiplyScalar(V).floor(),B=ie;if(W!==0&&(F=gf),_t.bindFramebuffer(P.FRAMEBUFFER,F)&&q&&_t.drawBuffers(E,F),_t.viewport(C),_t.scissor(L),_t.setScissorTest(B),et){let pt=Mt.get(E.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+N,pt.__webglTexture,W)}else if(ut){let pt=N;for(let It=0;It<E.textures.length;It++){let Dt=Mt.get(E.textures[It]);P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0+It,Dt.__webglTexture,W,pt)}}else if(E!==null&&W!==0){let pt=Mt.get(E.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,pt.__webglTexture,W)}y=-1},this.readRenderTargetPixels=function(E,N,W,q,F,et,ut,vt=0){if(!(E&&E.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let pt=Mt.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&ut!==void 0&&(pt=pt[ut]),pt){_t.bindFramebuffer(P.FRAMEBUFFER,pt);try{let It=E.textures[vt],Dt=It.format,Ct=It.type;if(!Lt.textureFormatReadable(Dt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Lt.textureTypeReadable(Ct)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=E.width-q&&W>=0&&W<=E.height-F&&(E.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+vt),P.readPixels(N,W,q,F,Tt.convert(Dt),Tt.convert(Ct),et))}finally{let It=I!==null?Mt.get(I).__webglFramebuffer:null;_t.bindFramebuffer(P.FRAMEBUFFER,It)}}},this.readRenderTargetPixelsAsync=async function(E,N,W,q,F,et,ut,vt=0){if(!(E&&E.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let pt=Mt.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&ut!==void 0&&(pt=pt[ut]),pt)if(N>=0&&N<=E.width-q&&W>=0&&W<=E.height-F){_t.bindFramebuffer(P.FRAMEBUFFER,pt);let It=E.textures[vt],Dt=It.format,Ct=It.type;if(!Lt.textureFormatReadable(Dt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Lt.textureTypeReadable(Ct))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let qt=P.createBuffer();P.bindBuffer(P.PIXEL_PACK_BUFFER,qt),P.bufferData(P.PIXEL_PACK_BUFFER,et.byteLength,P.STREAM_READ),E.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+vt),P.readPixels(N,W,q,F,Tt.convert(Dt),Tt.convert(Ct),0);let oe=I!==null?Mt.get(I).__webglFramebuffer:null;_t.bindFramebuffer(P.FRAMEBUFFER,oe);let Me=P.fenceSync(P.SYNC_GPU_COMMANDS_COMPLETE,0);return P.flush(),await Xu(P,Me,4),P.bindBuffer(P.PIXEL_PACK_BUFFER,qt),P.getBufferSubData(P.PIXEL_PACK_BUFFER,0,et),P.deleteBuffer(qt),P.deleteSync(Me),et}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(E,N=null,W=0){let q=Math.pow(2,-W),F=Math.floor(E.image.width*q),et=Math.floor(E.image.height*q),ut=N!==null?N.x:0,vt=N!==null?N.y:0;Vt.setTexture2D(E,0),P.copyTexSubImage2D(P.TEXTURE_2D,W,0,0,ut,vt,F,et),_t.unbindTexture()};let xf=P.createFramebuffer(),vf=P.createFramebuffer();this.copyTextureToTexture=function(E,N,W=null,q=null,F=0,et=null){et===null&&(F!==0?(As("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),et=F,F=0):et=0);let ut,vt,pt,It,Dt,Ct,qt,oe,Me,de=E.isCompressedTexture?E.mipmaps[et]:E.image;if(W!==null)ut=W.max.x-W.min.x,vt=W.max.y-W.min.y,pt=W.isBox3?W.max.z-W.min.z:1,It=W.min.x,Dt=W.min.y,Ct=W.isBox3?W.min.z:0;else{let gn=Math.pow(2,-F);ut=Math.floor(de.width*gn),vt=Math.floor(de.height*gn),E.isDataArrayTexture?pt=de.depth:E.isData3DTexture?pt=Math.floor(de.depth*gn):pt=1,It=0,Dt=0,Ct=0}q!==null?(qt=q.x,oe=q.y,Me=q.z):(qt=0,oe=0,Me=0);let le=Tt.convert(N.format),Rt=Tt.convert(N.type),ve;N.isData3DTexture?(Vt.setTexture3D(N,0),ve=P.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(Vt.setTexture2DArray(N,0),ve=P.TEXTURE_2D_ARRAY):(Vt.setTexture2D(N,0),ve=P.TEXTURE_2D),P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,N.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,N.unpackAlignment);let Jt=P.getParameter(P.UNPACK_ROW_LENGTH),sn=P.getParameter(P.UNPACK_IMAGE_HEIGHT),os=P.getParameter(P.UNPACK_SKIP_PIXELS),rn=P.getParameter(P.UNPACK_SKIP_ROWS),tr=P.getParameter(P.UNPACK_SKIP_IMAGES);P.pixelStorei(P.UNPACK_ROW_LENGTH,de.width),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,de.height),P.pixelStorei(P.UNPACK_SKIP_PIXELS,It),P.pixelStorei(P.UNPACK_SKIP_ROWS,Dt),P.pixelStorei(P.UNPACK_SKIP_IMAGES,Ct);let ye=E.isDataArrayTexture||E.isData3DTexture,mn=N.isDataArrayTexture||N.isData3DTexture;if(E.isDepthTexture){let gn=Mt.get(E),Ye=Mt.get(N),Qe=Mt.get(gn.__renderTarget),Il=Mt.get(Ye.__renderTarget);_t.bindFramebuffer(P.READ_FRAMEBUFFER,Qe.__webglFramebuffer),_t.bindFramebuffer(P.DRAW_FRAMEBUFFER,Il.__webglFramebuffer);for(let Ii=0;Ii<pt;Ii++)ye&&(P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Mt.get(E).__webglTexture,F,Ct+Ii),P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Mt.get(N).__webglTexture,et,Me+Ii)),P.blitFramebuffer(It,Dt,ut,vt,qt,oe,ut,vt,P.DEPTH_BUFFER_BIT,P.NEAREST);_t.bindFramebuffer(P.READ_FRAMEBUFFER,null),_t.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else if(F!==0||E.isRenderTargetTexture||Mt.has(E)){let gn=Mt.get(E),Ye=Mt.get(N);_t.bindFramebuffer(P.READ_FRAMEBUFFER,xf),_t.bindFramebuffer(P.DRAW_FRAMEBUFFER,vf);for(let Qe=0;Qe<pt;Qe++)ye?P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,gn.__webglTexture,F,Ct+Qe):P.framebufferTexture2D(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,gn.__webglTexture,F),mn?P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Ye.__webglTexture,et,Me+Qe):P.framebufferTexture2D(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Ye.__webglTexture,et),F!==0?P.blitFramebuffer(It,Dt,ut,vt,qt,oe,ut,vt,P.COLOR_BUFFER_BIT,P.NEAREST):mn?P.copyTexSubImage3D(ve,et,qt,oe,Me+Qe,It,Dt,ut,vt):P.copyTexSubImage2D(ve,et,qt,oe,It,Dt,ut,vt);_t.bindFramebuffer(P.READ_FRAMEBUFFER,null),_t.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else mn?E.isDataTexture||E.isData3DTexture?P.texSubImage3D(ve,et,qt,oe,Me,ut,vt,pt,le,Rt,de.data):N.isCompressedArrayTexture?P.compressedTexSubImage3D(ve,et,qt,oe,Me,ut,vt,pt,le,de.data):P.texSubImage3D(ve,et,qt,oe,Me,ut,vt,pt,le,Rt,de):E.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,et,qt,oe,ut,vt,le,Rt,de.data):E.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,et,qt,oe,de.width,de.height,le,de.data):P.texSubImage2D(P.TEXTURE_2D,et,qt,oe,ut,vt,le,Rt,de);P.pixelStorei(P.UNPACK_ROW_LENGTH,Jt),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,sn),P.pixelStorei(P.UNPACK_SKIP_PIXELS,os),P.pixelStorei(P.UNPACK_SKIP_ROWS,rn),P.pixelStorei(P.UNPACK_SKIP_IMAGES,tr),et===0&&N.generateMipmaps&&P.generateMipmap(ve),_t.unbindTexture()},this.initRenderTarget=function(E){Mt.get(E).__webglFramebuffer===void 0&&Vt.setupRenderTarget(E)},this.initTexture=function(E){E.isCubeTexture?Vt.setTextureCube(E,0):E.isData3DTexture?Vt.setTexture3D(E,0):E.isDataArrayTexture||E.isCompressedArrayTexture?Vt.setTexture2DArray(E,0):Vt.setTexture2D(E,0),_t.unbindTexture()},this.resetState=function(){b=0,T=0,I=null,_t.reset(),ht.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Tn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=Zt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Zt._getUnpackColorSpace()}};var Ie=16,en=class{constructor(t,e,n){this.sx=t,this.sy=e,this.sz=n,this.cx=Math.ceil(t/Ie),this.cy=Math.ceil(e/Ie),this.cz=Math.ceil(n/Ie),this.ox=Math.floor(t/2),this.oz=Math.floor(n/2),this.data=new Uint8Array(t*e*n),this.flags=new Uint8Array(t*e*n),this.dirty=new Set,this.listeners=[]}idx(t,e,n){return(e*this.sz+(n+this.oz))*this.sx+(t+this.ox)}inside(t,e,n){return e>=0&&e<this.sy&&t+this.ox>=0&&t+this.ox<this.sx&&n+this.oz>=0&&n+this.oz<this.sz}get(t,e,n){return t=Math.floor(t),e=Math.floor(e),n=Math.floor(n),this.inside(t,e,n)?this.data[this.idx(t,e,n)]:0}flag(t,e,n){return this.inside(t,e,n)?this.flags[this.idx(t,e,n)]:0}set(t,e,n,i,r=0,o=!1){if(!this.inside(t,e,n))return!1;let a=this.idx(t,e,n),l=this.data[a];if(this.data[a]=i,this.flags[a]=i?r:0,this.markDirty(t,e,n),!o)for(let c of this.listeners)c(t,e,n,i,l);return!0}markDirty(t,e,n){let i=t+this.ox,r=n+this.oz,o=Math.floor(i/Ie),a=Math.floor(e/Ie),l=Math.floor(r/Ie);this.dirty.add(this.key(o,a,l));let c=i%Ie,h=e%Ie,d=r%Ie;c===0&&o>0&&this.dirty.add(this.key(o-1,a,l)),c===Ie-1&&o<this.cx-1&&this.dirty.add(this.key(o+1,a,l)),h===0&&a>0&&this.dirty.add(this.key(o,a-1,l)),h===Ie-1&&a<this.cy-1&&this.dirty.add(this.key(o,a+1,l)),d===0&&l>0&&this.dirty.add(this.key(o,a,l-1)),d===Ie-1&&l<this.cz-1&&this.dirty.add(this.key(o,a,l+1))}key(t,e,n){return(t*this.cy+e)*this.cz+n}unkey(t){let e=t%this.cz,n=(t-e)/this.cz,i=n%this.cy;return[(n-i)/this.cy,i,e]}solidAt(t,e,n){return Pe(this.get(t,e,n))}topY(t,e){for(let n=this.sy-1;n>=0;n--)if(Pe(this.get(t,n,e)))return n;return-1}fill(t,e,n,i,r,o,a,l=0){for(let c=e;c<=r;c++)for(let h=n;h<=o;h++)for(let d=t;d<=i;d++)this.set(d,c,h,a,l,!0)}raycast(t,e,n,i,r,o,a,l=c=>c!==0){let c=Math.floor(t),h=Math.floor(e),d=Math.floor(n),f=Math.sign(i),p=Math.sign(r),m=Math.sign(o),x=i?Math.abs(1/i):1/0,g=r?Math.abs(1/r):1/0,u=o?Math.abs(1/o):1/0,v=i?(f>0?c+1-t:t-c)*x:1/0,_=r?(p>0?h+1-e:e-h)*g:1/0,M=o?(m>0?d+1-n:n-d)*u:1/0,A=0,b=0,T=0,I=0;for(let y=0;y<256&&A<=a;y++){let w=this.get(c,h,d);if(l(w,c,h,d))return{x:c,y:h,z:d,id:w,nx:b,ny:T,nz:I,t:A};v<_&&v<M?(c+=f,A=v,v+=x,b=-f,T=0,I=0):_<M?(h+=p,A=_,_+=g,b=0,T=-p,I=0):(d+=m,A=M,M+=u,b=0,T=0,I=-m)}return null}boxHits(t,e,n,i,r,o){for(let a=Math.floor(e);a<=Math.floor(r-1e-6);a++)for(let l=Math.floor(n);l<=Math.floor(o-1e-6);l++)for(let c=Math.floor(t);c<=Math.floor(i-1e-6);c++)if(Pe(this.get(c,a,l)))return!0;return!1}};var Td=[{n:[1,0,0],a:0,c:[[1,0,1],[1,0,0],[1,1,0],[1,1,1]],s:.8,t:"side"},{n:[-1,0,0],a:0,c:[[0,0,0],[0,0,1],[0,1,1],[0,1,0]],s:.8,t:"side"},{n:[0,1,0],a:1,c:[[0,1,1],[1,1,1],[1,1,0],[0,1,0]],s:1,t:"top"},{n:[0,-1,0],a:1,c:[[0,0,0],[1,0,0],[1,0,1],[0,0,1]],s:.55,t:"bottom"},{n:[0,0,1],a:2,c:[[0,0,1],[1,0,1],[1,1,1],[0,1,1]],s:.68,t:"side"},{n:[0,0,-1],a:2,c:[[1,0,0],[0,0,0],[0,1,0],[1,1,0]],s:.68,t:"side"}],nl=[[0,1],[1,1],[1,0],[0,0]],kx=[.45,.66,.83,1],Gs=class{constructor(){this.pos=[],this.uv=[],this.col=[],this.idx=[],this.n=0}quad(t,e,n,i){let r=this.n;for(let o=0;o<4;o++)this.pos.push(t[o][0],t[o][1],t[o][2]),this.uv.push(e[o][0],e[o][1]),this.col.push(n[o],n[o],n[o]);i?this.idx.push(r+1,r+2,r+3,r+1,r+3,r):this.idx.push(r,r+1,r+2,r,r+2,r+3),this.n+=4}out(){if(!this.n)return null;let t=new Uint8Array(this.col.length);for(let e=0;e<t.length;e++)t[e]=Math.max(0,Math.min(255,Math.round(this.col[e]*255)));return{pos:new Float32Array(this.pos),uv:new Float32Array(this.uv),col:t,idx:this.n>65535?new Uint32Array(this.idx):new Uint16Array(this.idx)}}};function Ed(s,t,e,n,i){let r={solid:new Gs,cutout:new Gs,plant:new Gs,trans:new Gs},o=e*Ie-s.ox,a=n*Ie,l=i*Ie-s.oz,c=.4/t.width,h={},d=p=>h[p]||(h[p]=t.uv(p)),f=(p,m,x)=>{let g=s.get(p,m,x);if(!g)return!1;let u=Yt[g];return u.solid&&!u.transparent};for(let p=a;p<a+Ie&&p<s.sy;p++)for(let m=l;m<l+Ie;m++)for(let x=o;x<o+Ie;x++){let g=s.get(x,p,m);if(!g)continue;let u=Yt[g];if(!u||u.invisible)continue;if(u.cross){let[_,M,A,b]=d(u.tex.side),T=.42,I=x+.5,y=m+.5,w=nl.map(([L,B])=>[_+c+L*(A-2*c),M+c+B*(b-2*c)]),C=[.95,.95,1,1];r.plant.quad([[I-T,p,y-T],[I+T,p,y+T],[I+T,p+.9,y+T],[I-T,p+.9,y-T]],w,C,!1),r.plant.quad([[I-T,p,y+T],[I+T,p,y-T],[I+T,p+.9,y-T],[I-T,p+.9,y+T]],w,C,!1);continue}if(u.box){let[_,M,A,b,T,I]=u.box;for(let y of Td){if(y.n[1]===-1&&f(x,p-1,m))continue;let[w,C,L,B]=d(u.tex[y.t]),H=y.c.map(Q=>[x+(Q[0]?b:_),p+(Q[1]?T:M),m+(Q[2]?I:A)]),G=nl.map(([Q,V])=>[w+c+Q*(L-2*c),C+c+V*(B-2*c)]),X=(u.light?1.1:1)*y.s;r.cutout.quad(H,G,[X,X,X,X],!1)}continue}let v=g===11||u.trans?r.trans:u.transparent?r.cutout:r.solid;for(let _ of Td){let M=x+_.n[0],A=p+_.n[1],b=m+_.n[2],T=s.get(M,A,b);if(T){let V=Yt[T];if(V&&V.solid&&!V.transparent||T===g&&u.transparent)continue}if(A<0)continue;let[I,y,w,C]=d(u.tex[_.t]),L=(_.a+1)%3,B=(_.a+2)%3,H=[0,0,0,0],G=new Array(4),X=new Array(4);for(let V=0;V<4;V++){let ot=_.c[V];if(G[V]=[x+ot[0],p+ot[1],m+ot[2]],X[V]=[I+c+nl[V][0]*(w-2*c),y+c+nl[V][1]*(C-2*c)],u.light){H[V]=3;continue}let ct=[0,0,0],gt=[0,0,0];ct[L]=ot[L]?1:-1,gt[B]=ot[B]?1:-1;let Ht=f(M+ct[0],A+ct[1],b+ct[2])?1:0,ie=f(M+gt[0],A+gt[1],b+gt[2])?1:0,ce=f(M+ct[0]+gt[0],A+ct[1]+gt[1],b+ct[2]+gt[2])?1:0;H[V]=Ht&&ie?0:3-(Ht+ie+ce)}let Q=u.light?[1.15,1.15,1.15,1.15]:H.map(V=>kx[V]*_.s);v.quad(G,X,Q,H[0]+H[2]<H[1]+H[3])}}return{solid:r.solid.out(),cutout:r.cutout.out(),plant:r.plant.out(),trans:r.trans.out()}}var Ad={meadow:{skyTop:6266856,skyHorizon:13625087,fog:12573951,sun:16773848,hemiSky:14676223,hemiGround:6978138,void:2768227,clouds:16777215},desert:{skyTop:5214176,skyHorizon:16770744,fog:16178350,sun:16770736,hemiSky:16773328,hemiGround:9072720,void:5913130,clouds:16774888},snow:{skyTop:6983616,skyHorizon:15134970,fog:14412020,sun:15791871,hemiSky:15791871,hemiGround:8030874,void:3820138,clouds:16777215},volcano:{skyTop:3807786,skyHorizon:14180410,fog:9058858,sun:16756864,hemiSky:16760992,hemiGround:4860458,void:1706510,clouds:6965834},dusk:{skyTop:2767482,skyHorizon:15769712,fog:13146762,sun:16765088,hemiSky:16767168,hemiGround:5917290,void:1710650,clouds:16769232}},il=class{constructor(t){this.renderer=new tl({canvas:t,antialias:!1,powerPreference:"high-performance",alpha:!1,stencil:!1}),this.renderer.outputColorSpace=Le,this.scene=new Bi,this.camera=new Be(75,1,.08,420),this.scene.add(this.camera),this.hemi=new qi(16777215,6710886,1.6),this.sun=new Xi(16777215,1.4),this.sun.position.set(.5,1,.35),this.scene.add(this.hemi,this.sun),this.chunks=new Map,this.world=null,this.pixel=1}setAtlas(t){this.atlas=t;let e=new Ps(t.data,t.width,t.height,tn);e.magFilter=Ce,e.minFilter=Ce,e.generateMipmaps=!1,e.colorSpace=Le,e.needsUpdate=!0,this.atlasTex=e;let n={map:e,vertexColors:!0,fog:!0};this.mats={solid:new Re({...n}),cutout:new Re({...n,alphaTest:.5}),plant:new Re({...n,alphaTest:.5,side:vn}),trans:new Re({...n,transparent:!0,opacity:.85,depthWrite:!1})},this.buildOverlays()}buildOverlays(){let t=new De(1.004,1.004,1.004);this.outline=new Tr(new Cr(t),new Ds({color:1118481,transparent:!0,opacity:.55})),this.outline.visible=!1,this.scene.add(this.outline);let e=new De(1.01,1.01,1.01),n=e.attributes.uv;this.crackGeo=e,this.crackUV0=n.array.slice(),this.crack=new jt(e,new Re({map:this.atlasTex,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-1})),this.crack.visible=!1,this.scene.add(this.crack)}setCrack(t,e,n,i){if(i<0){this.crack.visible=!1;return}let[r,o,a,l]=this.atlas.uv(`crack${Math.min(3,i)}`),c=this.crackGeo.attributes.uv;for(let h=0;h<c.count;h++)c.array[h*2]=r+this.crackUV0[h*2]*a,c.array[h*2+1]=o+(1-this.crackUV0[h*2+1])*l;c.needsUpdate=!0,this.crack.position.set(t+.5,e+.5,n+.5),this.crack.visible=!0}setTheme(t){let e=Ad[t]||Ad.meadow;this.theme=e,this.scene.fog=new br(e.fog,80,240),this.hemi.color.set(e.hemiSky),this.hemi.groundColor.set(e.hemiGround),this.sun.color.set(e.sun),this.sky&&(this.scene.remove(this.sky),this.sky.geometry.dispose());let n=new Gi(340,24,16),i=new kt(e.skyTop),r=new kt(e.skyHorizon),o=new kt(e.void),a=[],l=n.attributes.position;for(let c=0;c<l.count;c++){let h=l.getY(c)/340,d=h>0?r.clone().lerp(i,Math.pow(h,.6)):r.clone().lerp(o,Math.min(1,-h*2.2));a.push(d.r,d.g,d.b)}n.setAttribute("color",new ue(a,3)),this.sky=new jt(n,new Re({vertexColors:!0,side:Ve,fog:!1,depthWrite:!1})),this.sky.renderOrder=-1,this.scene.add(this.sky),this.buildClouds(e.clouds)}buildClouds(t){this.clouds&&(this.scene.remove(this.clouds),this.clouds.geometry.dispose());let e=new De(1,1,1),n=70,i=new Hi(e,new Re({color:t,transparent:!0,opacity:.85,fog:!1}),n),r=new ee,o=new cn,a=new U,l=new U,c=7,h=()=>(c=c*16807%2147483647,c/2147483647);for(let d=0;d<n;d++)l.set((h()-.5)*560,112+h()*14,(h()-.5)*560),a.set(12+h()*30,3,8+h()*22),r.compose(l,o,a),i.setMatrixAt(d,r);this.clouds=i,this.scene.add(i)}setWorld(t){for(let e of this.chunks.values())this.disposeChunk(e);this.chunks.clear(),this.world=t;for(let e=0;e<t.cx;e++)for(let n=0;n<t.cy;n++)for(let i=0;i<t.cz;i++)t.dirty.add(t.key(e,n,i));this.flush(1/0)}disposeChunk(t){for(let e of t)this.scene.remove(e),e.geometry.dispose()}flush(t=6){let e=this.world;if(!e||!e.dirty.size)return 0;let n=0;for(let i of[...e.dirty]){if(n>=t)break;e.dirty.delete(i);let[r,o,a]=e.unkey(i),l=this.chunks.get(i);l&&this.disposeChunk(l);let c=Ed(e,this.atlas,r,o,a),h=[];for(let[d,f]of Object.entries(c)){if(!f)continue;let p=new He;p.setAttribute("position",new Ae(f.pos,3)),p.setAttribute("uv",new Ae(f.uv,2)),p.setAttribute("color",new Ae(f.col,3,!0)),p.setIndex(new Ae(f.idx,1)),p.computeBoundingSphere();let m=new jt(p,this.mats[d]);m.matrixAutoUpdate=!1,d==="trans"&&(m.renderOrder=2),this.scene.add(m),h.push(m)}this.chunks.set(i,h),n++}return n}resize(t,e,n){this.pixel=n,this.renderer.setPixelRatio(n),this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix()}render(t){this.clouds&&(this.clouds.position.x=(this.clouds.position.x+t*.6)%240),this.sky&&this.sky.position.copy(this.camera.position),this.renderer.render(this.scene,this.camera)}};var sl=class{constructor(t,e){this.canvas=t,this.ui=e,this.keys=new Set,this.pressed=new Set,this.mouse={l:!1,r:!1,lp:!1,rp:!1},this.look={x:0,y:0},this.wheel=0,this.locked=!1,this.enabled=!1,this.touch=matchMedia("(pointer: coarse)").matches||"ontouchstart"in window&&navigator.maxTouchPoints>0,this.t={moveId:null,mx:0,my:0,ox:0,oy:0,lookId:null,lx:0,ly:0,attack:!1,attackP:!1,place:!1,jump:!1,crouch:!1,sprint:!1},this.pad=null,this.bind()}bind(){addEventListener("keydown",t=>{if(!this.enabled&&!["Escape"].includes(t.code)){this.pressed.add(t.code);return}["Space","ArrowUp","ArrowDown","Tab"].includes(t.code)&&t.preventDefault(),this.keys.has(t.code)||this.pressed.add(t.code),this.keys.add(t.code)}),addEventListener("keyup",t=>this.keys.delete(t.code)),addEventListener("blur",()=>{this.keys.clear(),this.mouse.l=this.mouse.r=!1}),this.canvas.addEventListener("mousedown",t=>{if(!this.touch){if(!this.locked&&this.enabled){this.requestLock();return}t.button===0&&(this.mouse.l=!0,this.mouse.lp=!0),t.button===2&&(this.mouse.r=!0,this.mouse.rp=!0)}}),addEventListener("mouseup",t=>{t.button===0&&(this.mouse.l=!1),t.button===2&&(this.mouse.r=!1)}),addEventListener("contextmenu",t=>t.preventDefault()),addEventListener("mousemove",t=>{this.locked&&(this.look.x+=t.movementX,this.look.y+=t.movementY)}),addEventListener("wheel",t=>{this.locked&&(this.wheel+=Math.sign(t.deltaY))},{passive:!0}),document.addEventListener("pointerlockchange",()=>{let t=this.locked;this.locked=document.pointerLockElement===this.canvas,t&&!this.locked&&this.onUnlock&&this.onUnlock()}),addEventListener("touchstart",()=>{this.touch||(this.touch=!0,this.onTouch&&this.onTouch())},{passive:!0,capture:!0})}requestLock(){if(!this.touch)try{let t=this.canvas.requestPointerLock({unadjustedMovement:!0});t&&t.catch&&t.catch(e=>{if(e&&e.name==="NotSupportedError")try{let n=this.canvas.requestPointerLock();n&&n.catch&&n.catch(()=>{})}catch{}})}catch{try{this.canvas.requestPointerLock()}catch{}}}exitLock(){document.pointerLockElement&&document.exitPointerLock()}enable(t){this.enabled=t,t||(this.keys.clear(),this.mouse.l=this.mouse.r=!1,this.t.attack=this.t.place=this.t.jump=!1)}wireTouch(t){let e=this.t,n=t.querySelector(".joy"),i=t.querySelector(".joy .knob"),r=t.querySelector(".look-zone"),o=h=>{e.moveId=h.identifier;let d=n.getBoundingClientRect();e.ox=d.left+d.width/2,e.oy=d.top+d.height/2,a(h)},a=h=>{let d=n.getBoundingClientRect(),f=d.width/2,p=h.clientX-e.ox,m=h.clientY-e.oy,x=Math.hypot(p,m);x>f&&(p*=f/x,m*=f/x),e.mx=p/f,e.my=-m/f,i.style.transform=`translate(${p}px, ${m}px)`,e.sprint=x>f*.95};t.querySelector(".joy-zone").addEventListener("touchstart",h=>{h.preventDefault(),e.moveId==null&&o(h.changedTouches[0])},{passive:!1}),r.addEventListener("touchstart",h=>{if(h.preventDefault(),e.lookId==null){let d=h.changedTouches[0];e.lookId=d.identifier,e.lx=d.clientX,e.ly=d.clientY,e.tapT=performance.now(),e.tapX=d.clientX,e.tapY=d.clientY}},{passive:!1}),addEventListener("touchmove",h=>{for(let d of h.changedTouches)d.identifier===e.moveId&&a(d),d.identifier===e.lookId&&(this.look.x+=(d.clientX-e.lx)*2.2,this.look.y+=(d.clientY-e.ly)*2.2,e.lx=d.clientX,e.ly=d.clientY)},{passive:!0});let l=h=>{for(let d of h.changedTouches)d.identifier===e.moveId&&(e.moveId=null,e.mx=e.my=0,e.sprint=!1,i.style.transform=""),d.identifier===e.lookId&&(e.lookId=null,performance.now()-e.tapT<220&&Math.hypot(d.clientX-e.tapX,d.clientY-e.tapY)<12&&(e.tapPlace=!0))};addEventListener("touchend",l),addEventListener("touchcancel",l);let c=(h,d,f)=>{let p=t.querySelector(h);if(!p)return;p.addEventListener("touchstart",x=>{x.preventDefault(),x.stopPropagation(),p.classList.add("on"),d()},{passive:!1});let m=x=>{p.classList.remove("on"),f&&f()};p.addEventListener("touchend",m),p.addEventListener("touchcancel",m)};c(".tb-attack",()=>{e.attack=!0,e.attackP=!0},()=>{e.attack=!1}),c(".tb-place",()=>{e.place=!0,e.placeP=!0},()=>{e.place=!1}),c(".tb-jump",()=>{e.jump=!0,e.jumpP=!0},()=>{e.jump=!1}),c(".tb-crouch",()=>{e.crouch=!e.crouch,t.querySelector(".tb-crouch").classList.toggle("lit",e.crouch)})}sample(){let t=this.keys,e=this.t,n=0,i=0;(t.has("KeyW")||t.has("ArrowUp"))&&(i+=1),(t.has("KeyS")||t.has("ArrowDown"))&&(i-=1),(t.has("KeyD")||t.has("ArrowRight"))&&(n+=1),(t.has("KeyA")||t.has("ArrowLeft"))&&(n-=1);let r=this.mouse.l,o=this.mouse.lp,a=this.mouse.rp,l=this.mouse.r,c=t.has("Space"),h=t.has("ShiftLeft")||t.has("ShiftRight"),d=t.has("ControlLeft")||t.has("KeyR")||!1,f=null;for(let u=1;u<=9;u++)this.pressed.has("Digit"+u)&&(f=u-1);let p=this.wheel;this.wheel=0,this.touch&&((e.mx||e.my)&&(n=e.mx,i=e.my),r=r||e.attack,o=o||e.attackP,a=a||e.placeP||e.tapPlace,l=l||e.place,c=c||e.jump,h=h||e.crouch,d=d||e.sprint&&i>.7,e.attackP=!1,e.placeP=!1,e.tapPlace=!1);let x=(navigator.getGamepads?[...navigator.getGamepads()].filter(Boolean):[])[0];if(x){let u=y=>Math.abs(y)<.16?0:y,v=u(x.axes[0]),_=u(x.axes[1]),M=u(x.axes[2]),A=u(x.axes[3]);(v||_)&&(n=v,i=-_),this.look.x+=Math.sign(M)*M*M*14,this.look.y+=Math.sign(A)*A*A*10;let b=y=>x.buttons[y]&&x.buttons[y].pressed,T=this.padPrev||[],I=y=>b(y)&&!T[y];r=r||b(7),o=o||I(7),l=l||b(6),a=a||I(6),c=c||b(0),h=h||b(1),d=d||b(10),I(5)&&(p+=1),I(4)&&(p-=1),I(9)&&this.pressed.add("Escape"),this.padPrev=x.buttons.map(y=>y.pressed),this.gamepad=!0}let g={mx:n,my:i,lookX:this.look.x,lookY:this.look.y,attack:r,attackPressed:o,use:a,useHeld:l,jump:c,crouch:h,sprint:d,sel:f,wheel:p,pressed:new Set(this.pressed)};return this.look.x=0,this.look.y=0,this.mouse.lp=!1,this.mouse.rp=!1,this.pressed.clear(),g}};var Cd={grass:{f:900,q:.8,d:.12,g:.5},gravel:{f:700,q:1.2,d:.12,g:.55},stone:{f:1500,q:2.5,d:.09,g:.5},wood:{f:500,q:4,d:.11,g:.6},sand:{f:2200,q:.6,d:.13,g:.35},snow:{f:1800,q:.7,d:.12,g:.35},glass:{f:3200,q:8,d:.14,g:.4},metal:{f:2400,q:10,d:.1,g:.35},cloth:{f:650,q:.7,d:.1,g:.45},egg:{f:1100,q:6,d:.18,g:.6}},rl=class{constructor(){this.ctx=null,this.master=null,this.volume=.8,this.musicVol=.4,this.muted=!1,this.listener={x:0,y:0,z:0},this.musicOn=!1}unlock(){if(this.ctx){this.ctx.state==="suspended"&&!this.suspended&&this.ctx.resume().catch(()=>{});return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;this.ctx=new t,this.master=this.ctx.createGain(),this.master.connect(this.ctx.destination),this.sfx=this.ctx.createGain(),this.sfx.connect(this.master),this.mus=this.ctx.createGain(),this.mus.connect(this.master);let e=this.ctx.sampleRate;this.noiseBuf=this.ctx.createBuffer(1,e,this.ctx.sampleRate);let n=this.noiseBuf.getChannelData(0);for(let i=0;i<e;i++)n[i]=Math.random()*2-1;this.apply()}apply(){if(!this.master)return;let t=this.ctx.currentTime;this.master.gain.setTargetAtTime(this.muted||this.suspended?0:this.volume,t,.03),this.mus.gain.setTargetAtTime(this.musicVol*.5,t,.3)}setVolume(t,e){this.volume=t,e!=null&&(this.musicVol=e),this.apply()}setMuted(t){this.muted=t,this.apply()}suspend(t){this.suspended=t,this.ctx&&(this.apply(),t?this.ctx.suspend().catch(()=>{}):this.ctx.resume().catch(()=>{}))}att(t){if(!t)return 1;let e=Math.hypot(t.x-this.listener.x,t.y-this.listener.y,t.z-this.listener.z);return Math.max(0,1-e/28)**1.4}noise(t,e,n,i,r,o="bandpass",a=0){if(!this.ctx||i<.01)return;let l=this.ctx,c=l.currentTime+a,h=l.createBufferSource();h.buffer=this.noiseBuf,h.playbackRate.value=.8+Math.random()*.4;let d=l.createBiquadFilter();d.type=o,d.frequency.value=e,d.Q.value=n;let f=l.createGain();f.gain.setValueAtTime(i,c),f.gain.exponentialRampToValueAtTime(.001,c+t),h.connect(d).connect(f).connect(r||this.sfx),h.start(c,Math.random()*.5),h.stop(c+t+.05)}tone(t,e,n="square",i=.15,r=0,o=0,a){if(!this.ctx||!(i>.002))return;let l=this.ctx,c=l.currentTime+o,h=l.createOscillator();h.type=n,h.frequency.setValueAtTime(t,c),r&&h.frequency.exponentialRampToValueAtTime(Math.max(30,t*r),c+e);let d=l.createGain();d.gain.setValueAtTime(1e-4,c),d.gain.exponentialRampToValueAtTime(i,c+.008),d.gain.exponentialRampToValueAtTime(1e-4,c+e),h.connect(d).connect(a||this.sfx),h.start(c),h.stop(c+e+.05)}block(t,e,n){let i=Cd[t]||Cd.stone,r=this.att(n);if(e==="dig")this.noise(i.d,i.f*(.9+Math.random()*.2),i.q,i.g*.55*r);else if(e==="break"){if(this.noise(i.d*2.2,i.f*.8,i.q*.6,i.g*.9*r),t==="glass")for(let o=0;o<3;o++)this.tone(2400+Math.random()*1800,.12,"triangle",.05*r,.6,o*.03)}else e==="place"?(this.noise(i.d*1.4,i.f*.7,i.q,i.g*.8*r),this.tone(i.f*.12,.06,"sine",.12*r)):e==="step"&&this.noise(i.d*.8,i.f*.75,i.q,i.g*.22*r)}hit(t,e){let n=this.att(t);if(this.noise(.08,800,1.5,.6*n,null,"lowpass"),this.tone(180,.09,"square",.12*n,.5),e)for(let i=0;i<4;i++)this.tone(1600+i*300,.06,"triangle",.05*n,1.3,i*.02)}hurt(t){this.tone(t?300:260,.14,"sawtooth",t?.12:.06,.55),this.noise(.1,600,1,t?.3:.15,null,"lowpass")}swing(t){this.noise(.12,1800,.7,.18*this.att(t),null,"highpass")}eat(){for(let t=0;t<3;t++)this.noise(.07,1200+t*200,2,.3,null,"bandpass",t*.12)}pickup(){this.tone(880+Math.random()*200,.07,"sine",.12,1.6)}click(){this.tone(660,.05,"square",.06,1.2)}hover(){this.tone(980,.03,"sine",.03)}beep(t){this.tone(t?1320:880,t?.35:.15,"square",.1)}kill(){[660,880,1320].forEach((t,e)=>this.tone(t,.12,"square",.08,1,e*.07))}death(){[440,330,220,165].forEach((t,e)=>this.tone(t,.22,"sawtooth",.08,.9,e*.12))}win(){[523,659,784,1046,784,1046].forEach((t,e)=>this.tone(t,.22,"square",.09,1,e*.13))}egg(t){this.noise(.5,900,3,.7*Math.max(.35,this.att(t))),[300,200,120].forEach((e,n)=>this.tone(e,.3,"sawtooth",.12,.6,n*.1))}throwS(){this.noise(.15,1400,1,.25,null,"highpass")}trap(){this.noise(.45,500,2,.5),this.tone(140,.4,"sawtooth",.12,.5),this.tone(90,.5,"square",.08,.6,.08)}warp(){this.tone(300,.4,"sine",.14,4),this.tone(450,.4,"triangle",.08,3)}levelUp(){[523,784,1046,1568].forEach((t,e)=>this.tone(t,.18,"triangle",.1,1,e*.09))}startMusic(t="calm"){if(!this.ctx||this.musicOn)return;this.musicOn=!0,this.musicStyle=t;let e=this.ctx,n={calm:[0,2,4,7,9,12,14,16],tense:[0,3,5,7,10,12,15,17]},i=0,r=e.currentTime+.1,o=[[0,4,7],[-3,0,4],[-7,-3,0],[-5,-1,2]],a=()=>{if(this.musicOn){for(;r<e.currentTime+.6;){let l=n[this.musicStyle]||n.calm,c=Math.floor(i/16)%4,h=i%16,d=57,f=p=>440*Math.pow(2,(p-69)/12);if(h===0)for(let p of o[c])this.tone(f(d+p-12),3.2,"triangle",.035,1,r-e.currentTime,this.mus);if(h%2===0&&Math.random()<.72){let p=l[Math.floor(Math.random()*l.length)]+o[c][0];this.tone(f(d+p+12),.45,"sine",.045,1,r-e.currentTime,this.mus)}h%4===2&&Math.random()<.5&&this.tone(f(d+o[c][1]),.25,"square",.012,1,r-e.currentTime,this.mus),r+=.21,i++}this.musicTimer=setTimeout(a,200)}};a()}stopMusic(){this.musicOn=!1,clearTimeout(this.musicTimer)}setMusicStyle(t){this.musicStyle=t}};var ol=["wood","stone","iron","diamond"],Rd={wood:["#a9824a","#7a5a2e"],stone:["#9a9a9a","#6a6a6a"],iron:["#e8e8e8","#a8a8a8"],diamond:["#6ff0e8","#2aa8a0"],leather:["#9a5a30","#6a3a1a"],chain:["#b8b8c0","#70707a"],gold:["#ffd84a","#c89a1a"]},Id=["leather","chain","iron","diamond"],Pd=["helmet","chest","legs","boots"],Ux={leather:[1,3,2,1],chain:[2,5,4,1],iron:[2,6,5,2],diamond:[3,8,6,3]},ne={},un=(s,t)=>{ne[s]={id:s,stack:64,...t}};for(let s of Yt)s&&un(s.id,{name:s.name,kind:"block",block:s.id,icon:null});ol.forEach((s,t)=>un(100+t,{name:`${s[0].toUpperCase()+s.slice(1)} Sword`,kind:"sword",tier:t,damage:[4,5,6,7][t],stack:1,icon:`sword_${s}`}));ol.forEach((s,t)=>un(110+t,{name:`${s[0].toUpperCase()+s.slice(1)} Pickaxe`,kind:"pick",tier:t,damage:2+t*.5,speed:[2,3.5,5,7][t],stack:1,icon:`pick_${s}`}));ol.forEach((s,t)=>un(120+t,{name:`${s[0].toUpperCase()+s.slice(1)} Axe`,kind:"axe",tier:t,damage:[3,4,5,6][t],speed:[2,3.5,5,7][t],stack:1,icon:`axe_${s}`}));un(130,{name:"Golden Apple",kind:"food",heal:8,stack:16,icon:"gapple"});un(131,{name:"Snowball",kind:"throw",stack:16,icon:"snowball"});un(132,{name:"Warp Orb",kind:"warp",stack:8,icon:"orb"});un(133,{name:"Apple",kind:"food",heal:4,stack:16,icon:"apple"});Id.forEach((s,t)=>Pd.forEach((e,n)=>un(150+t*4+n,{name:`${s[0].toUpperCase()+s.slice(1)} ${e[0].toUpperCase()+e.slice(1)}`,kind:"armor",tier:t,slot:n,points:Ux[s][n],stack:1,icon:`armor_${s}_${e}`})));un(170,{name:"Iron",kind:"currency",stack:64,icon:"ingot_iron"});un(171,{name:"Gold",kind:"currency",stack:64,icon:"ingot_gold"});un(172,{name:"Diamond",kind:"currency",stack:64,icon:"gem"});un(180,{name:"Shears",kind:"shears",speed:6,stack:1,damage:1,icon:"shears"});function Si(s,t,e,n){let i=[],r=Math.max(Math.abs(e-s),Math.abs(n-t));for(let o=0;o<=r;o++)i.push([Math.round(s+(e-s)*o/r),Math.round(t+(n-t)*o/r)]);return i}function Ld(){let s={},t=(i,r)=>{for(let[o,a]of Si(2,13,6,9))i.set(o,a,r.hex("#6a4a2a")),i.set(o+1,a,r.hex("#8a6a3a"))};for(let i of ol){let[r,o]=Rd[i];s[`sword_${i}`]=(a,l)=>{a.clear();for(let[c,h]of Si(5,10,13,2))a.set(c,h,l.hex(r)),a.set(c+1,h+1,l.hex(o)),a.set(c,h+1,l.hex(o));for(let[c,h]of Si(3,8,7,12))a.set(c,h,l.hex("#4a3a2a"));for(let[c,h]of Si(1,14,4,11))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));a.set(14,1,l.hex(r))},s[`pick_${i}`]=(a,l)=>{a.clear(),t(a,l);for(let[c,h]of Si(6,9,11,4))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));for(let[c,h]of[[4,4],[5,3],[6,2],[7,2],[8,2],[9,2],[10,3],[11,4],[12,5],[13,6],[13,7],[12,8],[5,4],[9,3],[12,6]])a.set(c,h,l.hex(c>8&&h>4?o:r))},s[`axe_${i}`]=(a,l)=>{a.clear(),t(a,l);for(let[c,h]of Si(6,9,11,4))a.set(c,h,l.hex("#6a4a2a")),a.set(c+1,h,l.hex("#8a6a3a"));for(let c=2;c<8;c++)for(let h=8;h<14;h++)h-8+(7-c)<7&&!(h===13&&c>5)&&a.set(h,c,l.hex(h>11?o:r))}}s.gapple=(i,r)=>e(i,r,"#ffd84a","#c89a1a"),s.apple=(i,r)=>e(i,r,"#e23c3c","#a01e1e");function e(i,r,o,a){i.clear();for(let l=4;l<14;l++)for(let c=3;c<13;c++){let h=Math.hypot(c-7.5,(l-8.8)*1.05);h<5&&i.set(c,l,r.hex(h>3.6||c>8&&l>9?a:o))}i.set(6,6,r.hex("#ffffff")),i.set(7,2,r.hex("#5a3a1a")),i.set(7,3,r.hex("#5a3a1a")),i.set(8,2,r.hex("#3f8f2a")),i.set(9,1,r.hex("#3f8f2a"))}s.snowball=(i,r)=>{i.clear();for(let o=3;o<13;o++)for(let a=3;a<13;a++){let l=Math.hypot(a-7.5,o-7.5);l<4.8&&i.set(a,o,r.hex(l>3.8||a>8&&o>8?"#b8c8d8":"#f4faff"))}},s.orb=(i,r)=>{i.clear();for(let o=3;o<13;o++)for(let a=3;a<13;a++){let l=Math.hypot(a-7.5,o-7.5);l<4.8&&i.set(a,o,r.hex(l>3.8?"#1a5a5a":l>2?"#2aa8a0":"#9ff0e8"))}i.set(6,6,r.hex("#ffffff"))};for(let i of Id){let[r,o]=Rd[i],a={helmet:[[3,4,10,2],[3,6,2,4],[11,6,2,4]],chest:[[2,3,4,3],[10,3,4,3],[4,5,8,8]],legs:[[4,3,8,3],[4,6,3,8],[9,6,3,8]],boots:[[3,8,3,5],[10,8,3,5],[2,12,4,2],[10,12,4,2]]};for(let l of Pd)s[`armor_${i}_${l}`]=(c,h)=>{c.clear();for(let[d,f,p,m]of a[l])for(let x=f;x<f+m;x++)for(let g=d;g<d+p;g++)c.set(g,x,h.hex((g+x)%5===0?o:r));for(let[d,f,p,m]of a[l])for(let x=d;x<d+p;x++)c.set(x,f+m-1,h.hex(o))}}let n=(i,r)=>(o,a)=>{o.clear();for(let l=6;l<12;l++)for(let c=2+(11-l);c<14-(l-6)*.3;c++)o.set(c,l,a.hex(l===6||c<4+(11-l)?"#ffffff":l>9?r:i))};s.ingot_iron=n("#d8d8d8","#9a9a9a"),s.ingot_gold=n("#ffd84a","#c89a1a"),s.gem=(i,r)=>{i.clear();let o=[[7,2],[8,2],[5,4],[6,4],[7,4],[8,4],[9,4],[10,4],[4,6],[5,6],[6,6],[7,6],[8,6],[9,6],[10,6],[11,6],[5,8],[6,8],[7,8],[8,8],[9,8],[10,8],[6,10],[7,10],[8,10],[9,10],[7,12],[8,12]];for(let[a,l]of o)i.set(a,l,r.hex(a<7?"#c8fffb":"#5fe0d8")),i.set(a,l+1,r.hex(a<7?"#5fe0d8":"#2aa8a0"))},s.shears=(i,r)=>{i.clear();for(let[o,a]of Si(3,12,11,4))i.set(o,a,r.hex("#d8d8d8"));for(let[o,a]of Si(5,12,13,4))i.set(o,a,r.hex("#a8a8a8"));for(let[o,a]of[[2,12],[3,13],[2,13],[5,13],[6,13]])i.set(o,a,r.hex("#c8302a"))};for(let i of Object.keys(s)){let r=s[i];s[i]=(o,a)=>(r(o,a),o)}return s}var Ws=(s,t)=>150+s*4+t;var Wn=1,ge=2;function nn(s){let t=s>>>0||1;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}function ts(s){let t=nn(s),e=new Uint8Array(512),n=new Float32Array(256);for(let a=0;a<256;a++)e[a]=a,n[a]=t();for(let a=255;a>0;a--){let l=Math.floor(t()*(a+1));[e[a],e[l]]=[e[l],e[a]]}for(let a=0;a<256;a++)e[a+256]=e[a];let i=(a,l)=>n[e[(a&255)+e[l&255]]],r=a=>a*a*(3-2*a),o=(a,l)=>{let c=Math.floor(a),h=Math.floor(l),d=r(a-c),f=r(l-h),p=i(c,h),m=i(c+1,h),x=i(c,h+1),g=i(c+1,h+1);return p+(m-p)*d+(x-p)*f+(p-m-x+g)*d*f};return(a,l,c=3)=>{let h=0,d=1,f=1,p=0;for(let m=0;m<c;m++)h+=o(a*f,l*f)*d,p+=d,d*=.5,f*=2;return h/p}}var es={meadow:{top:1,under:2,core:3,accent:28,trunk:6,leaves:7,plants:[40,40,40,41,42],tree:"oak",rock:4},desert:{top:8,under:9,core:9,accent:22,trunk:44,leaves:0,plants:[43,43,40],tree:"cactus",rock:9},snow:{top:10,under:2,core:3,accent:11,trunk:6,leaves:7,plants:[40],tree:"spruce",rock:3},volcano:{top:18,under:18,core:13,accent:19,trunk:18,leaves:0,plants:[],tree:"spire",rock:18}},Ln={castle:{wall:47,wall2:48,wall3:49,floor:52,pillar:47,roof:53,trim:50,window:54,path:4,light:27},temple:{wall:9,wall2:65,wall3:9,floor:9,pillar:51,roof:65,trim:51,window:12,path:9,light:27},fort:{wall:47,wall2:49,wall3:52,floor:52,pillar:51,roof:10,trim:50,window:11,path:52,light:27},ruins:{wall:18,wall2:49,wall3:21,floor:52,pillar:18,roof:18,trim:21,window:54,path:18,light:66},village:{wall:5,wall2:6,wall3:50,floor:50,pillar:6,roof:53,trim:50,window:12,path:4,light:27},sea:{wall:64,wall2:51,wall3:64,floor:51,pillar:51,roof:64,trim:51,window:12,path:51,light:27}};function dn(s,t,e,n,i,r,o,a={}){let l=Math.ceil(r*1.35),c=a.depth??r*1.1,h=[];for(let d=-l;d<=l;d++)for(let f=-l;f<=l;f++){let p=Math.hypot(f,d)/r+(t((e+f)*.13,(n+d)*.13)-.5)*(a.rough??.55);if(p>=1)continue;let m=e+f,x=n+d,g=a.flat?0:Math.floor(t(m*.21+50,x*.21)*2.2*(1-p)),u=i+g,v=Math.round(i-1-Math.pow(1-p,.75)*c*(.55+t(m*.3,x*.3+9)*.7));for(let _=v;_<=u;_++){let M=o.core;_===u?M=o.top:_>=u-2?M=o.under:t(m*.4,_*.4+x*.4)>.72&&(M=o.accent),s.set(m,_,x,M,ge,!0)}h.push([m,u,x,p])}return h}function Dd(s,t,e,n,i,r,o){if(r==="oak"){let a=4+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,o.trunk,ge,!0);for(let l=a-2;l<=a+1;l++){let c=l>=a?1:2;for(let h=-c;h<=c;h++)for(let d=-c;d<=c;d++)Math.abs(d)===c&&Math.abs(h)===c&&(l===a+1||t()<.5)||s.get(e+d,n+l,i+h)||s.set(e+d,n+l,i+h,o.leaves,ge,!0)}}else if(r==="spruce"){let a=6+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,o.trunk,ge,!0);for(let l=2;l<=a+1;l++){let c=l===a+1?0:Math.max(1,Math.round((a-l)/2.2));for(let h=-c;h<=c;h++)for(let d=-c;d<=c;d++)Math.abs(d)+Math.abs(h)>c+1||s.get(e+d,n+l,i+h)||s.set(e+d,n+l,i+h,o.leaves,ge,!0);if(l%2)for(let[h,d]of[[1,0],[-1,0],[0,1],[0,-1]])s.get(e+h*2,n+l,i+d*2)===o.leaves&&s.set(e+h*2,n+l,i+d*2,10,ge,!0)}}else if(r==="cactus"){let a=2+Math.floor(t()*2);for(let l=1;l<=a;l++)s.set(e,n+l,i,44,ge,!0)}else if(r==="spire"){let a=3+Math.floor(t()*4);for(let l=1;l<=a;l++)s.set(e,n+l,i,l===a?19:18,ge,!0)}}function fn(s,t,e,n,i=.18,r=1,o=()=>!0){let a=e.filter(([,,,c])=>c<.8),l=0;for(let c=0;c<r*8&&l<r;c++){let h=a[Math.floor(t()*a.length)];!h||h[3]<.25||s.get(h[0],h[1]+1,h[2])||!o(h[0],h[2])||s.get(h[0],h[1],h[2])===n.top&&(Dd(s,t,h[0],h[1],h[2],n.tree,n),l++)}if(n.plants.length)for(let[c,h,d,f]of e)f<.9&&t()<i&&!s.get(c,h+1,d)&&s.get(c,h,d)===n.top&&s.set(c,h+1,d,n.plants[Math.floor(t()*n.plants.length)],ge,!0)}function Qc(s,t,e,n,i,r){s.set(e,n,i,17,ge,!0);for(let o=n+1;o<=n+2;o++)s.get(e,o,i)>=40&&s.get(e,o,i)<=43&&s.set(e,o,i,0,0,!0);t.push({x:e,y:n,z:i,tier:r,items:[]})}function th(s,t,e,n){let i=e-s,r=n-t;return Math.abs(i)>Math.abs(r)?[Math.sign(i),0]:[0,Math.sign(r)||1]}var Ke=class{constructor(t,e,n,i,r=[0,1]){this.w=t,this.ox=e,this.oy=n,this.oz=i,this.fx=r[0],this.fz=r[1],this.rx=r[1],this.rz=-r[0]}wx(t,e){return this.ox+t*this.rx+e*this.fx}wz(t,e){return this.oz+t*this.rz+e*this.fz}pos(t,e,n){return{x:this.wx(t,n),y:this.oy+e,z:this.wz(t,n)}}set(t,e,n,i){this.w.set(this.wx(t,n),this.oy+e,this.wz(t,n),i,i?ge:0,!0)}get(t,e,n){return this.w.get(this.wx(t,n),this.oy+e,this.wz(t,n))}box(t,e,n,i,r,o,a){for(let l=Math.min(e,r);l<=Math.max(e,r);l++)for(let c=Math.min(n,o);c<=Math.max(n,o);c++)for(let h=Math.min(t,i);h<=Math.max(t,i);h++)this.set(h,l,c,a)}walls(t,e,n,i,r,o,a){for(let l=e;l<=r;l++)for(let c=n;c<=o;c++)for(let h=t;h<=i;h++)(h===t||h===i||c===n||c===o)&&this.set(h,l,c,a)}foundation(t,e,n,i,r,o,a=6,l=1){for(let c=e;c<=i;c++)for(let h=t;h<=n;h++){if(h<t+l||h>n-l||c<e+l||c>i-l){let f=!1;for(let p=0;p>=-3;p--)if(this.get(h,p,c)){f=!0;break}if(!f)continue}this.set(h,0,c,r);for(let f=1;f<14;f++)this.get(h,f,c)&&this.get(h,f,c)!==17&&this.set(h,f,c,0);for(let f=-1;f>=-a&&!this.get(h,f,c);f--)this.set(h,f,c,o)}}};var Nx=new Set([6,7,10,40,41,42,43,44,18,19]),al=(s,t,e,n,i,r)=>{let o=t();s.set(n,i,r,o<.12?e.wall3:o<.32?e.wall2:e.wall)};function Ge(s,t,e,n,i,r,o){let a=s.pos(e,n,i);Qc(s.w,t,a.x,a.y,a.z,r),t[t.length-1].group=o}function kd(s,t,e,n,i,r,o=5){s.box(n,i,r,n,i+o,r,t.trim),s.box(n+1,i+o-2,r,n+2,i+o,r,e)}function yn(s,t,e,n,i){s.box(e,n,i,e,n+2,i,t.trim),s.set(e,n+3,i,t.light)}function eh(s,t,e,n,i,r,o=!1){s.foundation(-6,-6,6,6,t.path,t.wall),s.box(-4,0,-4,4,0,4,t.floor);for(let a=1;a<=5;a++)for(let l=-4;l<=4;l++)for(let c=-4;c<=4;c++)(Math.abs(c)===4||Math.abs(l)===4)&&al(s,i,t,c,a,l);for(let[a,l]of[[-4,-4],[4,-4],[-4,4],[4,4]])s.box(a,1,l,a,7,l,t.pillar),s.set(a,8,l,e);s.box(-4,6,-4,4,6,4,t.floor);for(let a=-4;a<=4;a++)for(let l=-4;l<=4;l++)(Math.abs(l)===4||Math.abs(a)===4)&&(s.set(l,6,a,e),(l+a)%2===0&&!(Math.abs(l)===4&&Math.abs(a)===4)&&s.set(l,7,a,t.wall));for(let[a,l]of[[-4,0],[4,0],[-2,-4],[2,-4],[-2,4],[2,4]])s.box(a,2,l,a,3,l,t.window);if(s.box(-1,1,4,1,3,4,0),s.box(-1,4,4,1,4,4,t.trim),s.set(0,5,0,t.light),kd(s,t,e,0,7,-3,5),Ge(s,n,-3,1,-3,"spawn",r),Ge(s,n,3,1,-3,"spawn",r),Ge(s,n,-3,1,2,"spawn",r),o)for(let a=2;a<=7;a++)for(let l=-4;l<=4;l++)for(let c=-4;c<=4;c++)(Math.abs(c)===4||Math.abs(l)===4)&&i()<.16+a*.03&&s.get(c,a,l)!==e&&s.set(c,a,l,0);return s.pos(0,1,0)}function Ud(s,t,e,n,i,r){s.foundation(-5,-5,5,5,t.path,t.wall2),s.box(-3,0,-3,3,0,3,t.floor),s.walls(-3,1,-3,3,4,3,t.wall);for(let[o,a]of[[-3,-3],[3,-3],[-3,3],[3,3]])s.box(o,1,a,o,4,a,t.wall2);for(let[o,a]of[[-3,0],[3,0],[-1,-3],[1,-3]])s.box(o,2,a,o,3,a,t.window);s.box(0,1,3,0,2,3,0);for(let o=0;o<=4;o++)for(let a=-4;a<=4;a++)if(s.set(-4+o,5+o,a,t.roof),s.set(4-o,5+o,a,t.roof),o<4)for(let l=-3+o;l<=3-o;l++)Math.abs(a)===3&&s.set(l,5+o,a,t.wall);for(let o=-4;o<=4;o++)s.set(0,9,o,e);return s.set(0,4,0,t.light),s.box(-2,1,4,-2,1,4,55),s.box(2,1,4,2,2,4,55),yn(s,t,4,1,5),Ge(s,n,-2,1,-2,"spawn",r),Ge(s,n,2,1,-2,"spawn",r),Ge(s,n,2,1,1,"spawn",r),s.set(-2,1,1,56),s.pos(0,1,0)}function Nd(s,t,e,n,i,r){s.foundation(-6,-6,6,6,t.path,t.wall),s.box(-5,0,-5,5,0,5,t.floor),s.box(-4,1,-4,4,1,4,t.wall2),s.box(-3,1,-3,3,1,3,t.floor),s.box(-1,1,4,1,1,5,t.wall2);for(let o of[-4,-2,2,4])for(let a of[-4,4])s.box(o,2,a,o,5,a,t.pillar);for(let o of[-2,0,2])for(let a of[-4,4])s.box(a,2,o,a,5,o,t.pillar);s.walls(-4,2,-4,4,2,-4,t.wall),s.box(-4,6,-4,4,6,4,t.wall);for(let o=-4;o<=4;o++)for(let a=-4;a<=4;a++)(Math.abs(a)===4||Math.abs(o)===4)&&s.set(a,7,o,(a+o)%2?e:t.trim);return s.box(-1,7,-1,1,7,1,t.wall2),s.set(0,8,0,e),s.set(0,5,0,t.light),Ge(s,n,-3,2,-3,"spawn",r),Ge(s,n,3,2,-3,"spawn",r),Ge(s,n,3,2,2,"spawn",r),s.pos(0,2,0)}function Fd(s,t,e,n,i,r){s.foundation(-7,-7,7,7,t.path,t.wall),s.box(-6,0,-6,6,0,6,t.floor);for(let o=1;o<=3;o++)for(let a=-6;a<=6;a++)for(let l=-6;l<=6;l++)(Math.abs(l)===6||Math.abs(a)===6)&&al(s,i,t,l,o,a);for(let o=-6;o<=6;o++)for(let a=-6;a<=6;a++)(Math.abs(a)===6||Math.abs(o)===6)&&(a+o)%2===0&&s.set(a,4,o,e);s.box(-1,1,6,1,3,6,0),s.box(-1,4,6,1,4,6,0);for(let[o,a]of[[-6,-6],[6,-6],[-6,6],[6,6]]){let l=Math.sign(o),c=Math.sign(a);s.box(o-l,1,a-c,o,6,a,t.pillar),s.box(o-l,7,a-c,o,7,a,e)}return s.box(-1,1,-1,1,1,1,t.wall),s.set(0,1,0,0),s.box(-1,0,-1,1,0,1,t.wall),yn(s,t,-4,1,3),yn(s,t,4,1,3),Ge(s,n,-5,1,-5,"spawn",r),Ge(s,n,5,1,-5,"spawn",r),Ge(s,n,-5,1,4,"spawn",r),kd(s,t,e,0,1,-5,6),s.pos(0,1,3)}function qs(s,t,e,n,i,r=7,o=null,a="satellite",l=-1){s.box(n-1,0,i-1,n+1,0,i+1,t.floor),s.walls(n-1,1,i-1,n+1,r,i+1,t.wall),s.box(n,1,i+1,n,2,i+1,0),s.set(n-1,3,i,t.window),s.set(n+1,3,i,t.window),s.box(n-1,r+1,i-1,n+1,r+1,i+1,t.floor);for(let[c,h]of[[-1,-1],[1,-1],[-1,1],[1,1]])s.set(n+c,r+2,i+h,e||t.trim);o&&Ge(s,o,n,1,i-0,a,l)}function Od(s,t,e,n,i){s.foundation(-12,-12,12,12,t.path,t.wall),s.box(-10,0,-10,10,0,10,t.floor);for(let r=1;r<=4;r++)for(let o=-9;o<=9;o++)for(let a=-9;a<=9;a++)(Math.abs(a)===9||Math.abs(o)===9)&&al(s,i,t,a,r,o);for(let r=-9;r<=9;r++)for(let o=-9;o<=9;o++)(Math.abs(o)===9||Math.abs(r)===9)&&(o+r)%2===0&&s.set(o,5,r,t.wall);for(let[r,o]of[[0,1],[0,-1],[1,0],[-1,0]])for(let a=-1;a<=1;a++)for(let l=1;l<=3;l++)s.set(r?r*9:a,l,o?o*9:a,0);for(let[r,o]of[[-9,-9],[9,-9],[-9,9],[9,9]]){s.box(r-1,1,o-1,r+1,8,o+1,t.pillar),s.box(r-1,9,o-1,r+1,9,o+1,t.floor);for(let[a,l]of[[-1,-1],[1,-1],[-1,1],[1,1]])s.set(r+a,10,o+l,e);s.set(r,10,o,t.light)}s.walls(-3,1,-3,3,7,3,t.wall);for(let[r,o]of[[-3,-3],[3,-3],[-3,3],[3,3]])s.box(r,1,o,r,9,o,t.pillar);s.box(-3,8,-3,3,8,3,t.floor);for(let r=-3;r<=3;r++)for(let o=-3;o<=3;o++)(Math.abs(o)===3||Math.abs(r)===3)&&(o+r)%2===0&&s.set(o,9,r,e);for(let[r,o]of[[0,1],[0,-1],[1,0],[-1,0]])for(let a=1;a<=2;a++)s.set(r*3,a,o*3,0);for(let[r,o]of[[0,1],[0,-1],[1,0],[-1,0]])s.box(r*3,4,o*3,r*3,5,o*3,t.window);s.set(0,7,0,t.light),s.box(-1,1,-1,1,1,1,14);for(let[r,o]of[[-2,-2],[2,-2],[-2,2],[2,2]])Ge(s,n,r,1,o,"mid",100);for(let[r,o]of[[-7,-6],[7,6],[-6,7],[6,-7]])Ge(s,n,r,1,o,"mid",101);for(let[r,o]of[[-6,0],[6,0],[0,-6],[0,6]])yn(s,t,r,1,o)}function ll(s,t,e,n,i="satellite",r=-1){s.foundation(-4,-4,4,4,t.path,t.wall);for(let o=-3;o<=3;o++)for(let a=-3;a<=3;a++){if(!(Math.abs(a)===3||Math.abs(o)===3))continue;let l=1+Math.floor(n()*4);for(let c=1;c<=l;c++)al(s,n,t,a,c,o)}s.box(-1,1,3,1,4,3,0),s.box(-3,5,-3,-3,7,-3,t.pillar),s.set(-3,8,-3,t.light),Ge(s,e,1,1,-1,i,r),n()<.5&&Ge(s,e,-1,1,1,i,r)}function Xs(s,t,e,n){s.box(e-1,0,n-1,e+1,1,n+1,t.wall),s.box(e,2,n,e,4,n,t.pillar),s.box(e-1,4,n,e+1,4,n,t.pillar),s.set(e,5,n,14)}function ns(s,t,e){s.set(t,1,e,55),s.set(t+1,1,e,5),s.set(t,2,e,5)}function wi(s,t,e,n,i,r,o,a=0,l=Math.random){let c=i-e,h=r-n,d=Math.max(Math.abs(c),Math.abs(h));if(!d)return;let f=-h/Math.hypot(c,h),p=c/Math.hypot(c,h);for(let m=0;m<=d;m++){let x=m/d;if(a&&x>.5-a/2&&x<.5+a/2)continue;let g=e+c*x,u=n+h*x;for(let v=-2;v<=2;v++){let _=Math.round(g+f*v),M=Math.round(u+p*v);for(let A=o+1;A<=o+4;A++){let b=s.get(_,A,M);Nx.has(b)&&s.set(_,A,M,0,0,!0)}}for(let v=-1;v<=1;v++){let _=Math.round(g+f*v),M=Math.round(u+p*v);if(s.get(_,o,M)||s.set(_,o,M,v?t.floor:t.path,ge,!0),!s.get(_,o-1,M)&&m%6===0&&v===0)for(let A=o-1;A>o-4;A--)s.set(_,A,M,t.wall,ge,!0)}for(let v of[-2,2]){let _=Math.round(g+f*v),M=Math.round(u+p*v);s.get(_,o,M)||s.set(_,o,M,t.floor,ge,!0),m%2===0&&!s.get(_,o+1,M)&&s.set(_,o+1,M,t.wall,ge,!0),m%8===0&&!s.get(_,o+2,M)&&s.set(_,o+2,M,t.light,ge,!0)}}}var Fx={meadow:{style:"castle",spawn:"keep",bridges:"partial"},desert:{style:"temple",spawn:"temple",bridges:"none"},snow:{style:"fort",spawn:"fort",bridges:"full"},volcano:{style:"ruins",spawn:"ruinkeep",bridges:"none"}},Ox={keep:6,house:5,temple:6,fort:8,ruinkeep:6},Bx={keep:eh,house:Ud,temple:Nd,fort:Fd,ruinkeep:(s,t,e,n,i,r)=>eh(s,t,e,n,i,r,!0)};function $s(s,t="meadow",e=8,n={}){let i={...Fx[t],...n},r=Ln[i.style],o=es[t],a=new en(176,64,176),l=nn(s),c=ts(s),h=[],d=[],f=30,p=58,m=[];for(let g=0;g<e;g++){let u=g/e*Math.PI*2+.2,v=Math.round(Math.cos(u)*p),_=Math.round(Math.sin(u)*p),M=dn(a,c,v,_,f,10.5,o,{depth:10,rough:.32,flat:!0}),A=new Ke(a,v,f,_,th(v,_,0,0)),b=Gt[g%Gt.length].wool,T=Bx[i.spawn](A,r,b,d,l,g);fn(a,l,M,o,.14,2,(I,y)=>Math.max(Math.abs(I-v),Math.abs(y-_))>Ox[i.spawn]+2.5),h.push({x:T.x+.5,y:T.y,z:T.z+.5,yaw:Math.atan2(v,_),group:g})}let x=dn(a,c,0,0,f+2,17,o,{depth:16,rough:.35,flat:!0});Od(new Ke(a,0,f+2,0,[0,1]),r,38,d,l),fn(a,l,x,o,.1,5,(g,u)=>Math.max(Math.abs(g),Math.abs(u))>13);for(let g=0;g<e/2;g++){let u=(g+.5)/(e/2)*Math.PI*2+.2;m.push(u);let v=Math.round(Math.cos(u)*33),_=Math.round(Math.sin(u)*33),M=dn(a,c,v,_,f+1,7,o,{depth:8,rough:.4,flat:!0}),A=new Ke(a,v,f+1,_,th(v,_,0,0));g%2?ll(A,r,d,l,"satellite",200+g):(qs(A,r,0,0,0,7,d,"satellite",200+g),ns(A,2,2),Xs(A,r,-3,2)),fn(a,l,M,o,.15,1,(b,T)=>Math.hypot(b-v,T-_)>4)}if(i.bridges!=="none"){for(let g=0;g<m.length;g++){let u=m[g],v=Math.round(Math.cos(u)*33),_=Math.round(Math.sin(u)*33);wi(a,r,Math.round(Math.cos(u)*13),Math.round(Math.sin(u)*13),Math.round(Math.cos(u)*27),Math.round(Math.sin(u)*27),f+1,i.bridges==="partial"?.35:0,l)}if(i.bridges==="full")for(let g=1;g<e;g+=2){let u=g/e*Math.PI*2+.2;wi(a,r,Math.round(Math.cos(u)*50),Math.round(Math.sin(u)*50),Math.round(Math.cos(u)*38),Math.round(Math.sin(u)*38),f,0,l)}}for(let g=0;g<e;g++){let u=g/e*Math.PI*2+.2,v=Math.round(Math.cos(u)*49),_=Math.round(Math.sin(u)*49);a.get(v,f,_)&&!a.get(v,f+1,_)&&yn(new Ke(a,v,f+1,_,[0,1]),r,0,0,0)}return{world:a,spawns:h,chests:d,theme:t,top:f,voidY:4,center:{x:0,y:f+3,z:0},radius:80,style:i.style}}var zx={meadow:"castle",desert:"temple",snow:"fort",volcano:"ruins"};function zr(s,t="snow",e=4,n={}){let i=Ln[n.style||zx[t]],r=es[t],o=new en(176,64,176),a=nn(s),l=ts(s),c=30,h=56,d={world:o,theme:t,top:c,voidY:4,center:{x:0,y:c+2,z:0},radius:84,chests:[],spawns:[],teams:[],gens:[],npcs:[]};for(let m=0;m<e;m++){let x=m/e*Math.PI*2,g=Math.cos(x),u=Math.sin(x),v=Math.round(g*h),_=Math.round(u*h),M=dn(o,l,v,_,c,12.5,r,{depth:10,rough:.28,flat:!0}),A=Math.abs(g)>Math.abs(u)?[-Math.sign(g),0]:[0,-Math.sign(u)],b=new Ke(o,v,c,_,A),T=Gt[m];b.foundation(-9,-9,9,9,i.path,i.wall),b.box(-8,0,-8,8,0,8,i.floor);for(let H=-8;H<=8;H++)for(let G=-8;G<=8;G++)Math.abs(G)<=2&&Math.abs(H)<=2&&b.set(G,0,H,T.wool);for(let H=1;H<=2;H++)for(let G=-8;G<=8;G++)for(let X=-8;X<=8;X++)(Math.abs(X)===8||Math.abs(G)===8)&&b.set(X,H,G,H===2&&(X+G)%2?T.wool:i.wall);for(let H of[-1,0,1])for(let G=1;G<=2;G++)b.set(H,G,8,0),b.set(8,G,H,0),b.set(-8,G,H,0);for(let[H,G]of[[-8,-8],[8,-8],[-8,8],[8,8]])b.box(H,1,G,H,5,G,i.pillar),b.set(H,6,G,T.wool);b.box(-2,1,-7,2,1,-5,13),b.box(-2,2,-7,-2,4,-7,i.pillar),b.box(2,2,-7,2,4,-7,i.pillar),b.box(-2,5,-7,2,5,-7,T.wool),b.set(0,2,-6,13),b.set(0,3,-6,45);let I=b.pos(0,3,-6);b.walls(5,1,3,7,3,6,i.wall2),b.box(5,1,4,5,2,5,0),b.box(5,4,3,7,4,6,i.roof),b.set(6,0,5,i.floor);let y=b.pos(6,1,5),w=b.pos(-6,0,5),C=b.pos(-6,0,3);b.set(-6,0,5,24),b.set(-6,0,3,25),b.box(-7,1,2,-7,2,6,i.wall2),b.box(-7,3,2,-5,3,6,i.roof),yn(b,i,-3,1,7),yn(b,i,3,1,7),fn(o,a,M,r,.08,2,(H,G)=>Math.max(Math.abs(H-v),Math.abs(G-_))>10),d.gens.push({x:w.x,y:c,z:w.z,item:170,every:1.25,cap:40,team:m},{x:C.x,y:c,z:C.z,item:171,every:5,cap:16,team:m}),d.npcs.push({npc:!0,kind:"shop",team:m,x:y.x+.5,y:c+1,z:y.z+.5,yaw:Math.atan2(-(v-y.x),-(_-y.z)),name:"Shop"});let L=b.pos(0,1,1),B=Math.atan2(g,u);d.spawns.push({x:L.x+.5,y:c+1,z:L.z+.5,yaw:B,team:m}),d.teams.push({i:m,color:T,egg:{x:I.x,y:I.y,z:I.z},spawn:{x:L.x+.5,y:c+1,z:L.z+.5},center:{x:v,z:_}})}for(let m=0;m<e;m++){let x=(m+.5)/e*Math.PI*2,g=Math.round(Math.cos(x)*36),u=Math.round(Math.sin(x)*36),v=dn(o,l,g,u,c+1,6.5,r,{depth:7,rough:.35,flat:!0}),_=new Ke(o,g,c+1,u,[0,1]);_.foundation(-2,-2,2,2,i.path,i.wall),_.set(0,0,0,25),d.gens.push({x:g,y:c+1,z:u,item:171,every:7,cap:10}),qs(_,i,0,3,-3,5),ns(_,-3,2),fn(o,a,v,r,.12,1,(M,A)=>Math.hypot(M-g,A-u)>4)}let f=dn(o,l,0,0,c+2,11,r,{depth:12,rough:.35,flat:!0}),p=new Ke(o,0,c+2,0,[0,1]);p.foundation(-6,-6,6,6,i.path,i.wall),p.box(-5,0,-5,5,0,5,i.floor);for(let[m,x]of[[-2,0],[2,0]])p.set(m,0,x,26),d.gens.push({x:m,y:c+2,z:x,item:172,every:14,cap:6});for(let[m,x]of[[-5,-5],[5,-5],[-5,5],[5,5]])p.box(m,1,x,m,4,x,i.pillar),p.set(m,5,x,i.light);p.box(-5,5,-5,5,5,-5,i.wall),p.box(-5,5,5,5,5,5,i.wall),Xs(p,i,0,-3),fn(o,a,f,r,.1,3,(m,x)=>Math.max(Math.abs(m),Math.abs(x))>7);for(let m=0;m<e;m++){let x=(m+.5)/e*Math.PI*2;wi(o,i,Math.round(Math.cos(x)*12),Math.round(Math.sin(x)*12),Math.round(Math.cos(x)*30),Math.round(Math.sin(x)*30),c+1,.3,a)}return d}var Hx=30,Vx=8.6,re=.3,Hr=1e-4;function Vr(s){return s.crouch?1.5:1.8}function oi(s){return s.crouch?1.28:1.62}function ih(s,t,e,n,i){return s.boxHits(t-re,e,n-re,t+re,e+i,n+re)}function Gx(s,t,e,n){let i=Math.floor(e-.05);for(let r of[-re+.02,re-.02])for(let o of[-re+.02,re-.02])if(s.solidAt(Math.floor(t+r),i,Math.floor(n+o)))return!0;return!1}function nh(s,t,e,n){if(!n)return!1;let i=Vr(t),r=t.pos,o=Math.ceil(Math.abs(n)/.45),a=n/o;for(let l=0;l<o;l++){let c=e===0?r.x+a:r.x,h=e===1?r.y+a:r.y,d=e===2?r.z+a:r.z;if(!ih(s,c,h,d,i)){if(t.crouch&&t.onGround&&e!==1&&!Gx(s,c,r.y,d))return!0;r.x=c,r.y=h,r.z=d;continue}return e===0?r.x=a>0?Math.floor(r.x+re+a)-re-Hr:Math.floor(r.x-re+a)+1+re+Hr:e===2?r.z=a>0?Math.floor(r.z+re+a)-re-Hr:Math.floor(r.z-re+a)+1+re+Hr:r.y=a>0?Math.floor(r.y+i+a)-i-Hr:Math.floor(r.y+a)+1,ih(s,r.x,r.y,r.z,i)&&(e===0?r.x-=a:e===2?r.z-=a:r.y-=a),!0}return!1}function Bd(s,t,e,n){let i=(n.crouch?1.4:n.sprint?5.7:4.3)*(t.speedMul||1),r=Math.hypot(n.mx,n.mz),o=r>0?n.mx/Math.max(1,r)*i:0,a=r>0?n.mz/Math.max(1,r)*i:0,l=t.onGround?40:10,c=Math.min(1,l*e);t.vel.x+=(o-t.vel.x)*c,t.vel.z+=(a-t.vel.z)*c,t.kb.x*=Math.pow(t.onGround?.02:.25,e),t.kb.z*=Math.pow(t.onGround?.02:.25,e),Math.abs(t.kb.x)<.05&&(t.kb.x=0),Math.abs(t.kb.z)<.05&&(t.kb.z=0);let h=t.crouch;t.crouch=!!n.crouch,h&&!t.crouch&&ih(s,t.pos.x,t.pos.y,t.pos.z,1.8)&&(t.crouch=!0),n.jump&&t.onGround&&!t.crouch&&(t.vel.y=Vx,t.onGround=!1,t.jumped=!0),t.vel.y=Math.max(-55,t.vel.y-Hx*e);let d=t.pos.y,f=nh(s,t,0,(t.vel.x+t.kb.x)*e),p=nh(s,t,2,(t.vel.z+t.kb.z)*e);f&&(t.vel.x=0,t.kb.x=0),p&&(t.vel.z=0,t.kb.z=0),t.blocked=f||p;let m=t.vel.y,x=nh(s,t,1,m*e),g=t.onGround;x&&(t.vel.y=0),t.onGround=x&&m<=0;let u=0;if(t.onGround){let v=s.get(Math.floor(t.pos.x),Math.floor(t.pos.y-.05),Math.floor(t.pos.z)),_=v&&Yt[v];if(_&&_.bounce)return t.vel.y=_.bounce,t.onGround=!1,t.airTop=t.pos.y,t.bounced=!0,{landed:0}}return t.onGround?(g||(u=(t.airTop??t.pos.y)-t.pos.y),t.airTop=null):t.airTop=Math.max(t.airTop??d,t.pos.y),{landed:u}}function zd(s,t,e,n,i){if(!s.inside(e,n,i))return!1;let r=s.get(e,n,i);if(r&&!(r>=40&&r<=43))return!1;for(let o of t){if(!o.alive)continue;let a=Vr(o);if(e+1>o.pos.x-re&&e<o.pos.x+re&&i+1>o.pos.z-re&&i<o.pos.z+re&&n+1>o.pos.y&&n<o.pos.y+a)return!1}return!0}var Wx=3.2,qx=4.8;function Hd(s,t,e,n,i,r,o,a){let l=0,c=1/0;for(let[h,d,f,p]of[[s.x,t.x,e,r],[s.y,t.y,n,o],[s.z,t.z,i,a]]){if(Math.abs(d)<1e-9){if(h<f||h>p)return-1;continue}let m=(f-h)/d,x=(p-h)/d;if(m>x&&([m,x]=[x,m]),l=Math.max(l,m),c=Math.min(c,x),l>c)return-1}return l}var cl=class{constructor(t,e,n={}){this.map=t,this.world=t.world,this.mode=e,this.actors=[],this.drops=[],this.projectiles=[],this.events=[],this.time=0,this.state="countdown",this.countdown=n.countdown??5,this.seed=n.seed||1,this.rand=Xx(this.seed),this.winner=null,this.over=!1,this.npcs=[],e.attach(this)}emit(t){this.events.push(t),this.events.length>400&&this.events.splice(0,100)}add(t){return this.actors.push(t),t.match=this,t}teamOf(t){return t.team}enemies(t,e){return t!==e&&!this.mode.noPvp&&(t.team<0||t.team!==e.team)&&!(this.mode.allied&&this.mode.allied(t,e))}alive(){return this.actors.filter(t=>t.alive)}update(t){if(t=Math.min(t,.05),this.state==="countdown"){this.countdown-=t;for(let e of this.actors)this.stepPhysics(e,t,e.ctl?e.ctl(t,this):null,!0);this.countdown<=0&&(this.state="play",this.mode.start(),this.emit({t:"start"}));return}if(this.state==="over"){this.time+=t;for(let e of this.actors)e.alive&&this.stepPhysics(e,t,null,!0);return}this.time+=t;for(let e of this.actors){if(!e.alive){e.respawnT>0&&(e.respawnT-=t,e.respawnT<=0&&this.mode.respawn(e));continue}let n=e.ctl?e.ctl(t,this):null;this.tickActor(e,t,n)}this.updateDrops(t),this.updateProjectiles(t),this.mode.update(t)}stepPhysics(t,e,n,i){if(!t.alive)return;let r=n||{};r.yaw!=null&&(t.yaw=r.yaw),r.pitch!=null&&(t.pitch=Math.max(-1.55,Math.min(1.55,r.pitch)));let o=Bd(this.world,t,e,i?{mx:0,mz:0}:r);return t.moveAmt=Math.hypot(t.vel.x,t.vel.z),t.walkPhase+=t.moveAmt*e*2.2,o}tickActor(t,e,n){let i=n||{};i.sel!=null&&i.sel>=0&&i.sel<9&&i.sel!==t.sel&&(t.sel=i.sel,t.mine=null,t.eatT=0),t.sprint=!!i.sprint&&!i.crouch;let r=this.stepPhysics(t,e,i,!1);if(t.hurtT=Math.max(0,t.hurtT-e),t.attackCd=Math.max(0,t.attackCd-e),t.swingT=Math.max(0,t.swingT-e),t.spawnProtect=Math.max(0,t.spawnProtect-e),r&&r.landed>3.5&&!this.mode.noFall&&this.damage(t,Math.floor(r.landed-3),this.recentAttacker(t,5),"fall"),!t.alive)return;if(t.pos.y<this.map.voidY){this.kill(t,this.recentAttacker(t,10),"void");return}t.hp<t.maxHp&&this.time-t.lastHurt>5&&(t.regenT+=e,t.regenT>2.5&&(t.regenT=0,t.hp=Math.min(t.maxHp,t.hp+1)));let o=t.held();i.attack?this.attackOrMine(t,e,i.attackPressed):t.mine=null,o&&o.kind==="food"&&i.useHeld&&t.hp<t.maxHp?(t.eatT+=e,t.eatT>.9&&(t.eatT=0,t.hp=Math.min(t.maxHp,t.hp+o.heal),o.id===130&&(t.absorb=4),t.inv.useSlot(t.sel),this.emit({t:"eat",a:t}))):t.eatT=0,i.use&&this.use(t,i)}recentAttacker(t,e){return t.lastAttacker&&this.time-t.lastAttackT<e?t.lastAttacker:null}lookHit(t,e=qx){let n=t.eye(oi(t)),i=t.look();return this.world.raycast(n.x,n.y,n.z,i.x,i.y,i.z,e,r=>r!==0&&(Yt[r].solid||Yt[r].pick))}lookActor(t,e=Wx){let n=t.eye(oi(t)),i=t.look(),r=null,o=e;for(let a of this.actors){if(a===t||!a.alive)continue;let l=Vr(a),c=Hd(n,i,a.pos.x-re-.1,a.pos.y-.1,a.pos.z-re-.1,a.pos.x+re+.1,a.pos.y+l+.1,a.pos.z+re+.1);c>=0&&c<o&&(o=c,r=a)}for(let a of this.npcs){let l=Hd(n,i,a.x-.4,a.y,a.z-.4,a.x+.4,a.y+1.9,a.z+.4);l>=0&&l<o&&(o=l,r=a)}if(r){let a=this.lookHit(t,o);if(a&&a.t<o)return null}return r?{target:r,t:o}:null}attackOrMine(t,e,n){let i=this.lookActor(t);if(i&&!i.target.npc){t.mine=null,t.attackCd<=0&&(n||t.bot||t.autoSwing)&&this.melee(t,i.target);return}n&&(t.swingT=.25,this.emit({t:"swing",a:t}));let r=this.lookHit(t);if(!r||!Pe(r.id)&&!Yt[r.id].cross){t.mine=null,r&&n&&this.mode.onUse&&this.mode.onUse(t,r);return}if(!this.mode.canBreak(t,r.x,r.y,r.z,r.id)){t.mine=null;return}(!t.mine||t.mine.x!==r.x||t.mine.y!==r.y||t.mine.z!==r.z)&&(t.mine={x:r.x,y:r.y,z:r.z,p:0,need:this.breakTime(t,r.id),snd:0}),t.mine.p+=e,t.mine.snd+=e,t.swingT=.25,t.mine.snd>.24&&(t.mine.snd=0,this.emit({t:"dig",a:t,id:r.id,x:r.x,y:r.y,z:r.z})),t.mine.p>=t.mine.need&&this.breakBlock(t,r.x,r.y,r.z)}breakTime(t,e){let n=Yt[e];if(n.hardness<=0)return .05;let i=t.held(),r=1;i&&(i.kind==="pick"&&n.tool==="pick"||i.kind==="axe"&&n.tool==="axe"||i.kind==="shears"&&(n.tool==="shears"||e===7)?r=i.speed:i.kind==="sword"&&e===7&&(r=1.5)),n.tool==="shovel"&&(r=Math.max(r,1.6));let o=n.tool==="pick"&&(!i||i.kind!=="pick")?n.hardness*2.2:n.hardness*1.1;return Math.max(.05,o/r)}breakBlock(t,e,n,i){let r=this.world.get(e,n,i);if(!r)return;this.world.set(e,n,i,0),t.mine=null,t.broken++,this.emit({t:"break",a:t,id:r,x:e,y:n,z:i}),this.mode.onBreak(t,e,n,i,r);let o=this.mode.dropFor(r);if(o){let a=t.inv.add(o,1);a&&this.spawnDrop(o,a,e+.5,n+.5,i+.5)}for(let a=n+1;a<n+3;a++){let l=this.world.get(e,a,i);if(l&&Yt[l].cross)this.world.set(e,a,i,0);else break}}melee(t,e){if(t.attackCd=t.bot?.42:.3,t.swingT=.25,this.emit({t:"swing",a:t}),!this.enemies(t,e)||e.spawnProtect>0)return;let n=t.held(),i=n&&n.damage?n.damage:1,r=!t.onGround&&t.vel.y<-.5;if(r&&(i*=1.5),this.damage(e,i,t,"melee",r)){let a=Math.hypot(e.pos.x-t.pos.x,e.pos.z-t.pos.z)||1,l=(t.sprint?7.2:5.2)*(e.crouch?.6:1);e.kb.x=(e.pos.x-t.pos.x)/a*l,e.kb.z=(e.pos.z-t.pos.z)/a*l,e.onGround&&(e.vel.y=5.2,e.onGround=!1),t.sprint&&(t.sprint=!1)}}damage(t,e,n,i,r=!1){if(!t.alive||t.spawnProtect>0||i==="melee"&&t.hurtT>0)return!1;let o=e*(1-Math.min(.8,t.inv.armorPoints()*.04));if(t.absorb>0&&i!=="border"){let a=Math.min(t.absorb,o);t.absorb-=a,o-=a}return t.hp-=o,t.hurtT=.45,t.lastHurt=this.time,t.regenT=0,t.eatT=0,n&&n!==t&&(t.lastAttacker=n,t.lastAttackT=this.time),this.emit({t:"hurt",a:t,by:n,cause:i,crit:r,dmg:o}),t.hp<=0&&this.kill(t,n&&n!==t?n:this.recentAttacker(t,10),i),!0}kill(t,e,n){if(t.alive){if(t.alive=!1,t.hp=0,t.deaths++,t.mine=null,e&&e!==t&&e.kills++,this.emit({t:"kill",a:t,by:e,cause:n}),n!=="void"&&this.mode.dropsOnDeath)for(let i of t.inv.all())this.spawnDrop(i.id,i.count,t.pos.x,t.pos.y+.8,t.pos.z,!0);this.mode.onDeath(t,e,n)}}use(t,e){let n=t.held(),i=this.lookActor(t,4);if(i&&i.target.npc){this.emit({t:"npc",a:t,npc:i.target});return}let r=this.lookHit(t);if(!(r&&this.mode.onUse&&this.mode.onUse(t,r))){if(r&&r.id===17){let o=this.chestAt(r.x,r.y,r.z);if(o){this.emit({t:"chest",a:t,chest:o});return}}if(n&&n.kind==="block"&&r){let o=r.x+r.nx,a=r.y+r.ny,l=r.z+r.nz;if(Yt[r.id].cross){this.place(t,r.x,r.y,r.z,n.block);return}this.place(t,o,a,l,n.block);return}n&&(n.kind==="throw"||n.kind==="warp")&&this.throwItem(t,n.id)}}place(t,e,n,i,r){if(n>=this.world.sy-1||n<1||!this.mode.canPlace(t,e,n,i)||!zd(this.world,this.actors.filter(a=>a.alive),e,n,i))return!1;let o=t.inv.slots[t.sel];return!o||o.id!==r?!1:(this.world.set(e,n,i,r,Wn),t.inv.useSlot(t.sel),t.placed++,t.swingT=.2,this.emit({t:"place",a:t,id:r,x:e,y:n,z:i}),!0)}throwItem(t,e){if(t.attackCd>0)return;t.attackCd=.3,t.swingT=.25;let n=t.eye(oi(t)),i=t.look();this.projectiles.push({id:e,owner:t,x:n.x+i.x*.5,y:n.y+i.y*.5,z:n.z+i.z*.5,vx:i.x*22,vy:i.y*22+2,vz:i.z*22,age:0}),t.inv.useSlot(t.sel),this.emit({t:"throw",a:t,id:e})}updateProjectiles(t){for(let e=this.projectiles.length-1;e>=0;e--){let n=this.projectiles[e];n.age+=t,n.vy-=18*t;let i=n.x+n.vx*t,r=n.y+n.vy*t,o=n.z+n.vz*t,a=null;for(let c of this.actors)if(!(!c.alive||c===n.owner&&n.age<.3)&&Math.abs(c.pos.x-i)<.45&&Math.abs(c.pos.z-o)<.45&&r>c.pos.y&&r<c.pos.y+Vr(c)){a=c;break}let l=Pe(this.world.get(i,r,o));if(a||l||n.age>6||r<this.map.voidY-10){if(n.id===131&&a&&this.enemies(n.owner,a)){let c=Math.hypot(n.vx,n.vz)||1;a.kb.x=n.vx/c*4.5,a.kb.z=n.vz/c*4.5,a.onGround&&(a.vel.y=3.5,a.onGround=!1),this.damage(a,.5,n.owner,"snowball")}if(n.id===132&&n.owner.alive&&(l||a)&&r>this.map.voidY){let c=n.owner,h=n.x,d=n.y,f=n.z;if(l){d=Math.floor(r)+1;for(let p=0;p<3&&this.world.boxHits(h-re,d,f-re,h+re,d+1.8,f+re);p++)d++}c.pos.x=h,c.pos.y=d,c.pos.z=f,c.vel.x=c.vel.y=c.vel.z=0,c.kb.x=c.kb.z=0,this.damage(c,2,null,"warp"),this.emit({t:"warp",a:c})}this.emit({t:"impact",id:n.id,x:n.x,y:n.y,z:n.z}),this.projectiles.splice(e,1);continue}n.x=i,n.y=r,n.z=o}}spawnDrop(t,e,n,i,r,o=!1){this.drops.length>160&&this.drops.shift();let a=this.rand()*Math.PI*2,l=o?1.6+this.rand()*1.4:0;this.drops.push({id:t,count:e,x:n,y:i,z:r,vx:Math.cos(a)*l,vy:o?4:0,vz:Math.sin(a)*l,age:0,key:Math.random()})}updateDrops(t){for(let e=this.drops.length-1;e>=0;e--){let n=this.drops[e];n.age+=t,n.vy-=20*t;let i=n.y+n.vy*t;Pe(this.world.get(n.x,i-.15,n.z))?(n.y=Math.floor(i-.15)+1.15,n.vy=0,n.vx*=.5,n.vz*=.5):n.y=i;let r=n.x+n.vx*t,o=n.z+n.vz*t;if(Pe(this.world.get(r,n.y,n.z))?n.vx=0:n.x=r,Pe(this.world.get(n.x,n.y,o))?n.vz=0:n.z=o,n.vx*=Math.pow(.3,t),n.vz*=Math.pow(.3,t),n.y<this.map.voidY-8||n.age>240){this.drops.splice(e,1);continue}if(!(n.age<.4))for(let a of this.actors){if(!a.alive)continue;let l=a.pos.x-n.x,c=a.pos.y+.6-n.y,h=a.pos.z-n.z;if(l*l+c*c+h*h<2){let d=a.inv.add(n.id,n.count);if(d<n.count&&this.emit({t:"pickup",a,id:n.id,n:n.count-d}),d)n.count=d;else{this.drops.splice(e,1);break}}}}}chestAt(t,e,n){return this.map.chests.find(i=>i.x===t&&i.y===e&&i.z===n)}takeFromChest(t,e,n){let i=e.items[n];if(!i)return!1;let r=t.inv.add(i.id,i.count);return r===i.count&&ne[i.id].kind!=="armor"?!1:(r?i.count=r:e.items.splice(n,1),this.emit({t:"pickup",a:t,id:i.id,n:i.count-r}),!0)}takeAll(t,e){let n=!1;for(let i=e.items.length-1;i>=0;i--)n=this.takeFromChest(t,e,i)||n;return e.looted=!0,n}finish(t){this.over||(this.over=!0,this.state="over",this.winner=t,this.emit({t:"over",winner:t}))}};function Xx(s){return()=>{s|=0,s=s+1831565813|0;let t=Math.imul(s^s>>>15,1|s);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}var Gr={voidRise:"The void is rising!",play:"PLAY",chooseGame:"Choose a game",skins:"Skins",settings:"Settings",howto:"How to play",back:"Back",level:"Level {n}",loading:"Loading\u2026",sky:"Sky Islands",skyDesc:"Loot your island, bridge across the sky and knock everyone into the void. Last one standing wins!",solo8:"Solo \xB7 8 players",egg:"Egg Defense",eggDesc:"Guard your team egg, buy gear with iron & gold, then go break the enemy eggs!",teams4x2:"4 teams of 2",soon:"Coming soon",race:"Block Race",raceDesc:"Parkour sprint over floating blocks.",spleef:"Spleef Arena",spleefDesc:"Dig the floor out from under your rivals.",finding:"Finding players\u2026",starting:"Starting in {n}",cancel:"Cancel",you:"You",yourTeam:"Your team: {team}",go:"GO!",alive:"{n} players left",refillIn:"Chest refill {t}",borderIn:"Border {t}",borderNow:"Border closing!",refilled:"Chests refilled!",borderMsg:"The border is closing in!",suddenIn:"Eggs crumble {t}",sudden:"Sudden death! All eggs are gone!",eggGone:"{team} egg destroyed!",yourEgg:"Your egg was destroyed!",noRespawn:"You will no longer respawn",teamOut:"{team} team eliminated!",died:"You died!",respawnIn:"Respawning in {n}",fell:"fell into the void",border:"was caught by the border",diedMsg:"died",victory:"VICTORY!",gameOver:"GAME OVER",placeOf:"You placed #{n} of {m}",teamWins:"{team} team wins!",winnerIs:"{name} wins!",kills:"Kills",reward:"Coins",xp:"XP",playAgain:"Play again",changeGame:"Change game",doubleCoins:"Double coins",spectate:"Spectate",spectating:"Spectating {name}",leave:"Leave",paused:"Paused",resume:"Resume",leaveMatch:"Leave match",clickToPlay:"Click to play",sens:"Look sensitivity",fov:"Field of view",quality:"Graphics",qAuto:"Auto",qLow:"Low",qHigh:"High",volume:"Sound",music:"Music",language:"Language",invert:"Invert look",on:"On",off:"Off",auto:"Auto",chest:"Chest",takeAll:"Take all",inventory:"Inventory",shop:"Shop",cBlocks:"Blocks",cCombat:"Combat",cArmor:"Armor",cTools:"Tools",cUtility:"Utility",wool:"Wool",chainSet:"Chain armor",ironSet:"Iron armor",diamondSet:"Diamond armor",notEnough:"Not enough",bought:"Bought!",equip:"Equip",equipped:"Equipped",levelUp:"Level up! +25 coins",kill1:"+1 kill",team_0:"Red",team_1:"Blue",team_2:"Green",team_3:"Yellow",team_4:"Purple",team_5:"Orange",team_6:"Cyan",team_7:"Pink",h1:"Move with WASD, jump with Space, sprint with Ctrl or double-tap W.",h2:"Hold Shift to sneak: you will not fall off edges, perfect for bridging.",h3:"Left click breaks blocks and attacks. Right click places blocks, opens chests and eats.",h4:"On mobile: left stick to move, drag to look, buttons to break, place and jump. Tap the world to place a block.",h5:"Sky Islands: loot your chests, build bridges to other islands, be the last one standing.",h6:"Egg Defense: collect iron and gold at your generator, buy gear from the shopkeeper and protect your egg. While your egg survives, you respawn!"},Gd={voidRise:"\xA1El vac\xEDo est\xE1 subiendo!",play:"JUGAR",chooseGame:"Elige un juego",skins:"Aspectos",settings:"Ajustes",howto:"C\xF3mo jugar",back:"Volver",level:"Nivel {n}",loading:"Cargando\u2026",sky:"Islas del Cielo",skyDesc:"Saquea tu isla, construye puentes y tira a todos al vac\xEDo. \xA1Gana el \xFAltimo en pie!",solo8:"Solo \xB7 8 jugadores",egg:"Defensa del Huevo",eggDesc:"Protege el huevo de tu equipo, compra equipo con hierro y oro y rompe los huevos rivales.",teams4x2:"4 equipos de 2",soon:"Pr\xF3ximamente",race:"Carrera de Bloques",raceDesc:"Parkour sobre bloques flotantes.",spleef:"Arena Spleef",spleefDesc:"Rompe el suelo bajo tus rivales.",finding:"Buscando jugadores\u2026",starting:"Empieza en {n}",cancel:"Cancelar",you:"T\xFA",yourTeam:"Tu equipo: {team}",go:"\xA1YA!",alive:"Quedan {n} jugadores",refillIn:"Recarga de cofres {t}",borderIn:"Borde {t}",borderNow:"\xA1El borde se cierra!",refilled:"\xA1Cofres recargados!",borderMsg:"\xA1El borde se est\xE1 cerrando!",suddenIn:"Los huevos caen {t}",sudden:"\xA1Muerte s\xFAbita! \xA1No quedan huevos!",eggGone:"\xA1Huevo {team} destruido!",yourEgg:"\xA1Tu huevo fue destruido!",noRespawn:"Ya no reaparecer\xE1s",teamOut:"\xA1Equipo {team} eliminado!",died:"\xA1Has muerto!",respawnIn:"Reapareces en {n}",fell:"cay\xF3 al vac\xEDo",border:"fue atrapado por el borde",diedMsg:"muri\xF3",victory:"\xA1VICTORIA!",gameOver:"FIN DEL JUEGO",placeOf:"Quedaste #{n} de {m}",teamWins:"\xA1Gana el equipo {team}!",winnerIs:"\xA1{name} gana!",kills:"Bajas",reward:"Monedas",xp:"XP",playAgain:"Jugar otra vez",changeGame:"Cambiar juego",doubleCoins:"Doblar monedas",spectate:"Observar",spectating:"Observando a {name}",leave:"Salir",paused:"Pausa",resume:"Continuar",leaveMatch:"Salir de la partida",clickToPlay:"Haz clic para jugar",sens:"Sensibilidad",fov:"Campo de visi\xF3n",quality:"Gr\xE1ficos",qAuto:"Auto",qLow:"Bajo",qHigh:"Alto",volume:"Sonido",music:"M\xFAsica",language:"Idioma",invert:"Invertir vista",on:"S\xED",off:"No",auto:"Auto",chest:"Cofre",takeAll:"Tomar todo",inventory:"Inventario",shop:"Tienda",cBlocks:"Bloques",cCombat:"Combate",cArmor:"Armadura",cTools:"Herramientas",cUtility:"Utilidad",wool:"Lana",chainSet:"Armadura de malla",ironSet:"Armadura de hierro",diamondSet:"Armadura de diamante",notEnough:"No alcanza",bought:"\xA1Comprado!",equip:"Usar",equipped:"En uso",levelUp:"\xA1Subiste de nivel! +25 monedas",kill1:"+1 baja",team_0:"Rojo",team_1:"Azul",team_2:"Verde",team_3:"Amarillo",team_4:"Morado",team_5:"Naranja",team_6:"Cian",team_7:"Rosa",h1:"Mu\xE9vete con WASD, salta con Espacio, corre con Ctrl o doble toque en W.",h2:"Mant\xE9n Shift para agacharte: no caer\xE1s por los bordes, ideal para construir puentes.",h3:"Clic izquierdo rompe bloques y ataca. Clic derecho coloca bloques, abre cofres y come.",h4:"En m\xF3vil: joystick para moverte, desliza para mirar y usa los botones para romper, colocar y saltar. Toca el mundo para colocar un bloque.",h5:"Islas del Cielo: saquea tus cofres, construye puentes y s\xE9 el \xFAltimo en pie.",h6:"Defensa del Huevo: junta hierro y oro en tu generador, compra equipo al tendero y protege tu huevo. \xA1Mientras viva, reapareces!"},Wd={voidRise:"O vazio est\xE1 subindo!",play:"JOGAR",chooseGame:"Escolha um jogo",skins:"Visuais",settings:"Ajustes",howto:"Como jogar",back:"Voltar",level:"N\xEDvel {n}",loading:"Carregando\u2026",sky:"Ilhas do C\xE9u",skyDesc:"Saqueie sua ilha, construa pontes e derrube todos no vazio. O \xFAltimo de p\xE9 vence!",solo8:"Solo \xB7 8 jogadores",egg:"Defesa do Ovo",eggDesc:"Proteja o ovo do seu time, compre equipamentos com ferro e ouro e quebre os ovos inimigos!",teams4x2:"4 times de 2",soon:"Em breve",race:"Corrida de Blocos",raceDesc:"Parkour sobre blocos flutuantes.",spleef:"Arena Spleef",spleefDesc:"Quebre o ch\xE3o debaixo dos rivais.",finding:"Procurando jogadores\u2026",starting:"Come\xE7a em {n}",cancel:"Cancelar",you:"Voc\xEA",yourTeam:"Seu time: {team}",go:"J\xC1!",alive:"Restam {n} jogadores",refillIn:"Ba\xFAs recarregam {t}",borderIn:"Borda {t}",borderNow:"A borda est\xE1 fechando!",refilled:"Ba\xFAs recarregados!",borderMsg:"A borda est\xE1 se fechando!",suddenIn:"Ovos caem {t}",sudden:"Morte s\xFAbita! Todos os ovos se foram!",eggGone:"Ovo {team} destru\xEDdo!",yourEgg:"Seu ovo foi destru\xEDdo!",noRespawn:"Voc\xEA n\xE3o vai mais renascer",teamOut:"Time {team} eliminado!",died:"Voc\xEA morreu!",respawnIn:"Renascendo em {n}",fell:"caiu no vazio",border:"foi pego pela borda",diedMsg:"morreu",victory:"VIT\xD3RIA!",gameOver:"FIM DE JOGO",placeOf:"Voc\xEA ficou em #{n} de {m}",teamWins:"Time {team} vence!",winnerIs:"{name} venceu!",kills:"Abates",reward:"Moedas",xp:"XP",playAgain:"Jogar de novo",changeGame:"Trocar jogo",doubleCoins:"Dobrar moedas",spectate:"Assistir",spectating:"Assistindo {name}",leave:"Sair",paused:"Pausado",resume:"Continuar",leaveMatch:"Sair da partida",clickToPlay:"Clique para jogar",sens:"Sensibilidade",fov:"Campo de vis\xE3o",quality:"Gr\xE1ficos",qAuto:"Auto",qLow:"Baixo",qHigh:"Alto",volume:"Som",music:"M\xFAsica",language:"Idioma",invert:"Inverter vis\xE3o",on:"Sim",off:"N\xE3o",auto:"Auto",chest:"Ba\xFA",takeAll:"Pegar tudo",inventory:"Invent\xE1rio",shop:"Loja",cBlocks:"Blocos",cCombat:"Combate",cArmor:"Armadura",cTools:"Ferramentas",cUtility:"Utilidades",wool:"L\xE3",chainSet:"Armadura de malha",ironSet:"Armadura de ferro",diamondSet:"Armadura de diamante",notEnough:"Insuficiente",bought:"Comprado!",equip:"Usar",equipped:"Em uso",levelUp:"Subiu de n\xEDvel! +25 moedas",kill1:"+1 abate",team_0:"Vermelho",team_1:"Azul",team_2:"Verde",team_3:"Amarelo",team_4:"Roxo",team_5:"Laranja",team_6:"Ciano",team_7:"Rosa",h1:"Mova-se com WASD, pule com Espa\xE7o, corra com Ctrl ou toque duplo no W.",h2:"Segure Shift para agachar: voc\xEA n\xE3o cai das bordas, perfeito para construir pontes.",h3:"Clique esquerdo quebra blocos e ataca. Clique direito coloca blocos, abre ba\xFAs e come.",h4:"No celular: anal\xF3gico para andar, arraste para olhar e use os bot\xF5es para quebrar, colocar e pular. Toque no mundo para colocar um bloco.",h5:"Ilhas do C\xE9u: saqueie seus ba\xFAs, construa pontes e seja o \xFAltimo de p\xE9.",h6:"Defesa do Ovo: colete ferro e ouro no gerador, compre equipamentos com o lojista e proteja seu ovo. Enquanto ele existir, voc\xEA renasce!"},qd={voidRise:"Le vide monte !",play:"JOUER",chooseGame:"Choisis un jeu",skins:"Skins",settings:"Options",howto:"Comment jouer",back:"Retour",level:"Niveau {n}",loading:"Chargement\u2026",sky:"\xCEles C\xE9lestes",skyDesc:"Pille ton \xEEle, construis des ponts et pousse tout le monde dans le vide. Le dernier debout gagne !",solo8:"Solo \xB7 8 joueurs",egg:"D\xE9fense de l\u2019\u0152uf",eggDesc:"Prot\xE8ge l\u2019\u0153uf de ton \xE9quipe, ach\xE8te de l\u2019\xE9quipement avec du fer et de l\u2019or, puis casse les \u0153ufs ennemis !",teams4x2:"4 \xE9quipes de 2",soon:"Bient\xF4t",race:"Course de Blocs",raceDesc:"Parkour sur des blocs flottants.",spleef:"Ar\xE8ne Spleef",spleefDesc:"Creuse le sol sous tes rivaux.",finding:"Recherche de joueurs\u2026",starting:"D\xE9but dans {n}",cancel:"Annuler",you:"Toi",yourTeam:"Ton \xE9quipe : {team}",go:"GO !",alive:"{n} joueurs restants",refillIn:"Recharge des coffres {t}",borderIn:"Bordure {t}",borderNow:"La bordure se resserre !",refilled:"Coffres recharg\xE9s !",borderMsg:"La bordure se resserre !",suddenIn:"Fin des \u0153ufs {t}",sudden:"Mort subite ! Plus aucun \u0153uf !",eggGone:"\u0152uf {team} d\xE9truit !",yourEgg:"Ton \u0153uf a \xE9t\xE9 d\xE9truit !",noRespawn:"Tu ne r\xE9appara\xEEtras plus",teamOut:"\xC9quipe {team} \xE9limin\xE9e !",died:"Tu es mort !",respawnIn:"R\xE9apparition dans {n}",fell:"est tomb\xE9 dans le vide",border:"a \xE9t\xE9 pris par la bordure",diedMsg:"est mort",victory:"VICTOIRE !",gameOver:"PARTIE TERMIN\xC9E",placeOf:"Tu es #{n} sur {m}",teamWins:"L\u2019\xE9quipe {team} gagne !",winnerIs:"{name} gagne !",kills:"\xC9liminations",reward:"Pi\xE8ces",xp:"XP",playAgain:"Rejouer",changeGame:"Changer de jeu",doubleCoins:"Doubler les pi\xE8ces",spectate:"Regarder",spectating:"Tu regardes {name}",leave:"Quitter",paused:"Pause",resume:"Reprendre",leaveMatch:"Quitter la partie",clickToPlay:"Clique pour jouer",sens:"Sensibilit\xE9",fov:"Champ de vision",quality:"Graphismes",qAuto:"Auto",qLow:"Bas",qHigh:"Haut",volume:"Son",music:"Musique",language:"Langue",invert:"Inverser la vue",on:"Oui",off:"Non",auto:"Auto",chest:"Coffre",takeAll:"Tout prendre",inventory:"Inventaire",shop:"Boutique",cBlocks:"Blocs",cCombat:"Combat",cArmor:"Armure",cTools:"Outils",cUtility:"Divers",wool:"Laine",chainSet:"Armure de mailles",ironSet:"Armure de fer",diamondSet:"Armure de diamant",notEnough:"Pas assez",bought:"Achet\xE9 !",equip:"Choisir",equipped:"Choisi",levelUp:"Niveau sup\xE9rieur ! +25 pi\xE8ces",kill1:"+1 \xE9limination",team_0:"Rouge",team_1:"Bleue",team_2:"Verte",team_3:"Jaune",team_4:"Violette",team_5:"Orange",team_6:"Cyan",team_7:"Rose",h1:"D\xE9place-toi avec ZQSD/WASD, saute avec Espace, cours avec Ctrl ou double appui sur avancer.",h2:"Maintiens Maj pour t\u2019accroupir : tu ne tomberas pas des bords, parfait pour construire des ponts.",h3:"Clic gauche casse les blocs et attaque. Clic droit pose des blocs, ouvre les coffres et mange.",h4:"Sur mobile : joystick pour bouger, glisse pour regarder, boutons pour casser, poser et sauter. Touche le monde pour poser un bloc.",h5:"\xCEles C\xE9lestes : pille tes coffres, construis des ponts et sois le dernier debout.",h6:"D\xE9fense de l\u2019\u0152uf : r\xE9cup\xE8re du fer et de l\u2019or au g\xE9n\xE9rateur, ach\xE8te de l\u2019\xE9quipement au marchand et prot\xE8ge ton \u0153uf. Tant qu\u2019il vit, tu r\xE9apparais !"};Object.assign(Gr,{bridge:"Bridge Battle",bridgeDesc:"Two teams, one narrow bridge. Build across, fight, and jump into the enemy portal to score.",teams2v2:"Teams \xB7 2 vs 2",goalScored:"{name} scored for {team}!",roundStarts:"Round starts in {n}",bridgeGoal:"Jump into the enemy portal \xB7 first to {n}",deathrun:"Death Run",deathrunDesc:"Run the trap course and reach the finish. One player is the Death and springs the traps.",death1v7:"1 Death vs 7 runners",runGo:"Run!",trapCooling:"That trap is recharging",finishedPlace:"{name} finished #{n}!",runnersLeft:"Runners left: {n}",youAreDeath:"You are the Death",youAreRunner:"You are a Runner",deathHint:"Walk the upper lane and press the buttons when runners pass",runnerHint:"Reach the finish and watch out for traps!",ready:"Ready",deathWins:"The Death wins!",runnersWin:"The runners escaped!",runnersEscaped:"{n} runners escaped",youDidntMakeIt:"You did not make it",trap_dropfloor:"Drop floor",trap_lava:"Lava floor",trap_door:"Door",trap_pillars:"Pillars",parkour:"Parkour",parkourDesc:"Jump across floating platforms. Play 10 solo levels or race other players.",soloRace:"Solo \xB7 Race",pkSolo:"Solo Levels",pkSoloDesc:"10 courses that get harder. Beat the par time for 3 stars.",levels10:"10 levels",parkourRace:"Parkour Race",pkRaceDesc:"Six players, one course. First to the finish wins.",players6:"6 players",newLevel:"New",time:"Time",nextLevel:"Next level",retry:"Retry",levels:"Levels",checkpointN:"Checkpoint {n}/{total}",levelN:"Level {n}",placeN:"Place {n}/{total}",par:"Par",newBest:"New best!",raceWinner:"{name} wins the race!",parkourHint:"Fall and you go back to the last checkpoint",h7:"Capture the Flag: grab the enemy flag and carry it to your own stand while your flag is home.",h8:"Bridge Battle: build across the gap and jump into the enemy portal. First team to 5 goals wins.",h9:"Death Run: runners race through the traps to the finish. The Death presses buttons on the upper lane to spring them.",h10:"Parkour: jump from platform to platform. Sprint before long jumps, and use checkpoints.",zombie:"Zombie Apocalypse",zombieDesc:"Hold out against waves of the undead with your friends.",oitc:"One In The Chamber",oitcDesc:"One shot, one kill. Make every arrow count.",survival:"Survival Games",survivalDesc:"Loot, survive and outlast everyone in a big arena.",draw:"Draw!",ctf:"Capture the Flag",ctfDesc:"Two castles, two flags. Steal the enemy flag and carry it back to your stand while yours is home.",teams4v4:"Teams \xB7 4 vs 4",ctfGoal:"Capture the enemy flag {n} times",youHaveFlag:"You have the flag! Run home!",yourFlagTaken:"Your flag was taken!",flagTaken:"{name} took the {team} flag!",flagCaptured:"{name} captured a flag for {team}!",flagDropped:"The {team} flag was dropped!",flagReturned:"The {team} flag is back home"});Object.assign(Gd,{bridge:"Batalla del Puente",bridgeDesc:"Dos equipos, un puente estrecho. Construye, pelea y salta al portal enemigo para marcar.",teams2v2:"Equipos \xB7 2 vs 2",goalScored:"\xA1{name} marc\xF3 para {team}!",roundStarts:"La ronda empieza en {n}",bridgeGoal:"Salta al portal enemigo \xB7 gana quien llegue a {n}",deathrun:"Carrera Mortal",deathrunDesc:"Recorre el circuito de trampas y llega a la meta. Un jugador es la Muerte y activa las trampas.",death1v7:"1 Muerte vs 7 corredores",runGo:"\xA1Corre!",trapCooling:"Esa trampa se est\xE1 recargando",finishedPlace:"\xA1{name} termin\xF3 #{n}!",runnersLeft:"Corredores: {n}",youAreDeath:"Eres la Muerte",youAreRunner:"Eres un Corredor",deathHint:"Recorre el pasillo superior y pulsa los botones cuando pasen los corredores",runnerHint:"\xA1Llega a la meta y cuidado con las trampas!",ready:"Lista",deathWins:"\xA1Gana la Muerte!",runnersWin:"\xA1Los corredores escaparon!",runnersEscaped:"{n} corredores escaparon",youDidntMakeIt:"No lo lograste",trap_dropfloor:"Suelo falso",trap_lava:"Suelo de lava",trap_door:"Puerta",trap_pillars:"Pilares",parkour:"Parkour",parkourDesc:"Salta entre plataformas flotantes. Juega 10 niveles solo o compite contra otros.",soloRace:"Solo \xB7 Carrera",pkSolo:"Niveles Solo",pkSoloDesc:"10 circuitos cada vez m\xE1s dif\xEDciles. Supera el tiempo par para 3 estrellas.",levels10:"10 niveles",parkourRace:"Carrera de Parkour",pkRaceDesc:"Seis jugadores, un circuito. Gana el primero en llegar.",players6:"6 jugadores",newLevel:"Nuevo",time:"Tiempo",nextLevel:"Siguiente nivel",retry:"Reintentar",levels:"Niveles",checkpointN:"Punto de control {n}/{total}",levelN:"Nivel {n}",placeN:"Puesto {n}/{total}",par:"Par",newBest:"\xA1Nuevo r\xE9cord!",raceWinner:"\xA1{name} gana la carrera!",parkourHint:"Si caes, vuelves al \xFAltimo punto de control",h7:"Captura la Bandera: toma la bandera enemiga y ll\xE9vala a tu base mientras tu bandera est\xE9 en casa.",h8:"Batalla del Puente: construye sobre el vac\xEDo y salta al portal enemigo. Gana el primer equipo con 5 goles.",h9:"Carrera Mortal: los corredores cruzan las trampas hasta la meta. La Muerte pulsa botones en el pasillo superior para activarlas.",h10:"Parkour: salta de plataforma en plataforma. Corre antes de los saltos largos y usa los puntos de control.",zombie:"Apocalipsis Zombi",zombieDesc:"Resiste oleadas de no muertos con tus amigos.",oitc:"Una en la Rec\xE1mara",oitcDesc:"Un disparo, una baja. Haz que cada flecha cuente.",survival:"Juegos de Supervivencia",survivalDesc:"Saquea, sobrevive y aguanta m\xE1s que todos en una gran arena.",draw:"\xA1Empate!",ctf:"Captura la Bandera",ctfDesc:"Dos castillos, dos banderas. Roba la bandera enemiga y ll\xE9vala a tu base mientras la tuya est\xE1 en casa.",teams4v4:"Equipos \xB7 4 vs 4",ctfGoal:"Captura la bandera enemiga {n} veces",youHaveFlag:"\xA1Tienes la bandera! \xA1Corre a casa!",yourFlagTaken:"\xA1Robaron tu bandera!",flagTaken:"\xA1{name} tom\xF3 la bandera {team}!",flagCaptured:"\xA1{name} captur\xF3 una bandera para {team}!",flagDropped:"\xA1La bandera {team} cay\xF3!",flagReturned:"La bandera {team} volvi\xF3 a casa"});Object.assign(Wd,{bridge:"Batalha da Ponte",bridgeDesc:"Dois times, uma ponte estreita. Construa, lute e pule no portal inimigo para marcar.",teams2v2:"Times \xB7 2 vs 2",goalScored:"{name} marcou para o time {team}!",roundStarts:"A rodada come\xE7a em {n}",bridgeGoal:"Pule no portal inimigo \xB7 vence quem chegar a {n}",deathrun:"Corrida Mortal",deathrunDesc:"Atravesse o circuito de armadilhas e chegue ao final. Um jogador \xE9 a Morte e ativa as armadilhas.",death1v7:"1 Morte vs 7 corredores",runGo:"Corra!",trapCooling:"Essa armadilha est\xE1 recarregando",finishedPlace:"{name} terminou em #{n}!",runnersLeft:"Corredores: {n}",youAreDeath:"Voc\xEA \xE9 a Morte",youAreRunner:"Voc\xEA \xE9 um Corredor",deathHint:"Ande pelo corredor de cima e aperte os bot\xF5es quando os corredores passarem",runnerHint:"Chegue ao final e cuidado com as armadilhas!",ready:"Pronta",deathWins:"A Morte venceu!",runnersWin:"Os corredores escaparam!",runnersEscaped:"{n} corredores escaparam",youDidntMakeIt:"Voc\xEA n\xE3o conseguiu",trap_dropfloor:"Ch\xE3o falso",trap_lava:"Ch\xE3o de lava",trap_door:"Porta",trap_pillars:"Pilares",parkour:"Parkour",parkourDesc:"Pule entre plataformas flutuantes. Jogue 10 n\xEDveis solo ou corra contra outros jogadores.",soloRace:"Solo \xB7 Corrida",pkSolo:"N\xEDveis Solo",pkSoloDesc:"10 percursos cada vez mais dif\xEDceis. Bata o tempo par para 3 estrelas.",levels10:"10 n\xEDveis",parkourRace:"Corrida de Parkour",pkRaceDesc:"Seis jogadores, um percurso. O primeiro a chegar vence.",players6:"6 jogadores",newLevel:"Novo",time:"Tempo",nextLevel:"Pr\xF3ximo n\xEDvel",retry:"Tentar de novo",levels:"N\xEDveis",checkpointN:"Checkpoint {n}/{total}",levelN:"N\xEDvel {n}",placeN:"Posi\xE7\xE3o {n}/{total}",par:"Par",newBest:"Novo recorde!",raceWinner:"{name} venceu a corrida!",parkourHint:"Se cair, voc\xEA volta ao \xFAltimo checkpoint",h7:"Capture a Bandeira: pegue a bandeira inimiga e leve at\xE9 a sua base enquanto a sua bandeira estiver em casa.",h8:"Batalha da Ponte: construa sobre o vazio e pule no portal inimigo. O primeiro time com 5 gols vence.",h9:"Corrida Mortal: os corredores passam pelas armadilhas at\xE9 o final. A Morte aperta bot\xF5es no corredor de cima para ativ\xE1-las.",h10:"Parkour: pule de plataforma em plataforma. Corra antes dos saltos longos e use os checkpoints.",zombie:"Apocalipse Zumbi",zombieDesc:"Resista a ondas de mortos-vivos com seus amigos.",oitc:"Uma na Agulha",oitcDesc:"Um tiro, um abate. Fa\xE7a cada flecha valer.",survival:"Jogos de Sobreviv\xEAncia",survivalDesc:"Saqueie, sobreviva e dure mais que todos numa grande arena.",draw:"Empate!",ctf:"Capture a Bandeira",ctfDesc:"Dois castelos, duas bandeiras. Roube a bandeira inimiga e leve at\xE9 a sua base enquanto a sua est\xE1 em casa.",teams4v4:"Times \xB7 4 vs 4",ctfGoal:"Capture a bandeira inimiga {n} vezes",youHaveFlag:"Voc\xEA est\xE1 com a bandeira! Corra para casa!",yourFlagTaken:"Roubaram sua bandeira!",flagTaken:"{name} pegou a bandeira {team}!",flagCaptured:"{name} capturou uma bandeira para o time {team}!",flagDropped:"A bandeira {team} caiu!",flagReturned:"A bandeira {team} voltou para casa"});Object.assign(qd,{bridge:"Bataille du Pont",bridgeDesc:"Deux \xE9quipes, un pont \xE9troit. Construis, combats et saute dans le portail ennemi pour marquer.",teams2v2:"\xC9quipes \xB7 2 contre 2",goalScored:"{name} a marqu\xE9 pour l\u2019\xE9quipe {team} !",roundStarts:"La manche commence dans {n}",bridgeGoal:"Saute dans le portail ennemi \xB7 premier \xE0 {n}",deathrun:"Course Mortelle",deathrunDesc:"Traverse le parcours pi\xE9g\xE9 jusqu\u2019\xE0 l\u2019arriv\xE9e. Un joueur est la Mort et d\xE9clenche les pi\xE8ges.",death1v7:"1 Mort contre 7 coureurs",runGo:"Cours !",trapCooling:"Ce pi\xE8ge se recharge",finishedPlace:"{name} a fini #{n} !",runnersLeft:"Coureurs : {n}",youAreDeath:"Tu es la Mort",youAreRunner:"Tu es un Coureur",deathHint:"Marche sur le couloir du haut et appuie sur les boutons quand les coureurs passent",runnerHint:"Atteins l\u2019arriv\xE9e et attention aux pi\xE8ges !",ready:"Pr\xEAt",deathWins:"La Mort gagne !",runnersWin:"Les coureurs se sont \xE9chapp\xE9s !",runnersEscaped:"{n} coureurs se sont \xE9chapp\xE9s",youDidntMakeIt:"Tu n\u2019as pas r\xE9ussi",trap_dropfloor:"Sol pi\xE9g\xE9",trap_lava:"Sol de lave",trap_door:"Porte",trap_pillars:"Piliers",parkour:"Parkour",parkourDesc:"Saute entre des plateformes flottantes. Joue 10 niveaux en solo ou fais la course contre d\u2019autres joueurs.",soloRace:"Solo \xB7 Course",pkSolo:"Niveaux Solo",pkSoloDesc:"10 parcours de plus en plus durs. Bats le temps de r\xE9f\xE9rence pour 3 \xE9toiles.",levels10:"10 niveaux",parkourRace:"Course de Parkour",pkRaceDesc:"Six joueurs, un parcours. Le premier \xE0 l\u2019arriv\xE9e gagne.",players6:"6 joueurs",newLevel:"Nouveau",time:"Temps",nextLevel:"Niveau suivant",retry:"R\xE9essayer",levels:"Niveaux",checkpointN:"Point de contr\xF4le {n}/{total}",levelN:"Niveau {n}",placeN:"Place {n}/{total}",par:"R\xE9f.",newBest:"Nouveau record !",raceWinner:"{name} gagne la course !",parkourHint:"Si tu tombes, tu reviens au dernier point de contr\xF4le",h7:"Capture du Drapeau : prends le drapeau ennemi et ram\xE8ne-le \xE0 ton socle pendant que le tien est \xE0 la maison.",h8:"Bataille du Pont : construis au-dessus du vide et saute dans le portail ennemi. La premi\xE8re \xE9quipe \xE0 5 buts gagne.",h9:"Course Mortelle : les coureurs traversent les pi\xE8ges jusqu\u2019\xE0 l\u2019arriv\xE9e. La Mort appuie sur des boutons dans le couloir du haut pour les d\xE9clencher.",h10:"Parkour : saute de plateforme en plateforme. Sprinte avant les grands sauts et utilise les points de contr\xF4le.",zombie:"Apocalypse Zombie",zombieDesc:"R\xE9siste aux vagues de morts-vivants avec tes amis.",oitc:"Une Seule Balle",oitcDesc:"Un tir, une \xE9limination. Chaque fl\xE8che compte.",survival:"Jeux de Survie",survivalDesc:"Pille, survis et tiens plus longtemps que tous dans une grande ar\xE8ne.",draw:"\xC9galit\xE9 !",ctf:"Capture du Drapeau",ctfDesc:"Deux ch\xE2teaux, deux drapeaux. Vole le drapeau ennemi et ram\xE8ne-le \xE0 ton socle pendant que le tien est \xE0 la maison.",teams4v4:"\xC9quipes \xB7 4 contre 4",ctfGoal:"Capture le drapeau ennemi {n} fois",youHaveFlag:"Tu as le drapeau ! Cours \xE0 ta base !",yourFlagTaken:"Ton drapeau a \xE9t\xE9 vol\xE9 !",flagTaken:"{name} a pris le drapeau {team} !",flagCaptured:"{name} a captur\xE9 un drapeau pour l\u2019\xE9quipe {team} !",flagDropped:"Le drapeau {team} est tomb\xE9 !",flagReturned:"Le drapeau {team} est rentr\xE9"});var Vd={en:Gr,es:Gd,pt:Wd,fr:qd},Xd={en:"English",es:"Espa\xF1ol",pt:"Portugu\xEAs",fr:"Fran\xE7ais"},$d=Gr;function Yd(s){return $d=Vd[s]||Gr,Vd[s]?s:"en"}function k(s,t){let e=$d[s]??Gr[s]??s;if(t)for(let n in t)e=e.replace(`{${n}}`,t[n]);return e}var pn=s=>(s=Math.max(0,Math.ceil(s)),`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`),Ne=s=>k("team_"+s),Ys=s=>Gt[s]?Gt[s].hex:"#ffffff";function hl(s,t,e){let n=s.over&&s.winner===t.team,i=s.winner==null?k("draw"):n?k("teamWins",{team:Ne(t.team)}):k("teamWins",{team:Ne(s.winner)});return{win:n,rank:n?1:2,total:2,sub:e?`${i} \xB7 ${e}`:i}}function Ti(s,t){s.inv.clear();for(let[e,n]of t)s.inv.add(e,n);s.sel=0}function ai(s,t,e=2){s.reset(),s.alive=!0,s.eliminated=!1,s.pos.x=t.x,s.pos.y=t.y,s.pos.z=t.z,s.yaw=t.yaw??s.yaw,s.pitch=-.08,s.spawnProtect=e}var ul=(s,t)=>t[Math.floor(s()*t.length)],li=(s,t,e)=>t+Math.floor(s()*(e-t+1));function Zs(s,t){return Ws(ul(s,t),Math.floor(s()*4))}function $x(s,t,e=!1){let n=[],i=(r,o=1)=>n.push({id:r,count:o});t==="spawn"?(i(ul(s,[5,5,4,3]),li(s,14,24)),(e||s()<.45)&&i(s()<.6?101:100),(e||s()<.55)&&i(Zs(s,[0,0,1])),s()<.45&&i(Zs(s,[0,1,1,2])),s()<.4&&i(131,li(s,4,8)),s()<.35&&i(133,li(s,1,3)),s()<.25&&i(111),s()<.12&&i(130),s()<.12&&i(102)):t==="satellite"?(i(ul(s,[5,4,3]),li(s,12,20)),i(Zs(s,[1,2,2])),s()<.5&&i(Zs(s,[2,2,3])),s()<.45&&i(102),s()<.5&&i(130),s()<.3&&i(132),s()<.4&&i(131,li(s,6,12))):(i(ul(s,[5,4,3]),li(s,20,32)),i(Zs(s,[2,3,3])),s()<.65&&i(Zs(s,[2,3])),s()<.55&&i(s()<.5?103:102),s()<.75&&i(130,li(s,1,2)),s()<.5&&i(132,li(s,1,2)),s()<.35&&i(112),s()<.4&&i(131,li(s,8,16)));for(let r=n.length-1;r>0;r--){let o=Math.floor(s()*(r+1));[n[r],n[o]]=[n[o],n[r]]}return n}var dl=class{constructor(){this.id="sky",this.dropsOnDeath=!0,this.refillAt=180,this.borderAt=300,this.borderDur=120,this.refilled=!1,this.cages=[],this.ranks=[]}attach(t){this.m=t,this.radius=t.map.radius,this.border=this.radius,this.fillChests(!1)}fillChests(t){let e=this.m.rand,n=new Set;for(let i of this.m.map.chests){let r=i.group??`${Math.round(i.x/12)},${Math.round(i.z/12)}`,o=!n.has(r);n.add(r);let a=$x(e,i.tier,o&&i.tier==="spawn"&&!t);i.items=t?[...i.items,...a].slice(0,12):a,i.looted=!1}}setup(t){let e=this.m.map.spawns;t.forEach((n,i)=>{let r=e[i%e.length];n.pos.x=r.x,n.pos.y=r.y,n.pos.z=r.z,n.yaw=r.yaw,n.pitch=-.15,n.spawn=r,n.home=r,this.cage(Math.floor(r.x),Math.floor(r.y),Math.floor(r.z),!0)})}cage(t,e,n,i){let r=this.m.world;for(let o=e;o<=e+2;o++)for(let[a,l]of[[1,0],[-1,0],[0,1],[0,-1]])(i?!r.get(t+a,o,n+l):r.get(t+a,o,n+l)===12)&&r.set(t+a,o,n+l,i?12:0,2);(i?!r.get(t,e+2,n):r.get(t,e+2,n)===12)&&r.set(t,e+2,n,i?12:0,2),i&&this.cages.push([t,e,n])}start(){for(let[t,e,n]of this.cages)this.cage(t,e,n,!1);this.cages=[];for(let t of this.m.actors)t.spawnProtect=3}update(t){let e=this.m;if(!this.refilled&&e.time>=this.refillAt&&(this.refilled=!0,this.fillChests(!0),e.emit({t:"refill"})),e.time>=this.borderAt){let i=Math.min(1,(e.time-this.borderAt)/this.borderDur);if(this.border=this.radius+(6-this.radius)*i,this.borderWarned||(this.borderWarned=!0,e.emit({t:"border"})),this.borderTick=(this.borderTick||0)+t,this.borderTick>1){this.borderTick=0;for(let r of e.actors)r.alive&&Math.hypot(r.pos.x,r.pos.z)>this.border&&e.damage(r,1.5,e.recentAttacker(r,10),"border")}}e.time>=this.borderAt+this.borderDur-20&&(this.rising||(this.rising=!0,this.voidBase=e.map.voidY,e.emit({t:"voidrise"})),e.map.voidY=Math.min(e.map.top+6,e.map.voidY+t*.3));let n=e.actors.filter(i=>i.alive);n.length<=1&&!e.over&&(n[0]&&(n[0].rank=1),e.finish(n[0]||null))}canBreak(t,e,n,i,r){return!Yt[r].unbreakable&&r!==17&&Math.hypot(e,i)<this.radius+6}canPlace(t,e,n,i){return Math.hypot(e+.5,i+.5)<this.radius+4&&n>2}dropFor(t){return t===1?2:t===7||t>=40&&t<=43||t===12||t===11?0:t===10?10:t}onBreak(){}onDeath(t){t.eliminated=!0,t.rank=this.m.actors.filter(e=>e.alive).length+1}respawn(){}hud(t){let e=this.info(),n=[{text:k("alive",{n:e.alive}),b:!0}];return e.refillIn>0&&n.push({text:k("refillIn",{t:pn(e.refillIn)})}),n.push(e.rising?{text:k("voidRise"),cls:"warn"}:e.borderIn>0?{text:k("borderIn",{t:pn(e.borderIn)})}:{text:k("borderNow"),cls:"warn"}),{lines:n}}result(t){let e=this.m,n=e.over&&e.winner===t,i=e.actors.length,r=n?1:t.rank||e.actors.filter(o=>o.alive).length+1;return{win:n,rank:r,total:i,sub:k("placeOf",{n:r,m:i})}}winnerText(t){return t?k("winnerIs",{name:t.name}):k("gameOver")}info(){let t=this.m;return{rising:!!this.rising,alive:t.actors.filter(e=>e.alive).length,total:t.actors.length,refillIn:this.refilled?0:Math.max(0,this.refillAt-t.time),borderIn:Math.max(0,this.borderAt-t.time),border:this.border}}};var Js=(s,t,e,n)=>e>=0&&e<s.sy&&t+s.ox>=0&&t+s.ox<s.sx&&n+s.oz>=0&&n+s.oz<s.sz?s.data[(e*s.sz+(n+s.oz))*s.sx+(t+s.ox)]:0,Dn=(s,t,e,n)=>{let i=Js(s,t,e-1,n);return ci[i]===1&&i!==45&&!ci[Js(s,t,e,n)]&&!ci[Js(s,t,e+1,n)]};function kn(s,t,e,n,i=6){for(let r=e;r>e-i;r--)if(Dn(s,t,r,n))return r;return null}var sh=class{constructor(){this.a=[]}push(t){let e=this.a;e.push(t);let n=e.length-1;for(;n>0;){let i=n-1>>1;if(e[i].f<=e[n].f)break;[e[i],e[n]]=[e[n],e[i]],n=i}}pop(){let t=this.a,e=t[0],n=t.pop();if(t.length){t[0]=n;let i=0;for(;;){let r=i*2+1,o=r+1,a=i;if(r<t.length&&t[r].f<t[a].f&&(a=r),o<t.length&&t[o].f<t[a].f&&(a=o),a===i)break;[t[a],t[i]]=[t[i],t[a]],i=a}}return e}get size(){return this.a.length}},Yx=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];function rh(s,t,e,n,i,r,o,a={}){let l=a.limit||2400,c=a.near??0,h=(_,M,A)=>((M+4)*(s.sz+8)+(A+s.oz+4))*(s.sx+8)+(_+s.ox+4),d=(_,M,A)=>Math.hypot(_-i,A-o)+Math.abs(M-r)*.6,f=new sh,p=new Map,m={x:t,y:e,z:n,g:0,f:d(t,e,n),p:null};f.push(m),p.set(h(t,e,n),0);let x=m,g=0;for(;f.size&&g++<l;){let _=f.pop();if(Math.abs(_.x-i)<=c&&Math.abs(_.z-o)<=c&&Math.abs(_.y-r)<=Math.max(1,c)){x=_;break}d(_.x,_.y,_.z)<d(x.x,x.y,x.z)&&(x=_);for(let[M,A]of Yx){let b=_.x+M,T=_.z+A;if(M&&A&&!(Dn(s,_.x+M,_.y,_.z)&&Dn(s,_.x,_.y,_.z+A)))continue;let I=null,y=M&&A?1.414:1;if(Dn(s,b,_.y,T))I=_.y;else if(!M||!A){if(Dn(s,b,_.y+1,T)&&!ci[Js(s,_.x,_.y+2,_.z)])I=_.y+1,y+=.8;else if(!ci[Js(s,b,_.y,T)]&&!ci[Js(s,b,_.y+1,T)]){for(let L=1;L<=3;L++)if(Dn(s,b,_.y-L,T)){I=_.y-L,y+=L*.3;break}}}if(I==null)continue;let w=h(b,I,T),C=_.g+y;p.has(w)&&p.get(w)<=C||(p.set(w,C),f.push({x:b,y:I,z:T,g:C,f:C+d(b,I,T),p:_}))}}let u=Math.abs(x.x-i)<=Math.max(c,0)&&Math.abs(x.z-o)<=Math.max(c,0)&&Math.abs(x.y-r)<=Math.max(1,c),v=[];for(let _=x;_;_=_.p)v.push({x:_.x,y:_.y,z:_.z});return v.reverse(),{path:v,reached:u,end:x}}function Zd(s,t,e,n){let i=[],r=s,o=t,a=Math.abs(e-s)||1,l=Math.abs(n-t)||1;for(;i.length<200&&(r!==e||o!==n);){let c=Math.abs(e-r)/a,h=Math.abs(n-o)/l;r!==e&&(c>=h||o===n)?r+=Math.sign(e-r):o+=Math.sign(n-o),i.push([r,o])}return i}var fl=[{id:"wool",cat:"blocks",give:[["wool",16]],cost:[170,4]},{id:"planks",cat:"blocks",give:[[5,16]],cost:[170,10]},{id:"stone",cat:"blocks",give:[[3,12]],cost:[171,3]},{id:"obsidian",cat:"blocks",give:[[13,2]],cost:[172,2]},{id:"stone_sword",cat:"combat",give:[[101,1]],cost:[170,12]},{id:"iron_sword",cat:"combat",give:[[102,1]],cost:[171,6]},{id:"diamond_sword",cat:"combat",give:[[103,1]],cost:[172,4]},{id:"chain_set",cat:"armor",give:[0,1,2,3].map(s=>[Ws(1,s),1]),cost:[170,28]},{id:"iron_set",cat:"armor",give:[0,1,2,3].map(s=>[Ws(2,s),1]),cost:[171,14]},{id:"diamond_set",cat:"armor",give:[0,1,2,3].map(s=>[Ws(3,s),1]),cost:[172,8]},{id:"stone_pick",cat:"tools",give:[[111,1]],cost:[170,10]},{id:"iron_pick",cat:"tools",give:[[112,1]],cost:[171,4]},{id:"shears",cat:"tools",give:[[180,1]],cost:[170,16]},{id:"gapple",cat:"utility",give:[[130,1]],cost:[171,3]},{id:"snowball",cat:"utility",give:[[131,4]],cost:[170,6]},{id:"orb",cat:"utility",give:[[132,1]],cost:[172,3]}],pl=class{constructor(){this.id="egg",this.dropsOnDeath=!1,this.suddenAt=360,this.timeLimit=540}attach(t){this.m=t,this.radius=t.map.radius,this.border=this.radius,this.teams=t.map.teams.map(e=>({...e,eggAlive:!0,out:!1}));for(let e of t.map.gens)e.t=Math.random()*e.every;t.npcs=t.map.npcs}setup(t){t.forEach(e=>{this.respawnAt(e),e.home=this.teams[e.team].spawn})}teamWool(t){return Gt[t.team].wool}kit(t){t.inv.clear(),t.inv.add(100,1),t.inv.add(110,1),t.sel=0}respawnAt(t){let e=this.teams[t.team],n=e.spawn;t.reset(),t.alive=!0,t.pos.x=n.x+(Math.random()-.5)*1.5,t.pos.y=n.y,t.pos.z=n.z+(Math.random()-.5)*1.5,t.yaw=Math.atan2(n.x,n.z),t.pitch=-.1,t.spawnProtect=3,this.kit(t)}start(){this.m.emit({t:"eggstart"})}update(t){let e=this.m;for(let i of e.map.gens){if(i.t+=t,i.t<i.every)continue;i.t=0;let r=0;for(let o of e.drops)o.id===i.item&&Math.abs(o.x-i.x-.5)<1.5&&Math.abs(o.z-i.z-.5)<1.5&&(r+=o.count);r<i.cap&&e.spawnDrop(i.item,1,i.x+.5,i.y+1.3,i.z+.5)}if(!this.sudden&&e.time>=this.suddenAt){this.sudden=!0;for(let i of this.teams)i.eggAlive&&this.breakEgg(i,null);e.emit({t:"sudden"})}for(let i of this.teams){if(i.out)continue;let r=e.actors.filter(o=>o.team===i.i);if(!i.eggAlive&&r.every(o=>!o.alive)){i.out=!0,e.emit({t:"teamout",team:i.i});for(let o of r)o.rank=this.teams.filter(a=>!a.out).length+1}}let n=this.teams.filter(i=>!i.out);if(n.length<=1&&!e.over){for(let i of e.actors)n[0]&&i.team===n[0].i&&(i.rank=1);e.finish(n[0]?n[0].i:null)}if(e.time>=this.timeLimit&&!e.over){let i=o=>e.actors.filter(a=>a.team===o.i&&a.alive).length*100+e.actors.filter(a=>a.team===o.i).reduce((a,l)=>a+l.kills,0),r=n.sort((o,a)=>i(a)-i(o))[0];e.finish(r?r.i:null)}}breakEgg(t,e){t.eggAlive&&(t.eggAlive=!1,e&&(e.eggs=(e.eggs||0)+1),this.m.world.get(t.egg.x,t.egg.y,t.egg.z)===45&&this.m.world.set(t.egg.x,t.egg.y,t.egg.z,0),this.m.emit({t:"egg",team:t.i,by:e}))}canBreak(t,e,n,i,r){if(r===45){let o=this.teams.find(a=>a.egg.x===e&&a.egg.y===n&&a.egg.z===i);return!!o&&o.i!==t.team&&o.eggAlive}return this.m.world.flag(e,n,i)===Wn}canPlace(t,e,n,i){if(Math.hypot(e,i)>this.radius)return!1;for(let r of this.teams)if(Math.abs(e-r.egg.x)<=0&&Math.abs(i-r.egg.z)<=0&&n>=r.egg.y&&n<=r.egg.y)return!1;for(let r of this.m.map.gens)if(e===r.x&&i===r.z&&n===r.y+1)return!1;return n>2}dropFor(t){return t===45?0:t}onBreak(t,e,n,i,r){if(r===45){let o=this.teams.find(a=>a.egg.x===e&&a.egg.y===n&&a.egg.z===i);o&&this.breakEgg(o,t)}}onDeath(t,e,n){let i=this.m;if(n!=="void")for(let o of t.inv.all())ne[o.id].kind==="currency"&&i.spawnDrop(o.id,o.count,t.pos.x,t.pos.y+.8,t.pos.z,!0);if(e&&e.alive)for(let o of t.inv.all())ne[o.id].kind==="currency"&&n==="void"&&e.inv.add(o.id,o.count);this.teams[t.team].eggAlive?(t.respawnT=5,i.emit({t:"respawning",a:t})):t.eliminated=!0}respawn(t){this.teams[t.team].eggAlive&&(this.respawnAt(t),this.m.emit({t:"respawn",a:t}))}canBuy(t,e){return t.inv.count(e.cost[0])>=e.cost[1]}buy(t,e){let n=fl.find(i=>i.id===e);if(!n||!this.canBuy(t,n))return!1;t.inv.take(n.cost[0],n.cost[1]);for(let[i,r]of n.give)t.inv.add(i==="wool"?this.teamWool(t):i,r);return this.m.emit({t:"buy",a:t,id:e}),!0}nearShop(t){return this.m.npcs.find(e=>e.team===t.team&&Math.hypot(e.x-t.pos.x,e.z-t.pos.z)<3.6&&Math.abs(e.y-t.pos.y)<2)}hud(t){let e=this.info(),n=[];return e.suddenIn>0&&n.push({text:k("suddenIn",{t:pn(e.suddenIn)})}),{lines:n,cur:!0,chips:e.teams.map(i=>({color:Ys(i.i),icon:i.egg?"egg":"eggGone",label:i.out?"\u2715":String(i.alive),dim:i.out,mine:i.i===t.team}))}}result(t){let e=this.m,n=e.over&&e.winner===t.team,i=this.teams.length,r=n?1:t.rank||this.teams.filter(a=>!a.out).length,o=t.eggs||0;return{win:n,rank:r,total:i,sub:n?k("teamWins",{team:Ne(t.team)}):k("placeOf",{n:r,m:i}),coins:o*15,xp:o*20}}winnerText(t){return t!=null?k("teamWins",{team:Ne(t)}):k("gameOver")}startTitle(t){return k("yourTeam",{team:Ne(t.team)})}info(){return{teams:this.teams.map(t=>({i:t.i,egg:t.eggAlive,out:t.out,alive:this.m.actors.filter(e=>e.team===t.i&&e.alive).length})),suddenIn:Math.max(0,this.suddenAt-this.m.time)}}botPlan(t,e){let n=t.a,i=this.m,r=t.ctlObj,o=this.teams[n.team];t.role||(t.role=i.actors.filter(u=>u.team===n.team).indexOf(n)===0&&Math.random()<.6?"defend":"rush");let a=this.nearShop(n);a&&this.botShop(t);let l=n.inv.count(170),c=n.inv.count(171),h=i.npcs.find(u=>u.team===n.team),d=Math.hypot(o.spawn.x-n.pos.x,o.spawn.z-n.pos.z)<11&&Math.abs(o.spawn.y-n.pos.y)<3,f=n.inv.blocks()>=16&&n.inv.slots.some(u=>u&&u.id>=101&&u.id<=103),p=fl.some(u=>this.wanted(n,u.id)&&this.canBuy(n,u));if(d&&p&&!a)return t.goTo(Math.floor(h.x),h.y,Math.floor(h.z),e,1,!1),r;if(d&&(!f||t.role==="defend"&&!this.botGeared(n))&&i.time<600){let u=i.map.gens.find(v=>v.team===n.team&&v.item===(l<16||c>=6?170:171));return u&&Math.hypot(u.x+.5-n.pos.x,u.z+.5-n.pos.z)>.6?(t.steerOrPath(u.x,u.y+1,u.z,e),r):(r.mx=r.mz=0,t.aimAt(o.center.x,n.pos.y+1,o.center.z,e*.3),r)}if(n.inv.blocks()<4&&!d&&t.giveUp(e))return r;if(t.role==="defend"&&o.eggAlive&&i.time<420){let u=o.egg;return t.dist({x:u.x,y:u.y,z:u.z})>4?t.goTo(u.x,u.y-1,u.z-1,e,2,!1):t.wander(e),r}let m=this.teams.filter(u=>u.i!==n.team&&!u.out);if(!m.length)return r;(!t.eggTarget||t.eggTarget.out||!t.eggTarget.eggAlive&&Math.random()<.01)&&(t.eggTarget=m.sort((u,v)=>v.eggAlive-u.eggAlive||Math.hypot(u.egg.x-n.pos.x,u.egg.z-n.pos.z)-Math.hypot(v.egg.x-n.pos.x,v.egg.z-n.pos.z))[0]);let x=t.eggTarget;if(x.eggAlive){let u=x.egg;if(Math.hypot(u.x+.5-n.pos.x,u.z+.5-n.pos.z)<2.6&&Math.abs(u.y-n.pos.y)<3){r.mx=r.mz=0,t.aimAt(u.x+.5,u.y+.5,u.z+.5,e)<.3&&(r.attack=!0,t.selectKind("pick")||t.selectKind("sword"));let A=this.coverOf(u);return A&&t.aimAt(A.x+.5,A.y+.5,A.z+.5,e)<.3&&(r.attack=!0),r}let _=kn(i.world,u.x+1,u.y,u.z,4)??u.y-1;return t.goTo(u.x+1,_,u.z,e,1),r}let g=i.actors.filter(u=>u.alive&&u.team===x.i).sort((u,v)=>t.dist(u.pos)-t.dist(v.pos))[0];if(g){let u={x:Math.floor(g.pos.x),y:Math.floor(g.pos.y),z:Math.floor(g.pos.z)};t.goTo(u.x,kn(i.world,u.x,u.y,u.z,6)??u.y,u.z,e,1)}return r}coverOf(t){let e=this.m.world;for(let[n,i,r]of[[0,1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]])if(e.flag(t.x+n,t.y+i,t.z+r)===Wn)return{x:t.x+n,y:t.y+i,z:t.z+r};return null}wanted(t,e){return e==="wool"?t.inv.blocks()<24:e==="stone_sword"?!t.inv.slots.some(n=>n&&n.id>=101&&n.id<=103):e==="iron_sword"?!t.inv.slots.some(n=>n&&n.id>=102&&n.id<=103):e==="diamond_sword"?!t.inv.slots.some(n=>n&&n.id===103):e==="chain_set"?t.inv.armorPoints()<12:e==="iron_set"?t.inv.armorPoints()<15:e==="diamond_set"?t.inv.armorPoints()<20:e==="gapple"?t.inv.count(130)<1:!1}botGeared(t){return t.inv.armorPoints()>=12&&t.inv.best("sword")>=0&&t.inv.slots.some(e=>e&&e.id>=101&&e.id<=103)}botShop(t){let e=t.a;for(let n of["wool","stone_sword","iron_sword","diamond_sword","diamond_set","iron_set","chain_set","gapple"])this.wanted(e,n)&&this.buy(e,n);t.equip()}};var Jd=(s,t,e=1.4,n=2.2)=>Math.hypot(s.pos.x-t.x-.5,s.pos.z-t.z-.5)<e&&Math.abs(s.pos.y-t.y)<n,ml=class{constructor(){this.id="ctf",this.dropsOnDeath=!1,this.target=3,this.timeLimit=480}attach(t){this.m=t,this.radius=t.map.radius,this.teams=t.map.teams.map(e=>({...e,score:0,flag:{team:e.i,state:"home",x:e.stand.x,y:e.stand.y,z:e.stand.z,carrier:null,dropT:0}})),this.flags=this.teams.map(e=>e.flag)}setup(t){let e=[0,0];for(let n of t)n.slot=e[n.team]++,this.respawnAt(n)}respawnAt(t){let e=this.teams[t.team],n=e.spawns[t.slot%e.spawns.length];ai(t,n,3),t.respawnCount=(t.respawnCount||0)+1,Ti(t,[[101,1],[110,1],[Gt[t.team].wool,32],[130,1]]),t.carrying=null,t.speedMul=1,t.home={x:e.stand.x+.5,z:e.stand.z+.5+(e.i,0)}}start(){}notice(t,e,n){this.m.emit({t:"notice",text:t,cls:e,sound:n})}home(t){t.state="home",t.carrier=null,t.x=this.teams[t.team].stand.x,t.y=this.teams[t.team].stand.y,t.z=this.teams[t.team].stand.z}drop(t,e){t.state="dropped",t.carrier=null,t.dropT=15;let n=kn(this.m.world,Math.floor(e.pos.x),Math.floor(e.pos.y+.5),Math.floor(e.pos.z),12);if(n==null||e.pos.y<this.m.map.voidY+2){this.home(t),this.notice(k("flagReturned",{team:Ne(t.team)}),"","beep");return}t.x=Math.floor(e.pos.x),t.y=n,t.z=Math.floor(e.pos.z),e.carrying=null,e.speedMul=1,this.notice(k("flagDropped",{team:Ne(t.team)}),"","beep")}update(t){let e=this.m;for(let n of this.flags)if(n.state==="carried"){let i=n.carrier;if(!i.alive){this.drop(n,i);continue}n.x=i.pos.x-.5,n.y=i.pos.y,n.z=i.pos.z-.5;let r=this.teams[i.team];r.flag.state==="home"&&Jd(i,r.stand,1.8,2.5)&&(r.score++,i.caps=(i.caps||0)+1,i.carrying=null,i.speedMul=1,this.home(n),e.emit({t:"notice",text:k("flagCaptured",{team:Ne(i.team),name:i.name}),cls:"gold",sound:"win",big:!0,team:i.team}),r.score>=this.target&&e.finish(i.team))}else n.state==="dropped"&&(n.dropT-=t,n.dropT<=0&&(this.home(n),this.notice(k("flagReturned",{team:Ne(n.team)}),"","beep")));for(let n of e.actors)if(!(!n.alive||n.spawnProtect>2.5))for(let i of this.flags)i.state!=="carried"&&Jd(n,{x:i.x,y:i.y,z:i.z})&&(i.team!==n.team&&!n.carrying?(i.state="carried",i.carrier=n,n.carrying=i,n.speedMul=1,e.emit({t:"notice",text:k("flagTaken",{team:Ne(i.team),name:n.name}),cls:"bad",sound:"egg",team:i.team})):i.team===n.team&&i.state==="dropped"&&(this.home(i),this.notice(k("flagReturned",{team:Ne(i.team)}),"","beep")));if(e.time>=this.timeLimit&&!e.over){let[n,i]=this.teams,r=a=>e.actors.filter(l=>l.team===a).reduce((l,c)=>l+c.kills,0),o=n.score-i.score||r(0)-r(1);e.finish(o===0?null:o>0?0:1)}}canBreak(t,e,n,i){return this.m.world.flag(e,n,i)===Wn}canPlace(t,e,n,i){for(let r of this.teams){if(Math.abs(e-r.stand.x)<=1&&Math.abs(i-r.stand.z)<=1&&n>=r.stand.y-1&&n<=r.stand.y+2)return!1;for(let o of r.spawns)if(Math.abs(e+.5-o.x)<1&&Math.abs(i+.5-o.z)<1&&Math.abs(n-o.y)<2)return!1}return n>3&&Math.abs(e)<96&&Math.abs(i)<64}dropFor(t){return t}onBreak(){}onDeath(t){t.carrying&&this.drop(t.carrying,t),t.respawnT=5,this.m.emit({t:"respawning",a:t})}respawn(t){this.respawnAt(t),this.m.emit({t:"respawn",a:t})}hud(t){let e=[{text:pn(this.timeLimit-this.m.time)}];return t.carrying&&e.push({text:k("youHaveFlag"),cls:"gold"}),this.teams[t.team].flag.state==="carried"&&e.push({text:k("yourFlagTaken"),cls:"warn"}),{lines:e,chips:this.teams.map(i=>({color:Ys(i.i),icon:i.flag.state==="home"?"flag":"flagGone",label:String(i.score),big:!0,mine:i.i===t.team}))}}result(t){let e=hl(this.m,t,`${this.teams[0].score} - ${this.teams[1].score}`);return e.coins=(t.caps||0)*20,e.xp=(t.caps||0)*30,e}winnerText(t){return t==null?k("draw"):k("teamWins",{team:Ne(t)})}startTitle(t){return k("yourTeam",{team:Ne(t.team)})}startSub(){return k("ctfGoal",{n:this.target})}botEngage(t,e){let n=t.a;if(n.carrying)return e.d<2.5;if(e.o.carrying&&e.o.carrying.team===n.team)return!0;let i=this.m.time-n.lastHurt<2.5;if(t.role==="attack")return i||e.d<3&&t.brave>.65||t.dist(this.teams[1-n.team].stand)<14;let r=this.teams[n.team].stand;return i||Math.hypot(e.o.pos.x-r.x,e.o.pos.z-r.z)<18}botPlan(t,e){let n=t.a,i=this.m,r=t.ctlObj,o=this.teams[n.team],a=this.teams[1-n.team];t.role||(t.role=n.slot===0?"defend":"attack");let l=(c,h,d,f=1)=>{let p=kn(i.world,Math.floor(c),Math.floor(h)+1,Math.floor(d),8);return t.goTo(Math.floor(c),p??Math.floor(h),Math.floor(d),e,f),r};if(n.carrying)return l(o.stand.x,o.stand.y,o.stand.z,0);if(o.flag.state==="carried"&&(t.role==="defend"||t.dist(o.flag.carrier.pos)<40)){let c=o.flag.carrier;return l(c.pos.x,c.pos.y,c.pos.z,1)}if(o.flag.state==="dropped")return l(o.flag.x,o.flag.y,o.flag.z,0);if(t.role==="defend")return t.dist({x:o.stand.x,y:o.stand.y,z:o.stand.z})>7?l(o.stand.x,o.stand.y,o.stand.z+2,2):(t.wander(e),r);if(a.flag.state==="carried"){let c=a.flag.carrier;if(c.team===n.team)return l(c.pos.x,c.pos.y,c.pos.z,2)}if(t.routeAt!==n.respawnCount&&(t.routeAt=n.respawnCount,t.route=n.slot===1||Math.random()<.3?null:{x:0,y:i.map.top+1,z:(n.slot%2?1:-1)*34}),t.route)if(t.dist(t.route)<5||t.path&&!t.pathReached&&!t.bridge)t.route=null;else return l(t.route.x,t.route.y,t.route.z,2);return l(a.flag.x,a.flag.y,a.flag.z,0)}};function jd(s,t={}){let e=t.theme||"meadow",n=Ln[t.style||"castle"],i=es[e],r=new en(192,64,128),o=nn(s),a=ts(s),l=30,c=62,h={world:r,theme:e,top:l,voidY:4,center:{x:0,y:l+1,z:0},radius:100,chests:[],spawns:[],teams:[],npcs:[]};for(let p=0;p<2;p++){let m=p?1:-1,x=m*c,g=dn(r,a,x,0,l,14,i,{depth:12,rough:.25,flat:!0}),u=new Ke(r,x,l,0,[-m,0]),v=Gt[p];u.foundation(-11,-11,11,11,n.path,n.wall),u.box(-9,0,-9,9,0,9,n.floor);for(let A=1;A<=4;A++)for(let b=-9;b<=9;b++)for(let T=-9;T<=9;T++)(Math.abs(T)===9||Math.abs(b)===9)&&u.set(T,A,b,A===4?(T+b)%2?v.wool:0:A===3?v.wool:o()<.2?n.wall2:n.wall);for(let[A,b]of[[0,9],[9,0],[-9,0]])for(let T=-1;T<=1;T++)for(let I=1;I<=3;I++)u.set(A||T,I,b||T,0);for(let[A,b]of[[-9,-9],[9,-9],[-9,9],[9,9]])u.box(A-Math.sign(A),1,b-Math.sign(b),A,7,b,n.pillar),u.box(A-Math.sign(A),8,b-Math.sign(b),A,8,b,v.wool),u.set(A,9,b,n.light);u.box(-3,1,-8,3,1,-5,n.wall2),u.box(-2,2,-8,2,2,-6,n.floor);let _=u.pos(0,3,-7);u.set(0,2,-7,62),u.box(-3,2,-8,-3,5,-8,n.pillar),u.box(3,2,-8,3,5,-8,n.pillar),u.box(-3,6,-8,3,6,-8,v.wool);for(let[A,b]of[[-6,4],[6,4],[-6,-3],[6,-3]])u.box(A,1,b,A,2,b,n.wall2);ns(u,-7,6),ns(u,6,6),yn(u,n,-4,1,7),yn(u,n,4,1,7),fn(r,o,g,i,.08,3,(A,b)=>Math.max(Math.abs(A-x),Math.abs(b))>12);let M=[];for(let A=0;A<4;A++){let b=u.pos(-3+A*2,1,3);M.push({x:b.x+.5,y:l+1,z:b.z+.5,yaw:Math.atan2(m,0),team:p})}h.spawns.push(...M),h.teams.push({i:p,color:v,stand:{x:_.x,y:_.y,z:_.z},spawns:M,center:{x,z:0},front:{x:x-m*11,z:0}})}let d=dn(r,a,0,0,l,11,i,{depth:12,rough:.35,flat:!0}),f=new Ke(r,0,l,0,[1,0]);f.foundation(-5,-5,5,5,n.path,n.wall),Xs(f,n,0,0);for(let[p,m]of[[-4,-4],[4,-4],[-4,4],[4,4]])f.box(p,1,m,p,3,m,n.wall2),f.set(p,4,m,n.light);fn(r,o,d,i,.12,3,(p,m)=>Math.max(Math.abs(p),Math.abs(m))>6&&Math.abs(m)>4&&Math.abs(p)>3);for(let p of[-1,1]){let m=p*36,x=dn(r,a,0,m,l,8,i,{depth:9,rough:.35,flat:!0}),g=new Ke(r,0,l,m,[0,-p]);p<0?ll(g,n,h.chests,o):qs(g,n,0,0,0,6),fn(r,o,x,i,.12,2,(u,v)=>Math.hypot(u,v-m)>4);for(let u of[-1,1])wi(r,n,u*50,p*9,u*7,m-p*4,l,.25,o)}for(let p of[-1,1])wi(r,n,p*49,0,p*10,0,l,0,o);return h.chests.length=0,h}var Zx=(s,t)=>Math.floor(t.pos.x)>=s.x0&&Math.floor(t.pos.x)<=s.x1&&Math.floor(t.pos.z)>=s.z0&&Math.floor(t.pos.z)<=s.z1&&t.pos.y<s.y+.95&&t.pos.y>s.y-4,gl=class{constructor(){this.id="bridge",this.dropsOnDeath=!1,this.target=5,this.timeLimit=600,this.freezeT=0}attach(t){this.m=t,this.teams=t.map.teams.map(e=>({...e,score:0})),this.radius=t.map.radius}setup(t){let e=[0,0];for(let n of t)n.slot=e[n.team]++,this.respawnAt(n);this.freezeT=0}respawnAt(t){let e=this.teams[t.team],n=e.spawns[t.slot%e.spawns.length];ai(t,n,1.5),Ti(t,[[101,1],[110,1],[Gt[t.team].wool,64],[130,2]]),t.home={x:e.center.x,z:0}}start(){}resetRound(){for(let t of this.m.actors)this.respawnAt(t),t.spawnProtect=3.2;this.freezeT=3}update(t){let e=this.m;if(this.freezeT>0){this.freezeT-=t;for(let n of e.actors){let i=this.teams[n.team].spawns[n.slot%2];n.pos.x=i.x,n.pos.z=i.z,n.pos.y<i.y&&(n.pos.y=i.y),n.vel.x=n.vel.z=0,n.kb.x=n.kb.z=0}this.freezeT<=0&&e.emit({t:"notice",text:k("go"),cls:"kill",sound:"hi"});return}for(let n of e.actors)if(n.alive)for(let i of this.teams){if(!Zx(i.goal,n))continue;if(i.i===n.team){this.respawnAt(n);continue}let r=this.teams[n.team];if(r.score++,n.goals=(n.goals||0)+1,e.emit({t:"notice",text:k("goalScored",{name:n.name,team:Ne(n.team)}),cls:"gold",sound:"win",big:!0,team:n.team}),r.score>=this.target){e.finish(n.team);return}this.resetRound();return}if(e.time>=this.timeLimit&&!e.over){let[n,i]=this.teams,r=a=>e.actors.filter(l=>l.team===a).reduce((l,c)=>l+c.kills,0),o=n.score-i.score||r(0)-r(1);e.finish(o===0?null:o>0?0:1)}}canBreak(t,e,n,i){return this.m.world.flag(e,n,i)===Wn}canPlace(t,e,n,i){if(this.freezeT>0)return!1;let r=this.m.map.top;if(n>r+7||n<r-6)return!1;for(let o of this.teams){let a=o.goal;if(e>=a.x0-1&&e<=a.x1+1&&i>=a.z0-1&&i<=a.z1+1&&n>=a.y-4)return!1;for(let l of o.spawns)if(Math.abs(e+.5-l.x)<2&&Math.abs(i+.5-l.z)<2)return!1}return Math.abs(i)<22}dropFor(t){return t}onBreak(){}onDeath(t){t.respawnT=.6}respawn(t){this.respawnAt(t),this.m.emit({t:"respawn",a:t})}hud(){let t=[{text:pn(this.timeLimit-this.m.time)}];return this.freezeT>0&&t.push({text:k("roundStarts",{n:Math.ceil(this.freezeT)}),cls:"gold"}),{lines:t,chips:this.teams.map(e=>({color:Ys(e.i),label:`${e.score}/${this.target}`,big:!0}))}}result(t){let e=hl(this.m,t,`${this.teams[0].score} - ${this.teams[1].score}`);return e.coins=(t.goals||0)*15,e.xp=(t.goals||0)*25,e}winnerText(t){return t==null?k("draw"):k("teamWins",{team:Ne(t)})}startTitle(t){return k("yourTeam",{team:Ne(t.team)})}startSub(){return k("bridgeGoal",{n:this.target})}botEngage(t,e){let n=t.a;return t.role==="defend"?!0:e.d<4||this.m.time-n.lastHurt<2.5}botPlan(t,e){let n=t.a,i=this.m,r=t.ctlObj;if(this.freezeT>0)return r;t.role||(t.role=n.slot===0?"attack":Math.random()<.5?"defend":"attack");let o=this.teams[n.team],a=this.teams[1-n.team],l=i.map.top;if(t.role==="defend"){let p=o.goal.x+Math.sign(-o.goal.x)*3;return Math.hypot(n.pos.x-p-.5,n.pos.z-.5)>2.5?t.goTo(p,l+1,0,e,1,!1):(r.mx=r.mz=0,t.aimAt(0,l+1.6,0,e*.4)),r}let c=a.goal,h=Math.sign(c.x),d=c.x-h*3,f=Math.hypot(n.pos.x-c.x-.5,n.pos.z-.5);return f<4.5&&Math.abs(n.pos.y-(l+1))<1.5?(t.steer(c.x+.5,.5,e,!0,!0),n.onGround&&f>2&&(r.jump=!0),r):(t.goTo(d,l+1,0,e,1),r)}};function Kd(s,t={}){let e=Ln[t.style||"castle"],n=new en(112,64,48),i=nn(s),r=30,o=(c,h,d,f)=>n.set(c,h,d,f,f?ge:0,!0),a=(c,h,d,f,p,m,x)=>{for(let g=Math.min(h,p);g<=Math.max(h,p);g++)for(let u=Math.min(d,m);u<=Math.max(d,m);u++)for(let v=Math.min(c,f);v<=Math.max(c,f);v++)o(v,g,u,x)},l={world:n,theme:t.theme||"meadow",top:r,voidY:r-14,center:{x:0,y:r+1,z:0},radius:50,chests:[],spawns:[],teams:[],npcs:[]};for(let c=0;c<2;c++){let h=c?1:-1,d=Gt[c],f=h*21,p=h*40;for(let u=Math.min(f,p);u<=Math.max(f,p);u++)for(let v=-9;v<=9;v++){let _=Math.abs(v)===9||u===f||u===p,M=Math.abs(u-h*30)+Math.abs(v)*.8;o(u,r,v,_?e.wall:(u+v)%7===0?d.wool:e.floor);let A=Math.max(1,6-Math.floor(M/4)+Math.floor(i()*2));for(let b=r-1;b>=r-A;b--)o(u,b,v,b===r-1?e.wall:e.wall2)}for(let u=-9;u<=9;u++)for(let v of[f,p])(Math.abs(u)>2||v===p)&&o(v,r+1,u,(u+v)%2?e.wall:d.wool);for(let u=Math.min(f,p);u<=Math.max(f,p);u++)for(let v of[-9,9])o(u,r+1,v,u%2?e.wall:d.wool);for(let[u,v]of[[f,-9],[f,9],[p,-9],[p,9]])a(u,r+1,v,u,r+4,v,e.pillar),o(u,r+5,v,d.wool),o(u,r+6,v,e.light);let m=h*27;a(m-2,r,-2,m+2,r,2,e.trim),a(m-1,r-3,-1,m+1,r,1,57);for(let u=r-4;u>r-8;u--)a(m-1,u,-1,m+1,u,1,0);let x=h*36;a(x-1,r+1,-3,x+1,r+1,3,0),a(x+h*2,r+1,-4,x+h*2,r+3,4,e.wall),a(x+h*2,r+4,-4,x+h*2,r+4,4,d.wool);for(let u of[-6,6])a(h*32,r+1,u,h*32,r+2,u,e.wall2);let g=[];for(let u=0;u<2;u++)g.push({x:x+.5,y:r+1,z:(u?2:-2)+.5,yaw:Math.atan2(h,0),team:c});l.spawns.push(...g),l.teams.push({i:c,color:d,goal:{x:m,y:r,z:0,x0:m-1,x1:m+1,z0:-1,z1:1},spawns:g,center:{x:h*30,z:0}})}for(let c=-20;c<=20;c++)if(o(c,r,0,Math.abs(c)%6===0?e.trim:e.floor),Math.abs(c)<=2)for(let h=-2;h<=2;h++)o(c,r,h,e.floor);a(-2,r-1,-2,2,r-4,2,e.wall);for(let c of[-2,2])for(let h of[-2,2])o(h,r+1,c,e.wall2),o(h,r+2,c,e.light);return l}var Jx={dropfloor:0,lava:66,door:47,pillars:0},jx={dropfloor:2.4,lava:3,door:3.5,pillars:2.4},xl=class{constructor(t={}){Yr(this,"hudInCountdown",!0);this.id="deathrun",this.dropsOnDeath=!1,this.noPvp=!0,this.noFall=!1,this.timeLimit=300,this.cooldown=7,this.ctx=t}attach(t){this.m=t,this.traps=t.map.traps.map(e=>({...e,active:0,cd:0})),this.radius=t.map.radius,this.finishers=[]}setup(t){let e=!(this.ctx.save&&this.ctx.save.played&&this.ctx.save.played.deathrun),n=t.findIndex(o=>!o.bot),i=Math.floor(Math.random()*t.length);n>=0&&(e||Math.random()<.875)&&i===n&&(i=(i+1)%t.length),this.death=t[i];let r=0;for(let o of t)o.team=o===this.death?1:0,o===this.death?(ai(o,this.m.map.deathSpawn,0),o.role="death"):(ai(o,this.m.map.runnerSpawns[r++%8],0),o.role="runner"),Ti(o,[]),o.finished=0,o.home={x:o.pos.x,z:o.pos.z}}allied(){return!0}start(){for(let[t,e,n]of this.m.map.gate)this.m.world.set(t,e,n,0);this.m.emit({t:"notice",text:k("runGo"),cls:"kill",sound:"hi"})}trigger(t,e){let n=this.traps[t];if(!n||n.cd>0||this.m.state!=="play")return!1;n.active=jx[n.kind],n.cd=this.cooldown;let i=Jx[n.kind];for(let[r,o,a]of n.cells)this.m.world.set(r,o,a,i);return this.m.emit({t:"trap",i:t,by:e,x:(n.x0+n.x1)/2,y:this.m.map.top,z:0}),!0}onUse(t,e){if(t!==this.death||e.id!==60)return!1;let n=this.traps.find(i=>i.button.x===e.x&&i.button.z===e.z);return n&&(this.trigger(n.i,t)||this.m.emit({t:"notice",text:k("trapCooling"),cls:"bad"})),!0}update(t){let e=this.m,n=e.world;for(let o of this.traps)if(o.cd>0&&(o.cd-=t),o.active>0&&(o.active-=t,o.active<=0))for(let[a,l,c,h]of o.cells)n.set(a,l,c,h);for(let o of e.actors){if(!o.alive||o.role!=="runner"||o.finished)continue;n.get(Math.floor(o.pos.x),Math.floor(o.pos.y-.05),Math.floor(o.pos.z))===66&&o.onGround&&e.damage(o,20,this.death,"trap");let l=n.get(Math.floor(o.pos.x),Math.floor(o.pos.y+.05),Math.floor(o.pos.z)),c=e.map.finish;(l===59||o.pos.x>=c.x&&Math.abs(o.pos.z)<5&&Math.abs(o.pos.y-c.y)<3)&&(o.finished=this.finishers.length+1,this.finishers.push(o),o.rank=o.finished,e.emit({t:"notice",text:k("finishedPlace",{name:o.name,n:o.finished}),cls:"gold",sound:o.local?"win":"hi",team:o.local?0:-1,big:!!o.local}),o.alive=!1,o.eliminated=!0)}let r=e.actors.filter(o=>o.role==="runner").filter(o=>o.alive&&!o.finished);!e.over&&(!r.length||e.time>=this.timeLimit)&&e.finish(this.finishers.length?0:1)}canBreak(){return!1}canPlace(){return!1}dropFor(){return 0}onBreak(){}onDeath(t){t.eliminated=!0,t.role==="runner"&&(t.rank=0)}respawn(){}hud(t){let e=this.m,n=e.actors.filter(r=>r.role==="runner"&&r.alive&&!r.finished).length,i=[{text:pn(this.timeLimit-e.time)},{text:k("runnersLeft",{n}),b:!0}];if(t.role==="death"){i.unshift({text:k("youAreDeath"),cls:"warn"});let r=this.traps.filter(o=>Math.abs(o.button.x+.5-t.pos.x)<14).slice(0,3);for(let o of r)i.push({text:`${k("trap_"+o.kind)}: ${o.cd>0?Math.ceil(o.cd)+"s":k("ready")}`,cls:o.cd>0?"":"gold"})}else t.finished&&i.push({text:k("finishedPlace",{name:t.name,n:t.finished}),cls:"gold"});return{lines:i}}result(t){let e=this.m;if(t.role==="death"){let i=this.finishers.length===0;return{win:i,rank:i?1:2,total:2,sub:i?k("deathWins"):k("runnersEscaped",{n:this.finishers.length}),coins:e.actors.filter(r=>r.role==="runner"&&!r.finished).length*4}}let n=!!t.finished;return{win:n,rank:n?t.finished:e.actors.length,total:e.actors.length-1,sub:n?k("finishedPlace",{name:t.name,n:t.finished}):k("youDidntMakeIt"),coins:n?Math.max(0,30-t.finished*5):0,save:i=>{i.played=i.played||{},i.played.deathrun=(i.played.deathrun||0)+1}}}winnerText(t){return t===1?k("deathWins"):k("runnersWin")}startTitle(t){return t.role==="death"?k("youAreDeath"):k("youAreRunner")}startSub(t){return t.role==="death"?k("deathHint"):k("runnerHint")}botPlan(t,e){let n=t.a,i=this.m,r=t.ctlObj;if(n.role==="runner")return t.rI==null&&(t.rI=0,t.waitT=.3+Math.random()*3.2),t.followRoute(i.map.route,e),r;let o=i.actors.filter(f=>f.role==="runner"&&f.alive&&!f.finished);if(!o.length)return r.mx=r.mz=0,r;let a=o.reduce((f,p)=>p.pos.x>f.pos.x?p:f),l=this.traps.find(f=>f.cd<=0&&o.some(p=>p.pos.x>=f.x0-.5&&p.pos.x<=f.x1+1))||this.traps.find(f=>f.x1>=a.pos.x-2)||this.traps[this.traps.length-1],c=l.button.x+.5,h=c-n.pos.x;return Math.abs(h)>1.2?(r.mx=Math.sign(h),r.mz=(i.map.lane.z+.5-n.pos.z)*.8,r.sprint=Math.abs(h)>4,r.yaw=h>0?-Math.PI/2:Math.PI/2,r.pitch=-.2,t.pressT=0,r):(r.mx=r.mz=0,t.aimAt(c,l.button.y+.1,l.button.z+.5,e),o.filter(f=>f.pos.x>=l.x0-.5&&f.pos.x<=l.x1+1).length&&l.cd<=0&&(t.pressT=(t.pressT||0)+e,t.pressT>.6+(1-t.skill)*1.2+Math.random()*.6&&(this.trigger(l.i,n),t.pressT=0)),r)}};var Kx=["run","dropfloor","gaps","lava","beam","door","stairs","pillars","gaps","dropfloor","bounce","lava","run","beam","door","stairs","pillars","gaps","dropfloor","beam","bounce","lava","run","door","pillars","gaps","lava"];function Qd(s,t={}){let e=Ln[t.style||"castle"],n=nn(s),i=new en(336,64,40),r=30,o=r+5,a=(T,I,y,w)=>i.set(T,I,y,w,w?ge:0,!0),l=(T,I,y,w,C,L,B)=>{for(let H=Math.min(I,C);H<=Math.max(I,C);H++)for(let G=Math.min(y,L);G<=Math.max(y,L);G++)for(let X=Math.min(T,w);X<=Math.max(T,w);X++)a(X,H,G,B)},c=[],h=[],d=(T,I,y=0,w={})=>c.push({x:T,y:I,z:y,...w}),f=(T,I=r,y=e.floor)=>{for(let w=-3;w<=3;w++)a(T,I,w,Math.abs(w)===3?e.trim:y);a(T,I-1,0,e.wall)},p=(T,I,y=r)=>{for(let w=T;w<=I;w++)for(let C of[-4,4])a(w,y,C,e.wall),a(w,y+1,C,w%3===0?e.wall2:e.wall)},m=-160;l(m-6,r,-4,m+2,r,4,e.floor),l(m-7,r+1,-5,m+3,r+4,-5,e.wall),l(m-7,r+1,5,m+3,r+4,5,e.wall),l(m-7,r+1,-5,m-7,r+4,5,e.wall),l(m-7,r+5,-5,m+3,r+5,5,e.floor),l(m+3,r+1,-4,m+3,r+3,4,12);let x=[];for(let T=-4;T<=4;T++)for(let I=r+1;I<=r+3;I++)x.push([m+3,I,T]);let g=[];for(let T=0;T<8;T++)g.push({x:m-4+T%4*1.6+.5,y:r+1,z:-2.5+Math.floor(T/4)*4+.5,yaw:-Math.PI/2});let u=m+3,v=r;for(let T=m+3;T<m+6;T++)f(T);d(m+5,r+1),u=m+6;for(let T of Kx){let I=u;if(T==="run"){for(let y=0;y<6;y++)f(u+y,v);p(u,u+5,v+1),d(u+5,v+1),u+=6}else if(T==="gaps"){for(let y=0;y<4;y++)f(u,v),f(u+1,v),d(u+1,v+1,0,{jump:y>0}),u+=y<3?4:2;f(u,v),f(u+1,v),d(u+1,v+1,0,{jump:!0}),u+=2}else if(T==="beam"){f(u,v),u+=1;let y=10,w=3+Math.floor(n()*4);for(let C=0;C<y;C++)C!==w&&(a(u+C,v,0,e.trim),a(u+C,v-1,0,e.wall));for(let C=0;C<y;C+=1)C!==w&&d(u+C,v+1,0,{tight:!0,jump:C===w+1});u+=y,f(u,v),d(u,v+1),u+=1}else if(T==="stairs"){for(let y=0;y<3;y++)f(u,v),d(u,v+1),u++,v++;for(let y=0;y<3;y++)f(u,v),u++;d(u-1,v+1);for(let y=0;y<3;y++)v--,f(u,v),u++;d(u-1,v+1)}else if(T==="bounce"){f(u,v),f(u+1,v);for(let y=-1;y<=1;y++)a(u+1,v,y,61);d(u-1,v+1),u+=5,v+=1;for(let y=0;y<4;y++)f(u+y,v);d(u+2,v+1,0,{jump:!0}),u+=4;for(let y=0;y<2;y++)f(u+y,v);u+=2,v-=1,f(u,v),d(u,v+1),u+=1}else{let y={i:h.length,kind:T,x0:I,cells:[],active:0,cd:0};if(T==="dropfloor"){let C=n()<.5?1:0;for(let L=0;L<8;L++)for(let B=-3;B<=3;B++)a(u+L,v,B,63),(L+C)%2===0&&y.cells.push([u+L,v,B,63]);p(u,u+7,v+1),d(u+4,v+1),u+=8,f(u,v),d(u,v+1),u+=1}else if(T==="lava"){for(let C=0;C<9;C++){f(u+C,v);for(let L=-2;L<=2;L++)(C+Math.floor(n()*2))%3!==1&&y.cells.push([u+C,v,L,e.floor])}p(u,u+8,v+1),d(u+4,v+1),d(u+8,v+1),u+=9}else if(T==="door"){for(let L=0;L<5;L++)f(u+L,v);p(u,u+4,v+1);let C=Math.floor(n()*3)-1;for(let L=-3;L<=3;L++)for(let B=v+1;B<=v+3;B++)Math.abs(L-C)<=1?y.cells.push([u+2,B,L,0]):a(u+2,B,L,e.wall);for(let L=-3;L<=3;L++)a(u+2,v+4,L,e.wall2);d(u+1,v+1,C),d(u+3,v+1,C),d(u+4,v+1),u+=5}else if(T==="pillars"){f(u,v),u+=1;for(let C=0;C<4;C++){let L=C%2?1:-1;u+=1;for(let[B,H]of[[0,0],[1,0],[0,1],[1,1]]){a(u+B,v,L+H-1,e.wall2),C%2===s%2&&y.cells.push([u+B,v,L+H-1,e.wall2]);for(let G=v-1;G>v-5;G--)a(u+B,G,L+H-1,e.wall)}d(u,v+1,L>0?0:-1,{jump:!0}),u+=2}u+=1,f(u,v),f(u+1,v),d(u+1,v+1,0,{jump:!0}),u+=2}y.x1=u-1;let w=Math.round((y.x0+y.x1)/2);y.button={x:w,y:o+1,z:-8},h.push(y)}if(u-I>0){let y=Math.round((I+u-1)/2);for(let w of[-5,5])if(n()<.6&&!i.get(y,v+1,w)){for(let C=v-2;C<=v;C++)a(y,C,w,e.wall);a(y,v+1,w,e.light)}}}for(let T=0;T<8;T++)f(u+T,v);for(let T=-2;T<=2;T++)a(u+3,v+1,T,59);l(u+7,v+1,-4,u+7,v+4,4,e.wall);for(let T=-4;T<=4;T++)a(u+7,v+5,T,T%2?14:e.trim);d(u+5,v+1);let _={x:u+3,y:v+1,x1:u+3},M=m-2,A=u+6;l(M,o,-10,A,o,-6,e.floor),l(M,o-1,-8,A,o-1,-8,e.wall);for(let T=M;T<=A;T++)if(a(T,o+1,-10,e.wall),a(T,o+2,-10,T%4?e.wall:e.light),a(T,o+1,-6,54),a(T,o+2,-6,54),a(T,o+3,-6,e.wall),a(T,o+3,-10,e.wall),T%8===0)for(let I=r-6;I<o-1;I++)a(T,I,-8,e.pillar);for(let T of[-9,-8,-7])a(M,o+1,T,e.wall),a(A,o+1,T,e.wall);for(let T of h)a(T.button.x,o,-8,e.wall2),a(T.button.x,o+1,T.button.z,60);let b={x:M+2.5,y:o+1,z:-7.5,yaw:-Math.PI/2};return{world:i,theme:t.theme||"meadow",top:r,voidY:r-10,center:{x:0,y:r+1,z:0},radius:170,chests:[],spawns:g,runnerSpawns:g,deathSpawn:b,traps:h,route:c,finish:_,gate:x,lane:{y:o+1,z:-8,x0:M+1,x1:A-1}}}var is=s=>{let t=Math.floor(s/60),e=s-t*60;return`${t}:${e.toFixed(2).padStart(5,"0")}`},Qx=(s,t)=>s<=t?3:s<=t*1.4?2:1,Wr=class{constructor(t={}){Yr(this,"hudInCountdown",!0);this.solo=!!t.solo,this.id=this.solo?"parkour":"race",this.ctx=t,this.dropsOnDeath=!1,this.noPvp=!0,this.noFall=!0,this.hideBar=!0,this.timeLimit=this.solo?0:240}attach(t){this.m=t;let e=t.map;this.radius=e.radius,this.realVoid=e.voidY,e.voidY=-1e3;let n=e.checkpoints,i=e.route;this.cps=n.map((a,l)=>{let c=l+1<n.length?n[l+1].i:i.length,h=a.y;for(let d=a.i;d<=Math.min(c+1,i.length-1);d++)h=Math.min(h,i[d].y);return{...a,fallY:h-5}});let r=1/0,o=-1/0;for(let a of i)r=Math.min(r,a.x),o=Math.max(o,a.x);this.lowX0=r-8,this.low=new Float32Array(o-r+17).fill(1e9);for(let a of i)for(let l=a.x-6;l<=a.x+6;l++){let c=l-this.lowX0;c>=0&&c<this.low.length&&(this.low[c]=Math.min(this.low[c],a.y-5))}this.finishers=[],this.firstFinishT=0}fallY(t){let e=Math.floor(t.pos.x)-this.lowX0,n=e>=0&&e<this.low.length?this.low[e]:1e9;return n<1e8?Math.min(n,this.cps[t.cp].fallY):this.cps[t.cp].fallY}setup(t){let e=this.m.map.start;t.forEach((n,i)=>{let r=this.solo?0:(i%3-1)*1.4,o=this.solo?0:-Math.floor(i/3)*1.3;ai(n,{x:e.x+o,y:e.y,z:e.z+r,yaw:e.yaw},0),Ti(n,[]),n.team=0,n.cp=0,n.finished=0,n.finishT=0,n.falls=0,n.role="runner"})}allied(){return!0}start(){this.m.emit({t:"notice",text:k("runGo"),cls:"kill",sound:"hi"})}toCheckpoint(t){let e=this.cps[t.cp];if(t.pos.x=e.x,t.pos.y=e.y,t.pos.z=e.z,t.vel.x=t.vel.y=t.vel.z=0,t.kb&&(t.kb.x=t.kb.z=0),t.yaw=-Math.PI/2,t.falls++,t._bot){let n=t._bot;n.rI=e.i,n.waitT=.35+Math.random()*.4,n.lastTight=!1,n.slip=null}t.local&&this.m.emit({t:"cpback",a:t})}update(t){let e=this.m,n=e.world,i=e.map.finish;for(let o of e.actors){if(!o.alive||o.finished)continue;for(let c=o.cp+1;c<this.cps.length;c++){let h=this.cps[c];Math.abs(h.x-o.pos.x)<1.6&&Math.abs(h.z-o.pos.z)<1.6&&Math.abs(h.y-o.pos.y)<1.2&&(o.cp=c,o.local&&e.emit({t:"notice",text:k("checkpointN",{n:c,total:this.cps.length-1}),cls:"gold",sound:"hi"}))}let l=n.get(Math.floor(o.pos.x),Math.floor(o.pos.y+.05),Math.floor(o.pos.z))===59||o.pos.x>=i.x-.2&&Math.abs(o.pos.y-i.y)<2&&Math.abs(o.pos.z-i.z)<3;if(!l&&(o.pos.y<this.fallY(o)||o.pos.y<this.realVoid)){this.toCheckpoint(o);continue}l&&(o.finished=this.finishers.length+1,o.finishT=e.time,this.finishers.push(o),o.rank=o.finished,this.firstFinishT||(this.firstFinishT=e.time),this.solo?e.emit({t:"notice",text:is(e.time),cls:"gold",sound:"win",team:0,big:!0}):e.emit({t:"notice",text:k("finishedPlace",{name:o.name,n:o.finished}),cls:"gold",sound:o.local?"win":"hi",team:o.local?0:-1,big:!!o.local}))}if(e.over)return;if(this.solo){this.finishers.length&&e.finish(0);return}(!e.actors.some(o=>!o.finished)||e.time>=this.timeLimit||this.firstFinishT&&e.time-this.firstFinishT>30)&&e.finish(this.finishers.length?0:-1)}canBreak(){return!1}canPlace(){return!1}dropFor(){return 0}onBreak(){}onDeath(t){t.alive=!0,t.hp=t.maxHp,this.toCheckpoint(t)}respawn(){}standings(){return this.m.actors.slice().sort((t,e)=>t.finished&&e.finished?t.finished-e.finished:t.finished?-1:e.finished?1:e.pos.x-t.pos.x)}place(t){return this.standings().indexOf(t)+1}hud(t){let e=this.m,n=this.cps.length-1,i=[{text:this.solo?is(t.finished?t.finishT:e.time):pn(this.timeLimit-e.time),b:!0}];return this.solo?i.unshift({text:k("levelN",{n:e.map.level}),cls:"gold"}):i.push({text:k("placeN",{n:this.place(t),total:e.actors.length}),cls:"gold"}),i.push({text:k("checkpointN",{n:t.cp,total:n})}),this.solo&&i.push({text:`${k("par")} ${is(e.map.par)}`}),{lines:i}}result(t){let e=this.m,n=e.map.level;if(this.solo){let o=!!t.finished,a=t.finishT,l=o?Qx(a,e.map.par):0,c=this.ctx.save&&this.ctx.save.parkour||{},h=c.best&&c.best[n],d=!(c.stars&&c.stars[n]),f=o&&(!h||a<h);return{win:o,rank:1,total:1,stars:l,time:a,level:n,next:o&&n<10?n+1:0,sub:o?`${k("levelN",{n})} \xB7 ${is(a)}${f&&h?" \xB7 "+k("newBest"):""}`:k("levelN",{n}),coins:o?l*6+(d?20:0):0,xp:o?n*10:0,save:p=>{if(!o)return;let m=p.parkour=p.parkour||{best:{},stars:{},unlocked:1};(!m.best[n]||a<m.best[n])&&(m.best[n]=a),m.stars[n]=Math.max(m.stars[n]||0,l),m.unlocked=Math.max(m.unlocked||1,Math.min(10,n+1))}}}let i=this.place(t);return{win:t.finished===1,rank:i,total:e.actors.length,time:t.finished?t.finishT:0,sub:t.finished?k("finishedPlace",{name:t.name,n:t.finished}):k("placeN",{n:i,total:e.actors.length}),coins:Math.max(0,(7-i)*4)}}winnerText(){let t=this.finishers[0];return t?k("raceWinner",{name:t.name}):k("gameOver")}startTitle(){return this.solo?k("levelN",{n:this.m.map.level}):k("parkourRace")}startSub(){return k("parkourHint")}botPlan(t,e){let n=t.a,i=t.ctlObj;if(n._bot=t,n.finished)return i.mx=i.mz=0,i.jump=!1,i;t.rI==null&&(t.rI=0,t.waitT=.1+Math.random()*.8);let r=t.rI;return t.followRoute(this.m.map.route,e),t.rI!==r&&Math.random()<(1-t.skill)*.55&&(t.waitT=.15+Math.random()*(.9-t.skill*.5)),i}};var tf=[[38,31],[47,48],[64,51],[30,33],[9,65],[32,36],[52,14],[34,37],[21,22],[13,66]];function oh(s,t={}){let e=Math.max(1,Math.min(10,t.level||1)),n=nn(s*101+e*7),i=t.jumps||14+e*3,r=new en(i>50?400:240,80,64),o=(b,T,I,y)=>r.set(b,T,I,y,y?ge:0,!0),[a,l]=tf[(e-1)%tf.length],c=[],h=[],d=(b,T,I,y,w)=>{let C=Math.floor((y-1)/2);for(let L=-C;L<=y-1-C;L++)for(let B=-C;B<=y-1-C;B++)o(b+B,T,I+L,w)},f=i>50?-190:-110,p=24,m=0;d(f,p,m,5,l);for(let b=-2;b<=2;b++)o(f-2,p+1,b,12);let x={x:f+.5,y:p+1,z:m+.5,yaw:-Math.PI/2};h.push({x:f+.5,y:p+1,z:m+.5,i:0}),c.push({x:f+2,y:p+1,z:m}),f+=2;let g=0,u=p,v=5,_=e>=7?3:2;for(let b=0;b<i;b++){let T=n(),I="jump";e>=4&&T<.12?I="bounce":e>=3&&T<.3?I="up":T<.42&&(I="down");let y=e<=2?3:e<=5?n()<.5?2:3:e<=8?n()<.5?1:2:1,w=1+Math.floor(n()*_);(y===1||v===1)&&(w=Math.min(w,2));let C=0;I==="up"&&(C=1,w=e>=8&&n()<.4&&y>1&&v>1?2:1),I==="down"&&(C=-1-(n()<.3?1:0)),I==="bounce"&&(C=2,w=2),p+C>60&&(C=-1,I="down"),p+C<8&&(C=1,w=1,I="up");let L=w>=3||I==="up"&&w>=2||I==="bounce"?0:Math.floor(n()*3)-1;(w>=2&&y===1||I==="up"&&(y===1||v===1))&&(L=0),I==="bounce"&&(f+=1,o(f,p,m,61),c.push({x:f-1,y:p+1,z:m}));let B=Math.floor((y-1)/2);f+=w+1+B,m=Math.max(-24,Math.min(24,m+L)),p+=C,u=Math.min(u,p);let H=g>=6&&b<i-2;H?(d(f,p,m,3,l),o(f,p+1,m,58),h.push({x:f+.5,y:p+1,z:m+.5,i:c.length}),g=0):(d(f,p,m,y,b%4===3?l:a),g++),c.push({x:f,y:p+1,z:m,jump:!0,tight:y===1&&!H}),f+=y-1-B,v=H?3:y}f+=3,d(f,p,m,5,14);for(let b=-2;b<=2;b++)o(f,p+1,m+b,59);for(let[b,T]of[[-2,-2],[2,-2],[-2,2],[2,2]]){for(let I=1;I<=3;I++)o(f+b,p+I,m+T,51);o(f+b,p+4,m+T,27)}c.push({x:f,y:p+1,z:m,jump:!0}),c.push({x:f+1,y:p+1,z:m});let M={x:f,y:p+1,z:m},A=Math.round(c.length*.85+4);return{world:r,theme:t.theme||"meadow",top:p,voidY:u-8,center:{x:0,y:30,z:0},radius:120,chests:[],spawns:[x],start:x,checkpoints:h,route:c,finish:M,par:A,level:e}}var Ei={sky:{make:()=>new dl,build:s=>$s(s.seed,s.theme,8,s)},egg:{make:()=>new pl,build:s=>zr(s.seed,s.theme,4,s)},ctf:{make:()=>new ml,build:s=>jd(s.seed,s)},bridge:{make:()=>new gl,build:s=>Kd(s.seed,s)},deathrun:{make:s=>new xl(s),build:s=>Qd(s.seed,s)},race:{make:s=>new Wr(s),build:s=>oh(s.seed,s)},parkour:{make:s=>new Wr({...s,solo:!0}),build:s=>oh(s.level,s)}};var ah=class{constructor(t=9){this.slots=Array.from({length:t},()=>null),this.armor=[0,0,0,0]}count(t){let e=0;for(let n of this.slots)n&&n.id===t&&(e+=n.count);return e}add(t,e=1){let n=ne[t];if(!n)return e;if(n.kind==="armor"){if(!this.armor[n.slot]||ne[this.armor[n.slot]].points<n.points)return this.armor[n.slot]=t,0;if(this.armor[n.slot]===t||ne[this.armor[n.slot]].points>=n.points)return 0}for(let i of this.slots)if(i&&i.id===t&&i.count<n.stack){let r=Math.min(e,n.stack-i.count);if(i.count+=r,e-=r,!e)return 0}for(let i=0;i<this.slots.length&&e>0;i++)if(!this.slots[i]){let r=Math.min(e,n.stack);this.slots[i]={id:t,count:r},e-=r}return e}take(t,e=1){if(this.count(t)<e)return!1;for(let n=this.slots.length-1;n>=0&&e>0;n--){let i=this.slots[n];if(i&&i.id===t){let r=Math.min(e,i.count);i.count-=r,e-=r,i.count||(this.slots[n]=null)}}return!0}useSlot(t,e=1){let n=this.slots[t];n&&(n.count-=e,n.count<=0&&(this.slots[t]=null))}armorPoints(){let t=0;for(let e of this.armor)e&&(t+=ne[e].points);return t}best(t){let e=-1,n=-1;return this.slots.forEach((i,r)=>{let o=i&&ne[i.id];o&&o.kind===t&&(o.damage??o.tier??0)>e&&(e=o.damage??o.tier??0,n=r)}),n}blockSlot(){let t=-1,e=0;return this.slots.forEach((n,i)=>{n&&n.id<100&&ne[n.id].kind==="block"&&n.count>e&&(e=n.count,t=i)}),t}blocks(){let t=0;for(let e of this.slots)e&&e.id<100&&(t+=e.count);return t}clear(){this.slots.fill(null),this.armor=[0,0,0,0]}all(){let t=[];for(let e of this.slots)e&&t.push({...e});for(let e of this.armor)e&&t.push({id:e,count:1});return t}},tv=1,vl=class{constructor({name:t,team:e=-1,bot:n=!1,skin:i=0,local:r=!1}){this.id=tv++,this.name=t,this.team=e,this.bot=n,this.local=r,this.skin=i,this.pos={x:0,y:0,z:0},this.vel={x:0,y:0,z:0},this.kb={x:0,z:0},this.yaw=0,this.pitch=0,this.onGround=!1,this.crouch=!1,this.sprint=!1,this.inv=new ah(9),this.sel=0,this.hp=20,this.maxHp=20,this.alive=!0,this.eliminated=!1,this.hurtT=0,this.attackCd=0,this.swingT=0,this.lastAttacker=null,this.lastAttackT=-99,this.kills=0,this.deaths=0,this.placed=0,this.broken=0,this.mine=null,this.eatT=0,this.regenT=0,this.respawnT=0,this.spawnProtect=0,this.walkPhase=0,this.moveAmt=0,this.lastHurt=-99,this.absorb=0,this.rank=0}held(){let t=this.inv.slots[this.sel];return t?ne[t.id]:null}eye(t){return{x:this.pos.x,y:this.pos.y+t,z:this.pos.z}}look(){let t=Math.cos(this.pitch);return{x:-Math.sin(this.yaw)*t,y:Math.sin(this.pitch),z:-Math.cos(this.yaw)*t}}reset(){this.vel.x=this.vel.y=this.vel.z=0,this.kb.x=this.kb.z=0,this.hp=this.maxHp,this.hurtT=0,this.mine=null,this.eatT=0,this.airTop=null,this.onGround=!1,this.crouch=!1}};var ef=Math.PI*2,nf=s=>{for(;s>Math.PI;)s-=ef;for(;s<-Math.PI;)s+=ef;return s},ss=s=>({x:Math.floor(s.x),y:Math.floor(s.y+.01),z:Math.floor(s.z)}),yl=class{constructor(t,e,n=.5){this.a=t,this.m=e,this.skill=n,this.turn=5+n*9,this.cps=3.2+n*5,this.react=.55-n*.35,this.aimErr=.16-n*.12,this.greed=Math.random(),this.brave=.35+Math.random()*.5,this.path=null,this.pi=0,this.repath=0,this.goal=null,this.goalT=0,this.bridge=null,this.clickT=0,this.strafe=Math.random()<.5?1:-1,this.strafeT=0,this.pause=0,this.stuckT=0,this.lastPos={...t.pos},this.noticeT=0,this.target=null,this.jumpT=0,this.throwT=2+Math.random()*3,this.mineT=0,this.wanderT=0,this.patience=50+Math.random()*70,this.ctlObj={mx:0,mz:0,yaw:t.yaw,pitch:t.pitch,jump:!1,crouch:!1,sprint:!1,attack:!1,attackPressed:!1,use:!1,useHeld:!1,sel:null},t.ctl=i=>this.tick(i)}enemies(){return this.m.actors.filter(t=>t.alive&&this.m.enemies(this.a,t))}nearestEnemy(t=999){let e=null,n=t;for(let i of this.enemies()){let r=this.dist(i.pos);r<n&&(n=r,e=i)}return e?{o:e,d:n}:null}dist(t){return Math.hypot(t.x-this.a.pos.x,t.z-this.a.pos.z)+Math.abs(t.y-this.a.pos.y)*.5}visible(t){let e=this.a,n=e.eye(oi(e)),i={x:t.pos.x,y:t.pos.y+1.4,z:t.pos.z},r=i.x-n.x,o=i.y-n.y,a=i.z-n.z,l=Math.hypot(r,o,a)||1;return!this.m.world.raycast(n.x,n.y,n.z,r/l,o/l,a/l,l,h=>Pe(h)&&h!==7&&h!==12)}aimAt(t,e,n,i,r=0){let o=this.a,a=o.eye(oi(o)),l=t-a.x,c=e-a.y,h=n-a.z,d=Math.atan2(-l,-h)+r*Math.sin(this.m.time*3.1+o.id),f=Math.atan2(c,Math.hypot(l,h))+r*.5*Math.cos(this.m.time*2.3+o.id),p=this.ctlObj,m=this.turn*i,x=nf(d-p.yaw);return p.yaw=nf(p.yaw+Math.max(-m,Math.min(m,x))),p.pitch+=Math.max(-m,Math.min(m,f-p.pitch)),Math.abs(x)+Math.abs(f-p.pitch)*.5}selectKind(t){let e=this.a.inv.best(t);return e>=0&&(this.ctlObj.sel=e),e>=0}selectBlocks(){let t=this.a.inv.blockSlot();return t>=0&&(this.ctlObj.sel=t),t>=0}steer(t,e,n,i=!0,r=!1){let o=this.a,a=this.ctlObj,l=t-o.pos.x,c=e-o.pos.z,h=Math.hypot(l,c);return h<.05?(a.mx=0,a.mz=0,h):(a.mx=l/h,a.mz=c/h,a.sprint=i&&h>2,!r&&this.unsafeAhead(a.mx,a.mz)&&(a.mx=0,a.mz=0,a.sprint=!1),h)}unsafeAhead(t,e){let n=this.a,i=this.m.world;if(!n.onGround)return!1;let r=Math.floor(n.pos.x+t*.55),o=Math.floor(n.pos.z+e*.55),a=Math.floor(n.pos.y+.01);if(r===Math.floor(n.pos.x)&&o===Math.floor(n.pos.z))return!1;for(let l=a-1;l>=a-4;l--)if(Pe(i.get(r,l,o)))return!1;return!Pe(i.get(r,a,o))}goTo(t,e,n,i,r=0,o=!0){let a=this.a,l=ss(a.pos);this.repath-=i;let c=`${t},${e},${n}`;if(this.bridge)return this.doBridge(i);if(!this.path||this.pathKey!==c||this.repath<=0||this.pi>=this.path.length){let f=rh(this.m.world,l.x,l.y,l.z,t,e,n,{near:r,limit:2200});if(this.path=f.path,this.pi=1,this.pathKey=c,this.repath=f.reached?1.2+Math.random()*.6:2.6+Math.random()*1.2,this.pathReached=f.reached,!f.reached&&o){let p=f.end;if(Math.hypot(p.x-t,p.z-n)>2&&this.a.inv.blocks()>0&&!(this.noBridge>0)&&Math.hypot(p.x-l.x,p.z-l.z)<1.5)return this.startBridge(t,e,n),this.doBridge(i)}}let h=this.path[this.pi];if(!h)return this.ctlObj.mx=this.ctlObj.mz=0,this.pathReached;let d=this.steer(h.x+.5,h.z+.5,i,!0,!0);return h.y>a.pos.y+.4&&a.onGround&&d<1.4&&(this.ctlObj.jump=!0),d<.32&&Math.abs(h.y-a.pos.y)<1.2&&this.pi++,this.pi>=this.path.length&&!this.pathReached&&o&&this.a.inv.blocks()>0&&!(this.noBridge>0)?(this.startBridge(t,e,n),!1):this.pi>=this.path.length&&this.pathReached}startBridge(t,e,n){let i=ss(this.a.pos);this.bridge={gx:t,gy:e,gz:n,y:i.y,cells:Zd(i.x,i.z,t,n),i:0,t:0,placeT:0},this.path=null}doBridge(t){let e=this.a,n=this.m.world,i=this.bridge,r=this.ctlObj;if(i.t+=t,i.i!==i.lastI&&(i.lastI=i.i,i.prog=i.t),i.t-(i.prog||0)>6||e.pos.y<i.y-3)return this.bridge=null,this.goal=null,this.noBridge=5,!1;let o=ss(e.pos);e.onGround&&o.y!==i.y&&Math.abs(o.y-i.y)<=2&&(i.y=o.y);let a=i.cells[i.i];if(!a)return this.bridge=null,!0;let[l,c]=a,d=i.gy-i.y>=2&&i.i%2===1;if(!Dn(n,l,i.y,c)&&Dn(n,l,i.y+1,c))return this.steer(l+.5,c+.5,t,!1,!0),e.onGround&&(r.jump=!0),Math.abs(e.pos.x-(l+.5))<.35&&Math.abs(e.pos.z-(c+.5))<.35&&e.pos.y>i.y+.9&&(i.y+=1,i.i++),!1;if(Pe(n.get(l,i.y,c))||Pe(n.get(l,i.y+1,c))){let v=Pe(n.get(l,i.y+1,c))?i.y+1:i.y;return r.mx=0,r.mz=0,this.m.mode.canBreak(e,l,v,c,n.get(l,v,c))?(this.selectKind("pick")||this.selectKind("axe"),this.aimAt(l+.5,v+.5,c+.5,t)<.3&&(r.attack=!0),!1):(this.bridge=null,this.goal=null,this.noBridge=5,!1)}if(Dn(n,l,i.y,c))return r.crouch=!0,this.steer(l+.5,c+.5,t,!1),r.mx*=.8,r.mz*=.8,Math.abs(e.pos.x-(l+.5))<.3&&Math.abs(e.pos.z-(c+.5))<.3&&(i.i++,(Math.hypot(l-i.gx,c-i.gz)<2.5||kn(n,i.cells[i.i]?.[0]??l,i.y,i.cells[i.i]?.[1]??c,1)!=null&&i.i>3)&&rh(n,l,i.y,c,i.gx,i.gy,i.gz,{near:1,limit:600}).reached&&(this.bridge=null,this.path=null)),this.aimAt(l+.5,i.y-.5,c+.5,t),!1;if(d&&Dn(n,l,i.y+1,c))return r.jump=e.onGround,this.steer(l+.5,c+.5,t,!1),e.pos.y>i.y+.9&&(i.y+=1),!1;if(r.mx=0,r.mz=0,r.crouch=!0,r.sprint=!1,!this.selectBlocks())return this.bridge=null,!1;let f=l+.5-e.pos.x,p=c+.5-e.pos.z,m=Math.hypot(f,p)||1;(Math.abs(f)>Math.abs(p)?Math.abs(e.pos.x-(o.x+.5+Math.sign(f)*.28)):Math.abs(e.pos.z-(o.z+.5+Math.sign(p)*.28)))>.12&&o.x===Math.floor(e.pos.x)&&(r.mx=f/m*.5,r.mz=p/m*.5);let g=d?i.y:i.y-1,u=this.aimAt(l+.5,g+.5,c+.5,t);if(i.placeT+=t,i.placeT>.62-this.skill*.28&&u<.6){i.placeT=0;let v=e.inv.slots[r.sel??e.sel];v&&(e.sel=r.sel??e.sel,!Pe(n.get(l,g-0+(d?-1:0),c))&&d?this.m.place(e,l,i.y-1,c,v.id):this.m.place(e,l,g,c,v.id))}return!1}lootChest(t,e){let n=this.a;return Math.hypot(t.x+.5-n.pos.x,t.z+.5-n.pos.z)<2.6&&Math.abs(t.y-n.pos.y)<2.5?(this.ctlObj.mx=this.ctlObj.mz=0,this.aimAt(t.x+.5,t.y+.5,t.z+.5,e),this.pause+=e,this.pause>1.1+(1-this.skill)*.9?(this.m.takeAll(n,t),this.pause=0,this.equip(),!0):!1):(this.goTo(t.x,t.y,t.z,e,1),!1)}equip(){this.selectKind("sword")||this.selectKind("axe")}nearestChest(t,e=()=>!0){let n=null,i=t;for(let r of this.m.map.chests){if(r.looted||!r.items.length||!e(r))continue;let o=this.dist({x:r.x,y:r.y,z:r.z});o<i&&(i=o,n=r)}return n}fight(t,e,n){let i=this.a,r=this.ctlObj;this.bridge=null,this.selectKind("sword")||this.selectKind("axe")||this.selectKind("pick");let o=this.aimAt(t.pos.x,t.pos.y+1.2,t.pos.z,n,this.aimErr),a=2.8+this.skill*.3;if(e>a-.4)if(Math.abs(t.pos.y-i.pos.y)<1.5&&e<6)this.steer(t.pos.x,t.pos.z,n),i.blocked&&i.onGround&&(r.jump=!0);else{let c=ss(t.pos),h=kn(this.m.world,c.x,c.y,c.z,4);this.goTo(c.x,h??c.y,c.z,n,1)}else{this.strafeT-=n,this.strafeT<=0&&(this.strafeT=.6+Math.random()*.9,this.strafe=Math.random()<.5?1:-1);let l=t.pos.x-i.pos.x,c=t.pos.z-i.pos.z,h=Math.hypot(l,c)||1,d=e>2.2?.7:-.1;r.mx=l/h*d+-c/h*this.strafe*.6,r.mz=c/h*d+l/h*this.strafe*.6,this.unsafeAhead(r.mx,r.mz)&&(r.mx=l/h*.4,r.mz=c/h*.4,this.unsafeAhead(r.mx,r.mz)&&(r.mx=r.mz=0),r.crouch=!0),r.sprint=e>1.8,this.jumpT-=n,this.jumpT<=0&&i.onGround&&Math.random()<this.skill*.6&&(r.jump=!0,this.jumpT=.9+Math.random())}this.clickT-=n,e<a+.5&&o<.45&&this.clickT<=0&&(r.attack=!0,r.attackPressed=!0,this.clickT=1/this.cps)}tryThrow(t,e,n){let i=this.a;if(this.throwT-=n,this.throwT>0||e<5||e>16||i.inv.count(131)===0||!this.visible(t))return!1;this.throwT=2.5+Math.random()*3;let r=i.inv.slots.findIndex(l=>l&&l.id===131);if(r<0)return!1;i.sel=r,this.ctlObj.sel=r;let o=e/22;return this.aimAt(t.pos.x+t.vel.x*o,t.pos.y+1.3+e*.06,t.pos.z+t.vel.z*o,1,0)<.5?(this.ctlObj.use=!0,!0):!1}heal(t){let e=this.a;if(e.hp>9)return!1;let n=e.inv.slots.findIndex(i=>i&&ne[i.id].kind==="food");return n<0?!1:(this.ctlObj.sel=n,this.ctlObj.useHeld=!0,!0)}clutch(){let t=this.a,e=this.m.world;if(t.onGround||t.vel.y>-6||this.skill<.35)return;let n=ss(t.pos);if(kn(e,n.x,n.y,n.z,5)!=null||Math.random()>this.skill*.08)return;let i=t.inv.blockSlot();i<0||(t.sel=i,this.m.place(t,n.x,n.y-1,n.z,t.inv.slots[i].id))}tick(t){let e=this.a,n=this.m,i=this.ctlObj;if(this.noBridge=(this.noBridge||0)-t,i.jump=!1,i.attack=!1,i.attackPressed=!1,i.use=!1,i.useHeld=!1,i.crouch=!1,i.mx=0,i.mz=0,n.state!=="play")return i;this.clutch();let r=Math.hypot(e.pos.x-this.lastPos.x,e.pos.z-this.lastPos.z);this.lastPos={...e.pos};let o=this.path&&this.pi<this.path.length||!!this.bridge||this.goal&&this.goal.t!=="idle";this.stuckT=r<.4*t&&o&&!this.bridge?this.stuckT+t:Math.max(0,this.stuckT-t),this.stuckT>1.2&&(i.jump=!0,this.path=null),this.stuckT>3.5&&(this.stuckT=0,this.goal=null,this.bridge=null),r>.6*t&&(this.lostT=0);let a=this.nearestEnemy(30);if(a){this.noticeT+=t;let c=a.d<3||this.visible(a.o),h=n.mode.id==="sky"&&n.time<100&&!a.o.local;if(a.d<(this.bridge?4:h?4+this.brave*3:9+this.brave*8)&&c&&Math.abs(a.o.pos.y-e.pos.y)<5&&this.noticeT>this.react&&(!n.mode.botEngage||n.mode.botEngage(this,a)))return!(a.d<3.5)&&this.heal(t)||this.tryThrow(a.o,a.d,t)||this.fight(a.o,a.d,t),i}else this.noticeT=0;return this.heal(t)?i:(n.mode.botPlan?n.mode.botPlan(this,t):this.planSky(t))||i}planSky(t){let e=this.a,n=this.m,i=this.ctlObj,r=n.mode;if(r.rising&&e.pos.y<n.map.voidY+5&&this.tower(t))return i;if(r.border<r.radius&&Math.hypot(e.pos.x,e.pos.z)>r.border-5)return this.goal={t:"center"},this.goTo(0,n.map.center.y-2,0,t,3),i;let o=e.home,a=this.nearestChest(14,h=>Math.hypot(h.x-o.x,h.z-o.z)<9);if(a)return this.goal={t:"loot"},this.lootChest(a,t),i;if(e.inv.blocks()<8){let h=this.nearestChest(12);if(h)return this.goal={t:"loot"},this.lootChest(h,t),i;if(this.mineForBlocks(t))return i}let c=e.inv.armorPoints()+(e.inv.best("sword")>=0?4:0);if(!this.goal||this.goal.t==="loot"||this.goal.t==="idle"||(this.goalT-=t)<=0){this.goalT=6+Math.random()*6;let h=n.map.chests.some(f=>f.tier==="mid"&&!f.looted&&f.items.length),d=this.nearestEnemy(999);n.time<this.patience*(c<10?1:.75)?this.goal={t:h&&n.time>25&&this.greed>.8?"mid":"idle"}:h&&(this.greed>.6||c<5)&&(n.time<150||r.refilled&&n.time<r.borderAt&&Math.random()<.5)?this.goal={t:"mid"}:d?this.goal={t:"hunt",o:d.o}:this.goal={t:"mid"}}if(this.goal.t==="idle")return this.goalT=Math.min(this.goalT,3),this.wander(t),i;if(this.goal.t==="mid"){let h=this.nearestChest(80,d=>d.tier!=="spawn"||Math.hypot(d.x-o.x,d.z-o.z)<9);return h&&this.dist(h)<60?(this.lootChest(h,t),i):(this.goTo(0,n.map.center.y-2,0,t,2),i)}if(this.goal.t==="hunt"){let h=this.goal.o;if(!h||!h.alive)return this.goal=null,i;if(h.pos.y-e.pos.y>1.8&&Math.hypot(h.pos.x-e.pos.x,h.pos.z-e.pos.z)<5&&this.tower(t))return i;let d=ss(h.pos),f=kn(n.world,d.x,d.y,d.z,6);return this.goTo(d.x,f??d.y,d.z,t,1),i}return i}followRoute(t,e){let n=this.a,i=this.ctlObj,r=this.m.world;this.rI==null&&(this.rI=0);let o=t[this.rI],a=f=>(n.onGround||!(f.jump||f.tight))&&Math.hypot(f.x+.5-n.pos.x,f.z+.5-n.pos.z)<(f.tight?.6:.85)&&n.pos.y>f.y-.6&&n.pos.y<f.y+1.4;for(;o&&a(o);)this.lastTight=!!o.tight,this.rI++,o=t[this.rI];if(!o)return i.mx=i.mz=0,!0;if(this.waitT>0)return this.waitT-=e,i.mx=i.mz=0,!1;let l=o.x+.5-n.pos.x,c=o.z+.5-n.pos.z,h=Math.hypot(l,c)||1;i.mx=l/h,i.mz=c/h,i.yaw=Math.atan2(-l,-c),i.pitch=-.15;let d=o.jump||o.y>Math.floor(n.pos.y+.01);if(i.sprint=o.tight?h>2.6:d||h>1.5,n.onGround&&this.lastTight&&o.jump&&o.y<=Math.floor(n.pos.y+.01))return this.lastTight=!1,i.jump=!0,!1;if(h<.35&&!d&&(i.mx*=.4,i.mz*=.4),n.onGround){let f=Math.floor(n.pos.y+.01)-1,p=Math.floor(n.pos.x+i.mx*.42),m=Math.floor(n.pos.z+i.mz*.42),x=!r.solidAt(p,f,m)&&!r.solidAt(p,f-1,m);o.y>f+1&&(h<1.7||n.blocked)?i.jump=!0:x&&(o.jump||o.y>=f+1||h>1.2)?(this.slip==null&&(this.slip=Math.random()<(1-this.skill)*.12?.08+Math.random()*.12:0),this.slip>0?(this.slip-=e,this.slip<=0&&(i.jump=!0)):i.jump=!0):this.slip=null}return!1}tower(t){let e=this.a,n=this.ctlObj,i=this.m.world;if(!this.selectBlocks())return!1;let r=Math.floor(e.pos.x),o=Math.floor(e.pos.z),a=Math.floor(e.pos.y+.01);if(Pe(i.get(r,a+2,o)))return!1;if(n.mx=(r+.5-e.pos.x)*2,n.mz=(o+.5-e.pos.z)*2,this.aimAt(r+.5,e.pos.y-1,o+.5+.001,t),e.onGround)return n.jump=!0,this.towerY=a,!0;if(this.towerY!=null&&e.pos.y>=this.towerY+1.05&&!i.get(r,this.towerY,o)){let l=e.inv.slots[n.sel??e.sel];l&&(e.sel=n.sel??e.sel,this.m.place(e,r,this.towerY,o,l.id)),this.towerY=null}return!0}steerOrPath(t,e,n,i){let r=this.a;if(Math.abs(r.pos.y-e)<.6&&Math.hypot(t+.5-r.pos.x,n+.5-r.pos.z)<2.5){this.steer(t+.5,n+.5,i,!1);return}this.goTo(t,e,n,i,0,!1)}giveUp(t){let e=this.a;if(this.lostT=(this.lostT||0)+t,this.lostT<12)return!1;let n=this.m.map.center,i=e.pos.x-n.x,r=e.pos.z-n.z,o=Math.hypot(i,r)||1;return this.ctlObj.mx=i/o,this.ctlObj.mz=r/o,this.ctlObj.sprint=!0,e.blocked&&(this.ctlObj.jump=!0),!0}wander(t){let e=this.a;if(this.wanderT-=t,this.wanderT<=0||!this.wanderTo){this.wanderT=2+Math.random()*3;let i=e.home;this.wanderTo={x:i.x+(Math.random()-.5)*5,z:i.z+(Math.random()-.5)*5}}this.steer(this.wanderTo.x,this.wanderTo.z,t,!1)<.5&&(this.ctlObj.mx=this.ctlObj.mz=0,this.aimAt(0,e.pos.y+1,0,t*.3))}mineForBlocks(t){let e=this.a,n=this.m.world,i=ss(e.pos);if(!this.mineTarget||!n.get(this.mineTarget.x,this.mineTarget.y,this.mineTarget.z)){this.mineTarget=null;t:for(let a=1;a<=5;a++)for(let l=0;l<=2;l++)for(let c=-a;c<=a;c++)for(let h=-a;h<=a;h++){let d=i.x+h,f=i.y+l-(l===2?3:0),p=i.z+c;if(h===0&&c===0)continue;let m=n.get(d,f,p);if(m&&[2,3,4,5,6,8,9,18,28].includes(m)&&this.m.mode.canBreak(e,d,f,p,m)&&f>=i.y-1){this.mineTarget={x:d,y:f,z:p};break t}}}let r=this.mineTarget;return r?(this.aimAt(r.x+.5,r.y+.5,r.z+.5,t)<.25&&(this.ctlObj.attack=!0,this.selectKind("pick")||this.selectKind("axe")),!0):!1}planEgg(t){return(this.m.mode.botPlan?this.m.mode.botPlan(this,t):null)||this.ctlObj}};var Kt=1.8/32,ev=s=>{let t=s>>>0||7;return()=>(t^=t<<13,t^=t>>>17,t^=t<<5,(t>>>0)/4294967296)},js=(s,t)=>t[Math.floor(s()*t.length)],nv=["#f2c9a0","#e8b48a","#d49a6a","#b07a4a","#8a5a36","#6a4026","#f5d5b5"],iv=["#2a1a10","#4a2a14","#7a4a1e","#c89a4a","#e8d080","#1a1a1a","#a0302a","#e0e0e0","#3a5ad8","#d84a9a"],sv=["#d83a3a","#3a7ad8","#3aa84a","#e8c83a","#8a3ad8","#e8823a","#2ab8c0","#e86aa8","#3a3a3a","#e8e8e8","#4a5a7a","#7a4a2a"],rv=["#2a3a6a","#3a3a3a","#5a4a3a","#2a2a2a","#4a5a3a","#6a6a7a","#1a2a4a"];function ch(s,t=-1){let e=ev(s*9973+17),n=document.createElement("canvas");n.width=64,n.height=64;let i=n.getContext("2d"),r=js(e,nv),o=js(e,iv),a=t>=0?Gt[t].hex:js(e,sv),l=js(e,rv),c=js(e,["#2a2a2a","#4a3020","#e8e8e8","#3a3a5a"]),h=(u,v)=>{let _=parseInt(u.slice(1),16),M=A=>Math.max(0,Math.min(255,Math.round(A*v)));return`rgb(${M(_>>16)},${M(_>>8&255)},${M(_&255)})`},d=(u,v,_,M,A,b=.06)=>{for(let T=v;T<v+M;T++)for(let I=u;I<u+_;I++)i.fillStyle=h(A,1-b+e()*b*2),i.fillRect(I,T,1,1)},f=(u,v,_)=>{i.fillStyle=_,i.fillRect(u,v,1,1)};d(0,0,32,16,r,.04),d(8,0,8,8,o),d(16,0,8,8,r);let p=Math.floor(e()*4);d(0,8,32,p===0?2:p===1?3:4,o),d(24,8,8,8,o),p>=2&&(d(0,8,8,6,o),d(16,8,8,6,o)),p===3&&(d(8,8,1,4,o),d(15,8,1,4,o));let m=js(e,["#3a6ad8","#3a2a1a","#2a8a4a","#5a3a2a","#6a6a6a"]);f(9,12,"#ffffff"),f(10,12,m),f(13,12,m),f(14,12,"#ffffff"),e()<.6&&(f(10,11,h(o,.8)),f(13,11,h(o,.8))),d(11,14,2,1,h(r,.7),0),f(10,14,h(r,.82)),f(13,14,h(r,.82)),e()<.2&&d(9,14,6,2,o),d(16,16,24,16,a),d(20,16,8,4,a),d(28,16,8,4,h(a,.85));let x=Math.floor(e()*5);if(x===1&&d(20,22,8,2,"#ffffff",.02),x===2&&d(23,20,2,12,h(a,.7)),x===3)for(let u=0;u<8;u++)f(20+u,20+u%2,h(a,1.25));x===4&&d(20,26,8,6,h(a,.75)),d(22,20,4,2,h(r,.95),0),d(40,16,16,16,a),d(44,26,4,6,r),d(40,26,16,6,r),d(40,20,16,2,h(a,.8)),d(0,16,16,16,l),d(0,28,16,4,c),d(4,16,8,4,l),t>=0&&d(20,26,8,2,h(a,.6));let g=new ks(n);return g.magFilter=Ce,g.minFilter=Ce,g.colorSpace=Le,g}function ov(s,t,e,n,i,r){let a=[[t,e+r,r,i],[t+r+n,e+r,r,i],[t+r,e,n,r],[t+r+n,e,n,r],[t+2*r+n,e+r,n,i],[t+r,e+r,n,i]],l=s.attributes.uv;for(let c=0;c<6;c++){let[h,d,f,p]=a[c],m=h/64,x=(h+f)/64,g=1-d/64,u=1-(d+p)/64,v=c*4;l.setXY(v,m,g),l.setXY(v+1,x,g),l.setXY(v+2,m,u),l.setXY(v+3,x,u)}return l.needsUpdate=!0,s}function Ks(s,t,e,n,i,r,o){let a=ov(new De(t*Kt,e*Kt,n*Kt),i,r,t,e,n);a.translate(0,-e*Kt/2+o,0);let l=new jt(a,s),c=new Je;return c.add(l),c}var av=[9067056,11053232,14211288,5234904];function _l(s,t=-1){let e=ch(s,t),n=new Rn({map:e}),i=new Je,r=new Je;i.add(r);let o=Ks(n,8,8,8,0,0,4*Kt);o.position.y=24*Kt+0,o.children[0].geometry.translate(0,4*Kt,0);let a=Ks(n,8,12,4,16,16,6*Kt);a.position.y=18*Kt;let l=Ks(n,4,12,4,40,16,2*Kt);l.position.set(6*Kt,22*Kt,0);let c=Ks(n,4,12,4,40,16,2*Kt);c.position.set(-6*Kt,22*Kt,0);let h=Ks(n,4,12,4,0,16,0);h.position.set(2*Kt,12*Kt,0);let d=Ks(n,4,12,4,0,16,0);d.position.set(-2*Kt,12*Kt,0),r.add(o,a,l,c,h,d);let f=new Je;f.position.set(0,-10*Kt,-2*Kt),l.add(f);let p=av.map(g=>new Rn({color:g})),m=(g,u,v,_,M)=>{let A=new jt(new De(g*Kt,u*Kt,v*Kt),p[0]);return A.position.y=_,A.visible=!1,M.add(A),A},x=[[m(9,9,9,4*Kt,o)],[m(9,13,5,0,a),m(5,6,5,-1*Kt,l),m(5,6,5,-1*Kt,c)],[m(5,8,5,-4*Kt,h),m(5,8,5,-4*Kt,d)],[m(5,4,5,-10.5*Kt,h),m(5,4,5,-10.5*Kt,d)]];return{root:i,body:r,head:o,torso:a,armR:l,armL:c,legR:h,legL:d,hand:f,mat:n,armor:x,armorMats:p,heldId:null,tex:e}}function sf(s,t){for(let e=0;e<4;e++){let n=t.armor[e];for(let i of s.armor[e])i.visible=!!n,n&&(i.material=s.armorMats[ne[n].tier])}}function rf(s,t,e){let n=Math.sin(t.walkPhase*1.6)*Math.min(1,t.moveAmt/4)*.9;s.legR.rotation.x=n,s.legL.rotation.x=-n,s.armL.rotation.x=-n*.8;let i=t.swingT>0?Math.sin((1-t.swingT/.25)*Math.PI):0;s.armR.rotation.x=n*.8-i*1.6-(t.heldBlock?.3:0),s.armR.rotation.z=-i*.25,s.head.rotation.x=-t.pitch*.9,s.body.position.y=t.crouch?-.18:0,s.torso.rotation.x=t.crouch?.45:0,s.head.position.z=t.crouch?-.2:0,s.armR.position.z=s.armL.position.z=t.crouch?-.15:0;let r=t.hurtT>.2;s.mat.emissive&&s.mat.emissive.setRGB(r?.6:0,0,0)}var lh=new Map;function Ml(s,t,e){if(lh.has(s))return lh.get(s).clone();let n=ne[s],i;if(n&&n.kind==="block"){let r=Yt[n.block],o=new De(1,1,1),a=o.attributes.uv,l=["side","side","top","bottom","side","side"];for(let d=0;d<6;d++){let[f,p,m,x]=t.uv(r.tex[l[d]]);for(let g=0;g<4;g++){let u=d*4+g;a.setXY(u,f+a.getX(u)*m,p+(1-a.getY(u))*x)}}let c=[.8,.8,1,.55,.68,.68],h=[];for(let d=0;d<6;d++)for(let f=0;f<4;f++)h.push(c[d],c[d],c[d]);o.setAttribute("color",new ue(h,3)),i=new jt(o,new Re({map:e,vertexColors:!0,alphaTest:.5,transparent:r.id===11})),i.scale.setScalar(.32),i.userData.block=!0}else{let r=n?n.icon:"snowball",[o,a,l,c]=t.uv(r),h=t.width,d=Math.round(o*h),f=Math.round(a*t.height),p=[],m=[],x=[],g=1/16,u=(_,M)=>_>=0&&M>=0&&_<16&&M<16&&t.data[((f+M)*h+d+_)*4+3]>100;for(let _=0;_<16;_++)for(let M=0;M<16;M++){if(!u(M,_))continue;let A=((f+_)*h+d+M)*4,b=[t.data[A]/255,t.data[A+1]/255,t.data[A+2]/255].map(C=>Math.pow(C,2.2)),T=(M-8)*g,I=(7-_)*g,y=g*.5,w=[[[0,0,y],[g,0,y],[g,g,y],[0,g,y],1],[[g,0,-y],[0,0,-y],[0,g,-y],[g,g,-y],.75]];u(M,_-1)||w.push([[0,g,y],[g,g,y],[g,g,-y],[0,g,-y],.95]),u(M,_+1)||w.push([[0,0,-y],[g,0,-y],[g,0,y],[0,0,y],.6]),u(M-1,_)||w.push([[0,0,-y],[0,0,y],[0,g,y],[0,g,-y],.7]),u(M+1,_)||w.push([[g,0,y],[g,0,-y],[g,g,-y],[g,g,y],.8]);for(let C of w){let L=p.length/3;for(let B=0;B<4;B++)p.push(T+C[B][0],I+C[B][1],C[B][2]),m.push(b[0]*C[4],b[1]*C[4],b[2]*C[4]);x.push(L,L+1,L+2,L,L+2,L+3)}}let v=new He;v.setAttribute("position",new ue(p,3)),v.setAttribute("color",new ue(m,3)),v.setIndex(x),i=new jt(v,new Re({vertexColors:!0})),i.scale.setScalar(.62)}return lh.set(s,i),i.clone()}function of(s){let t=[];for(let a=0;a<=12;a++){let l=a/12,c=l*.95,h=Math.sin(Math.PI*Math.pow(l,.8))*.36*(1-l*.15);t.push(new Nt(Math.max(.001,h),c))}let e=new Rr(t,14),n=new kt(Gt[s].hex),i=[],r=e.attributes.position;for(let a=0;a<r.count;a++){let l=(Math.sin(r.getX(a)*40)*Math.cos(r.getY(a)*31+r.getZ(a)*27)+1)/2,c=l>.8?1.35:.85+l*.25;i.push(n.r*c,n.g*c,n.b*c)}return e.setAttribute("color",new ue(i,3)),new jt(e,new Rn({vertexColors:!0,emissive:n,emissiveIntensity:.25}))}function hh(s,t="#ffffff"){let e=document.createElement("canvas"),n=e.getContext("2d");n.font="bold 30px system-ui, sans-serif";let i=Math.ceil(n.measureText(s).width)+20;e.width=i,e.height=42,n.font="bold 30px system-ui, sans-serif",n.fillStyle="rgba(0,0,0,0.45)",n.fillRect(0,0,i,42),n.fillStyle=t,n.textBaseline="middle",n.fillText(s,10,22);let r=new ks(e);r.colorSpace=Le;let o=new wr(new Is({map:r,depthWrite:!1,transparent:!0}));return o.scale.set(i/190,.22,1),o.renderOrder=5,o}var lv={shoulder:[.5,-.62,-.18],dir:[-.2,.5,-1],roll:.5,scale:1,block:{scale:.24,rot:[0,.8,0],off:[-.05,.07,-.08]},tool:{scale:.5,rot:[0,-.8,.2],off:[-.08,.12,-.1]}},bl=class{constructor(t,e){this.R=t,this.atlas=e,this.scene=t.scene,this.chars=new Map,this.dropMeshes=new Map,this.projMeshes=new Map,this.eggs=[],this.npcs=[],this.particles=[];let n=new De(.12,.12,.12);this.pMesh=new Hi(n,new Re({vertexColors:!1}),400),this.pMesh.instanceMatrix.setUsage(Ic),this.pMesh.count=0,this.pMesh.frustumCulled=!1,this.pColors=new Float32Array(400*3),this.pMesh.instanceColor=new zi(this.pColors,3),this.scene.add(this.pMesh),this.vmScene=new Bi,this.vmCam=new Be(70,1,.01,10),this.vmScene.add(new qi(16777215,7829367,2.2));let i=new Xi(16777215,1.2);i.position.set(.3,1,.5),this.vmScene.add(i),this.vm=new Je,this.vmScene.add(this.vm),this.vmHeld=null,this.vmHeldId=-1,this.vmSwing=0,this.vmBob=0,this.vmCfg=JSON.parse(JSON.stringify(lv))}setMatch(t,e){this.clear(),this.m=t,this.local=e;for(let n of t.actors){let i=_l(n.skin,t.mode.id==="egg"?n.team:-1),r=n.team>=0?Gt[n.team].hex:"#ffffff";i.tag=hh(n.name,r),i.tag.position.y=2.15,i.root.add(i.tag),this.scene.add(i.root),this.chars.set(n.id,i),n===e&&(i.root.visible=!1)}if(this.flags=[],t.mode.flags)for(let n of t.mode.flags){let i=new Je,r=new jt(new De(.08,2.2,.08),new Rn({color:14474460}));r.position.y=1.1,i.add(r);let o=new jt(new De(.9,.6,.04),new Rn({color:Gt[n.team].hex,emissive:Gt[n.team].hex,emissiveIntensity:.25}));o.position.set(.47,1.85,0),i.add(o),this.scene.add(i),this.flags.push({f:n,g:i,cloth:o})}if(t.mode.id==="egg"&&t.mode.teams)for(let n of t.mode.teams){let i=of(n.i);i.position.set(n.egg.x+.5,n.egg.y,n.egg.z+.5),this.scene.add(i),this.eggs.push({t:n,mesh:i})}for(let n of t.npcs){let i=_l(4242+n.team*7,-1);i.root.position.set(n.x,n.y,n.z),i.root.rotation.y=n.yaw;let r=hh("SHOP","#ffe066");r.position.y=2.15,i.root.add(r);let o=new jt(new De(.47,.5,.05),new Rn({color:n.team>=0?Gt[n.team].hex:"#3a6ad8"}));o.position.set(0,.95,-.15),i.root.add(o),this.scene.add(i.root),this.npcs.push({n,ch:i})}this.buildViewmodelArm()}clear(){for(let t of this.chars.values())this.scene.remove(t.root);for(let t of this.dropMeshes.values())this.scene.remove(t);for(let t of this.projMeshes.values())this.scene.remove(t);for(let t of this.eggs)this.scene.remove(t.mesh);for(let t of this.flags||[])this.scene.remove(t.g);this.flags=[];for(let t of this.npcs)this.scene.remove(t.ch.root);this.voidPlane&&(this.scene.remove(this.voidPlane),this.voidPlane=null),this.chars.clear(),this.dropMeshes.clear(),this.projMeshes.clear(),this.eggs=[],this.npcs=[],this.particles=[],this.pMesh.count=0}buildViewmodelArm(){this.vmArm&&this.vm.remove(this.vmArm);let t=_l(this.local?this.local.skin:1,this.m&&this.m.mode.id==="egg"&&this.local?this.local.team:-1);this.vmArm=new jt(t.armR.children[0].geometry.clone(),t.mat),this.vm.add(this.vmArm),this.placeArm()}placeArm(){let t=this.vmCfg,e=new U(...t.dir).normalize();this.vmArm.position.set(...t.shoulder),this.vmArm.quaternion.setFromUnitVectors(new U(0,-1,0),e),this.vmArm.rotateY(t.roll),this.vmArm.scale.setScalar(t.scale),this.vmHandPos=new U(...t.shoulder).addScaledVector(e,.675*t.scale*.92)}heldModel(t){let e=Ml(t,this.atlas,this.R.atlasTex);return ne[t].kind==="block"?(e.scale.setScalar(.24),e.position.set(0,-.05,-.08),e.rotation.set(.3,.6,0)):(e.scale.setScalar(.55),e.rotation.set(0,Math.PI/2,-.8),e.position.set(0,-.04,-.18)),e}burst(t,e,n,i){let r=Yt[i],o=new kt(r?r.color:"#888");for(let a=0;a<10;a++)this.particles.length>=400&&this.particles.shift(),this.particles.push({x:t+.2+Math.random()*.6,y:e+.2+Math.random()*.6,z:n+.2+Math.random()*.6,vx:(Math.random()-.5)*3,vy:Math.random()*3+1,vz:(Math.random()-.5)*3,life:.5+Math.random()*.4,r:o.r*(.8+Math.random()*.3),g:o.g*(.8+Math.random()*.3),b:o.b*(.8+Math.random()*.3),s:.6+Math.random()*.6})}sparks(t,e,n,i=16777215,r=8){let o=new kt(i);for(let a=0;a<r;a++)this.particles.push({x:t,y:e,z:n,vx:(Math.random()-.5)*4,vy:Math.random()*3,vz:(Math.random()-.5)*4,life:.4+Math.random()*.3,r:o.r,g:o.g,b:o.b,s:.5})}update(t,e){let n=this.m;if(!n)return;let i=n.time;for(let f of n.actors){let p=this.chars.get(f.id);if(!p)continue;if(f===this.local&&!this.thirdPerson){p.root.visible=!1;continue}if(!f.alive){p.root.visible&&(p.deathT=(p.deathT||0)+t,p.root.rotation.z=Math.min(Math.PI/2,p.deathT*6),p.deathT>.6&&(p.root.visible=!1));continue}p.deathT=0,p.root.rotation.z=0,p.root.visible=!0,p.root.position.set(f.pos.x,f.pos.y,f.pos.z),p.root.rotation.y=f.yaw;let m=f.inv.slots[f.sel],x=m?m.id:0;f.heldBlock=x&&ne[x].kind==="block",p.heldId!==x&&(p.hand.clear(),x&&p.hand.add(this.heldModel(x)),p.heldId=x),rf(p,f,i);let g=f.inv.armor.join(",");p.armorSig!==g&&(p.armorSig=g,sf(p,f.inv)),p.mat.color&&p.mat.color.setRGB((f.hurtT>.25,1),f.hurtT>.25?.45:1,f.hurtT>.25?.45:1),p.tag.visible=e?Math.hypot(e.position.x-f.pos.x,e.position.z-f.pos.z)<40:!0}n.mode.rising&&(this.voidPlane||(this.voidPlane=new jt(new Vi(400,400),new Re({color:1706538,transparent:!0,opacity:.82,fog:!1,depthWrite:!1})),this.voidPlane.rotation.x=-Math.PI/2,this.voidPlane.renderOrder=3,this.scene.add(this.voidPlane)),this.voidPlane.position.y=n.map.voidY+Math.sin(i*2)*.05);for(let{n:f,ch:p}of this.npcs)p.head.rotation.y=Math.sin(i*.7+f.team)*.4;for(let f of this.flags||[]){let p=f.f;f.g.visible=!(p.state==="carried"&&p.carrier===this.local&&!this.thirdPerson),p.state==="carried"&&p.carrier?(f.g.position.set(p.carrier.pos.x-Math.sin(p.carrier.yaw)*.2,p.carrier.pos.y+.5,p.carrier.pos.z-Math.cos(p.carrier.yaw)*.2),f.g.scale.setScalar(.7),f.g.rotation.y=p.carrier.yaw):(f.g.position.set(p.x+.5,p.y,p.z+.5),f.g.scale.setScalar(1),f.g.rotation.y=i*.5),f.cloth.rotation.y=Math.sin(i*4+p.team)*.25}for(let f of this.eggs)f.mesh.visible=f.t.eggAlive,f.mesh.rotation.y=i*.6,f.mesh.position.y=f.t.egg.y+.03+Math.sin(i*2)*.03;let r=new Set;for(let f of n.drops){r.add(f.key);let p=this.dropMeshes.get(f.key);p||(p=Ml(f.id,this.atlas,this.R.atlasTex),ne[f.id].kind!=="block"?p.scale.setScalar(.42):p.scale.setScalar(.25),this.scene.add(p),this.dropMeshes.set(f.key,p)),p.position.set(f.x,f.y-.05+Math.sin(i*3+f.key*10)*.06,f.z),p.rotation.y=i*1.6+f.key*6}for(let[f,p]of this.dropMeshes)r.has(f)||(this.scene.remove(p),this.dropMeshes.delete(f));let o=new Set;for(let f of n.projectiles){o.add(f);let p=this.projMeshes.get(f);p||(p=new jt(new Gi(.11,8,6),new Re({color:f.id===132?2808008:16055039})),this.scene.add(p),this.projMeshes.set(f,p)),p.position.set(f.x,f.y,f.z)}for(let[f,p]of this.projMeshes)o.has(f)||(this.scene.remove(p),p.geometry.dispose(),this.projMeshes.delete(f));let a=new ee,l=new cn,c=new U,h=new U,d=0;for(let f=this.particles.length-1;f>=0;f--){let p=this.particles[f];if(p.life-=t,p.life<=0){this.particles.splice(f,1);continue}p.vy-=14*t,p.x+=p.vx*t,p.y+=p.vy*t,p.z+=p.vz*t,n.world.solidAt(Math.floor(p.x),Math.floor(p.y),Math.floor(p.z))&&(p.y=Math.floor(p.y)+1.06,p.vy=0,p.vx*=.5,p.vz*=.5),h.set(p.x,p.y,p.z),c.setScalar(p.s*Math.min(1,p.life*3)),a.compose(h,l,c),this.pMesh.setMatrixAt(d,a),this.pColors[d*3]=p.r,this.pColors[d*3+1]=p.g,this.pColors[d*3+2]=p.b,d++}this.pMesh.count=d,this.pMesh.instanceMatrix.needsUpdate=!0,this.pMesh.instanceColor.needsUpdate=!0}updateViewmodel(t,e,n){if(!e)return;let i=e.inv.slots[e.sel],r=i?i.id:0;if(r!==this.vmHeldId&&(this.vmHeld&&this.vm.remove(this.vmHeld),this.vmHeld=null,this.vmHeldId=r,this.vmEquip=.25,r)){let h=Ml(r,this.atlas,this.R.atlasTex),d=ne[r].kind==="block"?this.vmCfg.block:this.vmCfg.tool;h.scale.setScalar(d.scale),h.rotation.set(...d.rot,"YXZ"),h.position.copy(this.vmHandPos).add(new U(...d.off)),this.vmHeld=h,this.vm.add(h)}e.swingT>.2&&this.vmSwing<=0&&(this.vmSwing=.28),this.vmSwing=Math.max(0,this.vmSwing-t),this.vmEquip=Math.max(0,(this.vmEquip||0)-t);let o=this.vmSwing>0?Math.sin((1-this.vmSwing/.28)*Math.PI):0,a=e.onGround?Math.min(1,e.moveAmt/4.3):0;this.vmBob+=t*(e.sprint?13:9)*a;let l=Math.sin(this.vmBob)*.025*a,c=Math.abs(Math.cos(this.vmBob))*.03*a;this.vm.position.set(l-o*.15,-c-o*.12-this.vmEquip*1.2+(e.eatT>0?Math.sin(e.eatT*30)*.03+.12:0),o*-.1),this.vm.rotation.set(-o*.9,o*.35,o*.2)}};var af=["Pixel","Blocky","Shadow","Turbo","Lucky","Frosty","Sneaky","Crafty","Mighty","Swift","Cosmic","Rusty","Golden","Silent","Hyper","Mini","Mega","Fuzzy","Crispy","Wild","Stormy","Zippy","Noble","Dizzy","Epic","Neon","Lazy","Brave","Sly","Jolly"],qr=["Fox","Ninja","Creeper","Builder","Knight","Dragon","Panda","Wolf","Miner","Pirate","Rocket","Taco","Wizard","Bandit","Gamer","Tiger","Beast","Hero","Golem","Raven","Cookie","Bunny","Shark","Viking","Penguin","Hunter","Comet","Llama","Phantom","Otter"],lf=["Leo","Mia","Noah","Ava","Liam","Zoe","Kai","Ivy","Max","Luna","Eli","Nia","Sam","Ana","Theo","Ella","Jay","Ruby","Finn","Lola","Omar","Sara","Yuki","Ines","Tomas","Amara","Dani","Rafa","Chloe","Malik"];function uh(s=Math.random){let t=n=>n[Math.floor(s()*n.length)],e=Math.floor(s()*100);switch(Math.floor(s()*6)){case 0:return`${t(af)}${t(qr)}${e>40?e:""}`;case 1:return`${t(af)}_${t(qr)}`;case 2:return`${t(lf)}${2e3+Math.floor(s()*25)}`;case 3:return`x${t(qr)}x${e<30?e:""}`;case 4:return`${t(lf)}_${t(qr).toLowerCase()}`;default:return`${t(qr)}${t(["Pro","YT","King","Queen","HD","TV","99","777"])}`}}var cv={sky:{id:"sky",players:8,teams:0,maps:[{id:"meadow",theme:"meadow",seed:7},{id:"dunes",theme:"desert",seed:12},{id:"frostfort",theme:"snow",seed:4},{id:"emberruins",theme:"volcano",seed:6,sky:"volcano"},{id:"dusk",theme:"meadow",seed:21,sky:"dusk",style:"village",spawn:"house",bridges:"partial"}]},ctf:{id:"ctf",players:8,teams:2,teamSize:4,maps:[{id:"twincastles",theme:"meadow",seed:3},{id:"frostkeep",theme:"snow",seed:8,style:"fort"},{id:"sunfort",theme:"desert",seed:5,style:"temple"}]},bridge:{id:"bridge",players:4,teams:2,teamSize:2,maps:[{id:"skybridge",theme:"meadow",seed:2},{id:"sandbridge",theme:"desert",seed:3,style:"temple"},{id:"icebridge",theme:"snow",seed:4,style:"fort"},{id:"lavabridge",theme:"volcano",seed:5,style:"ruins",sky:"volcano"}]},deathrun:{id:"deathrun",players:8,teams:0,maps:[{id:"castlerun",theme:"meadow",seed:11},{id:"templerun",theme:"desert",seed:12,style:"temple"},{id:"frostrun",theme:"snow",seed:13,style:"fort"},{id:"lavarun",theme:"volcano",seed:14,style:"ruins",sky:"volcano"}]},race:{id:"race",players:6,teams:0,maps:[{id:"skyrace",theme:"meadow",seed:41,level:4,jumps:48},{id:"sandrace",theme:"desert",seed:42,level:5,jumps:50},{id:"icerace",theme:"snow",seed:43,level:6,jumps:48},{id:"lavarace",theme:"volcano",seed:44,level:7,jumps:46,sky:"volcano"},{id:"duskrace",theme:"meadow",seed:45,level:5,jumps:52,sky:"dusk"}]},egg:{id:"egg",players:8,teams:4,teamSize:2,maps:[{id:"frost",theme:"snow",seed:4},{id:"ember",theme:"volcano",seed:6,sky:"volcano"},{id:"greenkeep",theme:"meadow",seed:9},{id:"sandhold",theme:"desert",seed:15}]}},Sl=class{constructor(t,e,n={}){this.mode=cv[t],this.slots=[e],this.t=0,this.state="search",this.firstWait=n.firstWait??2.2,this.gap=n.gap??[.35,1.3],this.next=this.firstWait,this.countdown=n.countdown??4,this.names=new Set([e.name]),this.fast=!!n.fast,this.map=n.map?this.mode.maps.find(i=>i.id===n.map):this.mode.maps[Math.floor(Math.random()*this.mode.maps.length)]}update(t){if(this.t+=t,this.state==="search"){for(this.next-=t;this.next<=0&&this.slots.length<this.mode.players;){let e;do e=uh();while(this.names.has(e));this.names.add(e),this.slots.push({name:e,bot:!0,skin:Math.floor(Math.random()*1e5),skill:.25+Math.random()*.6});let n=this.mode.players-this.slots.length;this.next+=this.fast?0:n>3?this.gap[0]+Math.random()*(this.gap[1]-this.gap[0]):.25+Math.random()*.5}this.slots.length>=this.mode.players&&(this.state="countdown",this.cd=this.countdown)}else this.state==="countdown"&&(this.cd-=t,this.cd<=0&&(this.state="go"))}};var rs=[{id:0,seed:1,price:0},{id:1,seed:77,price:0},{id:2,seed:311,price:150},{id:3,seed:902,price:150},{id:4,seed:1450,price:250},{id:5,seed:2203,price:250},{id:6,seed:3517,price:400},{id:7,seed:4099,price:400},{id:8,seed:5821,price:600},{id:9,seed:7013,price:600},{id:10,seed:8888,price:900},{id:11,seed:9601,price:900}],cf={sens:1,fov:75,quality:"auto",volume:.8,music:.5,lang:"auto",invert:!1,viewBob:!0},wl=s=>100+(s-1)*60,Tl=class{constructor(t){this.p=t,this.data={v:1,coins:0,xp:0,level:1,skin:0,owned:[0,1],stats:{games:0,wins:0,kills:0,deaths:0,eggs:0},best:{},settings:{...cf},tutorial:!1}}async load(){try{let t=await this.p.loadData();if(t){let e=JSON.parse(t);e&&e.v===1&&(this.data={...this.data,...e,stats:{...this.data.stats,...e.stats||{}},settings:{...cf,...e.settings||{}}})}}catch{}this.data.coins=Math.max(0,this.data.coins|0),Array.isArray(this.data.owned)||(this.data.owned=[0,1]),this.data.owned.includes(this.data.skin)||(this.data.skin=0)}persist(){clearTimeout(this.t),this.t=setTimeout(()=>this.p.saveData(JSON.stringify(this.data)),250)}get settings(){return this.data.settings}addXp(t){let e=this.data;e.xp+=t;let n=0;for(;e.xp>=wl(e.level);)e.xp-=wl(e.level),e.level++,n++,e.coins+=25;return n}};var Qs=null,El=null,_n=new Map;function uf(s){El=s,Qs=document.createElement("canvas"),Qs.width=s.width,Qs.height=s.height,Qs.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(s.data),s.width,s.height),0,0)}var hf=s=>{let[t,e]=El.uv(s);return[Math.round(t*El.width),Math.round(e*El.height)]};function xe(s){if(_n.has(s))return _n.get(s);let t=document.createElement("canvas");t.width=t.height=48;let e=t.getContext("2d");e.imageSmoothingEnabled=!1;let n=ne[s];if(n&&n.kind==="block"&&!Yt[n.block].cross){let r=Yt[n.block],o=(c,h,d)=>{let[f,p]=hf(c);e.setTransform(...h),e.drawImage(Qs,f,p,16,16,-.02,-.02,16.04,16.04),d&&(e.globalCompositeOperation="source-atop",e.fillStyle=`rgba(0,0,0,${d})`,e.fillRect(0,0,16,16),e.globalCompositeOperation="source-over")};o(r.tex.side,[22/16,11/16,0,24/16,2,12],0),o(r.tex.side,[22/16,-11/16,0,24/16,24,23],0),e.setTransform(1,0,0,1,0,0);let a=document.createElement("canvas");a.width=a.height=48;let l=a.getContext("2d");l.fillStyle="rgba(0,0,0,0.22)",l.beginPath(),l.moveTo(2,12),l.lineTo(24,23),l.lineTo(24,47),l.lineTo(2,36),l.fill(),l.fillStyle="rgba(0,0,0,0.4)",l.beginPath(),l.moveTo(24,23),l.lineTo(46,12),l.lineTo(46,36),l.lineTo(24,47),l.fill(),e.globalCompositeOperation="source-atop",e.drawImage(a,0,0),e.globalCompositeOperation="source-over",o(r.tex.top,[22/16,-11/16,22/16,11/16,2,12],0)}else{let[r,o]=hf(n?n.kind==="block"?Yt[n.block].tex.side:n.icon:"snowball");e.drawImage(Qs,r,o,16,16,0,0,48,48)}let i=t.toDataURL();return _n.set(s,i),i}var dh=new Map;function Al(s,t=-1){let e=s+":"+t;if(dh.has(e))return dh.get(e);let n=ch(s,t).image,i=document.createElement("canvas");i.width=16,i.height=32;let r=i.getContext("2d");r.drawImage(n,8,8,8,8,4,0,8,8),r.drawImage(n,20,20,8,12,4,8,8,12),r.drawImage(n,44,20,4,12,0,8,4,12),r.drawImage(n,44,20,4,12,12,8,4,12),r.drawImage(n,4,20,4,12,4,20,4,12),r.drawImage(n,4,20,4,12,8,20,4,12);let o=i.toDataURL();return dh.set(e,o),o}var hv={heart:[".##.##.","#######","#######",".#####.","..###..","...#..."],armor:["##.##","#####",".###.",".###.",".###."]};function Ai(s,t,e,n=!1){let i=s+t+e+n;if(_n.has(i))return _n.get(i);let r=hv[s],o=r[0].length,a=r.length,l=3,c=document.createElement("canvas");c.width=(o+2)*l,c.height=(a+2)*l;let h=c.getContext("2d"),d=(p,m)=>m>=0&&m<a&&p>=0&&p<o&&r[m][p]==="#";for(let p=-1;p<=a;p++)for(let m=-1;m<=o;m++)d(m,p)?(h.fillStyle=n&&m>=o/2?e:t,h.fillRect((m+1)*l,(p+1)*l,l,l)):(d(m+1,p)||d(m-1,p)||d(m,p+1)||d(m,p-1))&&(h.fillStyle="#111",h.fillRect((m+1)*l,(p+1)*l,l,l));t!==e&&(h.fillStyle="rgba(255,255,255,0.55)",h.fillRect(2*l,2*l,l,l));let f=c.toDataURL();return _n.set(i,f),f}function fh(s){let t="egg"+s;if(_n.has(t))return _n.get(t);let e=document.createElement("canvas");e.width=24,e.height=28;let n=e.getContext("2d");n.fillStyle="#111",n.beginPath(),n.ellipse(12,15,10,12.5,0,0,Math.PI*2),n.fill(),n.fillStyle=s,n.beginPath(),n.ellipse(12,15,8,10.5,0,0,Math.PI*2),n.fill(),n.fillStyle="rgba(255,255,255,0.5)",n.beginPath(),n.ellipse(9,10,2.2,3.4,-.4,0,Math.PI*2),n.fill();let i=e.toDataURL();return _n.set(t,i),i}function ph(s){let t="flag"+s;if(_n.has(t))return _n.get(t);let e=document.createElement("canvas");e.width=24,e.height=28;let n=e.getContext("2d");n.fillStyle="#111",n.fillRect(3,1,5,27),n.fillRect(6,2,17,14),n.fillStyle="#d8d8d8",n.fillRect(4,2,3,25),n.fillStyle=s,n.fillRect(7,3,15,12),n.fillStyle="rgba(255,255,255,0.35)",n.fillRect(7,3,15,3);let i=e.toDataURL();return _n.set(t,i),i}var Ci=s=>String(s).replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t]);var uv=s=>k("team_"+s),dv={meadow:"Meadow Castles",dunes:"Desert Temples",frostfort:"Frost Fort",emberruins:"Ember Ruins",dusk:"Dusk Village",frost:"Frostbite",ember:"Ember Rock",greenkeep:"Green Keep",sandhold:"Sandhold",twincastles:"Twin Castles",frostkeep:"Frost Keep",sunfort:"Sun Fort",skybridge:"Sky Bridge",sandbridge:"Sand Bridge",icebridge:"Ice Bridge",lavabridge:"Lava Bridge",castlerun:"Castle Dash",templerun:"Sun Temple Dash",frostrun:"Frost Dash",lavarun:"Lava Dash",skyrace:"Sky Steps",sandrace:"Sand Steps",icerace:"Ice Steps",lavarace:"Lava Steps",duskrace:"Dusk Steps"};var df={wool:"wool",chain_set:"chainSet",iron_set:"ironSet",diamond_set:"diamondSet"},fv=[["blocks","cBlocks"],["combat","cCombat"],["armor","cArmor"],["tools","cTools"],["utility","cUtility"]],Cl=class{constructor(t,e){this.root=t,this.app=e,t.innerHTML='<div id="screen"></div><div id="hud" class="off"></div><div id="panel" class="off"></div><div id="toasts"></div><div id="fade"></div>',this.screenEl=t.querySelector("#screen"),this.hudEl=t.querySelector("#hud"),this.panelEl=t.querySelector("#panel"),this.toastEl=t.querySelector("#toasts"),this.sig={},this.screen=null,this.shopCat="blocks",t.addEventListener("click",n=>{let i=n.target.closest("[data-act]");!i||i.disabled||(n.preventDefault(),this.app.act(i.dataset.act,i.dataset))}),t.addEventListener("pointerover",n=>{let i=n.target.closest("button");i&&i!==this.lastHover&&(this.lastHover=i,this.app.audio.hover())}),t.addEventListener("input",n=>{let i=n.target;i.dataset.set&&this.app.setSetting(i.dataset.set,i.type==="range"?+i.value:i.value)}),t.addEventListener("change",n=>{let i=n.target;i.dataset.set&&i.tagName==="SELECT"&&this.app.setSetting(i.dataset.set,i.value)})}show(t,e){this.screen=t,this.screenEl.className=t?"on scr-"+t:"",this.screenEl.innerHTML=t?e:""}coinsHtml(t){return`<span class="coins"><i class="coin"></i>${t}</span>`}profileHtml(){let t=this.app.save.data,e=Math.min(100,t.xp/wl(t.level)*100);return`<div class="topbar"><div class="profile"><img class="pix" src="${Al(rs[t.skin].seed)}"><div><b>${k("level",{n:t.level})}</b><div class="xpbar"><i style="width:${e}%"></i></div></div></div>${this.coinsHtml(t.coins)}</div>`}menu(){this.show("menu",`${this.profileHtml()}
      <div class="logo"><span>VOXEL</span><span>ISLES</span></div>
      <div class="menu-btns">
        <button class="btn big green" data-act="modes">${k("play")}</button>
        <div class="row"><button class="btn" data-act="skins">${k("skins")}</button><button class="btn" data-act="settings">${k("settings")}</button><button class="btn" data-act="howto">${k("howto")}</button></div>
      </div>`)}modes(){let t=[["sky",()=>xe(1),"solo8"],["egg",()=>fh(Gt[1].hex),"teams4x2"],["ctf",()=>ph(Gt[0].hex),"teams4v4"],["bridge",()=>xe(57),"teams2v2"],["deathrun",()=>xe(60),"death1v7"],["parkour",()=>xe(61),"soloRace"]].filter(([r])=>this.app.available(r)),e=[["zombie",()=>xe(28)],["oitc",()=>xe(101)],["survival",()=>xe(17)]],n=([r,o,a])=>`<button class="card c-${r}" data-act="mode" data-mode="${r}"><div class="art"><img class="pix" src="${o()}"></div><h2>${k(r)}</h2><div class="tag">${k(a)}</div><p>${k(r+"Desc")}</p></button>`,i=([r,o])=>`<div class="card soon"><div class="art"><img class="pix" src="${o()}"></div><h2>${k(r)}</h2><div class="tag">${k("soon")}</div><p>${k(r+"Desc")}</p></div>`;this.show("modes",`${this.profileHtml()}<h1>${k("chooseGame")}</h1>
      <div class="cards">${t.map(n).join("")}${e.map(i).join("")}</div>
      <button class="btn back" data-act="menu">${k("back")}</button>`)}parkourPick(){this.show("pkpick",`${this.profileHtml()}<h1>${k("parkour")}</h1>
      <div class="cards">
        <button class="card c-parkour" data-act="pkSolo"><div class="art"><img class="pix" src="${xe(58)}"></div><h2>${k("pkSolo")}</h2><div class="tag">${k("levels10")}</div><p>${k("pkSoloDesc")}</p></button>
        <button class="card c-race" data-act="pkRace"><div class="art"><img class="pix" src="${xe(61)}"></div><h2>${k("parkourRace")}</h2><div class="tag">${k("players6")}</div><p>${k("pkRaceDesc")}</p></button>
      </div>
      <button class="btn back" data-act="modes">${k("back")}</button>`)}parkourLevels(t){t=t||{best:{},stars:{},unlocked:1};let e=[];for(let n=1;n<=10;n++){let i=n<=(t.unlocked||1),r=t.stars&&t.stars[n]||0,o=t.best&&t.best[n];e.push(`<button class="lvl ${i?"":"locked"} ${r?"done":""}" ${i?`data-act="level" data-level="${n}"`:"disabled"}><b>${n}</b><span class="st">${[1,2,3].map(a=>`<i class="${a<=r?"on":""}"></i>`).join("")}</span><em>${i?o?is(o):k("newLevel"):"\u2014"}</em></button>`)}this.show("pklevels",`${this.profileHtml()}<h1>${k("pkSolo")}</h1><div class="lvls">${e.join("")}</div>
      <button class="btn back" data-act="pkBack">${k("back")}</button>`)}lobby(t){let e=t.mode,n=e.teams>0;this.show("lobby",`<div class="lpanel"><h1>${k(e.id==="race"?"parkourRace":e.id)}</h1><div class="mapname">${dv[t.map.id]||""}</div>
      <div class="status"></div><div class="slots ${n?"teams t"+e.teams:""}"></div>
      <button class="btn small" data-act="cancelLobby">${k("cancel")}</button></div>`),this.sig.lobby="",this.updateLobby(t)}updateLobby(t){if(this.screen!=="lobby")return;let e=t.state+t.slots.length+(t.state==="countdown"?Math.ceil(t.cd):"");if(e===this.sig.lobby)return;this.sig.lobby=e;let n=this.screenEl.querySelector(".status");n.innerHTML=t.state==="search"?`<span class="spin"></span>${k("finding")} <b>${t.slots.length}/${t.mode.players}</b>`:`<b class="cd">${k("starting",{n:Math.max(1,Math.ceil(t.cd))})}</b>`;let i=[],r=t.mode.teams>0,o=t.mode.teamSize||2;for(let l=0;l<t.mode.players;l++){let c=t.slots[l],h=r?Math.floor(l/o):-1,d=h>=0?Gt[h].hex:"";i.push(c?`<div class="slot ${c.bot?"":"me"} pop" style="${d?`--tc:${d}`:""}"><img class="pix" src="${Al(c.skinSeed??c.skin,h)}"><span>${Ci(c.name)}</span></div>`:`<div class="slot empty" style="${d?`--tc:${d}`:""}"><i></i><span>\u2026</span></div>`)}let a=this.screenEl.querySelector(".slots");a.innerHTML=r?Array.from({length:t.mode.teams},(l,c)=>`<div class="tcol" style="--tc:${Gt[c].hex}"><div class="tname">${uv(c)}</div>${i.slice(c*o,c*o+o).join("")}</div>`).join(""):i.join("")}results(t){let e=t.canDouble&&!t.doubled;this.show("results",`<div class="rpanel ${t.win?"won":""}">
      <h1>${t.win?k("victory"):k("gameOver")}</h1>
      <div class="sub">${Ci(t.sub)}</div>
      ${t.stars?`<div class="bigstars">${[1,2,3].map(n=>`<i class="${n<=t.stars?"on":""}"></i>`).join("")}</div>`:""}
      <div class="rows">${t.time?`<div><span>${k("time")}</span><b>${is(t.time)}</b></div>`:`<div><span>${k("kills")}</span><b>${t.kills}</b></div>`}<div><span>${k("reward")}</span><b>${this.coinsHtml("+"+t.coins)}</b></div><div><span>${k("xp")}</span><b>+${t.xp}</b></div></div>
      ${this.profileHtml()}
      <div class="btns">
        ${t.next?`<button class="btn green" data-act="nextLevel">${k("nextLevel")}</button><button class="btn" data-act="again">${k("retry")}</button>`:`<button class="btn green" data-act="again">${t.solo?k("retry"):k("playAgain")}</button>`}
        <button class="btn" data-act="${t.solo?"pkLevels":"modes"}">${t.solo?k("levels"):k("changeGame")}</button>
        ${e?`<button class="btn gold" data-act="double"><i class="ad"></i>${k("doubleCoins")}</button>`:""}
        ${t.canSpectate?`<button class="btn" data-act="spectate">${k("spectate")}</button>`:""}
      </div></div>`)}pause(){this.show("pause",`<div class="ppanel"><h1>${k("paused")}</h1>
      <button class="btn green" data-act="resume">${k("resume")}</button>
      <button class="btn" data-act="settings">${k("settings")}</button>
      <button class="btn" data-act="howto">${k("howto")}</button>
      <button class="btn red" data-act="leave">${k("leaveMatch")}</button></div>`)}settings(){let t=this.app.save.settings,e=(i,r,o,a,l,c)=>`<label><span>${k(r)}</span><input type="range" data-set="${i}" min="${o}" max="${a}" step="${l}" value="${t[i]}"><em>${c(t[i])}</em></label>`,n=(i,r,o)=>`<label><span>${k(r)}</span><div class="seg">${o.map(([a,l])=>`<button class="${String(t[i])===String(a)?"on":""}" data-act="set" data-k="${i}" data-v="${a}">${l}</button>`).join("")}</div></label>`;this.show("settings",`<div class="spanel"><h1>${k("settings")}</h1>
      ${e("sens","sens",.2,3,.05,i=>i.toFixed(2))}
      ${e("fov","fov",60,100,1,i=>i)}
      ${e("volume","volume",0,1,.05,i=>Math.round(i*100)+"%")}
      ${e("music","music",0,1,.05,i=>Math.round(i*100)+"%")}
      ${n("quality","quality",[["auto",k("qAuto")],["low",k("qLow")],["high",k("qHigh")]])}
      ${n("invert","invert",[[!1,k("off")],[!0,k("on")]])}
      <label><span>${k("language")}</span><select data-set="lang"><option value="auto" ${t.lang==="auto"?"selected":""}>${k("auto")}</option>${Object.entries(Xd).map(([i,r])=>`<option value="${i}" ${t.lang===i?"selected":""}>${r}</option>`).join("")}</select></label>
      <button class="btn" data-act="back">${k("back")}</button></div>`),this.screenEl.querySelectorAll("input[type=range]").forEach(i=>i.addEventListener("input",()=>{let r=i.nextElementSibling,o=i.dataset.set,a=+i.value;r.textContent=o==="sens"?a.toFixed(2):o==="fov"?a:Math.round(a*100)+"%"}))}skins(){let t=this.app.save.data;this.show("skins",`${this.profileHtml()}<h1>${k("skins")}</h1><div class="skingrid">${rs.map(e=>{let n=t.owned.includes(e.id),i=t.skin===e.id,r=i?`<button class="btn small on" disabled>${k("equipped")}</button>`:n?`<button class="btn small" data-act="equip" data-id="${e.id}">${k("equip")}</button>`:`<button class="btn small gold" data-act="buySkin" data-id="${e.id}" ${t.coins<e.price?"disabled":""}>${this.coinsHtml(e.price)}</button>`;return`<div class="skin ${i?"eq":""}"><img class="pix" src="${Al(e.seed)}">${r}</div>`}).join("")}</div><button class="btn back" data-act="back">${k("back")}</button>`)}howto(){this.show("howto",`<div class="spanel how"><h1>${k("howto")}</h1>${["h1","h2","h3","h4","h5","h6","h7","h8","h9","h10"].map(t=>`<p>${k(t)}</p>`).join("")}<button class="btn" data-act="back">${k("back")}</button></div>`)}buildHud(t){let e=Array.from({length:9},(n,i)=>`<div class="hs" data-act="sel" data-i="${i}"><img><b></b><em>${i+1}</em></div>`).join("");return this.hudEl.innerHTML=`
      <div class="hurt"></div><div class="xhair"></div>
      <div class="info"></div><div class="eggs"></div><div class="feed"></div>
      <div class="title"><div class="big"></div><div class="sub"></div></div>
      <div class="itemname"></div>
      <div class="bottom"><div class="stats"><div class="armor"></div><div class="hearts"></div></div><div class="hotbar">${e}</div></div>
      <button class="pausebtn" data-act="pause"><i></i><i></i></button>
      <div class="lockhint">${k("clickToPlay")}</div>
      <div class="spec"><span></span><button class="btn small green" data-act="again">${k("playAgain")}</button><button class="btn small" data-act="leave">${k("leave")}</button></div>
      <div class="touch">
        <div class="look-zone"></div>
        <div class="joy-zone"><div class="joy"><div class="knob"></div></div></div>
        <div class="tb tb-attack"><img class="pix" src="${xe(101)}"></div>
        <div class="tb tb-place"><img class="pix" src="${xe(5)}"></div>
        <div class="tb tb-jump"><i class="arrow up"></i></div>
        <div class="tb tb-crouch"><i class="arrow down"></i></div>
      </div>`,this.hudEl.classList.toggle("is-touch",!!t),this.h={hurt:this.hudEl.querySelector(".hurt"),info:this.hudEl.querySelector(".info"),eggs:this.hudEl.querySelector(".eggs"),feed:this.hudEl.querySelector(".feed"),big:this.hudEl.querySelector(".title .big"),sub:this.hudEl.querySelector(".title .sub"),title:this.hudEl.querySelector(".title"),itemname:this.hudEl.querySelector(".itemname"),armor:this.hudEl.querySelector(".armor"),hearts:this.hudEl.querySelector(".hearts"),slots:[...this.hudEl.querySelectorAll(".hs")],lock:this.hudEl.querySelector(".lockhint"),spec:this.hudEl.querySelector(".spec"),xhair:this.hudEl.querySelector(".xhair"),place:this.hudEl.querySelector(".tb-place img")},this.sig={},this.hudEl}setTouch(t){this.hudEl.classList.toggle("is-touch",t)}hud(t){this.hudEl.classList.toggle("off",!t)}updateHud(t,e,n){let i=this.h,r=this.sig;r.nobar!==!!t.mode.hideBar&&(r.nobar=!!t.mode.hideBar,this.hudEl.classList.toggle("nobar",r.nobar));let o=e.inv,a=o.slots.map(p=>p?p.id+"x"+p.count:"-").join(",")+"|"+e.sel;if(a!==r.hot){let p=r.sel;r.hot=a,r.sel=e.sel,o.slots.forEach((u,v)=>{let _=i.slots[v];_.classList.toggle("on",v===e.sel);let M=_.firstElementChild,A=M.nextElementSibling,b=u?xe(u.id):"";M.dataset.src!==b&&(M.dataset.src=b,b&&(M.src=b),M.style.visibility=b?"":"hidden"),A.textContent=u&&u.count>1?u.count:""});let m=o.slots[e.sel];(p!==e.sel||(m?m.id:0)!==r.heldId)&&(r.heldId=m?m.id:0,i.itemname.textContent=m?ne[m.id].name:"",i.itemname.classList.remove("show"),i.itemname.offsetWidth,m&&i.itemname.classList.add("show"));let x=o.blockSlot(),g=x>=0?o.slots[x].id:5;i.place.dataset.id!==String(g)&&(i.place.dataset.id=g,i.place.src=xe(g))}let l=Math.max(0,Math.ceil(e.hp)),c=Math.ceil(e.absorb||0);if(r.hp!==l+":"+c){r.hp=l+":"+c;let p="";for(let m=0;m<10;m++){let x=l-m*2;p+=`<img src="${x>=2?Ai("heart","#e8322a","#3a1414"):x===1?Ai("heart","#e8322a","#3a1414",!0):Ai("heart","#3a1414","#3a1414")}">`}for(let m=0;m<Math.ceil(c/2);m++)p+=`<img src="${Ai("heart","#f5cf3d","#f5cf3d")}">`;i.hearts.innerHTML=p,i.hearts.classList.toggle("low",l<=6&&l>0)}let h=o.armorPoints();if(r.ap!==h){r.ap=h;let p="";if(h>0)for(let m=0;m<10;m++){let x=h-m*2;p+=`<img src="${x>=2?Ai("armor","#dfe6ee","#3a3a44"):x===1?Ai("armor","#dfe6ee","#3a3a44",!0):Ai("armor","#3a3a44","#3a3a44")}">`}i.armor.innerHTML=p}let d="",f=t.state==="countdown"&&!t.mode.hudInCountdown?null:t.mode.hud?t.mode.hud(e):null;if(f){for(let x of f.lines||[])d+=`<div class="${x.cls||""}">${x.b?`<b>${Ci(x.text)}</b>`:Ci(x.text)}</div>`;f.cur&&(d+=`<div class="cur"><span><img src="${xe(170)}">${o.count(170)}</span><span><img src="${xe(171)}">${o.count(171)}</span><span><img src="${xe(172)}">${o.count(172)}</span></div>`);let p=x=>x.icon==="egg"||x.icon==="eggGone"?`<img src="${fh(x.color)}" class="${x.icon==="eggGone"?"gone":""}">`:x.icon==="flag"||x.icon==="flagGone"?`<img src="${ph(x.color)}" class="${x.icon==="flagGone"?"gone":""}">`:"",m=(f.chips||[]).map(x=>`<div class="eg ${x.dim?"out":""} ${x.mine?"mine":""} ${x.big?"big":""}" style="--tc:${x.color}">${p(x)}<b>${Ci(x.label)}</b></div>`).join("");m!==r.eggs&&(r.eggs=m,i.eggs.innerHTML=m)}else r.eggs&&(r.eggs="",i.eggs.innerHTML="");d!==r.info&&(r.info=d,i.info.innerHTML=d)}title(t,e="",n=2.2,i=""){let r=this.h;r.big.textContent=t,r.sub.textContent=e,r.title.className="title show "+i,clearTimeout(this.titleT),n>0&&(this.titleT=setTimeout(()=>{r.title.className="title"},n*1e3))}clearTitle(){clearTimeout(this.titleT),this.h&&(this.h.title.className="title")}feed(t){let e=document.createElement("div");for(e.className="fe",e.innerHTML=t,this.h.feed.appendChild(e);this.h.feed.children.length>5;)this.h.feed.firstChild.remove();setTimeout(()=>{e.classList.add("fade"),setTimeout(()=>e.remove(),500)},5e3)}name(t,e){return`<b style="color:${t.team>=0?Gt[t.team].hex:t===e?"#7dff6a":"#fff"}">${Ci(t.name)}</b>`}toast(t,e=""){let n=document.createElement("div");for(n.className="toast "+e,n.textContent=t,this.toastEl.appendChild(n);this.toastEl.children.length>3;)this.toastEl.firstChild.remove();setTimeout(()=>{n.classList.add("fade"),setTimeout(()=>n.remove(),400)},2600)}hurtFlash(){let t=this.h.hurt;t.classList.remove("on"),t.offsetWidth,t.classList.add("on")}lockHint(t){this.h&&this.h.lock.classList.toggle("on",t)}spectate(t){this.h&&(this.h.spec.classList.toggle("on",!!t),t&&(this.h.spec.firstElementChild.textContent=k("spectating",{name:t})),this.hudEl.classList.toggle("specmode",!!t))}openPanel(t,e){this.panelEl.className="on "+e,this.panelEl.innerHTML=t,this.panelOpen=e}closePanel(){this.panelEl.className="off",this.panelEl.innerHTML="",this.panelOpen=null}invRow(t){let e=t.inv.slots.map((i,r)=>`<div class="is ${r===t.sel?"on":""}">${i?`<img class="pix" src="${xe(i.id)}"><b>${i.count>1?i.count:""}</b>`:""}</div>`).join(""),n=t.inv.armor.map(i=>`<div class="is ar">${i?`<img class="pix" src="${xe(i)}">`:""}</div>`).join("");return`<div class="invrow"><div class="lbl">${k("inventory")}</div><div class="isrow">${e}</div><div class="isrow armor">${n}</div></div>`}chest(t,e){let n=Array.from({length:12},(i,r)=>{let o=t.items[r];return`<div class="is ${o?"has":""}" ${o?`data-act="take" data-i="${r}"`:""} title="${o?Ci(ne[o.id].name):""}">${o?`<img class="pix" src="${xe(o.id)}"><b>${o.count>1?o.count:""}</b>`:""}</div>`}).join("");this.openPanel(`<div class="box"><div class="head"><h2>${k("chest")}</h2><button class="x" data-act="closePanel">\u2715</button></div>
      <div class="grid c12">${n}</div>
      <button class="btn green small" data-act="takeAll" ${t.items.length?"":"disabled"}>${k("takeAll")}</button>
      ${this.invRow(e)}</div>`,"chest")}shop(t,e){let n=(r,o)=>`<span class="cost ${t.inv.count(r)>=o?"":"no"}"><img src="${xe(r)}">${o}</span>`,i=fl.filter(r=>r.cat===this.shopCat).map(r=>{let o=r.give[0][0]==="wool"?Gt[t.team].wool:r.give[0][0],a=df[r.id]?k(df[r.id]):ne[o].name,l=r.give[0][1];return`<button class="offer ${t.inv.count(r.cost[0])>=r.cost[1]?"":"cant"}" data-act="buy" data-id="${r.id}"><img class="pix" src="${xe(o)}"><span class="nm">${Ci(a)}${l>1&&r.cat!=="armor"?` \xD7${l}`:""}</span>${n(r.cost[0],r.cost[1])}</button>`}).join("");this.openPanel(`<div class="box wide"><div class="head"><h2>${k("shop")}</h2><div class="wallet">${n(170,0)}${n(171,0)}${n(172,0)}</div><button class="x" data-act="closePanel">\u2715</button></div>
      <div class="tabs">${fv.map(([r,o])=>`<button class="${r===this.shopCat?"on":""}" data-act="shopCat" data-c="${r}">${k(o)}</button>`).join("")}</div>
      <div class="offers">${i}</div>${this.invRow(t)}</div>`,"shop"),this.panelEl.querySelectorAll(".wallet .cost").forEach((r,o)=>{r.lastChild.textContent=t.inv.count(170+o),r.classList.remove("no")})}};var pv=(s,t,e)=>Math.max(t,Math.min(e,s)),mh=class{async boot(){await Te.init();try{Te.loadingStart()}catch{}this.save=new Tl(Te),await this.save.load(),this.save.data.name||(this.save.data.name=uh(),this.save.persist()),await this.applyLang(),this.canvas=document.getElementById("view"),this.R=new il(this.canvas),this.atlas=Ih(Ld()),this.R.setAtlas(this.atlas),uf(this.atlas),this.view=new bl(this.R,this.atlas),this.audio=new rl,this.input=new sl(this.canvas,document.getElementById("ui")),this.ui=new Cl(document.getElementById("ui"),this),this.input.wireTouch(this.ui.buildHud(this.input.touch)),this.input.onTouch=()=>this.ui.setTouch(!0),this.input.onUnlock=()=>{this.state==="play"&&!this.ui.panelOpen&&!this.spectating&&this.me&&this.me.alive&&this.pause()};let t=()=>{this.audio.unlock(),!this.audio.musicOn&&this.save.settings.music>0&&this.audio.startMusic("calm")};for(let e of["pointerdown","keydown","touchstart"])addEventListener(e,t,{capture:!0,passive:!0});this.audio.setVolume(this.save.settings.volume,this.save.settings.music);try{this.audio.setMuted(!Te.isAudioEnabled()),Te.onAudioEnabledChange(e=>this.audio.setMuted(!e))}catch{}Te.onPause(()=>{this.hidden=!0,this.state==="play"&&!this.spectating&&this.pause(),this.audio.suspend(!0)}),Te.onResume(()=>{this.hidden=!1,this.audio.suspend(!1)}),this.pc={mx:0,mz:0,yaw:0,pitch:0,jump:!1,crouch:!1,sprint:!1,attack:!1,attackPressed:!1,use:!1,useHeld:!1,sel:null},this.menuMap=$s(7,"meadow"),this.pixel=1,this.ft=[],this.camEye=1.62,this.fov=75,this.orbit=0,this.useT=0,this.lastW=-1,addEventListener("resize",()=>this.resize()),this.applyQuality(),this.toMenu(),this.last=performance.now(),requestAnimationFrame(e=>this.frame(e)),window.__vi=this,this.maps={buildSkyIslands:$s,buildEggIslands:zr,...Object.fromEntries(Object.entries(Ei).map(([e,n])=>[e,(i,r)=>n.build({seed:i,...r})]))}}available(t){return!!Ei[t]||t==="parkour"&&!!Ei.race}async applyLang(){let t=this.save.settings.lang,e=t;if(t==="auto")try{e=await Te.getLanguage()}catch{e="en"}this.lang=Yd(String(e||"en").slice(0,2).toLowerCase()),document.documentElement.lang=this.lang}resize(){let t=innerWidth,e=innerHeight;this.R.resize(t,e,this.pixel),this.view.vmCam.aspect=t/e,this.view.vmCam.updateProjectionMatrix()}applyQuality(){let t=this.save.settings.quality,e=devicePixelRatio||1;this.maxPixel=t==="low"?Math.min(e,.75):t==="high"?Math.min(e,2):Math.min(e,this.input.touch?1.25:1.5),this.pixel=this.maxPixel,this.resize()}adapt(t){if(this.save.settings.quality!=="auto"||this.hidden||(this.ft.push(t),this.ft.length<90))return;let e=this.ft.reduce((n,i)=>n+i,0)/this.ft.length;this.ft.length=0,e>.024&&this.pixel>.6?(this.pixel=Math.max(.6,this.pixel*.85),this.resize()):e<.0135&&this.pixel<this.maxPixel&&(this.pixel=Math.min(this.maxPixel,this.pixel*1.1),this.resize())}setScene(t,e){this.R.setTheme(e),this.R.setWorld(t.world),this.bgMap=t}toMenu(t="menu"){this.endMatch(),this.state="menu",this.lobby=null,this.ui.hud(!1),this.ui.closePanel(),this.bgMap!==this.menuMap&&this.setScene(this.menuMap,"meadow"),this.screens=[],t==="modes"?this.ui.modes():this.ui.menu()}endMatch(){if(this.m)try{Te.gameplayStop()}catch{}this.m=null,this.me=null,this.spectating=null,this.ui.spectate(null),this.view.clear(),this.R.outline.visible=!1,this.R.setCrack(0,0,0,-1),this.input.enable(!1),this.input.exitLock(),this.ui.clearTitle()}startLobby(t,e){this.endMatch(),this.lastMode=t;let n=this.save.data;this.lobby=new Sl(t,{name:n.name,bot:!1,skin:rs[n.skin].seed},e),this.state="lobby",this.ui.hud(!1),this.ui.lobby(this.lobby);let i=this.lobby;setTimeout(()=>{if(this.lobby!==i)return;let r=i.map;i.built=Ei[i.mode.id].build(r),this.setScene(i.built,r.sky||r.theme)},40)}startMatch(){let t=this.lobby;this.lastSolo=0;let e=Ei[t.mode.id].make({save:this.save.data,slots:t.slots});this.beginMatch(t.built,e,t.slots,t.mode,5)}startSolo(t){this.endMatch(),this.lastSolo=t,this.lastMode="parkour";let e=["meadow","meadow","desert","snow","meadow","volcano","desert","snow","meadow","volcano"],n=[0,0,0,0,"dusk","volcano",0,0,"dusk","volcano"],i=e[t-1],r=Ei.parkour.build({level:t,theme:i});this.setScene(r,n[t-1]||i);let o=this.save.data,a=Ei.parkour.make({save:o});this.beginMatch(r,a,[{name:o.name,bot:!1,skin:rs[o.skin].seed}],{teams:0},3)}beginMatch(t,e,n,i,r){let o=new cl(t,e,{seed:Math.random()*1e9|0,countdown:r}),a=n.map((c,h)=>{let d=o.add(new vl({name:c.name,bot:c.bot,skin:c.skin,team:i.teams?Math.floor(h/(i.teamSize||2)):-1,local:!c.bot}));return c.bot&&new yl(d,o,c.skill),d}),l=a[0];l.autoSwing=!0,l.ctl=()=>this.pc,e.setup(a),this.m=o,this.me=l,this.lobby=null,this.awarded=!1,this.lastCd=-1,this.resultT=0,this.pc.yaw=l.yaw,this.pc.pitch=l.pitch,this.view.setMatch(o,l),this.state="play",this.ui.show(null),this.ui.hud(!0),this.ui.sig={},this.input.enable(!0),this.input.requestLock(),o.mode.startTitle&&this.ui.title(o.mode.startTitle(l),o.mode.startSub?o.mode.startSub(l):"",3.5,"team"),this.audio.setMusicStyle("calm");try{Te.gameplayStart()}catch{}}pause(){if(this.state==="play"){this.state="paused",this.input.enable(!1),this.input.exitLock(),this.ui.closePanel(),this.ui.pause();try{Te.gameplayStop()}catch{}}}resume(){if(this.state==="paused"){this.state="play",this.ui.show(null),this.input.enable(!0),this.input.requestLock();try{Te.gameplayStart()}catch{}}}async ad(t){this.input.enable(!1),this.audio.suspend(!0);let e=!1;try{e=t==="reward"?await Te.ads.rewarded():await Te.ads.midgame()}catch{}return this.hidden||this.audio.suspend(!1),e}async act(t,e){switch(this.audio.unlock(),this.audio.click(),t){case"menu":this.ui.menu();break;case"modes":this.state==="results"&&(this.state="busy",await this.ad("mid")),this.toMenu("modes");break;case"mode":e.mode==="parkour"?this.ui.parkourPick():this.startLobby(e.mode);break;case"pkSolo":this.ui.parkourLevels(this.save.data.parkour);break;case"pkBack":this.ui.parkourPick();break;case"pkLevels":if(this.state==="busy")break;this.state==="results"&&(this.state="busy",await this.ad("mid")),this.toMenu("modes"),this.ui.parkourLevels(this.save.data.parkour);break;case"pkRace":this.startLobby("race");break;case"level":this.startSolo(+e.level);break;case"nextLevel":if(this.state==="busy")break;this.state="busy",await this.ad("mid"),this.startSolo(this.lastResult.next);break;case"cancelLobby":this.lobby=null,this.toMenu("modes");break;case"skins":case"settings":case"howto":this.screens.push(this.ui.screen),this.ui[t]();break;case"back":{let n=this.screens.pop();this.state==="paused"?this.ui.pause():n==="modes"?this.ui.modes():this.ui.menu();break}case"set":this.setSetting(e.k,e.v==="true"?!0:e.v==="false"?!1:e.v),this.ui.settings();break;case"equip":this.save.data.skin=+e.id,this.save.persist(),this.ui.skins();break;case"buySkin":{let n=rs[+e.id],i=this.save.data;i.coins>=n.price&&!i.owned.includes(n.id)&&(i.coins-=n.price,i.owned.push(n.id),i.skin=n.id,this.save.persist(),this.audio.levelUp()),this.ui.skins();break}case"again":if(this.state==="busy")break;this.state="busy",await this.ad("mid"),this.lastSolo?this.startSolo(this.lastSolo):this.startLobby(this.lastMode);break;case"double":{await this.ad("reward")&&this.lastResult&&!this.lastResult.doubled&&(this.lastResult.doubled=!0,this.save.data.coins+=this.lastResult.coins,this.lastResult.coins*=2,this.save.persist(),this.audio.levelUp()),this.state==="results"&&this.ui.results(this.lastResult);break}case"spectate":this.startSpectate();break;case"pause":this.state==="play"&&!this.spectating&&this.pause();break;case"resume":this.resume();break;case"leave":this.toMenu();break;case"sel":this.me&&(this.me.sel=+e.i,this.me.mine=null);break;case"closePanel":this.closePanel();break;case"take":this.chest&&this.m.takeFromChest(this.me,this.chest,+e.i)&&this.ui.chest(this.chest,this.me);break;case"takeAll":this.chest&&(this.m.takeAll(this.me,this.chest),this.ui.chest(this.chest,this.me));break;case"shopCat":this.ui.shopCat=e.c,this.ui.shop(this.me,this.m.mode);break;case"buy":this.m&&this.m.mode.buy(this.me,e.id)?(this.audio.pickup(),this.ui.shop(this.me,this.m.mode)):(this.audio.beep(!1),this.ui.toast(k("notEnough"),"bad"));break}}setSetting(t,e){let n=this.save.settings;n[t]=e,(t==="volume"||t==="music")&&(this.audio.setVolume(n.volume,n.music),t==="music"&&e>0&&this.audio.ctx&&!this.audio.musicOn&&this.audio.startMusic("calm"),t==="music"&&e===0&&this.audio.stopMusic()),t==="quality"&&this.applyQuality(),t==="lang"&&this.applyLang().then(()=>{this.ui.settings(),this.relabel()}),this.save.persist()}relabel(){let t=this.ui.h;t.lock.textContent=k("clickToPlay");let e=t.spec.querySelectorAll("button");e[0].textContent=k("playAgain"),e[1].textContent=k("leave")}openChest(t){this.chest=t,this.ui.chest(t,this.me),this.input.enable(!1),this.input.exitLock()}openShop(){this.ui.shop(this.me,this.m.mode),this.input.enable(!1),this.input.exitLock()}closePanel(){this.ui.panelOpen&&(this.ui.closePanel(),this.chest=null,this.state==="play"&&(this.input.enable(!0),this.input.requestLock()))}updatePlayer(t,e){let n=this.me,i=this.pc,r=this.save.settings;if(i.mx=i.mz=0,i.jump=i.crouch=i.sprint=i.attack=i.attackPressed=i.use=i.useHeld=!1,i.sel=null,!n.alive||this.ui.panelOpen)return;let o=.0022*r.sens;n.yaw-=e.lookX*o,n.pitch=pv(n.pitch-e.lookY*o*(r.invert?-1:1),-1.55,1.55),i.yaw=n.yaw,i.pitch=n.pitch,e.sel!=null&&(n.sel=e.sel,n.mine=null),e.wheel&&(n.sel=((n.sel+e.wheel)%9+9)%9,n.mine=null);let a=performance.now()/1e3;e.pressed.has("KeyW")&&(a-this.lastW<.3&&(this.sprintLatch=!0),this.lastW=a),e.my<=.1&&(this.sprintLatch=!1);let l=Math.sin(n.yaw),c=Math.cos(n.yaw);i.mx=-l*e.my+c*e.mx,i.mz=-c*e.my-l*e.mx,i.jump=e.jump,i.crouch=e.crouch,i.sprint=(e.sprint||this.sprintLatch)&&e.my>.1,i.attack=e.attack,i.attackPressed=e.attackPressed,i.use=e.use,i.useHeld=e.useHeld;let h=n.held();e.useHeld&&h&&h.kind==="block"?(this.useT+=t,this.useT>.24&&(this.useT=0,i.use=!0)):this.useT=0,e.use&&(this.useT=0)}startSpectate(){this.m&&(this.state="play",this.ui.show(null),this.ui.hud(!0),this.pickSpecTarget(),this.input.enable(!1),this.input.exitLock())}pickSpecTarget(){let t=this.m.actors.filter(e=>e.alive&&e!==this.me);this.spectating=t.sort((e,n)=>n.kills-e.kills)[0]||null,this.view.thirdPerson=!1,this.ui.spectate(this.spectating?this.spectating.name:null)}showResults(){let t=this.m,e=this.me;if(!t)return;if(!this.awarded){this.awarded=!0;let i=t.mode.result(e),r=i.win,o=i.rank,a=10+e.kills*5+(i.coins||0)+(r?50:o<=3?15:0),l=25+e.kills*15+(i.xp||0)+(r?60:0),c=this.save.data;c.coins+=a,c.stats.games++,c.stats.kills+=e.kills,c.stats.deaths+=e.deaths,c.stats.eggs+=e.eggs||0,r&&c.stats.wins++,i.save&&i.save(c);let h=this.save.addXp(l);if(this.save.persist(),h&&(this.audio.levelUp(),this.ui.toast(k("levelUp"),"gold")),r)try{Te.happytime()}catch{}this.lastResult={win:r,coins:a,xp:l,kills:e.kills,sub:i.sub,title:i.title,stat:i.stat,stars:i.stars,time:i.time,next:i.next,solo:!!this.lastSolo}}let n=this.lastResult;n.canDouble=(()=>{try{return Te.ads.canReward()}catch{return!1}})(),n.canSpectate=!t.over&&t.actors.some(i=>i.alive&&i!==e),this.state="results",this.spectating=null,this.ui.spectate(null),this.ui.closePanel(),this.ui.hud(!1),this.ui.clearTitle(),this.input.enable(!1),this.input.exitLock(),this.ui.results(n);try{Te.gameplayStop()}catch{}}events(){let t=this.m,e=this.me,n=this.audio,i=this.view,r=this.ui,o=a=>a&&a.pos;for(let a of t.events)switch(a.t){case"swing":a.a!==e&&n.swing(o(a.a));break;case"dig":n.block(Yt[a.id].sound,"dig",{x:a.x+.5,y:a.y+.5,z:a.z+.5});break;case"break":n.block(Yt[a.id].sound,"break",{x:a.x+.5,y:a.y+.5,z:a.z+.5}),i.burst(a.x,a.y,a.z,a.id);break;case"place":n.block(Yt[a.id].sound,"place",{x:a.x+.5,y:a.y+.5,z:a.z+.5});break;case"hurt":a.a===e?(n.hurt(!0),r.hurtFlash(),this.shake=.25):(n.hit(o(a.a),a.crit),a.crit&&i.sparks(a.a.pos.x,a.a.pos.y+1.4,a.a.pos.z,16773280,10),a.by===e&&(this.hitmark=.15));break;case"kill":{let l=a.a,c=a.by,h=a.cause==="void"?"fell":a.cause==="border"?"border":"diedMsg";r.feed(c?`${r.name(c,e)} <img class="pix" src="${xe(101)}"> ${r.name(l,e)}${a.cause==="void"?' <span class="void">\u25BC</span>':""}`:`${r.name(l,e)} <span>${k(h)}</span>`),c===e&&(n.kill(),r.toast(k("kill1"),"kill")),l===e?(n.death(),this.deathT=0,this.deathYaw=e.yaw):Math.hypot(l.pos.x-e.pos.x,l.pos.z-e.pos.z)<30&&n.hurt(!1),l===this.spectating&&setTimeout(()=>this.spectating&&!this.spectating.alive&&this.pickSpecTarget(),1200);break}case"eat":a.a===e&&n.eat();break;case"chest":a.a===e&&this.openChest(a.chest);break;case"npc":a.a===e&&this.openShop();break;case"throw":n.throwS();break;case"warp":n.warp();break;case"pickup":a.a===e&&n.pickup();break;case"refill":r.toast(k("refilled"),"gold"),n.beep(!0);break;case"border":r.toast(k("borderMsg"),"bad"),n.beep(!1),n.setMusicStyle("tense");break;case"egg":{n.egg(t.mode.teams[a.team].egg),a.team===e.team?r.title(k("yourEgg"),k("noRespawn"),3.5,"bad"):r.toast(k("eggGone",{team:k("team_"+a.team)}),"bad");break}case"notice":{a.big?r.title(a.text,"",3,a.team===e.team?"go":"bad"):r.toast(a.text,a.cls||""),a.sound==="win"?a.team===e.team?n.win():n.beep(!1):a.sound==="egg"?n.egg(e.pos):a.sound&&n.beep(a.sound==="hi");break}case"trap":n.trap(),i.sparks(a.x+.5,a.y+1.2,a.z+.5,16734768,30),e.role==="runner"&&Math.abs(a.x-e.pos.x)<12&&(this.shake=.18);break;case"cpback":n.beep(!1);break;case"voidrise":r.toast(k("voidRise"),"bad"),n.beep(!1);break;case"sudden":r.toast(k("sudden"),"bad"),n.setMusicStyle("tense");break;case"teamout":r.feed(`<b style="color:${Gt[a.team].hex}">${k("teamOut",{team:k("team_"+a.team)})}</b>`);break;case"respawning":a.a===e&&r.title(k("died"),k("respawnIn",{n:5}),0,"bad");break;case"respawn":a.a===e&&(r.clearTitle(),e.pitch=-.1);break;case"start":r.title(k("go"),"",1.2,"go"),n.beep(!0);break;case"over":{let l=t.mode.result(e).win;l&&n.win();let c=l?k("victory"):t.mode.winnerText?t.mode.winnerText(a.winner):k("gameOver");this.state==="play"&&r.title(c,"",3,l?"go":""),this.resultT=3;break}}t.events.length=0}steps(){let t=this.m;for(let e of t.actors){if(!e.alive||!e.onGround||e.moveAmt<1||e.crouch)continue;let n=Math.floor(e.walkPhase/Math.PI);if(e._st===n)continue;e._st=n;let i=t.world.get(Math.floor(e.pos.x),Math.floor(e.pos.y-.1),Math.floor(e.pos.z));i&&Yt[i]&&this.audio.block(Yt[i].sound,"step",e.pos)}}camera(t,e){if(this.camHold)return;let n=this.R.camera,i=this.save.settings,r=i.fov;if(this.m&&this.me&&this.state!=="lobby"){let o=this.me,a=this.m,l=this.spectating;if(l&&l.alive){let c=l.yaw,h=l.pos.x,d=l.pos.y+1.6,f=l.pos.z,p=Math.sin(c)*4.2,m=1.4,x=Math.cos(c)*4.2,g=Math.hypot(p,m,x),u=a.world.raycast(h,d,f,p/g,m/g,x/g,g,T=>T&&Yt[T].solid),v=u?Math.max(.15,(u.t-.3)/g):1,_=h+p*v,M=d+m*v,A=f+x*v,b=u?1:Math.min(1,t*5);n.position.x+=(_-n.position.x)*b,n.position.y+=(M-n.position.y)*b,n.position.z+=(A-n.position.z)*b,n.lookAt(l.pos.x,l.pos.y+1.4,l.pos.z)}else if(o.alive||this.deathT<.01){this.camEye+=(oi(o)-this.camEye)*Math.min(1,t*14);let c=0;i.viewBob&&o.onGround&&(c=Math.abs(Math.sin(o.walkPhase))*.045*Math.min(1,o.moveAmt/4.3)),n.position.set(o.pos.x,o.pos.y+this.camEye+c,o.pos.z),this.shake=Math.max(0,(this.shake||0)-t),n.rotation.set(o.pitch,o.yaw,this.shake*Math.sin(a.time*60)*.06,"YXZ"),o.sprint&&o.moveAmt>4.5&&(r+=8)}else this.deathT+=t,n.position.y+=(o.pos.y+.4-n.position.y)*Math.min(1,t*3),n.rotation.set(Math.min(-.2,-this.deathT*.3),this.deathYaw,Math.min(.5,this.deathT),"YXZ")}else{let o=this.bgMap||this.menuMap;this.orbit+=t*.05;let a=(o.radius||60)*(o===this.menuMap?1.05:1.15);n.position.set(Math.cos(this.orbit)*a,o.top+a*.42,Math.sin(this.orbit)*a),n.lookAt(0,o.top-4,0)}this.fov+=(r-this.fov)*Math.min(1,t*8),Math.abs(n.fov-this.fov)>.05&&(n.fov=this.fov,n.updateProjectionMatrix())}overlays(){let t=this.R,e=this.me,n=this.m,i=!1;if(n&&e&&e.alive&&!this.spectating&&this.state==="play"&&!this.ui.panelOpen){let r=n.lookHit(e);r&&!n.lookActor(e)&&(i=!0,t.outline.position.set(r.x+.5,r.y+.5,r.z+.5),e.mine&&e.mine.x===r.x&&e.mine.y===r.y&&e.mine.z===r.z?t.setCrack(r.x,r.y,r.z,Math.floor(e.mine.p/e.mine.need*4)):t.setCrack(0,0,0,-1))}t.outline.visible=i,i||t.setCrack(0,0,0,-1)}frame(t){requestAnimationFrame(o=>this.frame(o));let e=Math.min(.05,(t-this.last)/1e3);this.last=t;let n=this.input.sample(),i=this.m,r=this.me;if(this.lobby&&this.state==="lobby"){if(this.lobby.update(e),this.ui.updateLobby(this.lobby),this.lobby.state==="countdown"&&this.lobby.built){let o=Math.ceil(this.lobby.cd);o!==this.lobbyBeep&&(this.lobbyBeep=o,this.audio.beep(!1))}this.lobby.state==="go"&&this.lobby.built&&this.startMatch()}if(i&&(this.state==="play"||this.state==="results"||this.state==="busy")){if(this.state==="play"&&!this.spectating?(this.updatePlayer(e,n),this.ui.panelOpen&&(n.pressed.has("Escape")||n.pressed.has("KeyE"))&&this.closePanel(),this.ui.panelOpen&&(!r.alive||this.chest&&Math.hypot(this.chest.x+.5-r.pos.x,this.chest.z+.5-r.pos.z)>6)&&this.closePanel()):this.updatePlayer(e,{lookX:0,lookY:0,mx:0,my:0,pressed:new Set}),this.state==="play"&&n.pressed.has("Escape")&&!this.input.locked&&!this.ui.panelOpen&&r.alive&&this.pause(),i.update(e),i.state==="countdown"){let o=Math.ceil(i.countdown);o!==this.lastCd&&o>0&&(this.lastCd=o,this.audio.beep(!1),this.state==="play"&&this.ui.title(String(o),"",.9,"count"))}if(this.events(),this.steps(),!r.alive&&r.respawnT>0&&this.state==="play"){let o=Math.ceil(r.respawnT);o!==this.respN&&(this.respN=o,this.ui.title(k("died"),k("respawnIn",{n:o}),0,"bad"))}!r.alive&&r.eliminated&&!this.awarded&&this.state==="play"&&(this.elimT=(this.elimT||0)+e,this.elimT>2&&(this.elimT=0,this.showResults())),i.over&&this.resultT>0&&(this.resultT-=e,this.resultT<=0&&this.state==="play"&&this.showResults())}if(this.camera(e,n),this.audio.listener=this.R.camera.position,i&&r&&(this.view.update(e,this.R.camera),this.overlays(),this.state==="play")){this.ui.updateHud(i,r,this.view);let o=!this.input.touch&&!this.input.locked&&!this.ui.panelOpen&&!this.spectating&&r.alive;this.ui.lockHint(o),this.hitmark>0&&(this.hitmark-=e,this.ui.h.xhair.classList.toggle("hit",this.hitmark>0))}if(this.R.flush(this.state==="play"?4:16),this.R.render(e),i&&r&&r.alive&&!this.spectating&&this.state==="play"){this.view.updateViewmodel(e,r,n);let o=this.R.renderer;o.autoClear=!1,o.clearDepth(),o.render(this.view.vmScene,this.view.vmCam),o.autoClear=!0}if(this.adapt(e),!this.firstFramed){this.firstFramed=!0;try{Te.firstFrame(),Te.gameReady()}catch{}}}};new mh().boot();})();
